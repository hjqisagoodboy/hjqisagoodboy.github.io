package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.TransformerBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 变压器（LV→MV / MV→HV）。
 *
 * <p>它是一块「有的面通电、有的面不通电」的方块：
 * <ul>
 *   <li>正面（{@code FACING} 那一面，放下时朝着玩家）：输出面，LV→MV 送 320 FE/t、MV→HV 送 2,560 FE/t；</li>
 *   <li>背面（正面的反方向）：输入面，LV→MV 收 80 FE/t、MV→HV 收 320 FE/t；</li>
 *   <li>其余四面：不接电，线缆也不会连上来。</li>
 * </ul>
 *
 * <p>具体收多少、送多少写在 {@link TransformerTier} 里，两种变压器共用同一个方块实体和同一套代码。
 *
 * <p>本轮不做真正的电压转换，只是「进缓存 → 出缓存」的透传：
 * 发电机从背面灌进来，MV 线缆从正面把电拉走，中间那个 4,000 FE 的缓存就是全部的「变换」。
 * 这样玩家就能用 MV 线缆去带 MV 机器，而电是从 LV 侧过来的。
 */
public class TransformerBlock extends BaseEntityBlock {

    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

    private final TransformerTier tier;

    /** 默认造 LV→MV（老代码和 JSON 都还用这个）。 */
    public TransformerBlock(Properties properties) {
        this(properties, TransformerTier.LV_MV);
    }

    public TransformerBlock(Properties properties, TransformerTier tier) {
        super(properties);
        this.tier = tier;
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    /** 这台变压器是哪种等级。 */
    public TransformerTier tier() {
        return this.tier;
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(properties -> new TransformerBlock(properties, this.tier));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    /** 正面朝着玩家（和熔炉一样），所以正面就是「看得见的那一面」。 */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new TransformerBlockEntity(pos, state);
    }

    /** 物品栏提示：等级、输入/输出上限、哪一面是输入哪一面是输出。 */
    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.tier", this.tier.label())
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.transformer.input", this.tier.inputLimit())
                .withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.transformer.output", this.tier.outputLimit())
                .withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable(this.tier.descriptionKey()).withStyle(ChatFormatting.GRAY));
    }
}
