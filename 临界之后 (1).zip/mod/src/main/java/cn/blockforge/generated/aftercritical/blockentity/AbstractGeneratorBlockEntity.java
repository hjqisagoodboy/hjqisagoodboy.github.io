package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.energy.BufferedEnergyStorage;
import cn.blockforge.generated.aftercritical.energy.EnergyTransfer;
import cn.blockforge.generated.aftercritical.itemhandler.ContainerItemHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.items.IItemHandler;

/**
 * 发电机共用的骨架：一个燃料槽 + 一个内部电缓存 + 每 tick 往邻居送电。
 *
 * <p>工作流程很简单：
 * <ol>
 *   <li>燃料槽里没东西、也没在烧 → 看看槽里的东西能不能烧，能就吃掉 1 个、记下要烧多少 tick；</li>
 *   <li>正在烧 → 每 tick 往内部缓存里加「输出功率」那么多 FE，燃烧进度 +1；</li>
 *   <li>缓存里有电 → 每 tick 往六个方向的邻居送，最多送「输出功率」那么多；</li>
 *   <li>缓存装不下这一 tick 的电 → 暂停燃烧（不浪费燃料），GUI 显示「电力已满」。</li>
 * </ol>
 *
 * <p>子类只需要回答两件事：输出多少 FE/t，以及什么东西能烧多久。
 */
public abstract class AbstractGeneratorBlockEntity extends BlockEntity
        implements Container, MenuProvider, EnergyMachineHost, TickableBlockEntity {

    /** 燃料槽。 */
    public static final int SLOT_FUEL = 0;
    public static final int SLOT_COUNT = 1;

    /** 发电机内部缓存：够装一整个煤的发电量，免得白烧。 */
    public static final int ENERGY_CAPACITY = 100_000;

    private final BufferedEnergyStorage energy;
    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);
    private final int outputPerTick;

    /**
     * 给物品管道用的物品接口：只能往燃料槽塞能烧的东西，抽不出来
     * （免得管道把燃料又搬走）。
     */
    private final IItemHandler itemHandler = new ContainerItemHandler(this,
            slot -> slot == SLOT_FUEL,
            slot -> false);

    /** 还要烧多少 tick；0 表示没在烧。 */
    private int burnTime;
    /** 当前这份燃料一共要烧多少 tick。 */
    private int burnTimeTotal;
    /** 状态：待机 / 正在烧 / 缓存满了。 */
    private int status = STATUS_IDLE;

    /** 成就「第一度电」只记一次，别每 tick 都去附近找玩家。 */
    private boolean powerMilestoneFired;

    protected AbstractGeneratorBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state,
                                           int outputPerTick) {
        super(type, pos, state);
        this.outputPerTick = outputPerTick;
        this.energy = new BufferedEnergyStorage(ENERGY_CAPACITY, 0, outputPerTick, this::setChanged);
    }

    /** 这个物品能烧多少 tick；返回 0 表示不是燃料。 */
    protected abstract int burnTicks(ItemStack stack);

    /** 对外暴露的 FE 接口，供能力注册用（别的模组的线缆能从这里抽电）。 */
    public IEnergyStorage getEnergyStorage() {
        return this.energy;
    }

    /** 对外暴露的物品接口：物品管道能自动给发电机喂燃料。 */
    public IItemHandler getItemHandler() {
        return this.itemHandler;
    }

    /** 额定输出功率，FE/t：燃烧发电机 80，燃料棒发电机 320。 */
    public int getOutputPerTick() {
        return this.outputPerTick;
    }

    /** 当前这份燃料还剩多少 tick（GUI 用不到，测试时有用）。 */
    public int getBurnTime() {
        return this.burnTime;
    }

    public int getBurnTimeTotal() {
        return this.burnTimeTotal;
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }

        boolean bufferFull = false;
        if (this.burnTime <= 0) {
            startBurning();
        }

        boolean burning = this.burnTime > 0;
        if (burning) {
            if (this.energy.getFreeSpace() >= this.outputPerTick) {
                this.energy.grow(this.outputPerTick);
                this.burnTime--;
                if (this.burnTime <= 0) {
                    this.burnTime = 0;
                    this.burnTimeTotal = 0;
                }
                if (!this.powerMilestoneFired) {
                    this.powerMilestoneFired = true;
                    ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 32.0,
                            ModAdvancementTriggers.FIRST_POWER);
                }
                setChanged();
            } else {
                bufferFull = true;
            }
        }

        EnergyTransfer.push(this.level, this.worldPosition, this.energy, this.outputPerTick);

        int newStatus;
        if (bufferFull) {
            newStatus = STATUS_FULL;
        } else if (burning) {
            newStatus = STATUS_RUNNING;
        } else {
            newStatus = STATUS_IDLE;
        }
        if (this.status != newStatus) {
            this.status = newStatus;
            setChanged();
        }
    }

    /** 燃料槽里还有燃料、而且缓存装得下 → 吃掉一个开始烧。 */
    private void startBurning() {
        ItemStack fuel = this.items.get(SLOT_FUEL);
        if (fuel.isEmpty() || this.energy.getFreeSpace() < this.outputPerTick) {
            return;
        }
        int ticks = burnTicks(fuel);
        if (ticks <= 0) {
            return;
        }
        fuel.shrink(1);
        if (fuel.isEmpty()) {
            this.items.set(SLOT_FUEL, ItemStack.EMPTY);
        }
        this.burnTimeTotal = ticks;
        this.burnTime = ticks;
        setChanged();
    }

    // ------------------------------------------------------------------
    // GUI 数据
    // ------------------------------------------------------------------

    @Override
    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    @Override
    public int getEnergyCapacity() {
        return this.energy.getMaxEnergyStored();
    }

    @Override
    public int getStatus() {
        return this.status;
    }

    /** 已经烧了多久（GUI 的进度条）。 */
    @Override
    public int getProgress() {
        return this.burnTimeTotal <= 0 ? 0 : this.burnTimeTotal - this.burnTime;
    }

    @Override
    public int getMaxProgress() {
        return this.burnTimeTotal;
    }

    // ------------------------------------------------------------------
    // 物品槽
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return this.items.size();
    }

    @Override
    public boolean isEmpty() {
        return this.items.get(SLOT_FUEL).isEmpty();
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        stack.limitSize(getMaxStackSize(stack));
        setChanged();
    }

    /** 只收「能烧的东西」，别的物品塞不进来。 */
    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot == SLOT_FUEL && burnTicks(stack) > 0;
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
        tag.putInt("BurnTime", this.burnTime);
        tag.putInt("BurnTimeTotal", this.burnTimeTotal);
        tag.putInt("Status", this.status);
        ContainerHelper.saveAllItems(tag, this.items, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
        this.burnTime = tag.getInt("BurnTime");
        this.burnTimeTotal = tag.getInt("BurnTimeTotal");
        this.status = tag.getInt("Status");
        ContainerHelper.loadAllItems(tag, this.items, registries);
    }
}
