package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.menu.GeneratorMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 燃料棒发电机：只吃煤燃料棒，一根烧 5 分钟（6000 tick），输出 320 FE/t。
 *
 * <p>6000 tick × 320 FE/t = 1,920,000 FE，正好对上定稿 v4 的总量。
 */
public class FuelRodGeneratorBlockEntity extends AbstractGeneratorBlockEntity {

    /** 输出功率：320 FE/t。 */
    public static final int OUTPUT_PER_TICK = 320;

    /** 一根煤燃料棒烧多久。 */
    public static final int COAL_FUEL_ROD_TICKS = 6_000;

    public FuelRodGeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.FUEL_ROD_GENERATOR.get(), pos, state, OUTPUT_PER_TICK);
    }

    @Override
    protected int burnTicks(ItemStack stack) {
        return stack.is(ModItems.COAL_FUEL_ROD.get()) ? COAL_FUEL_ROD_TICKS : 0;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.fuel_rod_generator");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new GeneratorMenu(ModMenus.FUEL_ROD_GENERATOR.get(), containerId, playerInventory, this, this);
    }
}
