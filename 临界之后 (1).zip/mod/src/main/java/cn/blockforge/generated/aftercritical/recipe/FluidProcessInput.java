package cn.blockforge.generated.aftercritical.recipe;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeInput;
import net.neoforged.neoforge.fluids.FluidStack;

import java.util.List;

/**
 * 流体机器配方匹配时用的「原料快照」：几个物品槽 + 几个输入罐。
 *
 * <p>矿机那三台只要一个 {@link ItemStack} 就够了（原版有 {@code SingleRecipeInput}），
 * 这里要同时带上物品和流体，所以自己做一个。
 */
public record FluidProcessInput(List<ItemStack> items, List<FluidStack> fluids) implements RecipeInput {

    public FluidProcessInput {
        items = List.copyOf(items);
        fluids = List.copyOf(fluids);
    }

    @Override
    public ItemStack getItem(int index) {
        return this.items.get(index);
    }

    @Override
    public int size() {
        return this.items.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        for (FluidStack stack : this.fluids) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }
}
