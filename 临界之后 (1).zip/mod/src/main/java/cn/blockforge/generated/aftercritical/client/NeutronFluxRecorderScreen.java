package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.blockentity.ReactorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.menu.NeutronFluxRecorderMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;

/**
 * 中子通量记录仪的界面：四行读数，没有槽位。
 *
 * <p>第一行是「连上没有」，第二行是连着哪种堆，第三行 k_eff，第四行中子通量。
 * 反应堆在 24 格内就能连上，不需要真的贴着放。
 */
public class NeutronFluxRecorderScreen extends StatPanelScreen<NeutronFluxRecorderMenu> {

    public NeutronFluxRecorderScreen(NeutronFluxRecorderMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected List<Line> statLines() {
        List<Line> lines = new ArrayList<>(NeutronFluxRecorderMenu.STAT_LINES);

        lines.add(new Line(Component.translatable(this.menu.isLinked()
                ? "gui.aftercritical.recorder.linked"
                : "gui.aftercritical.recorder.not_linked"),
                this.menu.isLinked() ? TEXT_OK : TEXT_BAD));

        lines.add(new Line(Component.translatable(this.menu.isCriticalKind()
                ? "gui.aftercritical.recorder.kind_critical"
                : "gui.aftercritical.recorder.kind_subcritical"), TEXT_DARK));

        lines.add(new Line(Component.translatable("gui.aftercritical.reactor.k_eff",
                ReactorScreen.formatK(this.menu.kScaled()), ReactorScreen.statusName(this.menu.status())),
                kColor()));

        lines.add(new Line(Component.translatable("gui.aftercritical.reactor.flux",
                ReactorScreen.formatFlux(this.menu.flux())), TEXT_DARK));

        return lines;
    }

    private int kColor() {
        double k = this.menu.kScaled() / (double) ReactorControllerBlockEntity.KEFF_SYNC_SCALE;
        if (k <= 0.0) {
            return TEXT_GRAY;
        }
        if (k > ReactorControllerBlockEntity.MELTDOWN_K) {
            return TEXT_BAD;
        }
        if (k > 1.0) {
            return TEXT_WARN;
        }
        return TEXT_OK;
    }
}
