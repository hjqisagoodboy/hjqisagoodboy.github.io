package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.ControlRodPortBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

/**
 * 控制棒端口：插【控制棒组件】的通道。
 *
 * <p>手上拿着控制棒右键就插进去，空手右键拔出来。堆体里至少要有 4 个端口、
 * 而且 4 根控制棒都插上，压水堆才肯启动；插得越深，功率被压得越低。
 */
public class ControlRodPortBlock extends TickablePartBlock {

    public static final String DESCRIPTION = "block.aftercritical.control_rod_port.desc";

    public ControlRodPortBlock(Properties properties) {
        super(properties, DESCRIPTION);
    }

    @Override
    protected MapCodec<? extends net.minecraft.world.level.block.BaseEntityBlock> codec() {
        return simpleCodec(ControlRodPortBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ControlRodPortBlockEntity(pos, state);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof ControlRodPortBlockEntity port) {
            port.insertFromHand(player, stack);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof ControlRodPortBlockEntity port) {
            port.takeOut(player);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
