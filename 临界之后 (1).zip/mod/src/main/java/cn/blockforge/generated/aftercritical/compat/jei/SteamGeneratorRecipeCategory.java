package cn.blockforge.generated.aftercritical.compat.jei;

import cn.blockforge.generated.aftercritical.registry.ModFluids;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.widgets.IRecipeExtrasBuilder;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.material.Fluid;

/**
 * 汽轮发电机在 JEI 里的样子。
 *
 * <p>汽轮发电机不是「吃配方」的机器，它是把蒸汽直接换成电和乏蒸汽，
 * 所以这里不挂 Minecraft 的配方，而是给 JEI 塞一条固定的展示条目：
 * 左边 1,000 mB/s 蒸汽，右边 1,000 mB/s 乏蒸汽，底下一行写发电 2,000 FE/t。
 *
 * <p>这样玩家在 JEI 里对着汽轮发电机按 U，就能看到它「吃什么、吐什么、发多少电」。
 */
public class SteamGeneratorRecipeCategory implements IRecipeCategory<SteamGeneratorRecipeCategory.Entry> {

    /** JEI 里展示的一条固定条目。 */
    public record Entry(int steamPerSecond, int exhaustPerSecond, int fePerTick) {
    }

    private static final int WIDTH = 150;
    private static final int HEIGHT = 74;
    private static final int FLUID_SLOT = 16;

    private final RecipeType<Entry> recipeType;
    private final Component title;
    private final IDrawable icon;

    public SteamGeneratorRecipeCategory(IGuiHelper guiHelper, RecipeType<Entry> recipeType,
                                        Component title, ItemLike machine) {
        this.recipeType = recipeType;
        this.title = title;
        this.icon = guiHelper.createDrawableItemLike(machine);
    }

    @Override
    public RecipeType<Entry> getRecipeType() {
        return this.recipeType;
    }

    @Override
    public Component getTitle() {
        return this.title;
    }

    @Override
    public IDrawable getIcon() {
        return this.icon;
    }

    @Override
    public int getWidth() {
        return WIDTH;
    }

    @Override
    public int getHeight() {
        return HEIGHT;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, Entry recipe, IFocusGroup focuses) {
        Fluid steam = ModFluids.STEAM.source.get();
        Fluid exhaust = ModFluids.EXHAUST_STEAM.source.get();
        builder.addSlot(RecipeIngredientRole.INPUT, 8, 10)
                .setFluidRenderer(recipe.steamPerSecond(), true, FLUID_SLOT, FLUID_SLOT)
                .addFluidStack(steam, recipe.steamPerSecond());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 104, 10)
                .setFluidRenderer(recipe.exhaustPerSecond(), true, FLUID_SLOT, FLUID_SLOT)
                .addFluidStack(exhaust, recipe.exhaustPerSecond());
    }

    @Override
    public void createRecipeExtras(IRecipeExtrasBuilder builder, Entry recipe, IFocusGroup focuses) {
        builder.addRecipeArrow().setPosition(46, 10);
        builder.addText(Component.translatable("jei.aftercritical.steam_generator.line",
                recipe.steamPerSecond(), recipe.exhaustPerSecond(), recipe.fePerTick()), 8, 38);
        builder.addText(Component.translatable("jei.aftercritical.steam_generator.note"), 8, 52);
    }
}
