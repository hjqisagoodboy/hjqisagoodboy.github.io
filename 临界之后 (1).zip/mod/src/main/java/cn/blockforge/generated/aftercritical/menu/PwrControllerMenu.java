package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.PwrControllerBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.material.Fluids;

import javax.annotation.Nullable;

/**
 * 压水堆控制器的界面：没有物品槽（燃料、控制棒都插在堆体里的端口上），
 * 上半块是控制棒插入深度滑块，右边是水和蒸汽两根长条，底下一串热工读数。
 *
 * <p>按钮编号和阶段 3 的反应堆保持一致：0 = 少 5%，1 = 多 5%，100+ = 直接设成这个深度。
 */
public class PwrControllerMenu extends AbstractMachineMenu implements FluidBarHost {

    public static final int BUTTON_ROD_LESS = 0;
    public static final int BUTTON_ROD_MORE = 1;
    public static final int BUTTON_ROD_ABSOLUTE = 100;

    /** 两根长条的位置。 */
    public static final int BAR_X = 168;
    public static final int BAR_TOP = 30;
    public static final int BAR_STEP = 22;
    public static final int BAR_W = 12;
    public static final int BAR_H = 18;

    /** 底部读数行数。 */
    public static final int STAT_LINES = 7;

    private static final int DATA_STATUS = 0;
    private static final int DATA_FORMED = 1;
    private static final int DATA_SHELL = 2;
    private static final int DATA_LEAD = 3;
    private static final int DATA_CONCRETE = 4;
    private static final int DATA_GLASS = 5;
    private static final int DATA_FUEL_PORTS = 6;
    private static final int DATA_ROD_PORTS = 7;
    private static final int DATA_COOLANT_PORTS = 8;
    private static final int DATA_FUEL = 9;
    private static final int DATA_RODS = 10;
    private static final int DATA_DEPTH = 11;
    private static final int DATA_TEMP = 12;
    private static final int DATA_THERMAL = 13;
    private static final int DATA_STEAM_RATE = 14;
    private static final int DATA_WATER = 15;
    private static final int DATA_STEAM = 16;
    private static final int DATA_MELTED = 17;
    private static final int DATA_COUNT = 18;

    @Nullable
    private final PwrControllerBlockEntity controller;

    private final int[] values = new int[DATA_COUNT];

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return index >= 0 && index < DATA_COUNT ? values[index] : 0;
        }

        @Override
        public void set(int index, int value) {
            if (index >= 0 && index < DATA_COUNT) {
                values[index] = value;
            }
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    /** 服务端用。 */
    public PwrControllerMenu(int containerId, Inventory playerInventory, PwrControllerBlockEntity controller) {
        this(containerId, playerInventory, (BlockEntity) controller);
    }

    /** 客户端用。 */
    public PwrControllerMenu(int containerId, Inventory playerInventory, @Nullable BlockEntity blockEntity) {
        super(ModMenus.PWR_CONTROLLER.get(), containerId, playerInventory, 0, null, 2);
        this.controller = blockEntity instanceof PwrControllerBlockEntity be ? be : null;
        this.addPlayerInventory(playerInventory);
        this.addDataSlots(this.data);
    }

    public static PwrControllerMenu fromNetwork(int containerId, Inventory playerInventory,
                                                RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        return new PwrControllerMenu(containerId, playerInventory,
                playerInventory.player.level().getBlockEntity(pos));
    }

    @Override
    public void broadcastChanges() {
        if (this.controller != null) {
            this.values[DATA_STATUS] = this.controller.statusCode();
            this.values[DATA_FORMED] = this.controller.isFormed() ? 1 : 0;
            this.values[DATA_SHELL] = this.controller.shellCount();
            this.values[DATA_LEAD] = this.controller.leadCount();
            this.values[DATA_CONCRETE] = this.controller.concreteCount();
            this.values[DATA_GLASS] = this.controller.glassCount();
            this.values[DATA_FUEL_PORTS] = this.controller.fuelPortCount();
            this.values[DATA_ROD_PORTS] = this.controller.rodPortCount();
            this.values[DATA_COOLANT_PORTS] = this.controller.coolantPortCount();
            this.values[DATA_FUEL] = this.controller.fuelCount();
            this.values[DATA_RODS] = this.controller.rodCount();
            this.values[DATA_DEPTH] = this.controller.rodDepth();
            this.values[DATA_TEMP] = this.controller.temperatureInt();
            this.values[DATA_THERMAL] = this.controller.thermalPower();
            this.values[DATA_STEAM_RATE] = this.controller.steamPerTick();
            this.values[DATA_WATER] = this.controller.waterAmount();
            this.values[DATA_STEAM] = this.controller.steamAmount();
            this.values[DATA_MELTED] = this.controller.meltedCount();
        }
        super.broadcastChanges();
    }

    /** 没有机器物品槽，Shift 点击不搬东西。 */
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (this.controller == null) {
            return false;
        }
        if (id == BUTTON_ROD_LESS || id == BUTTON_ROD_MORE) {
            int step = id == BUTTON_ROD_MORE ? 5 : -5;
            this.controller.setRodDepth(this.controller.rodDepth() + step);
        } else if (id >= BUTTON_ROD_ABSOLUTE) {
            this.controller.setRodDepth(id - BUTTON_ROD_ABSOLUTE);
        } else {
            return false;
        }
        this.broadcastChanges();
        return true;
    }

    // ------------------------------------------------------------------
    // 读数（界面直接调）
    // ------------------------------------------------------------------

    public int status() {
        return this.values[DATA_STATUS];
    }

    public boolean isFormed() {
        return this.values[DATA_FORMED] != 0;
    }

    public int shell() {
        return this.values[DATA_SHELL];
    }

    public int lead() {
        return this.values[DATA_LEAD];
    }

    public int concrete() {
        return this.values[DATA_CONCRETE];
    }

    public int glass() {
        return this.values[DATA_GLASS];
    }

    public int fuelPorts() {
        return this.values[DATA_FUEL_PORTS];
    }

    public int rodPorts() {
        return this.values[DATA_ROD_PORTS];
    }

    public int coolantPorts() {
        return this.values[DATA_COOLANT_PORTS];
    }

    public int fuel() {
        return this.values[DATA_FUEL];
    }

    public int rods() {
        return this.values[DATA_RODS];
    }

    public int rodDepth() {
        return this.values[DATA_DEPTH];
    }

    public int temperature() {
        return this.values[DATA_TEMP];
    }

    public int thermalPower() {
        return this.values[DATA_THERMAL];
    }

    public int steamPerTick() {
        return this.values[DATA_STEAM_RATE];
    }

    public int melted() {
        return this.values[DATA_MELTED];
    }

    // ------------------------------------------------------------------
    // FluidBarHost：水（进）+ 蒸汽（出）
    // ------------------------------------------------------------------

    @Override
    public int barCount() {
        return 2;
    }

    @Override
    public int barX(int index) {
        return BAR_X;
    }

    @Override
    public int barY(int index) {
        return BAR_TOP + index * BAR_STEP;
    }

    @Override
    public int barWidth(int index) {
        return BAR_W;
    }

    @Override
    public int barHeight(int index) {
        return BAR_H;
    }

    @Override
    public int barAmount(int index) {
        return this.values[index == 0 ? DATA_WATER : DATA_STEAM];
    }

    @Override
    public int barFluidId(int index) {
        if (barAmount(index) <= 0) {
            return -1;
        }
        return BuiltInRegistries.FLUID.getId(index == 0 ? Fluids.WATER : ModFluids.STEAM.source.get());
    }

    @Override
    public int barCapacity() {
        return PwrControllerBlockEntity.WATER_CAPACITY;
    }

    @Override
    public boolean barIsInput(int index) {
        return index == 0;
    }

    // ------------------------------------------------------------------
    // 版式：底部读数比普通机器多几行
    // ------------------------------------------------------------------

    @Override
    public int textY() {
        return MachineLayout.textY(0);
    }

    @Override
    public int inventoryLabelY() {
        return textY() + STAT_LINES * MachineLayout.TEXT_STEP + 3;
    }

    @Override
    public int inventoryY() {
        return inventoryLabelY() + 10;
    }

    @Override
    public int guiHeight() {
        return inventoryY() + 58 + 18 + 6;
    }
}
