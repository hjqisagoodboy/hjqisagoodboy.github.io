package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.FastReactorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 钠冷快堆控制器的界面：8 格 MOX 燃料 + 1 格乏燃料产物 + 一根钠长条 + 一串读数。
 *
 * <p>版式：
 * <ul>
 *   <li>左边两行 4 格是 MOX 燃料组件，右边单独一格放烧完的乏燃料组件（快堆）；</li>
 *   <li>燃料格下面一条控制棒插入深度滑块（和压水堆一样：− / + / 直接点）；</li>
 *   <li>右边一根长条是内部钠罐，管道灌满就能一直跑；</li>
 *   <li>底下读数：结构、部件数、燃料 / 控制棒、热量、发电量、烧到多少。</li>
 * </ul>
 */
public class FastReactorMenu extends AbstractMachineMenu implements FluidBarHost {

    public static final int BUTTON_ROD_LESS = 0;
    public static final int BUTTON_ROD_MORE = 1;
    public static final int BUTTON_ROD_ABSOLUTE = 100;

    /** 钠长条的位置。 */
    public static final int BAR_X = 150;
    public static final int BAR_TOP = 26;
    public static final int BAR_W = 14;
    public static final int BAR_H = 18;

    /** 底部读数行数。 */
    public static final int STAT_LINES = 6;

    private static final int DATA_STATUS = 0;
    private static final int DATA_FORMED = 1;
    private static final int DATA_SHELL = 2;
    private static final int DATA_DETECTORS = 3;
    private static final int DATA_GENERATORS = 4;
    private static final int DATA_ROD_PORTS = 5;
    private static final int DATA_FUEL = 6;
    private static final int DATA_RODS = 7;
    private static final int DATA_DEPTH = 8;
    private static final int DATA_OUTPUT = 9;
    private static final int DATA_SODIUM = 10;
    private static final int DATA_BURN = 11;
    private static final int DATA_HEAT = 12;
    private static final int DATA_COUNT = 13;

    @Nullable
    private final FastReactorControllerBlockEntity controller;

    private final int[] values = new int[DATA_COUNT];

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return index >= 0 && index < DATA_COUNT ? values[index] : 0;
        }

        @Override
        public void set(int index, int value) {
            if (index >= 0 && index < DATA_COUNT) {
                values[index] = value;
            }
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    /** 服务端用。 */
    public FastReactorMenu(int containerId, Inventory playerInventory, FastReactorControllerBlockEntity controller) {
        this(containerId, playerInventory, (BlockEntity) controller);
    }

    /** 客户端用。 */
    public FastReactorMenu(int containerId, Inventory playerInventory, @Nullable BlockEntity blockEntity) {
        super(ModMenus.FAST_REACTOR_CONTROLLER.get(), containerId, playerInventory,
                FastReactorControllerBlockEntity.SLOT_COUNT, null, 1);
        this.controller = blockEntity instanceof FastReactorControllerBlockEntity be ? be : null;

        // 8 格燃料：两行四列
        for (int i = 0; i < FastReactorControllerBlockEntity.FUEL_SLOTS; i++) {
            int column = i % 4;
            int row = i / 4;
            this.addSlot(new FuelSlot(controller(blockEntity), i,
                    MachineLayout.ITEM_X + column * MachineLayout.ITEM_STEP,
                    MachineLayout.ITEM_Y + row * MachineLayout.ITEM_STEP));
        }
        // 产物格：单独摆在右边
        this.addSlot(new OutputSlot(controller(blockEntity), FastReactorControllerBlockEntity.SLOT_OUTPUT,
                MachineLayout.ITEM_X + 72, MachineLayout.ITEM_Y));

        this.addPlayerInventory(playerInventory);
        this.addDataSlots(this.data);
    }

    /** 客户端拿不到方块实体时给个空壳容器，免得建菜单时炸掉。 */
    private static net.minecraft.world.Container controller(@Nullable BlockEntity blockEntity) {
        return blockEntity instanceof FastReactorControllerBlockEntity be
                ? be
                : new net.minecraft.world.SimpleContainer(FastReactorControllerBlockEntity.SLOT_COUNT);
    }

    public static FastReactorMenu fromNetwork(int containerId, Inventory playerInventory,
                                              RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        return new FastReactorMenu(containerId, playerInventory,
                playerInventory.player.level().getBlockEntity(pos));
    }

    @Override
    public void broadcastChanges() {
        if (this.controller != null) {
            this.values[DATA_STATUS] = this.controller.statusCode();
            this.values[DATA_FORMED] = this.controller.isFormed() ? 1 : 0;
            this.values[DATA_SHELL] = this.controller.shellCount();
            this.values[DATA_DETECTORS] = this.controller.detectorCount();
            this.values[DATA_GENERATORS] = this.controller.generatorCount();
            this.values[DATA_ROD_PORTS] = this.controller.rodPortCount();
            this.values[DATA_FUEL] = this.controller.fuelCount();
            this.values[DATA_RODS] = this.controller.rodCount();
            this.values[DATA_DEPTH] = this.controller.rodDepth();
            this.values[DATA_OUTPUT] = this.controller.outputFePerTick();
            this.values[DATA_SODIUM] = this.controller.sodiumAmount();
            this.values[DATA_BURN] = this.controller.burnPercent();
            this.values[DATA_HEAT] = this.controller.heatPermille();
        }
        super.broadcastChanges();
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (this.controller == null) {
            return false;
        }
        if (id == BUTTON_ROD_LESS || id == BUTTON_ROD_MORE) {
            int step = id == BUTTON_ROD_MORE ? 5 : -5;
            this.controller.setRodDepth(this.controller.rodDepth() + step);
        } else if (id >= BUTTON_ROD_ABSOLUTE) {
            this.controller.setRodDepth(id - BUTTON_ROD_ABSOLUTE);
        } else {
            return false;
        }
        this.broadcastChanges();
        return true;
    }

    // ------------------------------------------------------------------
    // 读数
    // ------------------------------------------------------------------

    public int status() {
        return this.values[DATA_STATUS];
    }

    public boolean isFormed() {
        return this.values[DATA_FORMED] != 0;
    }

    public int shell() {
        return this.values[DATA_SHELL];
    }

    public int detectors() {
        return this.values[DATA_DETECTORS];
    }

    public int generators() {
        return this.values[DATA_GENERATORS];
    }

    public int rodPorts() {
        return this.values[DATA_ROD_PORTS];
    }

    public int fuel() {
        return this.values[DATA_FUEL];
    }

    public int rods() {
        return this.values[DATA_RODS];
    }

    public int rodDepth() {
        return this.values[DATA_DEPTH];
    }

    public int outputFePerTick() {
        return this.values[DATA_OUTPUT];
    }

    public int burnPercent() {
        return this.values[DATA_BURN];
    }

    public int heatPercent() {
        return Math.round(this.values[DATA_HEAT] / 10.0F);
    }

    public int sodiumAmount() {
        return this.values[DATA_SODIUM];
    }

    // ------------------------------------------------------------------
    // FluidBarHost：一根钠长条
    // ------------------------------------------------------------------

    @Override
    public int barCount() {
        return 1;
    }

    @Override
    public int barX(int index) {
        return BAR_X;
    }

    @Override
    public int barY(int index) {
        return BAR_TOP;
    }

    @Override
    public int barWidth(int index) {
        return BAR_W;
    }

    @Override
    public int barHeight(int index) {
        return BAR_H;
    }

    @Override
    public int barAmount(int index) {
        return this.values[DATA_SODIUM];
    }

    @Override
    public int barFluidId(int index) {
        return barAmount(index) <= 0 ? -1 : BuiltInRegistries.FLUID.getId(ModFluids.SODIUM.source.get());
    }

    @Override
    public int barCapacity() {
        return FastReactorControllerBlockEntity.SODIUM_CAPACITY;
    }

    @Override
    public boolean barIsInput(int index) {
        return true;
    }

    // ------------------------------------------------------------------
    // 版式：底部六行读数
    // ------------------------------------------------------------------

    @Override
    public int textY() {
        return MachineLayout.textY(1);
    }

    @Override
    public int inventoryLabelY() {
        return textY() + STAT_LINES * MachineLayout.TEXT_STEP + 3;
    }

    @Override
    public int inventoryY() {
        return inventoryLabelY() + 10;
    }

    @Override
    public int guiHeight() {
        return inventoryY() + 58 + 18 + 6;
    }

    /** 燃料格：只收 MOX 燃料组件。 */
    public static class FuelSlot extends Slot {

        public FuelSlot(net.minecraft.world.Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.is(cn.blockforge.generated.aftercritical.registry.ModItems.MOX_FUEL_ASSEMBLY.get());
        }
    }
}
