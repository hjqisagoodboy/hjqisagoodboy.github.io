package cn.blockforge.generated.aftercritical.effect;

import cn.blockforge.generated.aftercritical.registry.ModEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;

/**
 * 「站在这里就一直吃辐射」的统一写法。
 *
 * <p>坑：辐射沾染每秒结算一次，只在剩余时间能被 20 整除的那一 tick 扣血。
 * 所以不能每 tick 都无脑加一次 60 tick 的效果——那样剩余时间永远是 60，
 * 每 tick 都能被 20 整除，玩家会被瞬间扣死。
 * 这里改成「快到点了才续」，效果自然按每秒一次的节奏掉血。
 */
public final class RadiationAura {

    /** 一次续多久（3 秒）。 */
    public static final int DURATION = 60;
    /** 剩余时间少于这么多才续，剩下的交给效果自己倒数。 */
    private static final int REFRESH_BELOW = 20;

    private RadiationAura() {}

    /** 给这个生物续上辐射沾染（已经有一段时间的话就不动）。 */
    public static void apply(LivingEntity living) {
        // 穿齐四件防护服就完全不沾染：连效果都不挂，省得连挖掘都跟着变慢
        if (RadiationProtection.isFullSuit(living)) {
            return;
        }
        MobEffectInstance current = living.getEffect(ModEffects.RADIATION_CONTAMINATION);
        if (current != null && current.getDuration() >= REFRESH_BELOW) {
            return;
        }
        living.addEffect(new MobEffectInstance(ModEffects.RADIATION_CONTAMINATION, DURATION, 0));
    }
}
