package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.ItemPipeBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 物品管道：把物品从一个方块搬到另一个方块。
 *
 * <p>一根管道每 tick 从相邻方块里抽 1 个物品，再顺着连在一起的管道塞进最近的、
 * 愿意收下它的方块。管道本身不耗电、不需要燃料。
 *
 * <p>「接上」的判断：邻居是同种管道，或者邻居身上有物品接口（机器的输出槽、
 * 箱子、漏斗……都算）。
 */
public class ItemPipeBlock extends AbstractPipeBlock {

    public ItemPipeBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(ItemPipeBlock::new);
    }

    @Override
    protected boolean canConnectTo(LevelAccessor level, BlockPos selfPos, BlockPos neighbourPos,
                                   Direction faceOfNeighbour) {
        if (level.getBlockState(neighbourPos).getBlock() instanceof ItemPipeBlock) {
            return true;
        }
        if (level instanceof Level realLevel) {
            if (realLevel.getCapability(Capabilities.ItemHandler.BLOCK, neighbourPos, faceOfNeighbour) != null) {
                return true;
            }
            // 只实现了原版 Container 的方块（少见，但别漏了）也算接上
            return realLevel.getBlockEntity(neighbourPos) instanceof Container;
        }
        return false;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ItemPipeBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                  BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return (tickLevel, pos, tickState, blockEntity) -> {
            if (blockEntity instanceof ItemPipeBlockEntity pipe) {
                pipe.serverTick();
            }
        };
    }

    /** 物品栏提示：搬什么、怎么连。 */
    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.item_pipe.desc")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.pipe.auto_connect")
                .withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.pipe.no_power")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
