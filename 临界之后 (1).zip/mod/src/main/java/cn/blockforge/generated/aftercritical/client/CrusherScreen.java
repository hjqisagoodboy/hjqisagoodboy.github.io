package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.CrusherMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** 破碎机的界面：面板、能量条、箭头全部继承自 {@link AbstractMachineScreen}。 */
public class CrusherScreen extends AbstractMachineScreen<CrusherMenu> {

    public CrusherScreen(CrusherMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }
}
