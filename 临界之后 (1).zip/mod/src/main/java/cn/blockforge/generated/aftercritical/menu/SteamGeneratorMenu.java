package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.blockentity.SteamGeneratorBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 汽轮发电机 / 冷凝器那一套「只看流体」的界面：没有物品槽，左边能量条，右边两根长条
 * （进汽 / 乏蒸汽），底下写读数。
 *
 * <p>蒸汽、乏蒸汽都靠管道或通用流体罐进出，不需要把罐子摆在界面里。
 */
public class SteamGeneratorMenu extends AbstractMachineMenu implements FluidBarHost {

    /** 两根长条的位置（面板坐标）。 */
    public static final int BAR_X = 150;
    public static final int BAR_TOP = 28;
    public static final int BAR_STEP = 22;
    public static final int BAR_W = 14;
    public static final int BAR_H = 18;

    /** 底部读数几行。 */
    public static final int STAT_LINES = 5;

    /** 界面上的「弃电保汽」按钮。 */
    public static final int BUTTON_DUMP_POWER = 0;

    private static final int DATA_STEAM = 0;
    private static final int DATA_EXHAUST = 1;
    private static final int DATA_RATE = 2;
    private static final int DATA_OUTPUT = 3;
    private static final int DATA_DUMP = 4;
    private static final int DATA_WASTED = 5;
    private static final int DATA_COUNT = 6;

    @Nullable
    private final SteamGeneratorBlockEntity generator;
    private int steam;
    private int exhaust;
    private int rate;
    private int output;
    private int dumpPower;
    private int wasted;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case DATA_STEAM -> steam;
                case DATA_EXHAUST -> exhaust;
                case DATA_RATE -> rate;
                case DATA_OUTPUT -> output;
                case DATA_DUMP -> dumpPower;
                case DATA_WASTED -> wasted;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case DATA_STEAM -> steam = value;
                case DATA_EXHAUST -> exhaust = value;
                case DATA_RATE -> rate = value;
                case DATA_OUTPUT -> output = value;
                case DATA_DUMP -> dumpPower = value;
                case DATA_WASTED -> wasted = value;
                default -> {
                }
            }
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    /** 服务端用。 */
    public SteamGeneratorMenu(int containerId, Inventory playerInventory, SteamGeneratorBlockEntity generator) {
        this(containerId, playerInventory, generator, generator);
    }

    /** 客户端用：方块实体没了也能开界面看个空壳。 */
    public SteamGeneratorMenu(int containerId, Inventory playerInventory, Container container,
                              @Nullable EnergyMachineHost machine) {
        super(ModMenus.STEAM_GENERATOR.get(), containerId, playerInventory, 0, machine, 2);
        this.generator = machine instanceof SteamGeneratorBlockEntity be ? be : null;
        this.addPlayerInventory(playerInventory);
        this.addDataSlots(this.data);
    }

    public static SteamGeneratorMenu fromNetwork(int containerId, Inventory playerInventory,
                                                 RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof SteamGeneratorBlockEntity generator) {
            return new SteamGeneratorMenu(containerId, playerInventory, generator);
        }
        return new SteamGeneratorMenu(containerId, playerInventory, new SimpleContainer(0), null);
    }

    @Override
    public void broadcastChanges() {
        if (this.generator != null) {
            this.steam = this.generator.steamAmount();
            this.exhaust = this.generator.exhaustAmount();
            this.rate = this.generator.steamPerTick();
            this.output = this.generator.outputFePerTick();
            this.dumpPower = this.generator.isDumpPower() ? 1 : 0;
            this.wasted = this.generator.wastedFePerTick();
        }
        super.broadcastChanges();
    }

    /** 界面上的「弃电保汽」按钮：点一下开关切换，服务端立刻生效。 */
    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (this.generator == null || id != BUTTON_DUMP_POWER) {
            return false;
        }
        this.generator.setDumpPower(!this.generator.isDumpPower());
        this.broadcastChanges();
        return true;
    }

    /** 没有机器槽，Shift 点击不搬东西（不然会往 0 个槽里塞）。 */
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    // ------------------------------------------------------------------
    // FluidBarHost
    // ------------------------------------------------------------------

    @Override
    public int barCount() {
        return 2;
    }

    @Override
    public int barX(int index) {
        return BAR_X;
    }

    @Override
    public int barY(int index) {
        return BAR_TOP + index * BAR_STEP;
    }

    @Override
    public int barWidth(int index) {
        return BAR_W;
    }

    @Override
    public int barHeight(int index) {
        return BAR_H;
    }

    @Override
    public int barAmount(int index) {
        return index == 0 ? this.steam : this.exhaust;
    }

    @Override
    public int barFluidId(int index) {
        if (barAmount(index) <= 0) {
            return -1;
        }
        return BuiltInRegistries.FLUID.getId(index == 0
                ? ModFluids.STEAM.source.get() : ModFluids.EXHAUST_STEAM.source.get());
    }

    @Override
    public int barCapacity() {
        return SteamGeneratorBlockEntity.TANK_CAPACITY;
    }

    @Override
    public boolean barIsInput(int index) {
        return index == 0;
    }

    // ------------------------------------------------------------------
    // 版式：底部读数四行
    // ------------------------------------------------------------------

    @Override
    public int textY() {
        return MachineLayout.textY(0);
    }

    @Override
    public int inventoryLabelY() {
        return textY() + STAT_LINES * MachineLayout.TEXT_STEP + 3;
    }

    @Override
    public int inventoryY() {
        return inventoryLabelY() + 10;
    }

    @Override
    public int guiHeight() {
        return inventoryY() + 58 + 18 + 6;
    }

    /** 界面里显示出来的蒸汽流量（服务端算好，靠 ContainerData 同步过来）。 */
    public int steamPerTick() {
        return this.rate;
    }

    public int outputFePerTick() {
        return this.output;
    }

    /** 弃电保汽是不是开着（界面按钮显示用）。 */
    public boolean dumpPower() {
        return this.dumpPower != 0;
    }

    /** 本 tick 弃掉了多少 FE。 */
    public int wastedFePerTick() {
        return this.wasted;
    }

    public int tankCapacity() {
        return SteamGeneratorBlockEntity.TANK_CAPACITY;
    }
}
