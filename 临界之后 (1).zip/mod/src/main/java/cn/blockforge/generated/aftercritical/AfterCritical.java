package cn.blockforge.generated.aftercritical;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.advancement.MoltenOreHarvest;
import cn.blockforge.generated.aftercritical.registry.ModArmorMaterials;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModBlocks;
import cn.blockforge.generated.aftercritical.registry.ModCapabilities;
import cn.blockforge.generated.aftercritical.registry.ModCreativeTabs;
import cn.blockforge.generated.aftercritical.registry.ModDataComponents;
import cn.blockforge.generated.aftercritical.registry.ModEffects;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import cn.blockforge.generated.aftercritical.registry.ModRecipes;
import cn.blockforge.generated.aftercritical.registry.ModSounds;
import cn.blockforge.generated.aftercritical.network.ModNetwork;
import cn.blockforge.generated.aftercritical.world.NuclearBlast;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.common.NeoForge;

/**
 * 《临界之后》主类。
 *
 * <p>目前已完成：6 种矿石方块 + 世界生成 + 铀矿石的“辐射沾染”效果 + 阶段 0 的基础机器骨架。
 */
@Mod(AfterCritical.MOD_ID)
public final class AfterCritical {
    public static final String MOD_ID = "aftercritical";

    public AfterCritical(IEventBus modBus) {
        // 护甲材质必须排在物品前面：物品注册时要拿它去造四件防护服
        ModArmorMaterials.ARMOR_MATERIALS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModMenus.MENUS.register(modBus);
        ModEffects.EFFECTS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);

        // 机器的加工配方：三种配方类型 + 三个读写器（JSON 在 data/aftercritical/recipe/ 里）
        ModRecipes.RECIPE_TYPES.register(modBus);
        ModRecipes.RECIPE_SERIALIZERS.register(modBus);

        // 第四步的自定义流体（氢、氧、氮、氯、钠、氨、硫酸）
        ModFluids.FLUID_TYPES.register(modBus);
        ModFluids.FLUIDS.register(modBus);

        // 流体单元用到的数据组件：物品堆上「装着哪种流体、多少 mB」
        ModDataComponents.DATA_COMPONENTS.register(modBus);

        // 声音：核爆那一段 70 秒的爆炸录音（sounds/nuke_explosion.ogg）
        ModSounds.SOUND_EVENTS.register(modBus);

        // 把机器的 FE 接口挂到方块能力上（别的模组的线缆才找得到）
        modBus.addListener(RegisterCapabilitiesEvent.class, ModCapabilities::register);

        // 成就系统用到的自定义触发条件（「机器事件」）
        ModAdvancementTriggers.TRIGGERS.register(modBus);

        // 网络包：核爆的全屏爆闪、蘑菇云的位置与大小
        modBus.addListener(ModNetwork::register);

        // 核爆：一次熔毁要分好多秒慢慢炸开 120 格，靠服务端每 tick 推进一点点
        NeoForge.EVENT_BUS.addListener(NuclearBlast::onServerTick);

        // 隐藏结局「轮回」：玩家挖到核弹炸出来的核熔钻石矿 / 绿宝石矿时记一笔
        NeoForge.EVENT_BUS.addListener(MoltenOreHarvest::onBlockBreak);
    }
}
