package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

/**
 * 冷却剂端口的内容：一个进水罐 + 一个出汽罐。
 *
 * <p>这两个罐子是压水堆和外面世界唯一的流体接口：
 * <ul>
 *   <li>0 号罐（进水）：<b>只收水</b>，管道把水灌进来；</li>
 *   <li>1 号罐（出汽）：<b>只放蒸汽</b>，管道把蒸汽抽去汽轮发电机。</li>
 * </ul>
 * 压水堆控制器每 tick 从所有端口的进水罐抽水，再把产出的蒸汽灌回出汽罐。
 */
public class CoolantPortBlockEntity extends BlockEntity {

    /** 每个罐 8,000 mB，够 50 mB/t 的堆跑 160 秒。 */
    public static final int TANK_CAPACITY = 8_000;

    public static final int TANK_WATER = 0;
    public static final int TANK_STEAM = 1;

    private final FluidTank waterTank = new FluidTank(TANK_CAPACITY);
    private final FluidTank steamTank = new FluidTank(TANK_CAPACITY);

    private final IFluidHandler fluidHandler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return 2;
        }

        @Override
        public FluidStack getFluidInTank(int tank) {
            return tank == TANK_WATER ? waterTank.getFluid()
                    : tank == TANK_STEAM ? steamTank.getFluid() : FluidStack.EMPTY;
        }

        @Override
        public int getTankCapacity(int tank) {
            return TANK_CAPACITY;
        }

        @Override
        public boolean isFluidValid(int tank, FluidStack stack) {
            return tank == TANK_WATER;
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            // 出汽罐是反应堆的「出口」，谁都不能往里倒东西；
            // 进水罐只认水（重水以后可以直接顶替，先留好口子）
            if (resource.isEmpty() || !isCoolant(resource.getFluid())) {
                return 0;
            }
            int filled = waterTank.fill(resource, action);
            if (filled > 0) {
                setChanged();
            }
            return filled;
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            FluidStack drained = steamTank.drain(resource, action);
            if (!drained.isEmpty()) {
                setChanged();
            }
            return drained;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            FluidStack drained = steamTank.drain(maxDrain, action);
            if (!drained.isEmpty()) {
                setChanged();
            }
            return drained;
        }
    };

    /** 水或者重水都能当冷却剂。 */
    private static boolean isCoolant(Fluid fluid) {
        return fluid.isSame(Fluids.WATER) || fluid.isSame(ModFluids.HEAVY_WATER.source.get());
    }

    public CoolantPortBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.COOLANT_PORT.get(), pos, state);
    }

    public IFluidHandler getFluidHandler() {
        return this.fluidHandler;
    }

    /** 进水罐（只进不出，控制器直接来抽）。 */
    public FluidTank waterTank() {
        return this.waterTank;
    }

    /** 出汽罐（控制器往里灌，管道往外抽）。 */
    public FluidTank steamTank() {
        return this.steamTank;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Water", this.waterTank.writeToNBT(registries, new CompoundTag()));
        tag.put("Steam", this.steamTank.writeToNBT(registries, new CompoundTag()));
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.waterTank.readFromNBT(registries, tag.getCompound("Water"));
        this.steamTank.readFromNBT(registries, tag.getCompound("Steam"));
    }
}
