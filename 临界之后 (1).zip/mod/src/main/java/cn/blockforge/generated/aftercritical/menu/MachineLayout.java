package cn.blockforge.generated.aftercritical.menu;

/**
 * 所有机器界面共用的一把「尺子」。
 *
 * <p>以前每台机器的界面都靠自己那张贴图，槽位坐标写死在各自的菜单里、凹槽画在 PNG 上，
 * 想统一改个位置就得重新画十张图。现在界面改成「代码画的统一面板」，位置全部来自这里：
 * 菜单摆槽位、界面画面板都读同一份坐标，永远不会错位。
 *
 * <p>版式（面板 220 × 228）：
 * <pre>
 *   ┌──────────────────────────────────────────┐
 *   │ 标题                          ⚡          │
 *   │ ┌──┐   [输入] →→→ [输出]   ▮[罐][罐] 4000│
 *   │ │  │                        ▮[罐][罐]     │
 *   │ │FE│  状态 / 能量 / 进度     ▮[罐][罐]     │
 *   │ │  │  操作槽 · 返还槽 提示    ▮[罐][罐]     │
 *   │ └──┘                                     │
 *   │  背包 3 行 + 快捷栏                       │
 *   └──────────────────────────────────────────┘
 * </pre>
 *
 * <p>左边一列是能量条（带闪电图标），中间是物品输入 → 输出（夹一个箭头，箭头里灌的就是加工进度），
 * 右边一列是流体长条，每根长条右边紧跟两个罐子槽：左边「操作槽」、右边「返还槽」。
 */
public final class MachineLayout {

    /** 面板宽。 */
    public static final int WIDTH = 220;
    /** 面板高。 */
    public static final int HEIGHT = 228;

    /** 玩家背包（9 列 × 3 行）左上角的 x（y 按流体行数算，见 {@link #inventoryYFor(int)}）。 */
    public static final int INVENTORY_X = 29;

    /** 机器区最矮要留多高（物品槽两行 + 一行留白）。 */
    public static final int CONTENT_MIN_BOTTOM = 84;

    /** 左侧能量条外框。 */
    public static final int ENERGY_X = 8;
    public static final int ENERGY_Y = 26;
    public static final int ENERGY_W = 14;
    public static final int ENERGY_H = 58;

    /** 闪电图标的位置（能量条顶上）。 */
    public static final int BOLT_X = 9;
    public static final int BOLT_Y = 8;

    /** 中间物品区的第一格。 */
    public static final int ITEM_X = 30;
    public static final int ITEM_Y = 26;
    /** 格子间距（18 = 16 像素格子 + 2 像素缝）。 */
    public static final int ITEM_STEP = 18;

    /**
     * 物品输入槽一行摆几个，摆满就换到下一行。
     *
     * <p>以前所有输入槽都排在同一行：玻璃固化炉有 3 个输入槽，
     * 第三格正好落进箭头的 x 区间（格子 66~82 压在箭头 70~98 上），
     * 两者糊成一团。现在一行只摆 2 个，第三格换到第二行，箭头那块地方永远是干净的。
     */
    public static final int INPUT_COLUMNS = 2;

    /** 右侧流体列：第一根长条的 x、第一行的 y、行距。 */
    public static final int FLUID_X = 126;
    public static final int FLUID_TOP = 22;
    public static final int FLUID_STEP = 18;
    public static final int FLUID_BAR_W = 12;
    public static final int FLUID_BAR_H = 16;
    /** 相对长条左边缘：操作槽、返还槽、mB 数字。 */
    public static final int FLUID_OP_DX = 16;
    public static final int FLUID_RET_DX = 34;
    public static final int FLUID_TEXT_DX = 56;

    /** 底部文字块：第一行、行距。 */
    public static final int TEXT_X = 30;
    public static final int TEXT_STEP = 11;

    /** 箭头默认高度。 */
    public static final int ARROW_HEIGHT = 13;

    private MachineLayout() {}

    /** 第 {@code index} 个物品输入槽的 x（一行 {@link #INPUT_COLUMNS} 个）。 */
    public static int inputSlotX(int index) {
        return ITEM_X + (index % INPUT_COLUMNS) * ITEM_STEP;
    }

    /** 第 {@code index} 个物品输入槽的 y（一行摆满就往下挪一行）。 */
    public static int inputSlotY(int index) {
        return ITEM_Y + (index / INPUT_COLUMNS) * ITEM_STEP;
    }

    /** 最后一行流体长条的底边 y；没有流体行就是 0。 */
    public static int fluidRowsBottom(int rows) {
        if (rows <= 0) {
            return 0;
        }
        return FLUID_TOP + (rows - 1) * FLUID_STEP + FLUID_BAR_H + 1;
    }

    /** 机器区（面板上半部分）的底边。 */
    public static int contentBottom(int rows) {
        return Math.max(CONTENT_MIN_BOTTOM, fluidRowsBottom(rows));
    }

    /** 底部文字块第一行的 y。 */
    public static int textY(int rows) {
        return contentBottom(rows) + 6;
    }

    /** 「背包」两个字的位置。 */
    public static int inventoryLabelY(int rows) {
        return textY(rows) + 3 * TEXT_STEP + 3;
    }

    /** 玩家背包第一行的 y。 */
    public static int inventoryYFor(int rows) {
        return inventoryLabelY(rows) + 10;
    }

    /** 整块面板的高度：背包 3 行 + 快捷栏 + 下边距。 */
    public static int heightFor(int rows) {
        return inventoryYFor(rows) + 58 + 18 + 6;
    }

    /**
     * 一根「输入 → 输出」箭头。
     *
     * @param x      箭头左端在面板里的 x
     * @param y      箭头中间的 y（不是左上角）
     * @param length 箭头总长（含箭头尖）
     */
    public record Arrow(int x, int y, int length) {

        /** 箭头尖占多长。 */
        public static final int HEAD = 7;

        /** 箭杆（进度条）的长度。 */
        public int shaftLength() {
            return Math.max(1, this.length - HEAD);
        }
    }
}
