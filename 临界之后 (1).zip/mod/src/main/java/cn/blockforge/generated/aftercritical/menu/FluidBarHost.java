package cn.blockforge.generated.aftercritical.menu;

/**
 * 「我的界面右边有几根流体长条」——由菜单告诉界面，界面只管照着画。
 *
 * <p>流体机器（电解槽、化工厂……）、级联控制器、储罐控制器都实现它，
 * 所以不管哪台机器，右边的长条长得一样、鼠标停了提示一样、数字位置也一样。
 */
public interface FluidBarHost {

    /** 有几根长条。 */
    int barCount();

    /** 第 {@code index} 根长条左上角（面板坐标）。 */
    int barX(int index);

    int barY(int index);

    /** 第 {@code index} 根长条的宽高。 */
    int barWidth(int index);

    int barHeight(int index);

    /** 里面现在有多少 mB。 */
    int barAmount(int index);

    /** 里面是哪种流体（注册表编号），空的返回 -1。 */
    int barFluidId(int index);

    /** 一根长条能装多少 mB。 */
    int barCapacity();

    /** 这根长条算不算「进液」（机器要往里灌的那种）。 */
    /**
     * 鼠标右键长条时，客户端要发哪个「菜单按钮」给服务端；返回负数表示这根长条不响应右键。
     *
     * <p>流体机器用它实现「拿罐子对着长条右键 = 装 / 卸」，其他方块不用就直接不管。
     */
    default int barButtonBase() {
        return -1;
    }

    default boolean barIsInput(int index) {
        return true;
    }
}
