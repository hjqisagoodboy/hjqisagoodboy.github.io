package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.block.HotCellArmBlock;
import cn.blockforge.generated.aftercritical.menu.HotCellArmMenu;
import cn.blockforge.generated.aftercritical.recipe.MachineRecipe;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import cn.blockforge.generated.aftercritical.registry.ModRecipes;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.items.IItemHandler;

import javax.annotation.Nullable;
import java.util.Set;

/**
 * 热室机械臂的方块实体：1 格放冷却的靶材、1 格出同位素，每 tick 吃 32 FE。
 *
 * <p>它本身和普通加工机器（破碎机、装配机）共用一套加工骨架，
 * 只是把「输入是什么」卡死成 7 种【冷却的靶材】，再给物品接口加了一条规矩：
 * <b>管道/漏斗只能往里塞，不能往外抽</b>——真去抽的话，东西会直接掉在地上，
 * 还会给 3×3×3 范围内的活物上辐射（见 {@link HotCellArmBlock#radiate}）。
 * 想安全取走产物，就打开界面用手拿。
 */
public class HotCellArmBlockEntity extends MachineBlockEntity {

    public static final int SLOT_INPUT = 0;
    public static final int SLOT_OUTPUT = 1;
    public static final int SLOT_COUNT = 2;

    /** 运行耗电：32 FE/t。 */
    public static final int ENERGY_PER_TICK = 32;

    /** 只有这 7 种「冷却的靶材」能进机械臂。 */
    public static final Set<Item> COOLED_TARGETS = Set.of(
            ModItems.COOLED_COBALT59.get(), ModItems.COOLED_LITHIUM6.get(),
            ModItems.COOLED_URANIUM238.get(), ModItems.COOLED_CESIUM133.get(),
            ModItems.COOLED_STRONTIUM88.get(), ModItems.COOLED_PLUTONIUM239.get(),
            ModItems.COOLED_SILICON30.get());

    private static final int[] INPUTS = {SLOT_INPUT};
    private static final int[] OUTPUTS = {SLOT_OUTPUT};

    /** 真正的槽位读写走它，外面那个 {@link #hazardHandler} 只是在抽取时加「惩罚」。 */
    private final IItemHandler slots;
    private final IItemHandler hazardHandler = new IItemHandler() {
        @Override
        public int getSlots() {
            return SLOT_COUNT;
        }

        @Override
        public ItemStack getStackInSlot(int slot) {
            return slots.getStackInSlot(slot);
        }

        @Override
        public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
            return slots.insertItem(slot, stack, simulate);
        }

        /**
         * 管道 / 漏斗想从机械臂里抽东西：模拟的时候如实回答，真抽的时候
         * 直接触发「掉一地 + 辐射」，一个也不给。
         */
        @Override
        public ItemStack extractItem(int slot, int amount, boolean simulate) {
            ItemStack available = slots.extractItem(slot, amount, true);
            if (available.isEmpty()) {
                return ItemStack.EMPTY;
            }
            if (!simulate) {
                ejectContents();
            }
            return ItemStack.EMPTY;
        }

        @Override
        public int getSlotLimit(int slot) {
            return slots.getSlotLimit(slot);
        }

        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            return slots.isItemValid(slot, stack);
        }
    };

    public HotCellArmBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.HOT_CELL_ARM.get(), pos, state, SLOT_COUNT, ENERGY_PER_TICK);
        this.slots = super.getItemHandler();
    }

    @Override
    protected int[] inputSlots() {
        return INPUTS;
    }

    @Override
    protected int[] outputSlots() {
        return OUTPUTS;
    }

    @Override
    protected RecipeType<MachineRecipe> recipeType() {
        return ModRecipes.HOT_CELL;
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot == SLOT_INPUT && COOLED_TARGETS.contains(stack.getItem());
    }

    @Override
    public IItemHandler getItemHandler() {
        return this.hazardHandler;
    }

    /** 把里面的东西全吐在地上，并给周围上一圈辐射。 */
    public void ejectContents() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        for (int i = 0; i < SLOT_COUNT; i++) {
            ItemStack stack = getItem(i);
            if (stack.isEmpty()) {
                continue;
            }
            Containers.dropItemStack(this.level, this.worldPosition.getX() + 0.5,
                    this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5, stack.copy());
            setItem(i, ItemStack.EMPTY);
        }
        HotCellArmBlock.radiate(this.level, this.worldPosition);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.hot_cell_arm");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new HotCellArmMenu(containerId, playerInventory, this);
    }
}
