package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.effect.RadiationAura;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.List;

/**
 * 辐射尘：核爆下风向飘下来的一层灰，薄得像雪（两像素高）。
 *
 * <p>为什么单独写一个方块、而不是直接继承原版雪层：原版雪有 8 层厚度、
 * 会自己融化、还会被别的雪叠上去，核爆落下来的尘不需要这些。
 * 这里只做三件事：
 * <ol>
 *   <li>形状是贴着地面的薄片（碰撞也是薄片，所以人真的踩在它上面，不会悬空）；</li>
 *   <li>下面的方块被挖掉就自己消失（跟植物一样），不会在半空留一片灰；</li>
 *   <li>踩上去沾染辐射——和污染土一个道理。</li>
 * </ol>
 *
 * <p>拿在手上、或者只是装在背包里，也会隔一阵子沾一次辐射：这是
 * {@code FalloutExposure} 那个每 20 tick 跑一次的监听器负责的，不在这里。
 */
public class RadioactiveDustBlock extends Block {

    /** 这一层尘贴地只有 2 像素高（雪层第 1 层的高度）。 */
    private static final VoxelShape SHAPE = Block.box(0.0, 0.0, 0.0, 16.0, 2.0, 16.0);

    public RadioactiveDustBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return simpleCodec(RadioactiveDustBlock::new);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos,
                                  CollisionContext context) {
        return SHAPE;
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos,
                                           CollisionContext context) {
        return SHAPE;
    }

    /** 底下必须是实心方块（跟雪一样不能贴在半空）。 */
    @Override
    protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos below = pos.below();
        return level.getBlockState(below).isFaceSturdy(level, below, Direction.UP);
    }

    /** 底下的方块没了，这一层尘也跟着没了。 */
    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighbour,
                                     LevelAccessor level, BlockPos pos, BlockPos neighbourPos) {
        if (!state.canSurvive(level, pos)) {
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, direction, neighbour, level, pos, neighbourPos);
    }

    @Override
    protected boolean isPathfindable(BlockState state, PathComputationType type) {
        return type == PathComputationType.LAND;
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        if (!level.isClientSide && entity instanceof LivingEntity living) {
            RadiationAura.apply(living);
        }
        super.stepOn(level, pos, state, entity);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.radioactive_dust.radiation")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.radioactive_dust.hand")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
