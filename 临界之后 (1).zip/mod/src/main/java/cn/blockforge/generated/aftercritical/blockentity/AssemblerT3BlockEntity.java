package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.menu.AssemblerT3Menu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 装配机 T3：HV 机器，额定 300 FE/t，能做三级配方（机械臂HV、伽马辐照器、研究堆控制器……）。
 *
 * <p>加工逻辑继续沿用 T1 那一套，只改四个参数：功率、能做的配方等级、界面类型、界面标题。
 * 界面上只摆 3 个输入槽 + 1 个产物槽（三级配方最多也就吃三样东西），
 * 底下的容器还是 T1 那 8 格，所以老配方（1~2 级）照样能在这台机器上跑。
 */
public class AssemblerT3BlockEntity extends AssemblerT2BlockEntity {

    /** 额定运行功率：300 FE/t。 */
    public static final int ENERGY_PER_TICK = 300;

    public AssemblerT3BlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ASSEMBLER_T3.get(), pos, state);
    }

    @Override
    protected int baseEnergyPerTick() {
        return ENERGY_PER_TICK;
    }

    /** 三级机器，1/2/3 级配方全都能做。 */
    @Override
    protected int machineTier() {
        return 3;
    }

    @Override
    protected MenuType<?> menuType() {
        return ModMenus.ASSEMBLER_T3.get();
    }

    @Override
    protected String titleKey() {
        return "container.aftercritical.assembler_t3";
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new AssemblerT3Menu(containerId, playerInventory, this);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable(titleKey());
    }
}
