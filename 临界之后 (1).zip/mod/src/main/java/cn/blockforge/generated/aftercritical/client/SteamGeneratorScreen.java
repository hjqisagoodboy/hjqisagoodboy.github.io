package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.SteamGeneratorMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;

/**
 * 汽轮发电机的界面：左边能量条（电攒在这里、再由线缆送走）、右边进汽 / 乏蒸汽两根长条。
 *
 * <p>底下五行读数：运行状态、当前发电功率、弃电多少、蒸汽罐和乏蒸汽罐各剩多少、操作提示。
 *
 * <p>中间那个按钮是「弃电保汽」：电力满了以后，是继续吃蒸汽把电丢掉（开，默认），
 * 还是停下来等电送走（关）。这个开关就是为了防「电满 → 蒸汽堵 → 压水堆熔毁」那条链子。
 */
public class SteamGeneratorScreen extends StatPanelScreen<SteamGeneratorMenu> {

    /** 「弃电保汽」按钮的位置（面板坐标）。 */
    private static final int BUTTON_X = 30;
    private static final int BUTTON_Y = 46;
    private static final int BUTTON_W = 96;
    private static final int BUTTON_H = 14;

    public SteamGeneratorScreen(SteamGeneratorMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected List<Line> statLines() {
        List<Line> lines = new ArrayList<>(5);
        lines.add(new Line(statusLine(), statusColor()));
        lines.add(new Line(Component.translatable("gui.aftercritical.steam.rate",
                this.menu.steamPerTick(), this.menu.outputFePerTick()), TEXT_DARK));
        lines.add(new Line(Component.translatable("gui.aftercritical.steam.dump",
                Component.translatable(this.menu.dumpPower()
                        ? "gui.aftercritical.steam.dump.on" : "gui.aftercritical.steam.dump.off"),
                this.menu.wastedFePerTick()), this.menu.dumpPower() ? TEXT_OK : TEXT_GRAY));
        lines.add(new Line(Component.translatable("gui.aftercritical.steam.tanks",
                this.menu.barAmount(0), this.menu.barAmount(1), this.menu.tankCapacity()), TEXT_DARK));
        lines.add(new Line(Component.translatable("gui.aftercritical.steam.hint"), TEXT_GRAY));
        return lines;
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        super.renderBg(guiGraphics, partialTick, mouseX, mouseY);

        boolean on = this.menu.dumpPower();
        int x = this.leftPos + BUTTON_X;
        int y = this.topPos + BUTTON_Y;

        guiGraphics.fill(x, y, x + BUTTON_W, y + BUTTON_H, PANEL_BG);
        guiGraphics.fill(x, y, x + BUTTON_W, y + 1, PANEL_LIGHT);
        guiGraphics.fill(x, y + BUTTON_H - 1, x + BUTTON_W, y + BUTTON_H, PANEL_DARK);
        guiGraphics.fill(x, y, x + 1, y + BUTTON_H, PANEL_LIGHT);
        guiGraphics.fill(x + BUTTON_W - 1, y, x + BUTTON_W, y + BUTTON_H, PANEL_DARK);
        // 开的时候按钮里染一条绿，关的时候灰——不用读字也知道状态
        guiGraphics.fill(x + 2, y + BUTTON_H - 4, x + BUTTON_W - 2, y + BUTTON_H - 2,
                on ? 0xFF3FA03F : 0xFF9A9A9A);

        Component label = Component.translatable("gui.aftercritical.steam.button",
                Component.translatable(on
                        ? "gui.aftercritical.steam.dump.on" : "gui.aftercritical.steam.dump.off"));
        guiGraphics.drawString(this.font, label,
                x + (BUTTON_W - this.font.width(label)) / 2, y + 3, TEXT_DARK, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && this.minecraft != null && this.minecraft.gameMode != null) {
            int x = (int) mouseX - this.leftPos;
            int y = (int) mouseY - this.topPos;
            if (x >= BUTTON_X && x < BUTTON_X + BUTTON_W && y >= BUTTON_Y && y < BUTTON_Y + BUTTON_H) {
                this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId,
                        SteamGeneratorMenu.BUTTON_DUMP_POWER);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
}
