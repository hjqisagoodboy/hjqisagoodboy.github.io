package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.TankControllerMenu;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * 储罐控制器的界面：一根 64,000 mB 的大长条 + 一对罐子槽，版式和所有机器一致。
 *
 * <p>底下第一行写结构搭好没有，第二行写里面是什么流体、装了多少（超过一千就按千显示，
 * 免得一排数字挤出面板），第三行是罐子槽怎么用。
 */
public class TankControllerScreen extends AbstractMachineScreen<TankControllerMenu> {

    public TankControllerScreen(TankControllerMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected Component statusLine() {
        return Component.translatable(this.menu.isFormed()
                ? "gui.aftercritical.tank.formed"
                : "gui.aftercritical.tank.not_formed");
    }

    @Override
    protected int statusColor() {
        return this.menu.isFormed() ? TEXT_OK : TEXT_BAD;
    }

    @Override
    protected Component energyLine() {
        int fluidId = this.menu.getFluidId();
        String name = fluidId < 0
                ? Component.translatable("gui.aftercritical.fluid.empty").getString()
                : ModFluids.displayName(fluidId).getString();
        return Component.literal(name + "：" + this.menu.getAmount() + " / " + this.menu.getCapacity() + " mB");
    }

    @Override
    protected Component hintLine() {
        return Component.translatable("gui.aftercritical.tank.jar_hint");
    }
}
