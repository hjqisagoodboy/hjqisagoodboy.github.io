package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.block.TransformerBlock;
import cn.blockforge.generated.aftercritical.block.TransformerTier;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.IEnergyStorage;

import javax.annotation.Nullable;

/**
 * 变压器的方块实体：一个缓存，两个「口」。
 *
 * <p>只做透传，不做真正的电压转换，收多少送多少由方块上的 {@link TransformerTier} 决定：
 * <ul>
 *   <li>背面（正面 {@code FACING} 的反方向）= 输入口：LV→MV 每 tick 接 80 FE、MV→HV 接 320 FE；</li>
 *   <li>正面 = 输出口：LV→MV 每 tick 送 320 FE、MV→HV 送 2,560 FE；</li>
 *   <li>其余四面没有 FE 接口，线缆和机器都连不上。</li>
 * </ul>
 *
 * <p>所以一条「LV 发电机 → LV 线缆 → 变压器背面 → 变压器正面 → MV 线缆 → MV 机器」的链路就能跑通：
 * 电从背面进来、在 4,000 FE 的缓存里待着、再从正面被 MV 线缆拉走。
 */
public class TransformerBlockEntity extends BlockEntity {

    /** 变压器内部缓存，单位 FE。 */
    public static final int ENERGY_CAPACITY = 4_000;

    private int energy;

    /** 两个口共用同一份缓存，只是「能进」和「能出」的规则不一样。 */
    private final IEnergyStorage inputStorage = new InputStorage();
    private final IEnergyStorage outputStorage = new OutputStorage();

    public TransformerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.TRANSFORMER.get(), pos, state);
    }

    /** 这台变压器是哪种等级；方块认不出来时按 LV→MV 处理。 */
    public TransformerTier tier() {
        return getBlockState().getBlock() instanceof TransformerBlock block
                ? block.tier()
                : TransformerTier.LV_MV;
    }

    /**
     * 能力注册用。
     *
     * @param side 方块被查询的那一面；{@code null} 表示不分面的查询
     * @return 正面给输出口、背面给输入口，其余面没有接口
     */
    @Nullable
    public IEnergyStorage getStorage(@Nullable Direction side) {
        if (side == null) {
            return this.outputStorage;
        }
        BlockState state = getBlockState();
        if (!(state.getBlock() instanceof TransformerBlock)) {
            return null;
        }
        Direction facing = state.getValue(TransformerBlock.FACING);
        if (side == facing) {
            return this.outputStorage;
        }
        if (side == facing.getOpposite()) {
            return this.inputStorage;
        }
        return null;
    }

    public int getEnergyStored() {
        return this.energy;
    }

    public int getEnergyCapacity() {
        return ENERGY_CAPACITY;
    }

    private int fill(int amount) {
        if (amount <= 0) {
            return 0;
        }
        int accepted = Math.min(amount, ENERGY_CAPACITY - this.energy);
        if (accepted <= 0) {
            return 0;
        }
        this.energy += accepted;
        setChanged();
        return accepted;
    }

    private int drain(int amount) {
        if (amount <= 0) {
            return 0;
        }
        int taken = Math.min(amount, this.energy);
        if (taken <= 0) {
            return 0;
        }
        this.energy -= taken;
        setChanged();
        return taken;
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy = Math.max(0, Math.min(tag.getInt("Energy"), ENERGY_CAPACITY));
    }

    // ------------------------------------------------------------------
    // 两个口
    // ------------------------------------------------------------------

    /** 输入口：只能进，不能出（每 tick 按等级限流）。 */
    private final class InputStorage implements IEnergyStorage {

        @Override
        public int receiveEnergy(int toReceive, boolean simulate) {
            int accepted = Math.min(toReceive, tier().inputLimit());
            if (simulate) {
                return Math.max(0, Math.min(accepted, ENERGY_CAPACITY - energy));
            }
            return fill(accepted);
        }

        @Override
        public int extractEnergy(int toExtract, boolean simulate) {
            return 0;
        }

        @Override
        public int getEnergyStored() {
            return energy;
        }

        @Override
        public int getMaxEnergyStored() {
            return ENERGY_CAPACITY;
        }

        @Override
        public boolean canExtract() {
            return false;
        }

        @Override
        public boolean canReceive() {
            return energy < ENERGY_CAPACITY;
        }
    }

    /** 输出口：只能被拉走，不能灌进来（每 tick 按等级限流）。 */
    private final class OutputStorage implements IEnergyStorage {

        @Override
        public int receiveEnergy(int toReceive, boolean simulate) {
            return 0;
        }

        @Override
        public int extractEnergy(int toExtract, boolean simulate) {
            int offered = Math.min(toExtract, tier().outputLimit());
            if (simulate) {
                return Math.max(0, Math.min(offered, energy));
            }
            return drain(offered);
        }

        @Override
        public int getEnergyStored() {
            return energy;
        }

        @Override
        public int getMaxEnergyStored() {
            return ENERGY_CAPACITY;
        }

        @Override
        public boolean canExtract() {
            return energy > 0;
        }

        @Override
        public boolean canReceive() {
            return false;
        }
    }
}
