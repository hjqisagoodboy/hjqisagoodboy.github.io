package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.menu.FuelPortMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 燃料端口的内容：最多 8 支 LEU 燃料组件。
 *
 * <p>右键打开界面，界面里是 8 个燃料格 + 一条燃烧进度条——这条进度由压水堆控制器每 tick 推过来，
 * 看着它慢慢走完 6 分钟，就有一支 LEU 变成乏燃料组件。手拿燃料组件右键还是能直接塞。
 * 燃料烧坏了（压水堆超温）会原地变成一支【熔毁的燃料棒】，黑乎乎地留在端口里提醒你去清理。
 */
public class FuelPortBlockEntity extends BlockEntity implements Container, TickableBlockEntity, MenuProvider {

    /** 一个端口最多放 8 支。 */
    public static final int SLOTS = 8;

    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOTS, ItemStack.EMPTY);

    /** 当前这一支燃料烧到第几 tick（控制器推过来的，只给界面看，不进存档）。 */
    private int burnProgress;
    /** 一支燃料要烧多少 tick；0 表示没接上压水堆。 */
    private int burnMax;
    /** 上一次数燃料时有几支；界面直接读，省得每帧扫格子。 */
    private int cachedFuelCount;

    public FuelPortBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.FUEL_PORT.get(), pos, state);
    }

    // ------------------------------------------------------------------
    // 压水堆推过来的燃烧状态
    // ------------------------------------------------------------------

    /**
     * 压水堆控制器每 tick 调一次：把「这一支烧到哪了」写进端口，界面就能看见进度条。
     *
     * <p>不进存档、也不 setChanged：这些数字随时可以由控制器重新推一遍，
     * 用不着为了它每 tick 存一次盘。
     */
    public void setBurnState(int progress, int max) {
        this.burnProgress = Math.max(0, progress);
        this.burnMax = Math.max(0, max);
    }

    /** 这一支已经烧了多少 tick。 */
    public int burnProgress() {
        return this.burnProgress;
    }

    /** 一支燃料要烧多少 tick；0 = 没接上压水堆。 */
    public int burnMax() {
        return this.burnMax;
    }

    /** 这个端口现在接在压水堆上吗。 */
    public boolean isLinked() {
        return this.burnMax > 0;
    }

    /** 界面刷新时顺手更新一下燃料支数。 */
    public int refreshFuelCount() {
        this.cachedFuelCount = fuelCount();
        return this.cachedFuelCount;
    }

    /** 上一次数出来的燃料支数。 */
    public int cachedFuelCount() {
        return this.cachedFuelCount;
    }

    // ------------------------------------------------------------------
    // 右键交互
    // ------------------------------------------------------------------

    /** 手上拿着燃料组件就一支一支插进去；拿别的东西什么都不做。 */
    public boolean insertFromHand(Player player, ItemStack held) {
        if (!held.is(ModItems.LEU_FUEL_ASSEMBLY.get())) {
            return false;
        }
        int moved = 0;
        for (int i = 0; i < SLOTS && !held.isEmpty(); i++) {
            if (!this.items.get(i).isEmpty()) {
                continue;
            }
            this.items.set(i, held.copyWithCount(1));
            held.shrink(1);
            moved++;
        }
        if (moved > 0) {
            setChanged();
            player.displayClientMessage(Component.translatable("message.aftercritical.fuel_port.inserted",
                    moved, fuelCount()), true);
            return true;
        }
        player.displayClientMessage(Component.translatable("message.aftercritical.fuel_port.full"), true);
        return false;
    }

    /** 空手右键：把端口里的东西（燃料或熔毁的燃料棒）全还给玩家。 */
    public boolean takeAll(Player player) {
        int taken = 0;
        for (int i = 0; i < SLOTS; i++) {
            ItemStack stack = this.items.get(i);
            if (stack.isEmpty()) {
                continue;
            }
            if (!player.getInventory().add(stack.copy())) {
                player.drop(stack.copy(), false);
            }
            this.items.set(i, ItemStack.EMPTY);
            taken++;
        }
        if (taken > 0) {
            setChanged();
            player.displayClientMessage(Component.translatable("message.aftercritical.fuel_port.taken", taken), true);
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------
    // 给控制器看的数
    // ------------------------------------------------------------------

    /** 里面还有几支能烧的燃料。 */
    public int fuelCount() {
        int total = 0;
        for (ItemStack stack : this.items) {
            if (stack.is(ModItems.LEU_FUEL_ASSEMBLY.get())) {
                total += stack.getCount();
            }
        }
        return total;
    }

    /**
     * 烧完一支燃料：原地变成一块【乏燃料组件】，等着被拆掉、拿去后处理。
     *
     * <p>压水堆里的 LEU 组件烧满 20 分钟就「用到头了」，这时候取出来的是乏燃料，
     * 不是还能继续烧的燃料——后处理线就是从这儿开始的。
     */
    public boolean burnOneFuel() {
        for (int i = 0; i < SLOTS; i++) {
            if (!this.items.get(i).is(ModItems.LEU_FUEL_ASSEMBLY.get())) {
                continue;
            }
            this.items.set(i, new ItemStack(ModItems.SPENT_FUEL_ASSEMBLY.get()));
            setChanged();
            return true;
        }
        return false;
    }

    /** 烧坏一支燃料：换成一截熔毁的燃料棒。返回是否真的坏了一支。 */
    public boolean damageOneFuel() {
        for (int i = 0; i < SLOTS; i++) {
            if (!this.items.get(i).is(ModItems.LEU_FUEL_ASSEMBLY.get())) {
                continue;
            }
            ItemStack melted = new ItemStack(ModItems.MELTED_FUEL_ROD.get());
            this.items.set(i, melted);
            setChanged();
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------
    // Container
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return SLOTS;
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        setChanged();
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return stack.is(ModItems.LEU_FUEL_ASSEMBLY.get());
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    @Override
    public void serverTick() {
        // 燃料端口本身不用每 tick 干活，控制器会主动来数。
    }

    // ------------------------------------------------------------------
    // 界面
    // ------------------------------------------------------------------

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.fuel_port");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new FuelPortMenu(containerId, playerInventory, this);
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        ContainerHelper.saveAllItems(tag, this.items, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        ContainerHelper.loadAllItems(tag, this.items, registries);
    }
}
