package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import net.minecraft.core.NonNullList;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

/**
 * 「操作槽 + 返还槽」这一对罐子槽的全部逻辑，机器、储罐、级联控制器共用一份。
 *
 * <p>为什么单独拎出来：一样的事情在三台机器里各写一遍，迟早会出现「这台能叠 64、那台只能放 1 个」
 * 这种不一致。现在规矩只有一份：
 * <ul>
 *   <li>{@link #pour}：满罐 → 长条。倒空的罐子变回空罐、钻进返还槽；</li>
 *   <li>{@link #fill}：长条 → 空罐。灌满的罐子钻进返还槽；</li>
 *   <li>操作槽里是一叠罐子时，一个 tick 只处理最上面一个，处理完的往返还槽叠；</li>
 *   <li>返还槽满了 / 装的是别的流体时，操作槽里的罐子原地不动，等玩家清空返还槽，
 *       所以不会出现「罐子凭空消失」。</li>
 * </ul>
 */
public final class JarSlotService {

    private JarSlotService() {}

    /**
     * 把操作槽里的罐子往长条里倒。
     *
     * @return 这一 tick 真的倒了东西就返回 true
     */
    public static boolean pour(FluidTank tank, NonNullList<ItemStack> items, int opSlot, int retSlot) {
        ItemStack jar = items.get(opSlot);
        if (!(jar.getItem() instanceof UniversalTankItem)) {
            return false;
        }
        FluidStack stored = UniversalTankItem.getFluid(jar);
        if (stored.isEmpty()) {
            return false;
        }
        if (!tank.isEmpty() && !FluidStack.isSameFluidSameComponents(tank.getFluid(), stored)) {
            return false;
        }
        int space = tank.getCapacity() - tank.getFluidAmount();
        if (space <= 0) {
            return false;
        }
        int moved = Math.min(space, stored.getAmount());
        ItemStack leftover = UniversalTankItem.withFluid(jar, stored.getFluid(), stored.getAmount() - moved);
        boolean emptied = !UniversalTankItem.isFilled(leftover);
        // 一叠罐子只整罐整罐地倒；单罐可以从容地倒一半，剩下的留在操作槽
        if (jar.getCount() > 1 && !emptied) {
            return false;
        }
        if (emptied && !canDeliver(items, retSlot, leftover)) {
            return false;
        }
        int filled = tank.fill(stored.copyWithAmount(moved), IFluidHandler.FluidAction.EXECUTE);
        if (filled <= 0) {
            return false;
        }
        if (emptied) {
            deliver(items, opSlot, retSlot, leftover);
        } else {
            items.set(opSlot, UniversalTankItem.withFluid(jar, stored.getFluid(),
                    stored.getAmount() - filled));
        }
        return true;
    }

    /**
     * 从长条里灌满操作槽中的空罐。
     *
     * @return 这一 tick 真的灌了东西就返回 true
     */
    public static boolean fill(FluidTank tank, NonNullList<ItemStack> items, int opSlot, int retSlot) {
        if (tank.isEmpty()) {
            return false;
        }
        ItemStack jar = items.get(opSlot);
        if (!(jar.getItem() instanceof UniversalTankItem)) {
            return false;
        }
        int free = UniversalTankItem.freeSpace(jar);
        if (free <= 0) {
            return false;
        }
        FluidStack stored = tank.getFluid();
        if (!UniversalTankItem.accepts(jar, stored.getFluid())) {
            return false;
        }
        int moved = Math.min(free, stored.getAmount());
        if (moved <= 0) {
            return false;
        }
        boolean becomesFull = moved >= free;
        // 一叠空罐要整罐整罐地灌满才往外送，不然一半一半的罐子没法叠
        if (jar.getCount() > 1 && !becomesFull) {
            return false;
        }
        ItemStack filledJar = UniversalTankItem.withFluid(jar, stored.getFluid(),
                UniversalTankItem.getFluid(jar).getAmount() + moved);
        if (becomesFull && !canDeliver(items, retSlot, filledJar)) {
            return false;
        }
        FluidStack drained = tank.drain(moved, IFluidHandler.FluidAction.EXECUTE);
        if (drained.isEmpty()) {
            return false;
        }
        if (becomesFull) {
            deliver(items, opSlot, retSlot, filledJar);
        } else {
            items.set(opSlot, filledJar);
        }
        return true;
    }

    /** 返还槽还能不能再塞一个 {@code result}。 */
    public static boolean canDeliver(NonNullList<ItemStack> items, int retSlot, ItemStack result) {
        ItemStack ret = items.get(retSlot);
        if (ret.isEmpty()) {
            return true;
        }
        return ItemStack.isSameItemSameComponents(ret, result)
                && ret.getCount() < Math.min(ret.getMaxStackSize(), result.getMaxStackSize());
    }

    /**
     * 处理完的罐子从操作槽挪进返还槽。
     *
     * @return 挪成功返回 true
     */
    public static boolean deliver(NonNullList<ItemStack> items, int opSlot, int retSlot, ItemStack result) {
        if (!canDeliver(items, retSlot, result)) {
            return false;
        }
        ItemStack ret = items.get(retSlot);
        if (ret.isEmpty()) {
            items.set(retSlot, result.copyWithCount(1));
        } else {
            ret.grow(1);
        }
        ItemStack op = items.get(opSlot);
        op.shrink(1);
        if (op.isEmpty()) {
            items.set(opSlot, ItemStack.EMPTY);
        }
        return true;
    }
}
