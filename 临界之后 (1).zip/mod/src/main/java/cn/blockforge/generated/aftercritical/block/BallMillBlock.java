package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.BallMillBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/** 球磨机方块：LV，60 FE/t。 */
public class BallMillBlock extends MachineBlock {

    public BallMillBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(BallMillBlock::new);
    }

    @Override
    protected int energyPerTick() {
        return BallMillBlockEntity.ENERGY_PER_TICK;
    }

    @Override
    protected String recipeHintKey() {
        return "tooltip.aftercritical.ball_mill.recipes";
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new BallMillBlockEntity(pos, state);
    }
}
