package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.CascadeControllerBlockEntity;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 级联控制器的界面：三根流体长条（进料 / 产物 A / 产物 B），每根右边一对罐子槽。
 *
 * <p>0 号长条是进料罐：操作槽里放满罐就往里倒，倒空的罐子跑进返还槽；
 * 1、2 号是产物罐，操作槽里放空罐就会灌满，灌满的罐子跑进返还槽。
 *
 * <p>底部写着现在连着几台离心机、够不够电——离心机是用扫描找出来的，
 * 所以玩家挪动离心机之后，数字会在 1 秒内自己更新。
 */
public class CascadeControllerMenu extends AbstractMachineMenu implements FluidBarHost {

    /** 机器槽数量：三根长条 × 两个槽。 */
    public static final int MACHINE_SLOTS = CascadeControllerBlockEntity.SLOT_COUNT;

    @Nullable
    private final CascadeControllerBlockEntity controller;

    private final int[] tankAmount = new int[CascadeControllerBlockEntity.TANK_COUNT];
    private final int[] tankFluid = new int[CascadeControllerBlockEntity.TANK_COUNT];
    private int connected;

    private final ContainerData tankData = new ContainerData() {
        @Override
        public int get(int index) {
            if (index == CascadeControllerBlockEntity.TANK_COUNT * 2) {
                return connected;
            }
            int tank = index / 2;
            return index % 2 == 0 ? tankAmount[tank] : tankFluid[tank];
        }

        @Override
        public void set(int index, int value) {
            if (index == CascadeControllerBlockEntity.TANK_COUNT * 2) {
                connected = value;
                return;
            }
            int tank = index / 2;
            if (index % 2 == 0) {
                tankAmount[tank] = value;
            } else {
                tankFluid[tank] = value;
            }
        }

        @Override
        public int getCount() {
            return CascadeControllerBlockEntity.TANK_COUNT * 2 + 1;
        }
    };

    /** 服务端用。 */
    public CascadeControllerMenu(int containerId, Inventory playerInventory,
                                 CascadeControllerBlockEntity controller) {
        this(ModMenus.CASCADE_CONTROLLER.get(), containerId, playerInventory, controller, controller);
    }

    private CascadeControllerMenu(MenuType<?> type, int containerId, Inventory playerInventory,
                                  Container container, @Nullable CascadeControllerBlockEntity controller) {
        super(type, containerId, playerInventory, MACHINE_SLOTS, controller,
                CascadeControllerBlockEntity.TANK_COUNT);
        this.controller = controller;
        for (int i = 0; i < CascadeControllerBlockEntity.TANK_COUNT; i++) {
            this.addSlot(new OperateSlot(container, CascadeControllerBlockEntity.jarOpSlot(i),
                    jarOpX(i), jarY(i)));
            this.addSlot(new ReturnSlot(container, CascadeControllerBlockEntity.jarReturnSlot(i),
                    jarReturnX(i), jarY(i)));
        }
        this.addPlayerInventory(playerInventory);
        this.addDataSlots(this.tankData);
    }

    /** 客户端收到「打开菜单」的包后调用。 */
    public static CascadeControllerMenu fromNetwork(int containerId, Inventory playerInventory,
                                                    RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof CascadeControllerBlockEntity controller) {
            return new CascadeControllerMenu(ModMenus.CASCADE_CONTROLLER.get(), containerId, playerInventory,
                    controller, controller);
        }
        return new CascadeControllerMenu(ModMenus.CASCADE_CONTROLLER.get(), containerId, playerInventory,
                new SimpleContainer(CascadeControllerBlockEntity.SLOT_COUNT), null);
    }

    @Override
    public void broadcastChanges() {
        if (this.controller != null) {
            for (int i = 0; i < CascadeControllerBlockEntity.TANK_COUNT; i++) {
                this.tankAmount[i] = this.controller.getTankAmount(i);
                this.tankFluid[i] = this.controller.getTankFluidId(i);
            }
            this.connected = this.controller.getConnectedCount();
        }
        super.broadcastChanges();
    }

    // ------------------------------------------------------------------
    // 长条坐标（和流体机器用同一套尺子，右边一列对齐）
    // ------------------------------------------------------------------

    public static int barXOf(int tankIndex) {
        return MachineLayout.FLUID_X;
    }

    public static int barYOf(int tankIndex) {
        return MachineLayout.FLUID_TOP + tankIndex * MachineLayout.FLUID_STEP;
    }

    public static int jarOpX(int tankIndex) {
        return MachineLayout.FLUID_X + MachineLayout.FLUID_OP_DX;
    }

    public static int jarReturnX(int tankIndex) {
        return MachineLayout.FLUID_X + MachineLayout.FLUID_RET_DX;
    }

    public static int jarY(int tankIndex) {
        return barYOf(tankIndex) - 1;
    }

    // ------------------------------------------------------------------
    // FluidBarHost
    // ------------------------------------------------------------------

    @Override
    public int barCount() {
        return CascadeControllerBlockEntity.TANK_COUNT;
    }

    @Override
    public int barX(int index) {
        return barXOf(index);
    }

    @Override
    public int barY(int index) {
        return barYOf(index);
    }

    @Override
    public int barWidth(int index) {
        return MachineLayout.FLUID_BAR_W;
    }

    @Override
    public int barHeight(int index) {
        return MachineLayout.FLUID_BAR_H;
    }

    @Override
    public int barAmount(int index) {
        return getTankAmount(index);
    }

    @Override
    public int barFluidId(int index) {
        return getTankFluidId(index);
    }

    @Override
    public int barCapacity() {
        return getTankCapacity();
    }

    @Override
    public boolean barIsInput(int index) {
        return index == CascadeControllerBlockEntity.TANK_FEED;
    }

    public int getTankCount() {
        return CascadeControllerBlockEntity.TANK_COUNT;
    }

    public int getTankAmount(int index) {
        return index >= 0 && index < this.tankAmount.length ? this.tankAmount[index] : 0;
    }

    public int getTankFluidId(int index) {
        return index >= 0 && index < this.tankFluid.length ? this.tankFluid[index] : -1;
    }

    public int getTankCapacity() {
        return CascadeControllerBlockEntity.TANK_CAPACITY;
    }

    public int getConnected() {
        return this.connected;
    }

    public int getMaxCentrifuges() {
        return CascadeControllerBlockEntity.MAX_CENTRIFUGES;
    }

    /** 操作槽：只放通用流体罐，能叠 64 个。 */
    public static class OperateSlot extends Slot {

        public OperateSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.getItem() instanceof UniversalTankItem;
        }
    }

    /** 返还槽：只能拿，不能塞。 */
    public static class ReturnSlot extends Slot {

        public ReturnSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return false;
        }
    }
}
