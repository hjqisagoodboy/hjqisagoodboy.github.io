package cn.blockforge.generated.aftercritical.world;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * 「炸完还烫着」的那张临时表：每一发核弹起爆时在这里记一片圆形热区，
 * 过 {@value #HOT_TICKS} tick（10 分钟）就自动作废。
 *
 * <p>为什么要单独记一笔：焦土方块本身没有「我是几分钟前炸出来的」这种信息，
 * 而方块状态只有有限的几种取值，存不下一个精确的时间戳。所以反过来做——
 * 由爆炸这边记下「哪个位置、多大范围、什么时候炸的」，焦土被踩到时回头来问一句
 * 「我现在还烫吗」。好处是：
 * <ul>
 *   <li>焦土方块不用挂方块实体，几万块焦土也不会多占一点内存；</li>
 *   <li>方块状态、贴图、掉落都不动，旧存档里的焦土照样能认出是焦土；</li>
 *   <li>没被踩到的焦土完全不产生任何 tick 开销。</li>
 * </ul>
 *
 * <p>这张表跟着世界存档一起存盘（{@code data/aftercritical_scorched_heat.dat}），
 * 所以「炸完 10 分钟」是按世界自己的游戏时间算的：关服、存档都不会让冷却暂停。
 * 反过来，玩家离线期间世界时间照走，回来时如果已经过了 10 分钟，地上的焦土就是不烫的。
 *
 * <p>热区只认水平距离（不分高度）：焦土是铺在地表的一层，同一次爆炸里坑底和山头的焦土
 * 高度差得很远，用三维距离反而会把边缘漏判成「不烫」。
 */
public final class ScorchedHeatData extends SavedData {

    /** 炸完还烫多久：10 分钟。 */
    public static final int HOT_TICKS = 20 * 60 * 10;

    private static final String DATA_NAME = "aftercritical_scorched_heat";
    private static final String KEY_ZONES = "Zones";
    private static final String KEY_X = "X";
    private static final String KEY_Z = "Z";
    private static final String KEY_RADIUS = "Radius";
    private static final String KEY_EXPIRES_AT = "ExpiresAt";

    private static final SavedData.Factory<ScorchedHeatData> FACTORY =
            new SavedData.Factory<>(ScorchedHeatData::new, ScorchedHeatData::load);

    /** 一片还在烫的圆，{@code expiresAt} 之后就不算数了。 */
    private record HotZone(double x, double z, double radius, long expiresAt) {
        boolean covers(double px, double pz) {
            double dx = px - this.x;
            double dz = pz - this.z;
            return dx * dx + dz * dz <= this.radius * this.radius;
        }
    }

    private final List<HotZone> zones = new ArrayList<>();

    private ScorchedHeatData() {}

    /** 取这张表；这个世界第一次用到时才新建。 */
    public static ScorchedHeatData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(FACTORY, DATA_NAME);
    }

    /**
     * 记下一发爆炸：从这一 tick 起，半径以内炸出来的焦土烫 10 分钟。
     *
     * <p>顺手把已经到点的那几片清掉，免得玩家一局炸几十颗核弹，表越攒越长。
     *
     * @param core   爆心
     * @param radius 焦土铺开的最大半径（爆炸自己的焦土半径，不是挖掘半径）
     */
    public static void markBlast(ServerLevel level, BlockPos core, double radius) {
        ScorchedHeatData data = get(level);
        long now = level.getGameTime();
        data.zones.removeIf(zone -> zone.expiresAt() <= now);
        data.zones.add(new HotZone(core.getX() + 0.5, core.getZ() + 0.5, radius + 0.5, now + HOT_TICKS));
        data.setDirty();
    }

    /** 这一格焦土现在还烫不烫。 */
    public static boolean isHot(ServerLevel level, BlockPos pos) {
        ScorchedHeatData data = get(level);
        if (data.zones.isEmpty()) {
            return false;
        }
        long now = level.getGameTime();
        double px = pos.getX() + 0.5;
        double pz = pos.getZ() + 0.5;
        for (HotZone zone : data.zones) {
            if (zone.expiresAt() > now && zone.covers(px, pz)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (HotZone zone : this.zones) {
            CompoundTag entry = new CompoundTag();
            entry.putDouble(KEY_X, zone.x());
            entry.putDouble(KEY_Z, zone.z());
            entry.putDouble(KEY_RADIUS, zone.radius());
            entry.putLong(KEY_EXPIRES_AT, zone.expiresAt());
            list.add(entry);
        }
        tag.put(KEY_ZONES, list);
        return tag;
    }

    private static ScorchedHeatData load(CompoundTag tag, HolderLookup.Provider registries) {
        ScorchedHeatData data = new ScorchedHeatData();
        ListTag list = tag.getList(KEY_ZONES, Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            data.zones.add(new HotZone(entry.getDouble(KEY_X), entry.getDouble(KEY_Z),
                    entry.getDouble(KEY_RADIUS), entry.getLong(KEY_EXPIRES_AT)));
        }
        return data;
    }
}
