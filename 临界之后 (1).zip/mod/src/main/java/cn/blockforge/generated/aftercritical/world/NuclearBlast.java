package cn.blockforge.generated.aftercritical.world;

import cn.blockforge.generated.aftercritical.block.MeltedFuelRodStubBlock;
import cn.blockforge.generated.aftercritical.block.MoltenOreBlock;
import cn.blockforge.generated.aftercritical.blockentity.CoreRemnantBlockEntity;
import cn.blockforge.generated.aftercritical.effect.RadiationProtection;
import cn.blockforge.generated.aftercritical.network.BlastFlashPayload;
import cn.blockforge.generated.aftercritical.registry.ModBlocks;
import cn.blockforge.generated.aftercritical.registry.ModEffects;
import cn.blockforge.generated.aftercritical.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;

/**
 * 核爆：一次熔毁把 120 格以内全部推平，而且分好几百 tick 慢慢做。
 *
 * <h2>为什么不能直接调原版爆炸</h2>
 * 原版的「威力」不是半径，是一个数越大就越狠地反复射线扫描。要炸出 120 格的坑，
 * 威力得开到几百，一个 tick 内几百万次方块更新会直接把服务器卡死。
 * 所以这里自己写：把圆拆成一列一列的柱子，每 tick 只处理一小批，
 * 玩家看到的是地面从中心往外一格格塌下去，几秒钟推完。
 *
 * <h2>三个阶段</h2>
 * <ol>
 *   <li><b>挖</b>：半径以内，把每一列从地表挖到坑底。坑深按到爆心的水平距离收窄
 *       （中心最深、边缘 0 格），所以是一个碗不是一口井。地表以上的房子、树一起没。</li>
 *   <li><b>收尾</b>：挖完的下一 tick 一次性搞定——把悬在空中的堆芯残骸挪下来、
 *       在爆心 10 格内的地上撒几块新残骸、在 30 格内把熔毁的燃料棒插进土里、
 *       再清掉 200 格内所有掉落物。</li>
 *   <li><b>扫尾</b>：从半径往外一圈圈扫。内侧过渡带
 *       （七成自然方块变污染土/烧结砂，树变焦木、树叶消失）；外沿只落
 *       一成概率的辐射尘。</li>
 * </ol>
 * 换水不在上面这三段里，它是<b>跟挖坑同时跑</b>的一趟独立队列（见下面的「炸完留下什么」）。
 *
 * <h2>坑为什么不再是梯田</h2>
 * 原来「每列挖多深只由到爆心的距离决定」，坑壁就是一圈圈完美的同心圆台阶。
 * 现在叠了三层随机（全在 {@code column} 里，都是整数哈希算出来的，不用随机数表）：
 * <ul>
 *   <li><b>低频噪声</b>：每 18 格一个平滑抖动的值、两个八度，每列深度乘 {@code 1+0.3×噪声}，
 *       坑底成了起伏的碗；</li>
 *   <li><b>轮廓噪声</b>：半径乘 {@code 1+0.09×噪声}，坑沿犬牙交错，不再是个圆；</li>
 *   <li><b>逐列抖动</b>：每列再随机 ±3 格，3% 的列额外多挖 6~12 格（炸穿的深井）；</li>
 *   <li><b>边缘碎裂带</b>：0.82R 到坑沿之间，整列不挖的概率从 10% 升到 90%，坑口是碎的；</li>
 *   <li><b>中心残堆</b>：爆心 12% 半径内留几坨没炸透的石柱，坑底就不那么平。</li>
 * </ul>
 * 每列只多几十次乘加，扫的列数没变，所以每 tick 的方块预算照旧卡在 6000。
 *
 * <h2>炸完留下什么</h2>
 * <ul>
 *   <li>爆心 0~131 格（抽干区）里的水 → <b>直接删成空气</b>。整列从地表一直扫到世界底面：
 *       海面、海底、山里的地下水、山洞里的水塘，全都不放过——玩家要的就是「坑里一滴水都没有」，
 *       空心的水墙、慢慢下降的水面，根子都是这一片水没删干净。水下植物（海带、海草、海泡菜、珊瑚）
 *       也一起删掉；抽干区再往外 8 格还删一条隔离带，外围的核废水得翻过这条干坡才流得进来；</li>
 *   <li>抽干区以外、辐射尘外沿（180 格）以内的水 → 统一换成 <b>核废水</b>（灰黑半透明，泡着吃辐射），
 *       所以海上炸完仍是一圈黑水；水下植物一律删掉；过渡带、辐射尘带的水都算——
 *       海上落不了辐射尘，那就让它变脏水；</li>
 *   <li><b>含水方块也算水</b>：滴水石锥、发光地衣、含水楼梯、栅栏这些「方块留着、水泡在里面」
 *       的（waterlogged），方块名根本不叫「水」。以前它们被当成普通方块跳过去，水抽不掉、
 *       也不会变黑，还一直在往外渗——玩家看到的「水一直消失又一直出现」就是这个。
 *       现在抽干区里：含水的发光地衣、水下植物直接删，其余含水方块把水放干、方块留下；
 *       外圈则整格换成核废水，跟旁边的黑水连成一片；</li>
 *   <li>坑里（120 格以内）的水 → 跟着挖掘一起挖成空气，坑先见底；</li>
 *   <li><b>全程抽水</b>：每 tick 有一支巡检队在抽干区的列里转圈，见到水 / 核废水就删成空气，
 *       每 tick 限读 20 万格，海面那片十几秒就能转一圈。挖坑挖到哪儿、水从哪边渗回来，
 *       下一圈就把它抽走，不会再「先抽干、再慢慢积水」。巡检至少扫完两整圈，这次核爆才算结束；</li>
 *   <li>核爆自己烧出来的焦土、辐射焦土、污染土、烧结砂、焦木、辐射尘、堆芯残骸、燃料棒残桩
 *       <b>不再是无敌方块</b>：第二发炸上去照挖照烧，跟普通地貌一样。以前它们挂在保护名单里，
 *       第二发只把它们底下的方块变成焦土，自己纹丝不动；</li>
 *   <li>坑里的岩浆 → <b>核熔废水</b>（深绿、发光、又烫又脏），压成贴坑底的薄薄一层，
 *       最多两格厚，不会像柱子一样悬在半空；</li>
 *   <li>过渡带（120~130 格）的岩浆 → 原地变核熔废水；辐射尘带（130~180 格）
 *       只往地上落一层薄灰；</li>
 *   <li>爆心 100 格内的坑底、坑壁往下 24 格：煤矿 → 核熔的钻石矿 / 核熔的绿宝石矿，
 *       原版的钻石矿、绿宝石矿 → 对应那种核熔矿，其它矿物一律烧成焦土 / 辐射焦土。
 *       只扫「炸开露出来」的这一小段，整层地下去扫会卡死服务器。</li>
 * </ul>
 *
 * <h2>焦土怎么分层</h2>
 * <ul>
 *   <li>爆心 100 格以内：自然方块一律换成焦土 / 辐射焦土（黑灰色），树直接烧没；</li>
 *   <li>100~130 格：三成保持原样，七成变污染土（土）或烧结砂（沙）；</li>
 *   <li>130 格以外：不换方块，只有 10% 的柱子上会多一层薄薄的辐射尘。</li>
 * </ul>
 * 数「三层」的时候只数土 / 沙 / 石头，所有植物（陆地的、水下的）一律不算层，
 * 水也不算——所以焦土能一路烤到海底的沙子，海带海草挡不住。
 *
 * <p>挖掘用 {@code UPDATE_CLIENTS} 标志：只把变化推给客户端，不连锁触发方块更新。
 * 不这样的话上百万个方块每个都去喊一遍邻居，水会漫、沙子会掉、红石会跳，卡到没法玩。
 * 中心区的水也不再「叫醒」了——上一版就是给坑边的水开更新，水才顺着坑壁慢慢往下掉、
 * 看着像一根悬空的黑水柱。现在中心区的水只由抽水巡检直接删，不给它流动的机会。
 *
 * <p>任务只存在内存里：服务器要是正好在爆炸中途关掉，剩下的格子就不会再挖了
 * （已经挖掉的照常存档）。这是有意的取舍——不往存档里塞一大堆临时数据。
 */
public final class NuclearBlast {

    /** 破坏半径（格）。这是水平半径，也是一次核爆的总口径。 */
    public static final int DESTROY_RADIUS = 120;
    /** 爆心「全焦土」半径（格）。这一圈同时也是「必死圈」：圈内生物当场气化，创造/旁观除外。 */
    public static final int SCORCH_RADIUS = 100;
    /** 过渡带外沿（格）：七成污染土 / 烧结砂 + 焦木。 */
    public static final int TRANSITION_RADIUS = 130;
    /** 落辐射尘的外沿（格）。 */
    public static final int FALLOUT_RADIUS = 180;
    /** 坑深占半径的比例：半径 120 时正好挖 42 格深。 */
    private static final double CRATER_DEPTH_RATIO = 0.35;
    /** 地表以上还要清多高（房子、树、高塔）。 */
    private static final int SCAN_ABOVE = 64;
    /** 坑底往下做几层焦壳（只数地面方块，树叶树干不算层数）。 */
    private static final int SHELL_DEPTH = 3;
    /**
     * 坑底、坑壁往下多少格之内做「矿物转化」。
     *
     * <p>这就是玩家说的「只有炸开露出来的矿才会变」：只扫坑底往下 24 格，
     * 而不是把 100 格半径下面那几百万格地下整个翻一遍——那样服务器会直接卡死，
     * 而且玩家永远也看不见。核爆后站在坑底往下挖，就能碰到核熔钻石矿、核熔绿宝石矿。
     */
    private static final int ORE_SCAN_DEPTH = 24;
    /** 烤焦 / 扫尾时最多往下扫多少格（防止一片树冠把整根柱子扫穿）。 */
    private static final int SCORCH_SCAN = 48;
    /** 过渡带里「七成」的百分比。 */
    private static final int TRANSITION_PERCENT = 70;
    /** 落辐射尘的概率百分比。 */
    private static final int FALLOUT_PERCENT = 10;
    /**
     * 坑里的岩浆换成的核熔废水最多铺几格厚。
     *
     * <p>原来是一格岩浆换一格废水，湖底挖空以后整列悬在天上。现在压成贴坑底的薄层：
     * 两格厚足够看出「坑底积了一锅汤」，又不会堆成柱子。
     */
    private static final int MOLTEN_LAYER_CAP = 2;
    /** 爆心附近撒几块熔融的堆芯残骸。 */
    private static final int CORE_REMNANT_COUNT = 3;
    /** 堆芯残骸撒在爆心几格以内。 */
    private static final double CORE_REMNANT_SPREAD = 10.0;
    /** 熔毁的燃料棒插在爆心几格以内。 */
    private static final double FUEL_ROD_SPREAD = 30.0;
    /** 清掉落物的半径（格）。 */
    public static final double CLEANUP_RADIUS = 200.0;
    /** 全屏爆闪（连同暖色滤镜、镜头抖、视野冲击）能传多远（格）。 */
    private static final double FLASH_RADIUS = 512.0;

    /*
     * 下面这几个数是「别把坑炸成梯田」用的，全在 {@link #column} 里生效。
     */

    /** 低频深度噪声的强度：每列深度乘 {@code 1 + 0.3 × 噪声}，坑底变成起伏的碗。 */
    private static final double DEPTH_NOISE = 0.3;
    /** 深度噪声的格子大小（格）：每 18 格一个平滑抖动的值，两个八度。 */
    private static final int DEPTH_NOISE_CELL = 18;
    /** 坑沿轮廓噪声的强度：半径乘 {@code 1 + 0.09 × 噪声}，坑沿犬牙交错。 */
    private static final double EDGE_NOISE = 0.09;
    /** 轮廓噪声的格子大小（格）。 */
    private static final int EDGE_NOISE_CELL = 24;
    /** 逐列深度抖动：每列再随机 ±3 格。 */
    private static final int COLUMN_JITTER = 3;
    /** 会炸出「深井」的列占比（百分比）。 */
    private static final int DEEP_WELL_PERCENT = 3;
    /** 深井最少多挖几格、最多再多挖几格（合起来是 6~12 格）。 */
    private static final int DEEP_WELL_MIN = 6;
    private static final int DEEP_WELL_EXTRA = 7;
    /** 边缘碎裂带从 0.82R 开始，挖的概率从 90% 掉到 10%。 */
    private static final double BREAK_START_RATIO = 0.82;
    private static final double BREAK_NEAR_CHANCE = 0.90;
    private static final double BREAK_FAR_CHANCE = 0.10;
    /*
     * 爆心那一坨「没炸透的残堆」。
     *
     * 上一版是全写死的：位置固定（种子写死）、阈值固定、每根高矮也几乎一样，
     * 所以每次炸完坑底都是同一丛冲天石柱——玩家管这叫「固定留下柱子」。
     * 现在这三个数（留不留、留多高、留多大一圈）每次核爆各摇一次，
     * 噪声种子也跟着摇，于是这一炮可能是一地矮土包，下一炮干脆一个都没有。
     */

    /** 残堆的范围（占半径的比例）：每次在 16%~30% 里摇一个。 */
    private static final double PILLAR_ZONE_MIN = 0.16;
    private static final double PILLAR_ZONE_MAX = 0.30;
    /** 残堆噪声的格子：7 格一团，残堆是成片的土包，不是一根根针。 */
    private static final int PILLAR_NOISE_CELL = 7;
    /** 残堆噪声超过这个值才留：每次在 0.32~0.70 里摇，摇高了就是一个包都不留。 */
    private static final double PILLAR_THRESHOLD_MIN = 0.32;
    private static final double PILLAR_THRESHOLD_MAX = 0.70;
    /** 残堆留多高：这一列本该挖下去多少的比例，再乘一个逐列的乱数，所以高矮不齐。 */
    private static final double PILLAR_RETAIN_MIN = 0.06;
    private static final double PILLAR_RETAIN_MAX = 0.16;
    /** 残堆最高几格（6 + 半径 × 5%：半径 193 约 16 格），再高就成冲天柱子了。 */
    private static final double PILLAR_CAP_BASE = 6.0;
    private static final double PILLAR_CAP_PER_RADIUS = 0.05;

    /**
     * 每 tick 最多处理几列。
     *
     * <p>实际预算按坑深往下调：每 tick 大约改 {@link #BLOCKS_PER_TICK_BUDGET} 个方块，
     * 坑越深、一列要挖的方块越多，一 tick 就少挖几列。这样熔毁（半径 120、深 42）
     * 还是原来的速度，而沙皇（半径 300、深 155）不会一 tick 改十几万个方块把服务器打死。
     */
    private static final int COLUMNS_PER_TICK = 100;
    /** 每 tick 大约改多少个方块（6000 大约是一台普通服务器能连续扛住的量级）。 */
    private static final int BLOCKS_PER_TICK_BUDGET = 6000;
    /**
     * 换水每 tick 最多走几列。
     *
     * <p>真正的上限是下面那个「扫描格子」预算——现在一列要从地表一路读到世界底面，
     * 读方块也是要花时间的，光按列数限速挡不住。
     */
    private static final int WATER_COLUMNS_PER_TICK = 800;
    /**
     * 换水每 tick 最多读几格。
     *
     * <p>整列扫穿以后，一列不再是「几十格水」而是「四百格高度」：不按扫描量限速的话，
     * 一百八十格半径那一圈一次要读几千万格，服务器会当场卡住。
     * 一个 16 格高的段落里要是压根没有水，整段直接跳过（{@code maybeHas}），
     * 所以陆地上实际读得很少，这个预算主要防的是大海。
     */
    private static final int WATER_CELLS_PER_TICK = 120_000;
    /** 换水每 tick 最多改几个方块（写方块比读贵，单独卡一道）。 */
    private static final int WATER_BLOCKS_PER_TICK = 6000;
    /** 换掉一格水按几格扫描算（写方块比读方块贵得多）。 */
    private static final int WATER_CHANGE_COST = 4;
    /** 换水队列的列坐标偏移（半径 300 的沙皇展开到 450 格，还塞得下）。 */
    private static final int WATER_OFFSET = 512;
    /** 一列最多往下扫多少格（世界高 384，-64 到 320 正好扫完）。 */
    private static final int WATER_SCAN_DEPTH = 384;
    /**
     * 爆心「抽干区」半径占破坏半径的比例：半径 120 时约 131 格。
     *
     * <p>坑沿还有 ±9% 的犬牙噪声，所以抽干区要比名义半径再大一圈，把整圈坑壁都盖进去。
     * 这一圈里的水一律删成空气（山里的地下水、洞穴里的水塘也一起删），
     * 外面那一圈才染成核废水——玩家要的「黑水围一圈」还在。
     */
    private static final double PURGE_RADIUS_RATIO = 131.0 / DESTROY_RADIUS;
    /**
     * 抽干区外面再删几格宽的隔离带（格）。
     *
     * <p>不删这一圈的话，挖完一眨眼外围的核废水就贴着坑壁灌回来，坑里又积水。
     * 留出一条干坡，水要翻过坡才流得进来，玩家看到的就是「坑一直干着」。
     */
    private static final int PURGE_BAND = 8;
    /**
     * 抽干巡检每 tick 最多读几格。
     *
     * <p>中心区有一万多列、一列读到世界底面，全读一遍是几千万格。按 20 万格一 tick 限速，
     * 十几秒就能转完一圈；而且大部分段落是空气或石头，靠 {@code maybeHas} 整段跳过，
     * 实际开销比这个上限小得多。
     */
    private static final int PURGE_CELLS_PER_TICK = 200_000;
    /**
     * 抽干巡检至少要扫完几整圈，这次核爆才算结束。
     *
     * <p>只扫一圈不够：坑是边挖边塌的，挖到后半程，前面已经抽干的列可能又被渗回来的水灌上。
     * 两圈的意思是——第一圈把原有的水抽光，第二圈在坑挖开以后回头确认一遍，看到渗回来的水再抽掉。
     * 不过这个数只卡「结束」，真要碰上局部区块没加载，还是由 {@code maxTicks} 兜底收工。
     */
    private static final int PURGE_MIN_SWEEPS = 2;
    /** 扫尾阶段每 tick 处理几列（一列只查几个方块，可以快一点）。 */
    private static final int FALLOUT_COLUMNS_PER_TICK = 260;
    /** 最多花多久推完：基础 3000 tick，半径越大给得越多（沙皇约 6 分钟，区块一直不加载就不等了）。 */
    private static final int MAX_TICKS_BASE = 3000;
    /** 爆心一瞬间的伤害上限（一件不穿、站在正中心就是这个数）。只在焦土圈以外使用。 */
    private static final float MAX_PLAYER_DAMAGE = 45.0F;
    /**
     * 焦土圈内那刀「必死」的伤害值。
     *
     * <p>用一个十亿而不是 {@link Float#MAX_VALUE}：护甲最多减 80%、附魔再减一点，
     * 减完照样远超凡人的血量，又不会让加法溢出成 Infinity 那种脏数据。
     */
    private static final float LETHAL_DAMAGE = 1.0E9F;
    /** 熔毁瞬间的辐射持续多久（30 秒）。 */
    private static final int RADIATION_TICKS = 30 * 20;

    /** 只推客户端，不连锁更新邻居。 */
    private static final int UPDATE_FLAGS = Block.UPDATE_CLIENTS;
    /** 世界最小/最大高度之间的安全边距，别把基岩层下面的空腔也挖了。 */
    private static final int BOTTOM_MARGIN = 1;

    private static final List<Task> TASKS = new ArrayList<>();

    private NuclearBlast() {}

    /** 服务端每 tick 推进一步（由主类挂到 ServerTickEvent.Post 上）。 */
    public static void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        tick(server);
        MushroomCloud.tick(server);
        FalloutDust.tick(server);
        FalloutExposure.tick(server);
    }

    /**
     * 起爆：立刻结算冲击波（伤害、辐射、声音、闪光），再把挖掘排进队列。
     *
     * <p>先算冲击波是为了「人先被掀飞，地再塌」，顺序反过来会看到玩家站在半空掉下去。
     */
    public static void start(ServerLevel level, BlockPos core, BlockPos anchor) {
        start(level, core, anchor, DESTROY_RADIUS, 0);
    }

    /**
     * 起爆（指定半径）。
     *
     * <p>半径是参数而不是写死的，是为了以后加核弹：核弹物品只要调
     * {@code NuclearBlast.start(level, pos, null, 半径)} 就能沿用这一整套
     * 挖掘、焦土、清场和蘑菇云，换的只是数字。
     */
    public static void start(ServerLevel level, BlockPos core, BlockPos anchor, int radius) {
        start(level, core, anchor, radius, 0);
    }

    /**
     * 起爆（半径 + 要撒几截熔毁燃料棒）。
     *
     * <p>{@code fuelRods} 是熔毁时堆里烧坏的燃料棒数量：这些燃料棒不再当掉落物吐出来，
     * 而是被炸飞、一头扎进爆心 30 格内的焦土里，玩家得自己去掰。
     */
    public static void start(ServerLevel level, BlockPos core, BlockPos anchor, int radius, int fuelRods) {
        start(level, core, anchor, radius, fuelRods, craterDepth(radius), RADIATION_TICKS);
    }

    /**
     * 起爆（半径 + 燃料棒 + 坑深 + 辐射时长）。
     *
     * <p>核弹走这一条：当量越大，{@code depth} 越深（沙皇 155 格，熔毁才 42 格），
     * 辐射也按当量拉长。蘑菇云跟着半径和坑深一起放大。
     */
    public static void start(ServerLevel level, BlockPos core, BlockPos anchor, int radius, int fuelRods,
                             int depth, int radiationTicks) {
        BlockPos center = core.immutable();
        int safeDepth = Math.max(1, depth);
        TASKS.add(new Task(level, center, anchor == null ? null : anchor.immutable(), radius, fuelRods,
                safeDepth));
        shockwave(level, center, radius, radiationTicks, anchor != null);
        flash(level, center);
        // 熔毁那一朵固定 30 秒；核弹按当量走（600 + 半径 × 6 tick）
        MushroomCloud.start(level, center, radius, safeDepth,
                anchor != null ? MushroomCloud.MELTDOWN_DURATION : MushroomCloud.durationFor(radius));
        FalloutDust.start(level, center, radius);
        // 这一发炸出来的焦土只烫 10 分钟：在这里登记一片热区，到点自动凉掉（见 ScorchedHeatData）。
        // 熔毁走的是同一个 start，所以熔毁坑口的焦土也是烫 10 分钟，一视同仁。
        ScorchedHeatData.markBlast(level, center, scorchRadius(radius));
    }

    /** 这个半径该挖多深（半径 120 → 42 格）。 */
    private static int craterDepth(int radius) {
        return (int) Math.round(radius * CRATER_DEPTH_RATIO);
    }

    /** 半径 120 的爆炸里，100 格「全焦土」线换算到这个半径是多少格。 */
    private static double scorchRadius(int radius) {
        return radius * (SCORCH_RADIUS / (double) DESTROY_RADIUS);
    }

    /** 过渡带外沿（半径 120 时 130 格）。 */
    private static double transitionRadius(int radius) {
        return radius * (TRANSITION_RADIUS / (double) DESTROY_RADIUS);
    }

    /** 辐射尘外沿（半径 120 时 180 格）。 */
    private static double falloutRadius(int radius) {
        return radius * (FALLOUT_RADIUS / (double) DESTROY_RADIUS);
    }

    private static void tick(MinecraftServer server) {
        if (TASKS.isEmpty()) {
            return;
        }
        Iterator<Task> iterator = TASKS.iterator();
        while (iterator.hasNext()) {
            Task task = iterator.next();
            if (task.level.getServer() != server) {
                continue;
            }
            if (task.tick()) {
                iterator.remove();
            }
        }
    }

    // ------------------------------------------------------------------
    // 一瞬间的部分：冲击波 + 全屏爆闪
    // ------------------------------------------------------------------

    /**
     * 冲击波：焦土圈以内直接蒸发，圈外按距离结算伤害。
     *
     * <p>规则：
     * <ul>
     *   <li><b>焦土圈以内</b>（{@link #scorchRadius}，半径 120 时正好 100 格）：所有生物当场清血，
     *       <b>不看护甲、不看附魔、不看防护服、不看抗性药水，连不死图腾也挡不住</b>。
     *       站在爆心就是「气化」，不会再有「穿齐防护服活下来、然后被塌方摔死」这种死法；</li>
     *   <li><b>焦土圈到破坏半径之间</b>：还是老规矩，玩家按 {@code (1 - 距离/半径)^1.35}
     *       吃 0～45 点爆炸伤害，穿齐防护服只吃 35%——这一圈本来就该活得下来；</li>
     *   <li><b>创造模式 / 旁观者</b>：不吃任何伤害，只闪屏、被掀一下、看提示。</li>
     * </ul>
     */
    private static void shockwave(ServerLevel level, BlockPos core, int blastRadius, int radiationTicks,
                                  boolean meltdown) {
        Vec3 center = Vec3.atCenterOf(core);
        double radius = blastRadius;
        double lethal = scorchRadius(blastRadius);
        List<LivingEntity> victims = level.getEntitiesOfClass(LivingEntity.class,
                new AABB(core).inflate(radius));

        for (LivingEntity living : victims) {
            double distance = living.position().distanceTo(center);
            if (distance > radius) {
                continue;
            }
            double falloff = 1.0 - distance / radius;

            // 创造模式 / 旁观：炸不死，只给提示 + 掀一下（连辐射都不挂）
            if (living instanceof ServerPlayer immune && (immune.isCreative() || immune.isSpectator())) {
                immune.displayClientMessage(meltdown
                        ? Component.translatable("message.aftercritical.reactor.meltdown")
                        : Component.translatable("message.aftercritical.nuke.blast", blastRadius), false);
                knockback(immune, center, falloff);
                continue;
            }

            // 焦土圈以内：必死。距离只影响闪屏亮度，不影响死活。
            if (distance <= lethal) {
                vaporize(level, living);
                continue;
            }

            if (living instanceof ServerPlayer player) {
                float damage = (float) (MAX_PLAYER_DAMAGE * Math.pow(falloff, 1.35)
                        * RadiationProtection.blastMultiplier(player));
                if (damage >= 0.5F) {
                    player.hurt(level.damageSources().explosion(null, null), damage);
                }
                // 辐射：穿齐四件就一点都不沾
                if (!RadiationProtection.isFullSuit(player)) {
                    player.addEffect(new MobEffectInstance(ModEffects.RADIATION_CONTAMINATION,
                            radiationTicks, 0));
                }
                player.displayClientMessage(meltdown
                        ? Component.translatable("message.aftercritical.reactor.meltdown")
                        : Component.translatable("message.aftercritical.nuke.blast", blastRadius), false);
                knockback(player, center, falloff);
            } else {
                living.hurt(level.damageSources().explosion(null, null), 1000.0F);
                if (living.isAlive()) {
                    living.discard();
                }
            }
        }

        // 响声：用户自己录的那一整段 70 秒核爆（主冲击 + 余震 + 低频隆隆 + 尾音）。
        // 音量 64 不是「吵 64 倍」，而是拿它当传播范围用：一条声音能被发到多远的玩家是
        // 「音量 × 16」格，衰减到头的位置是「音量 × attenuation_distance」（见 sounds.json 里的 16）。
        // 两样乘出来正好都是 1024 格，跟蘑菇云的发包半径一致——看得见那朵云的地方就听得见响，
        // 再远一起消失。所以不再叠原版那两声爆炸音效：它们会盖在这段录音的主冲击上面。
        level.playSound(null, core, ModSounds.NUKE_EXPLOSION.get(), SoundSource.BLOCKS, 64.0F, 1.0F);
        // 只用爆炸烟，不再用 FLASH 粒子：那玩意在一百格外会渲染成一个白方块
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER,
                core.getX() + 0.5, core.getY() + 1.0, core.getZ() + 0.5, 12, 10.0, 6.0, 10.0, 0.0);
    }

    /**
     * 焦土圈内的一刀必死：不管穿了什么。
     *
     * <p>原版那套减伤是「护甲 → 附魔 → 抗性 → 伤害吸收」，一路按比例往下砍，
     * 而 {@code hurt} 结尾才判不死图腾，图腾只认「血量是不是见底」，不看伤害类型。
     * 所以这里按顺序拆干净：
     * <ol>
     *   <li>先扒掉所有药水效果（抗性提升、防火、伤害吸收）和附魔金苹果的护盾；</li>
     *   <li>一刀 {@link #LETHAL_DAMAGE} 的爆炸伤害——护甲、附魔再怎么减也减不成能活下来的数，
     *       顺便让死亡信息正确写成「被爆炸炸死」；</li>
     *   <li>图腾挡下之后就清了无敌帧再补一刀（两只手各一个也补得完，最多三刀）；</li>
     *   <li>到头来还活着的非玩家（比如某些免疫伤害的生物）直接移出世界。</li>
     * </ol>
     */
    private static void vaporize(ServerLevel level, LivingEntity living) {
        living.removeAllEffects();
        living.setAbsorptionAmount(0.0F);
        for (int i = 0; i < 3 && living.isAlive(); i++) {
            living.invulnerableTime = 0;
            living.hurt(i == 0 ? level.damageSources().explosion(null, null)
                    : level.damageSources().genericKill(), LETHAL_DAMAGE);
        }
        if (living.isAlive() && !(living instanceof ServerPlayer)) {
            living.discard();
        }
    }

    /**
     * 全屏爆闪：给 512 格内的每个玩家发一个「白幕」包，越近越亮。
     *
     * <p>不能用原版 {@code FLASH} 粒子代替——那个粒子在远处会变成一个白色方块，
     * 上一版就是这么翻车的。白幕是客户端直接在屏幕上盖一层白，跟距离无关不会变形。
     *
     * <p>这个包只是个「开炮」信号：它出发之后，客户端自己的时间轴走 70 秒
     * （纯白 → 橙色火球 → 暖色滤镜 → 慢慢退干净，加上镜头抖和视野冲击），
     * 具体曲线全在 {@code BlastFxState} 里，这里只管「离爆心多近」这一个数。
     * 距离越近，那 70 秒里的每一样都会更猛一点；最远的玩家也保留三成，不至于什么都看不见。
     */
    private static void flash(ServerLevel level, BlockPos core) {
        Vec3 center = Vec3.atCenterOf(core);
        for (ServerPlayer player : level.players()) {
            double distance = player.position().distanceTo(center);
            if (distance > FLASH_RADIUS) {
                continue;
            }
            float intensity = (float) Math.pow(1.0 - distance / FLASH_RADIUS, 1.5);
            PacketDistributor.sendToPlayer(player, new BlastFlashPayload(intensity));
        }
    }

    /** 把玩家从爆心往外掀，越近掀得越狠。 */
    private static void knockback(ServerPlayer player, Vec3 center, double falloff) {
        Vec3 away = player.position().subtract(center);
        Vec3 flat = away.lengthSqr() < 1.0E-4
                ? new Vec3(1.0, 0.0, 0.0)
                : away.normalize();
        player.setDeltaMovement(player.getDeltaMovement()
                .add(flat.x * falloff * 3.5, 0.4 + falloff * 1.4, flat.z * falloff * 3.5));
        player.hurtMarked = true;
    }

    // ------------------------------------------------------------------
    // 慢慢挖的部分
    // ------------------------------------------------------------------

    /** 一次核爆要走的三个阶段。 */
    private enum Phase {
        /** 半径内一列一列挖空。 */
        DIG,
        /** 挖完的一次性收尾：挪残骸、插燃料棒、清掉落物。 */
        SETTLE,
        /** 往外扫尾：过渡带 + 辐射尘。 */
        FALLOUT,
        /** 结束。 */
        DONE
    }

    /** 一次核爆的进度。 */
    private static final class Task {
        private final ServerLevel level;
        private final BlockPos core;
        /** 堆芯残骸的原位置（控制器那一格）：挖完之后要把它挪到地上。 */
        @Nullable
        private final BlockPos anchor;
        /** 这次核爆的半径。 */
        private final int radius;
        /** 坑深（格）：从爆心往下挖多少。核弹比熔毁深得多。 */
        private final int depth;
        /** 每 tick 处理几列：坑越深，一列越费，预算就往下调。 */
        private final int columnsPerTick;
        /** 这次核爆最多走多少 tick（半径越大给得越多）。 */
        private final int maxTicks;
        /** 烧坏的燃料棒数量：挖完之后在爆心 30 格内插成残桩。 */
        private final int fuelRods;
        /**
         * 这次核爆是不是「玩家起爆的核弹」。
         *
         * <p>区分办法就是看有没有传 anchor：反应堆熔毁要传控制器那一格（残骸要挪到地上），
         * 核弹没有残骸，传的是 {@code null}。核熔矿会把这个值写进方块状态里，
         * 成就「轮回」只认 {@code true} 的那一批。
         */
        private final boolean fromNuke;
        /** 全焦土 / 过渡带 / 辐射尘三条线，按半径等比换算。 */
        private final double scorchR;
        private final double transitionR;
        private final double falloutR;
        /** 待处理的列，packed = (dx + 512) << 16 | (dz + 512)。 */
        private final Deque<Integer> digQueue;
        /** 扫尾阶段的列，挖完之后才建。 */
        private final Deque<Integer> falloutQueue = new ArrayDeque<>();
        /**
         * 换水队列：爆心 0~辐射尘外沿的每一列，按距离从近到远排好。
         *
         * <p>打包成 {@code 距离平方 << 32 | 列坐标} 存进 long 数组——沙皇半径 300 时
         * 这一圈有六十多万列，用 {@code Integer} 装箱会白白多吃十几兆内存。
         * 换水跟挖坑同时推进，但跑得更快，永远在坑前面。
         */
        private final long[] waterQueue;
        private int waterCursor;
        /** 区块还没加载的列，等主要范围扫完再回头补。 */
        private final Deque<Integer> waterRetry = new ArrayDeque<>();
        /**
         * 中心「抽干区」半径（格）：这一圈里的水全删成空气，连山里的地下水一起。
         *
         * <p>不再像上一版那样「给水开更新、让水自己灌回来」——那一脚正是水墙、
         * 水位慢慢往下掉的来源。现在中心区的水只有一条出路：被删掉。
         */
        private final double purgeR;
        /** 换水队列里前多少列属于抽干区（含隔离带）。队列按距离排好，数一段前缀就行。 */
        private final int purgeColumns;
        /** 抽干巡检的游标：在中心区的列里一圈一圈地转，转到头再从头来。 */
        private int purgeCursor;
        /** 抽干巡检已经转完几整圈（游标归零时 +1，用来判断能不能收工）。 */
        private int purgeSweeps;
        /** 这一 tick 里换掉了几格水（{@link #floodColumn} 顺手记的，算扫描预算用）。 */
        private int waterChanged;
        private final BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        /*
         * 这一次核爆自己的噪声种子和残堆参数。
         *
         * 以前这三套种子是写死的常量，所以不管在哪儿炸、炸几次，坑沿的犬牙、坑底的起伏、
         * 残堆的位置都一模一样——「固定的柱子」就是那么来的。现在开炸时摇一次，
         * 同一颗弹在原地炸两回，坑都不会长得一样。
         */
        private final long depthSeed;
        private final long edgeSeed;
        private final long pillarSeed;
        /** 残堆范围（占半径的比例）。 */
        private final double pillarZone;
        /** 噪声超过这个值才留残堆：摇高了就一个包都不留。 */
        private final double pillarThreshold;
        /** 残堆留多高（占这一列本该挖的深度的比例）。 */
        private final double pillarRetain;
        /** 残堆最高几格。 */
        private final double pillarCap;
        private Phase phase = Phase.DIG;
        private int age;
        private boolean settled;

        private Task(ServerLevel level, BlockPos core, @Nullable BlockPos anchor, int radius, int fuelRods,
                     int depth) {
            this.level = level;
            this.core = core;
            this.anchor = anchor;
            this.radius = radius;
            this.depth = depth;
            this.fuelRods = Math.max(0, fuelRods);
            // anchor 只有反应堆熔毁才传：熔毁的坑底也会结核熔矿，但那种不算「核弹的产物」
            this.fromNuke = anchor == null;
            RandomSource random = level.random;
            this.depthSeed = random.nextLong();
            this.edgeSeed = random.nextLong();
            this.pillarSeed = random.nextLong();
            this.pillarZone = lerp(
                    PILLAR_ZONE_MIN, PILLAR_ZONE_MAX, random.nextDouble());
            this.pillarThreshold = lerp(
                    PILLAR_THRESHOLD_MIN, PILLAR_THRESHOLD_MAX, random.nextDouble());
            this.pillarRetain = lerp(
                    PILLAR_RETAIN_MIN, PILLAR_RETAIN_MAX, random.nextDouble());
            this.pillarCap = PILLAR_CAP_BASE + radius * PILLAR_CAP_PER_RADIUS;
            // 一列平均要挖 depth * 0.55 个方块（碗形坑），按预算反推这一 tick 能挖几列
            this.columnsPerTick = Math.max(24, Math.min(COLUMNS_PER_TICK,
                    (int) (BLOCKS_PER_TICK_BUDGET / Math.max(20.0, depth * 0.55))));
            this.maxTicks = MAX_TICKS_BASE + radius * 30;
            this.scorchR = scorchRadius(radius);
            this.transitionR = transitionRadius(radius);
            this.falloutR = falloutRadius(radius);
            this.purgeR = radius * PURGE_RADIUS_RATIO;
            this.digQueue = buildQueue(core, radius);
            this.waterQueue = buildWaterQueue((int) Math.ceil(this.falloutR));
            this.purgeColumns = countColumnsWithin(this.waterQueue, this.purgeR + PURGE_BAND);
        }

        /** 推进一步；返回 true 表示这次核爆已经结束。 */
        private boolean tick() {
            // 时间到也不在半路收工：抽干巡检还没跑够圈数时，再多给一半时间，
            // 等它把坑里的水抽干净。不然任务一结束巡检就停了，水面又会慢慢渗回来。
            // 多给的时间也有上限——万一某个区块一直不加载，不能把任务永久挂在这里。
            int grace = this.purgeSweeps >= PURGE_MIN_SWEEPS ? 0 : this.maxTicks / 2;
            if (this.age++ > this.maxTicks + grace) {
                return true;
            }
            // 换水跟挖坑并行：水面下的海最先变黑，接着才是坑塌下来
            waterTick();
            // 中心区巡检：挖到哪儿、水从哪边渗回来，见到水就删，全程不停
            purgeTick();
            switch (this.phase) {
                case DIG -> {
                    if (digTick()) {
                        this.phase = Phase.SETTLE;
                    }
                }
                case SETTLE -> {
                    settle();
                    buildFalloutQueue();
                    this.phase = Phase.FALLOUT;
                }
                case FALLOUT -> {
                    if (falloutTick() && this.waterCursor >= this.waterQueue.length
                            && this.waterRetry.isEmpty() && this.waterSweepDone()
                            && this.purgeSweeps >= PURGE_MIN_SWEEPS) {
                        finish();
                        return true;
                    }
                }
                default -> {
                    return true;
                }
            }
            return false;
        }

        /** 处理一批挖掘列；返回 true 表示挖完了。 */
        private boolean digTick() {
            int budget = this.columnsPerTick;
            while (budget-- > 0 && !this.digQueue.isEmpty()) {
                int packed = this.digQueue.pollFirst();
                if (!column(packed)) {
                    // 区块还没加载：挪到队尾，下一 tick 再试
                    this.digQueue.addLast(packed);
                }
            }
            return this.digQueue.isEmpty();
        }

        /**
         * 换水：每 tick 往前走一批列。
         *
         * <p>主队列是按距离排好的数组，一路往前走；区块还没加载的列扔进 {@link #waterRetry}，
         * 等主队列扫完再回头补一次。这样远处的区块就算没加载，也不会把整趟换水卡死在那里。
         *
         * <p>现在一列是从地表读到世界底面，读方块也要算钱（{@link #WATER_CELLS_PER_TICK}）——
         * 不按扫描量限速的话，一百八十格半径那一圈一次要读几千万格。
         */
        private void waterTick() {
            int columns = WATER_COLUMNS_PER_TICK;
            int budget = WATER_CELLS_PER_TICK;
            int changedBudget = WATER_BLOCKS_PER_TICK;
            while (columns > 0 && budget > 0 && changedBudget > 0) {
                int packed;
                if (this.waterCursor < this.waterQueue.length) {
                    packed = (int) this.waterQueue[this.waterCursor++];
                } else if (!this.waterRetry.isEmpty()) {
                    packed = this.waterRetry.pollFirst();
                } else {
                    return;
                }
                this.waterChanged = 0;
                int scanned = floodColumn(packed);
                columns--;
                if (scanned < 0) {
                    // 区块还没加载：挪到队尾，下一 tick 再试（这一趟不花扫描预算）
                    this.waterRetry.addLast(packed);
                } else {
                    budget -= scanned + this.waterChanged * WATER_CHANGE_COST;
                    changedBudget -= this.waterChanged;
                }
            }
        }

        /**
         * 把这一列从地表到世界底面整列扫穿：抽干区的水 → 空气，外围的水 → 核废水，
         * 水下植物 → 删掉。
         *
         * <p>为什么不看「顶上是不是水」、也不在碰到第一块不是水的方块时停手：
         * 山里的地下水、山洞里的水塘、海底植物底下那一格水，全都在下面几十格。
         * 以前一碰到石头就 break，所以炸完山体里还是清水、海底植物还会顶着一根清水柱子。
         *
         * <p>按 16 格高的段落跳着扫：整段连一格水都没有就直接跳过（{@code maybeHas}），
         * 不然一百八十格半径那一圈每列要读四百格，服务器读不起。
         *
         * @return 读了多少格（区块没加载返回 -1）
         */
        private int floodColumn(int packed) {
            int dx = (packed >> 16) - WATER_OFFSET;
            int dz = (packed & 0xFFFF) - WATER_OFFSET;
            int x = this.core.getX() + dx;
            int z = this.core.getZ() + dz;
            this.cursor.set(x, this.core.getY(), z);
            if (!this.level.isLoaded(this.cursor)) {
                return -1;
            }
            int minY = this.level.getMinBuildHeight();
            int top = Math.min(this.level.getMaxBuildHeight() - 1,
                    this.level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1);
            if (top <= minY) {
                return 0;
            }
            int bottom = Math.max(minY, top - WATER_SCAN_DEPTH);
            // 抽干区以内：水直接删成空气（山里的地下水、坑底下的水塘也一起删）；
            // 抽干区以外：照旧染成核废水，海上、河边围出来的那一圈黑水还在。
            double distance = Math.sqrt((double) dx * dx + (double) dz * dz);
            boolean purge = distance <= this.purgeR + PURGE_BAND;
            BlockState wastewater = purge
                    ? Blocks.AIR.defaultBlockState()
                    : ModBlocks.NUCLEAR_WASTEWATER_FLUID.get().defaultBlockState();
            LevelChunk chunk = this.level.getChunk(x >> 4, z >> 4);
            int scanned = 0;
            int y = top;
            while (y >= bottom) {
                int sectionIndex = this.level.getSectionIndex(y);
                int sectionBottom = Math.max(bottom, minY + sectionIndex * 16);
                LevelChunkSection section = chunk.getSection(sectionIndex);
                scanned += 4; // 查一次段落的调色板也按几格算，不然空段落跳得太便宜
                if (!section.maybeHas(NuclearBlast::isWetState)) {
                    // 这 16 格里一格水、一棵水下植物都没有：整段跳过
                    y = sectionBottom - 1;
                    continue;
                }
                for (int yy = y; yy >= sectionBottom; yy--) {
                    this.cursor.set(x, yy, z);
                    BlockState state = this.level.getBlockState(this.cursor);
                    if (state.is(Blocks.WATER)) {
                        this.level.setBlock(this.cursor, wastewater, UPDATE_FLAGS);
                        this.waterChanged++;
                    } else if (isWaterPlant(state)) {
                        // 水下植物一律删掉；泡着水的那格顺手灌成核废水，不留一个清水孔洞
                        this.level.setBlock(this.cursor,
                                state.getFluidState().is(Fluids.WATER) ? wastewater : Blocks.AIR.defaultBlockState(),
                                UPDATE_FLAGS);
                        this.waterChanged++;
                    } else if (isBleedingWaterloggedPlant(state)) {
                        // 含水的发光地衣：它自己就会一直往旁边渗水，光放干没用，整格删掉。
                        // 外围的换成一格核废水，跟旁边连成一片。
                        this.level.setBlock(this.cursor,
                                purge ? Blocks.AIR.defaultBlockState() : wastewater, UPDATE_FLAGS);
                        this.waterChanged++;
                    } else {
                        // 滴水石锥、含水楼梯、栅栏这些「方块留着、里面泡着水」的：
                        // 把水放干，方块本身留着。以前只认方块名正好叫「水」的，
                        // 这些位置既删不掉、也不会变黑，还一直在给旁边供水。
                        BlockState drained = drainWaterlogged(state);
                        if (drained != null) {
                            this.level.setBlock(this.cursor, drained, UPDATE_FLAGS);
                            this.waterChanged++;
                        }
                    }
                    scanned++;
                }
                y = sectionBottom - 1;
            }
            return scanned;
        }

        /** 换水的主队列扫完了没有（没加载的列还在重试里排队，不耽误放水）。 */
        private boolean waterSweepDone() {
            return this.waterCursor >= this.waterQueue.length;
        }

        /**
         * 抽干巡检：每 tick 从中心区拿一列从头读到世界底面，见到水 / 核废水就删成空气。
         *
         * <p>换水那一趟只跑一遍；可水是会动的——挖开坑以后，隔离带外面的核废水
         * 会沿着坑壁、洞穴慢慢渗回来。所以要一路盯着：巡逻队在中心区的列里
         * 一圈一圈地转，转到哪儿就把哪儿的水抽走。玩家看到的是坑一直干着，
         * 不会再出现「先抽干、再慢慢积水」。
         *
         * <p>游标是环形的：扫到队列末尾就回到开头，不用另外记「扫到第几圈」。
         */
        private void purgeTick() {
            if (this.purgeColumns <= 0) {
                return;
            }
            int budget = PURGE_CELLS_PER_TICK;
            while (budget > 0 && this.purgeCursor < this.purgeColumns) {
                int packed = (int) this.waterQueue[this.purgeCursor];
                int scanned = purgeColumn(packed);
                if (scanned < 0) {
                    // 区块还没加载：先跳过，下一圈再来看（也记一点扫描成本，免得空转）
                    this.purgeCursor++;
                    budget -= 16;
                    continue;
                }
                this.purgeCursor++;
                budget -= Math.max(scanned, 1);
            }
            if (this.purgeCursor >= this.purgeColumns) {
                this.purgeCursor = 0; // 转完一圈，从头再来
                this.purgeSweeps++;   // 记一圈，够圈数了才允许收工
            }
        }

        /**
         * 抽干一列：从地表一路读到世界底面，见到水 / 核废水 / 水下植物就删成空气。
         *
         * <p>为什么扫到世界底面而不是只扫到坑底：玩家反馈「两边山里的地下水没变、
         * 也没消失」。那些水藏在山体里、洞穴里、坑底以下，光看水面根本看不见，
         * 但它们会顺着裂缝渗进坑里，最后又是一圈水墙。所以整列清空，一了百了。
         *
         * <p>按 16 格高的段落跳着读：整段没有水就直接跳过（{@code maybeHas}），
         * 陆地上实际读不了几格，真正贵的是海。
         *
         * @return 读了多少格（区块没加载返回 -1）
         */
        private int purgeColumn(int packed) {
            int dx = (packed >> 16) - WATER_OFFSET;
            int dz = (packed & 0xFFFF) - WATER_OFFSET;
            int x = this.core.getX() + dx;
            int z = this.core.getZ() + dz;
            this.cursor.set(x, this.core.getY(), z);
            if (!this.level.isLoaded(this.cursor)) {
                return -1;
            }
            int minY = this.level.getMinBuildHeight();
            int top = Math.min(this.level.getMaxBuildHeight() - 1,
                    this.level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1);
            if (top <= minY) {
                return 0;
            }
            LevelChunk chunk = this.level.getChunk(x >> 4, z >> 4);
            int scanned = 0;
            int y = top;
            while (y >= minY) {
                int sectionIndex = this.level.getSectionIndex(y);
                int sectionBottom = Math.max(minY, minY + sectionIndex * 16);
                scanned += 4; // 查一次段落调色板也按几格算，不然空段落跳得太便宜
                LevelChunkSection section = chunk.getSection(sectionIndex);
                if (!section.maybeHas(NuclearBlast::isWateryState)) {
                    y = sectionBottom - 1;
                    continue;
                }
                for (int yy = y; yy >= sectionBottom; yy--) {
                    this.cursor.set(x, yy, z);
                    BlockState state = this.level.getBlockState(this.cursor);
                    if (state.is(Blocks.WATER)
                            || state.is(ModBlocks.NUCLEAR_WASTEWATER_FLUID.get())
                            || isWaterPlant(state)
                            || isBleedingWaterloggedPlant(state)) {
                        // 纯水 / 核废水 / 水下植物 / 含水的发光地衣：整格删成空气
                        this.level.setBlock(this.cursor, Blocks.AIR.defaultBlockState(), UPDATE_FLAGS);
                    } else {
                        // 滴水石锥、含水楼梯这类：方块留着，把泡在里面的水抽干。
                        // 这一格以前永远抽不掉（方块名不叫「水」），水就一直渗出来，
                        // 玩家看到的就是「水一直消失又一直出现」。
                        BlockState drained = drainWaterlogged(state);
                        if (drained != null) {
                            this.level.setBlock(this.cursor, drained, UPDATE_FLAGS);
                        }
                    }
                    scanned++;
                }
                y = sectionBottom - 1;
            }
            return scanned;
        }

        /** 处理一批扫尾列；返回 true 表示全部扫完。 */
        private boolean falloutTick() {
            int budget = FALLOUT_COLUMNS_PER_TICK;
            while (budget-- > 0 && !this.falloutQueue.isEmpty()) {
                int packed = this.falloutQueue.pollFirst();
                if (!falloutColumn(packed)) {
                    this.falloutQueue.addLast(packed);
                }
            }
            return this.falloutQueue.isEmpty();
        }

        /**
         * 收尾：不再给残骸垫柱子了（那根冲天长柱子就是上一版垫出来的）。
         *
         * <p>现在的做法是：把原来那一格悬空的堆芯残骸删掉，在爆心 10 格内的地面上
         * 随机撒几块新的残骸；再把烧坏的燃料棒一截截插进爆心 30 格内的焦土里。
         * 最后清掉 200 格内所有掉落物——炸树炸花掉下来的种子、树苗全扫干净。
         */
        private void settle() {
            if (this.settled) {
                return;
            }
            this.settled = true;

            // 1) 原来悬在控制器那一格的残骸先删掉，等会儿在地面上重新撒
            if (this.anchor != null
                    && this.level.getBlockState(this.anchor).is(ModBlocks.CORE_REMNANT.get())) {
                this.level.setBlock(this.anchor, Blocks.AIR.defaultBlockState(), UPDATE_FLAGS);
            }

            RandomSource random = this.level.random;

            // 2)、3) 只有「反应堆熔毁」才有残骸和燃料棒；以后要是做核弹，
            //    anchor 传 null，这里就只是炸一个坑，不会凭空冒出堆芯
            if (this.anchor != null) {
                // 爆心 10 格内的地上撒几块还烫着的堆芯残骸
                for (int i = 0; i < CORE_REMNANT_COUNT; i++) {
                    BlockPos pos = randomGround(random, CORE_REMNANT_SPREAD);
                    if (pos == null) {
                        continue;
                    }
                    this.level.setBlock(pos, ModBlocks.CORE_REMNANT.get().defaultBlockState(), Block.UPDATE_ALL);
                    if (this.level.getBlockEntity(pos) instanceof CoreRemnantBlockEntity remnant) {
                        remnant.startMushroomCloud();
                    }
                }

                // 烧坏的燃料棒：一截截插在 30 格内的焦土上，随机朝向
                for (int i = 0; i < this.fuelRods; i++) {
                    BlockPos pos = randomGround(random, FUEL_ROD_SPREAD);
                    if (pos == null) {
                        continue;
                    }
                    BlockState stub = ModBlocks.MELTED_FUEL_ROD_STUB.get().defaultBlockState()
                            .setValue(MeltedFuelRodStubBlock.ROTATION, random.nextInt(4));
                    this.level.setBlock(pos, stub, Block.UPDATE_ALL);
                }
            }

            // 4) 掉落物清场：花、种子、树苗、机器里掉出来的东西，200 格内一律清掉
            cleanDrops(this.level, this.core, CLEANUP_RADIUS);
        }

        /** 在爆心周围 {@code spread} 格内的地面上随机找一个能落脚的格子。 */
        @Nullable
        private BlockPos randomGround(RandomSource random, double spread) {
            for (int attempt = 0; attempt < 12; attempt++) {
                double angle = random.nextDouble() * Math.PI * 2.0;
                double distance = spread * Math.sqrt(random.nextDouble());
                int x = this.core.getX() + (int) Math.round(Math.cos(angle) * distance);
                int z = this.core.getZ() + (int) Math.round(Math.sin(angle) * distance);
                this.cursor.set(x, this.core.getY(), z);
                if (!this.level.isLoaded(this.cursor)) {
                    continue;
                }
                int y = this.level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                if (y <= this.level.getMinBuildHeight() + BOTTOM_MARGIN
                        || y >= this.level.getMaxBuildHeight()) {
                    continue;
                }
                BlockPos pos = new BlockPos(x, y, z);
                BlockState state = this.level.getBlockState(pos);
                if (state.isAir() || isReplaceablePlant(state)) {
                    return pos;
                }
            }
            return null;
        }

        /** 扫尾的列全部铺出来（半径 120~180）。 */
        private void buildFalloutQueue() {
            int outer = (int) Math.ceil(this.falloutR);
            int inner = this.radius;
            int limit = outer * outer;
            List<Integer> columns = new ArrayList<>();
            int innerSq = inner * inner;
            for (int dx = -outer; dx <= outer; dx++) {
                for (int dz = -outer; dz <= outer; dz++) {
                    int distanceSq = dx * dx + dz * dz;
                    if (distanceSq > limit || distanceSq <= innerSq) {
                        continue;
                    }
                    columns.add(((dx + 512) << 16) | ((dz + 512) & 0xFFFF));
                }
            }
            columns.sort((a, b) -> Integer.compare(distanceSq(a, 512), distanceSq(b, 512)));
            this.falloutQueue.addAll(columns);
        }

        /** 收尾时再清一遍掉落物（扫尾阶段烤树还会掉树苗）。 */
        private void finish() {
            cleanDrops(this.level, this.core, CLEANUP_RADIUS);
        }

        /** 处理一列挖掘；区块没加载返回 false。 */
        private boolean column(int packed) {
            int dx = (packed >> 16) - 256;
            int dz = (packed & 0xFFFF) - 256;
            int x = this.core.getX() + dx;
            int z = this.core.getZ() + dz;
            this.cursor.set(x, this.core.getY(), z);
            if (!this.level.isLoaded(this.cursor)) {
                return false;
            }

            double distance = Math.sqrt((double) dx * dx + (double) dz * dz);
            // 1) 坑沿不是圆：轮廓噪声把半径上下拉 ±9%，坑口一圈就成了犬牙
            double edge = Math.max(1.0, this.radius
                    * (1.0 + EDGE_NOISE * noise(x, z, EDGE_NOISE_CELL, this.edgeSeed)));
            double ratio = distance / edge;
            if (ratio > 1.0) {
                // 这一列正好落在犬牙的凹口里：整列不挖，但地表照样烤焦（不然坑口会留一块绿草地）
                scorchKept(x, z, distance);
                return true;
            }
            // 2) 边缘碎裂带：越靠外越容易整列不挖（90% → 10%），坑口是碎的而不是切出来的
            if (ratio > BREAK_START_RATIO) {
                double t = (ratio - BREAK_START_RATIO) / (1.0 - BREAK_START_RATIO);
                double chance = BREAK_NEAR_CHANCE - (BREAK_NEAR_CHANCE - BREAK_FAR_CHANCE) * clamp(t);
                if (this.level.random.nextDouble() > chance) {
                    scorchKept(x, z, distance);
                    return true;
                }
            }

            // 3) 深度：碗形打底 × 低频噪声（坑底起伏）× 逐列抖动，外加少数「炸穿的深井」
            double base = this.depth * Math.pow(Math.max(0.0, 1.0 - ratio * ratio), 1.35);
            double wobble = 1.0 + DEPTH_NOISE * noise(x, z, DEPTH_NOISE_CELL, this.depthSeed);
            int dug = (int) Math.round(base * wobble)
                    + this.level.random.nextInt(COLUMN_JITTER * 2 + 1) - COLUMN_JITTER;
            if (this.level.random.nextInt(100) < DEEP_WELL_PERCENT) {
                dug += DEEP_WELL_MIN + this.level.random.nextInt(DEEP_WELL_EXTRA);
            }
            dug = Math.max(0, dug);

            int floorY = Math.max(this.level.getMinBuildHeight() + BOTTOM_MARGIN, this.core.getY() - dug);
            // 4) 爆心那一圈可能留几坨残堆：上面这截照挖，下面原地留着。
            //    留多高 = 本该挖的深度 × 这次摇出来的比例 × 逐列乱数（所以高矮不齐），
            //    再卡一个上限——上一版就是没卡上限，大当量炸出来是一丛四层楼的冲天石柱。
            if (dug > 0 && ratio < this.pillarZone
                    && noise(x, z, PILLAR_NOISE_CELL, this.pillarSeed) > this.pillarThreshold) {
                double jag = 0.45 + this.level.random.nextDouble() * 1.15;
                double retain = Math.min(this.pillarCap, dug * this.pillarRetain * jag);
                int lift = (int) Math.round(retain);
                if (lift > 0) {
                    floorY = Math.max(floorY, this.core.getY() - dug + lift);
                }
            }

            int scanTop = Math.min(this.level.getMaxBuildHeight() - 1, this.core.getY() + SCAN_ABOVE);
            // 树冠也算进去：地表以上凡是高过爆炸平面的东西都要抹掉
            int surface = Math.min(scanTop, this.level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z));
            // 不含树叶的地表：决定「焦壳从哪一层开始烤」
            int groundTop = Math.min(scanTop,
                    this.level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z)) - 1;

            // 顶向下挖：水一律挖成空气（直接蒸发），岩浆也只记个数、不在原地放方块——
            // 不然湖底挖空以后那几格换出来的核熔废水会悬在半空，成一根柱子。
            int lavaCells = 0;
            for (int y = surface; y >= floorY; y--) {
                if (destroy(x, y, z)) {
                    lavaCells++;
                }
            }
            // 岩浆压薄了铺在坑底：最多占 MOLTEN_LAYER_CAP 格，湖再深也就一层汤；
            // 碰到残堆、坑壁就停，不顺着它们往上爬。
            placeMoltenFloor(x, z, floorY, lavaCells);
            // 坑内从坑底往下烤，坑外（半径边缘那几圈）从地表往下烤：
            // 这样整个半径的地表都会变成废土，而不是只有坑底
            int shellTop = Math.min(floorY - 1, groundTop);
            scorchColumn(x, z, shellTop, distance);
            // 爆心 100 格以内：把坑底 / 坑壁往下 24 格里露出来的原版矿物「烧熔」
            if (distance <= this.scorchR) {
                moltenOreColumn(x, z, shellTop);
            }
            return true;
        }

        /**
         * 边缘碎裂带里没挖的那几列：坑口留个凸起，但树要烧没、地表要烤焦。
         *
         * <p>不烤的话，爆炸半径里头会夹着一圈绿油油的草地，看着像被谁裁出来的。
         * 从最高的树叶开始往下烤，跟坑里的列走同一套焦土规则。
         */
        private void scorchKept(int x, int z, double distance) {
            int scanTop = Math.min(this.level.getMaxBuildHeight() - 1, this.core.getY() + SCAN_ABOVE);
            int surface = Math.min(scanTop, this.level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z));
            scorchColumn(x, z, surface, distance);
        }

        /**
         * 把这一格挖掉成空气。
         *
         * <p>水在这一步只是被挖成空气——它是不是核废水早在换水那一趟就定好了，
         * 这里不负责换水质。岩浆也不在原地换，只是告诉调用方「这一格是岩浆」，
         * 由调用方在坑底压薄了补一层。这一瞬间不推邻居更新：上百万格一起喊邻居会直接卡死。
         *
         * <p>挖开以后不再「叫醒」四周的水（上一版就是那一脚让水墙塌下来、水位慢慢往下掉）。
         * 现在靠 {@link #purgeTick()} 的巡检把中心区的水直接抽走，坑沿那圈不会再立起来。
         *
         * @return 这一格原本是岩浆
         */
        private boolean destroy(int x, int y, int z) {
            this.cursor.set(x, y, z);
            BlockState state = this.level.getBlockState(this.cursor);
            if (state.isAir() || isProtected(state)) {
                return false;
            }
            this.level.setBlock(this.cursor, Blocks.AIR.defaultBlockState(), UPDATE_FLAGS);
            return state.is(Blocks.LAVA);
        }

        /**
         * 把这一列的岩浆压成薄薄一层，贴坑底铺开。
         *
         * <p>以前是每格岩浆原地换核熔废水，湖底一挖空就是一根悬在半空的柱子。
         * 现在整列岩浆只换算成最多 {@value #MOLTEN_LAYER_CAP} 格，从坑底往上铺；
         * 碰到残堆、坑壁就停手，绝不顺着它们往上爬。
         *
         * @param lavaCells 这一列被挖掉的岩浆格数（0 表示没有岩浆）
         */
        private void placeMoltenFloor(int x, int z, int floorY, int lavaCells) {
            if (lavaCells <= 0) {
                return;
            }
            BlockState molten = ModBlocks.NUCLEAR_MOLTEN_WASTE_FLUID.get().defaultBlockState();
            int top = Math.min(this.level.getMaxBuildHeight() - 1, floorY + MOLTEN_LAYER_CAP - 1);
            int placed = 0;
            for (int y = floorY; y <= top && placed < MOLTEN_LAYER_CAP; y++) {
                this.cursor.set(x, y, z);
                if (!this.level.getBlockState(this.cursor).isAir()) {
                    break;
                }
                this.level.setBlock(this.cursor, molten, UPDATE_FLAGS);
                placed++;
            }
        }

        /**
         * 焦壳：从 {@code startY} 往下烤。
         *
         * <p>「烤三层」说的是三层<b>地面</b>（土 / 沙 / 石头）。树叶、树干、花草、
         * 海带海草全都不算层数，会一路烧下去——所以站在半径边缘的树会被烧成一截焦黑的树桩，
         * 长满海带的海底也会一路烤到下面的沙子。石头以外不认识的方块直接停手，别把坑壁乱换。
         *
         * <p>水（包括已经变成核废水的）不算障碍：穿过去继续往下烤。不这样做的话，
         * 只要海面上有一层水，海底的沙子和沙砾就一辈子变不成焦土。
         */
        private void scorchColumn(int x, int z, int startY, double distance) {
            RandomSource random = this.level.random;
            int minY = this.level.getMinBuildHeight();
            int burntLayers = 0;
            int stop = Math.max(minY, startY - SCORCH_SCAN);
            for (int y = startY; y >= stop; y--) {
                this.cursor.set(x, y, z);
                BlockState state = this.level.getBlockState(this.cursor);
                if (state.isAir() || isProtected(state)) {
                    continue;
                }
                // 上一发留下的焦土 / 污染土 / 烧结砂 / 焦木：穿过去接着烤下面的地面。
                // 以前是直接 return，结果废土下面那层原样不动，看着像「炸了等于没炸」。
                if (isBlastDebris(state)) {
                    continue;
                }
                // 水 / 核废水 / 岩浆：往下穿过去接着烤，跳过的每一格给扫描深度补一格
                if (isFluid(state)) {
                    stop = Math.max(minY, stop - 1);
                    continue;
                }
                BlockState replacement = burnt(state, distance, this.scorchR, random);
                if (replacement == null) {
                    return;
                }
                this.level.setBlock(this.cursor, replacement, UPDATE_FLAGS);
                if (isGroundLayer(state)) {
                    burntLayers++;
                    if (burntLayers >= SHELL_DEPTH) {
                        return;
                    }
                }
            }
        }

        /**
         * 矿物转化：从焦壳往下 {@link #ORE_SCAN_DEPTH} 格，把露出来的原版矿物换掉。
         *
         * <p>规则（用户定的）：
         * <ul>
         *   <li>煤矿 → 核熔的钻石矿 / 核熔的绿宝石矿（五五开，看运气）；</li>
         *   <li>钻石矿 → 核熔的钻石矿，绿宝石矿 → 核熔的绿宝石矿（深板岩那两种也算）；</li>
         *   <li>其它原版矿物（铁、铜、金、红石、青金石、下界石英、远古残骸……）
         *       一概烧成焦土 / 辐射焦土，等于这一片矿脉彻底废了。</li>
         * </ul>
         *
         * <p>只扫坑底往下这一小段，是性能上的取舍：整层地下全扫会卡死服务器，
         * 而且那些矿玩家这辈子都挖不到。想找核熔矿，就站到坑底往下挖。
         */
        private void moltenOreColumn(int x, int z, int topY) {
            RandomSource random = this.level.random;
            int bottom = Math.max(this.level.getMinBuildHeight() + BOTTOM_MARGIN, topY - ORE_SCAN_DEPTH);
            for (int y = topY; y >= bottom; y--) {
                this.cursor.set(x, y, z);
                BlockState replacement = moltenOre(this.level.getBlockState(this.cursor), random, this.fromNuke);
                if (replacement != null) {
                    this.level.setBlock(this.cursor, replacement, UPDATE_FLAGS);
                }
            }
        }

        /** 处理扫尾的一列；区块没加载返回 false。 */
        private boolean falloutColumn(int packed) {
            int dx = (packed >> 16) - 512;
            int dz = (packed & 0xFFFF) - 512;
            int x = this.core.getX() + dx;
            int z = this.core.getZ() + dz;
            this.cursor.set(x, this.core.getY(), z);
            if (!this.level.isLoaded(this.cursor)) {
                return false;
            }
            double distance = Math.sqrt((double) dx * dx + (double) dz * dz);
            if (distance <= this.transitionR) {
                transitionColumn(x, z);
            } else {
                dustColumn(x, z);
            }
            return true;
        }

        /**
         * 过渡带（120~130 格）：七成自然方块变污染土 / 烧结砂，树变焦木、树叶消失。
         *
         * <p>从最高处往下扫，树叶和花草直接删掉，树干换成焦木，碰到地面方块就按 70% 掷骰子。
         * 这一带的岩浆原地变成核熔废水（底下没被挖掉，所以不会悬空）。
         *
         * <p>水在这一带不归这里管：换水那一趟已经按 0~180 格统一换过了，
         * 这里碰到水 / 核废水只是穿过去，好让海底的泥土和沙子照样变成污染土和烧结砂。
         * 三层地面之后就停手——再往深挖没人看得见，还费时间。
         */
        private void transitionColumn(int x, int z) {
            RandomSource random = this.level.random;
            int top = Math.min(this.level.getMaxBuildHeight() - 1,
                    this.level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z) - 1);
            int minY = this.level.getMinBuildHeight();
            int stop = Math.max(minY, top - SCORCH_SCAN);
            int groundLayers = 0;
            for (int y = top; y >= stop && groundLayers < SHELL_DEPTH; y--) {
                this.cursor.set(x, y, z);
                BlockState state = this.level.getBlockState(this.cursor);
                if (state.isAir()) {
                    continue;
                }
                if (isProtected(state)) {
                    return;
                }
                // 上一发留下的废土：穿过去，接着处理它下面那层
                if (isBlastDebris(state)) {
                    continue;
                }
                // 岩浆原地换成核熔废水：这一带没有坑，底下没被挖掉，所以不会悬在半空
                if (state.is(Blocks.LAVA)) {
                    this.level.setBlock(this.cursor,
                            ModBlocks.NUCLEAR_MOLTEN_WASTE_FLUID.get().defaultBlockState(), UPDATE_FLAGS);
                    continue;
                }
                // 水在这一带不归这里管：换水那一趟已经按 0~180 格统一换过了。
                // 碰到水 / 核废水就穿过去，好让海底的泥土和沙子照样变成污染土和烧结砂。
                if (isFluid(state)) {
                    stop = Math.max(minY, stop - 1);
                    continue;
                }
                if (state.is(BlockTags.LOGS)) {
                    this.level.setBlock(this.cursor, charred(state), UPDATE_FLAGS);
                    continue;
                }
                if (isBurnablePlant(state)) {
                    this.level.setBlock(this.cursor, Blocks.AIR.defaultBlockState(), UPDATE_FLAGS);
                    continue;
                }
                BlockState replacement = transitionGround(state);
                if (replacement == null) {
                    return;
                }
                if (random.nextInt(100) < TRANSITION_PERCENT) {
                    this.level.setBlock(this.cursor, replacement, UPDATE_FLAGS);
                }
                groundLayers++;
            }
        }

        /** 辐射尘带（130~180 格）：一成的柱子上多一层薄灰。 */
        private void dustColumn(int x, int z) {
            RandomSource random = this.level.random;
            int y = this.level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
            if (y <= this.level.getMinBuildHeight() || y >= this.level.getMaxBuildHeight() - 1) {
                return;
            }
            this.cursor.set(x, y, z);
            if (!isNaturalGround(this.level.getBlockState(this.cursor))) {
                return;
            }
            if (random.nextInt(100) >= FALLOUT_PERCENT) {
                return;
            }
            this.cursor.set(x, y + 1, z);
            BlockState above = this.level.getBlockState(this.cursor);
            if (!above.isAir() && !isReplaceablePlant(above)) {
                return;
            }
            this.level.setBlock(this.cursor,
                    ModBlocks.RADIOACTIVE_DUST.get().defaultBlockState(), UPDATE_FLAGS);
        }
    }

    /**
     * 把半径铺成列，按到爆心的距离排好（近的先挖，看起来是从中心塌下去）。
     *
     * <p>铺到 {@code 半径 × 1.09}：轮廓噪声最多把坑沿往外推到这么远，
     * 队列少了那几圈，犬牙就只剩往里凹的一边。多出来的列在 {@code column} 里会被直接跳过，
     * 不挖方块，只多几次乘加。
     */
    private static Deque<Integer> buildQueue(BlockPos core, int radius) {
        int outer = (int) Math.ceil(radius * (1.0 + EDGE_NOISE));
        List<Integer> columns = new ArrayList<>(outer * outer * 3);
        int radiusSq = outer * outer;
        for (int dx = -outer; dx <= outer; dx++) {
            for (int dz = -outer; dz <= outer; dz++) {
                if (dx * dx + dz * dz <= radiusSq) {
                    columns.add(((dx + 256) << 16) | ((dz + 256) & 0xFFFF));
                }
            }
        }
        columns.sort((a, b) -> Integer.compare(distanceSq(a, 256), distanceSq(b, 256)));
        return new ArrayDeque<>(columns);
    }

    /** packed 列坐标到爆心的水平距离平方（排序用，跟 core 无关所以可以静态算）。 */
    private static int distanceSq(int packed, int offset) {
        int dx = (packed >> 16) - offset;
        int dz = (packed & 0xFFFF) - offset;
        return dx * dx + dz * dz;
    }

    /**
     * 把爆心 0~{@code outer} 格的每一列按距离排好，给换水用。
     *
     * <p>打包成 {@code 距离平方 << 32 | 列坐标}：高 32 位是距离，所以
     * {@link java.util.Arrays#sort(long[])} 一跑就是从爆心往外，中心那片海最先变黑。
     * 用 long 数组而不是 {@code Deque<Integer>}，是因为沙皇半径 300 时这一圈有六十多万列，
     * 装箱要多占十几兆内存。
     */
    private static long[] buildWaterQueue(int outer) {
        int limitSq = outer * outer;
        int size = 0;
        for (int dx = -outer; dx <= outer; dx++) {
            for (int dz = -outer; dz <= outer; dz++) {
                if (dx * dx + dz * dz <= limitSq) {
                    size++;
                }
            }
        }
        long[] queue = new long[size];
        int index = 0;
        for (int dx = -outer; dx <= outer; dx++) {
            for (int dz = -outer; dz <= outer; dz++) {
                int distanceSq = dx * dx + dz * dz;
                if (distanceSq > limitSq) {
                    continue;
                }
                int packed = ((dx + WATER_OFFSET) << 16) | ((dz + WATER_OFFSET) & 0xFFFF);
                queue[index++] = ((long) distanceSq << 32) | (packed & 0xFFFFFFFFL);
            }
        }
        java.util.Arrays.sort(queue);
        return queue;
    }

    /**
     * 数一数换水队列前面有多少列落在半径以内（用来给抽干巡检划范围）。
     *
     * <p>队列已经按距离平方排好序、距离平方就存在 long 的高 32 位，
     * 所以从前往后数、第一个超出的地方就是边界，不用再算一遍坐标。
     */
    private static int countColumnsWithin(long[] queue, double radius) {
        int limitSq = (int) Math.ceil(radius * radius);
        int index = 0;
        while (index < queue.length && (int) (queue[index] >>> 32) <= limitSq) {
            index++;
        }
        return index;
    }

    // ------------------------------------------------------------------
    // 噪声：只用整数哈希，不查表、不开数组
    // ------------------------------------------------------------------

    /**
     * 两个八度的二维值噪声，返回 -1~1。
     *
     * <p>「值噪声」就是：把世界切成 {@code cell} 格见方的格子，每格顶点用整数坐标哈希出一个
     * 0~1 的值，格子内部按平滑曲线插值。两个八度（粗的 + 一半细的）叠起来，
     * 才有大起伏里带小起伏的坑底，而不是一层层台阶。
     *
     * <p>不用随机数、不查表，每列多几十次乘加——不会多扫一个方块，所以挖坑速度不变。
     */
    private static double noise(int x, int z, int cell, long seed) {
        double coarse = valueNoise(x, z, cell, seed);
        double fine = valueNoise(x, z, Math.max(2, cell / 2), seed * 0x9E3779B97F4A7C15L + 0x632BE59BD9B4E019L);
        return (coarse * 0.65 + fine * 0.35) * 2.0 - 1.0;
    }

    /** 单个八度的值噪声，返回 0~1。 */
    private static double valueNoise(int x, int z, int cell, long seed) {
        int gx = Math.floorDiv(x, cell);
        int gz = Math.floorDiv(z, cell);
        double fx = (double) Math.floorMod(x, cell) / (double) cell;
        double fz = (double) Math.floorMod(z, cell) / (double) cell;
        // 平滑一下，格子边界才看不出折线
        double sx = fx * fx * (3.0 - 2.0 * fx);
        double sz = fz * fz * (3.0 - 2.0 * fz);
        double n00 = hash01(gx, gz, seed);
        double n10 = hash01(gx + 1, gz, seed);
        double n01 = hash01(gx, gz + 1, seed);
        double n11 = hash01(gx + 1, gz + 1, seed);
        double top = n00 + (n10 - n00) * sx;
        double bottom = n01 + (n11 - n01) * sx;
        return top + (bottom - top) * sz;
    }

    /** 整数坐标 → [0,1) 的伪随机：走两步乘法混合，够散就行。 */
    private static double hash01(int x, int z, long seed) {
        long h = seed;
        h = h * 0x9E3779B97F4A7C15L + x * 0xC2B2AE3D27D4EB4FL;
        h = h * 0x9E3779B97F4A7C15L + z * 0x165667B19E3779F9L;
        h ^= h >>> 33;
        h *= 0xFF51AFD7ED558CCDL;
        h ^= h >>> 33;
        h *= 0xC4CEB9FE1A85EC53L;
        h ^= h >>> 33;
        return (h >>> 11) * 0x1.0p-53;
    }

    private static double clamp(double t) {
        return Math.max(0.0, Math.min(1.0, t));
    }

    /** 在两个数之间按 t（0~1）线性插值。 */
    private static double lerp(double from, double to, double t) {
        return from + (to - from) * t;
    }

    /** 一次性清掉半径内所有掉落物。 */
    public static void cleanDrops(ServerLevel level, BlockPos core, double radius) {
        AABB area = new AABB(
                core.getX() + 0.5 - radius, level.getMinBuildHeight(), core.getZ() + 0.5 - radius,
                core.getX() + 0.5 + radius, level.getMaxBuildHeight(), core.getZ() + 0.5 + radius);
        for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, area)) {
            item.discard();
        }
    }

    // ------------------------------------------------------------------
    // 方块判定
    // ------------------------------------------------------------------

    /**
     * 结出核熔的钻石矿，顺手盖一个「核弹炸出来的」记号。
     *
     * <p>这个记号就是成就「轮回」的判定依据：玩家挖到 {@code from_nuke=true} 的两种核熔矿
     * 才算数，熔毁废墟里那种（{@code false}）挖了不算。
     */
    private static BlockState moltenDiamond(boolean fromNuke) {
        return ModBlocks.NUCLEAR_MOLTEN_DIAMOND_ORE.get().defaultBlockState()
                .setValue(MoltenOreBlock.FROM_NUKE, fromNuke);
    }

    /** 结出核熔的绿宝石矿，同上。 */
    private static BlockState moltenEmerald(boolean fromNuke) {
        return ModBlocks.NUCLEAR_MOLTEN_EMERALD_ORE.get().defaultBlockState()
                .setValue(MoltenOreBlock.FROM_NUKE, fromNuke);
    }

    /**
     * 一块原版矿物烧熔之后该变成什么；不是矿物就返回 {@code null}（原样不动）。
     *
     * <p>判断用的是原版的矿物标签（煤矿、钻石矿、绿宝石矿等），所以深板岩版本会自动
     * 一起算进去，不用把十几种方块名字一个个列出来。下界那几种矿物没有标签，单独列。
     */
    @Nullable
    private static BlockState moltenOre(BlockState state, RandomSource random, boolean fromNuke) {
        if (state.is(BlockTags.DIAMOND_ORES)) {
            return moltenDiamond(fromNuke);
        }
        if (state.is(BlockTags.EMERALD_ORES)) {
            return moltenEmerald(fromNuke);
        }
        if (state.is(BlockTags.COAL_ORES)) {
            // 煤矿是核爆里最先被烧熔的，烧完之后结晶成什么样看运气
            return random.nextBoolean() ? moltenDiamond(fromNuke) : moltenEmerald(fromNuke);
        }
        if (isPlainOre(state)) {
            return scorchedEarth(random);
        }
        return null;
    }

    /** 除煤 / 钻石 / 绿宝石之外的原版矿物：铁、铜、金、红石、青金石、下界那几种。 */
    private static boolean isPlainOre(BlockState state) {
        return state.is(BlockTags.IRON_ORES)
                || state.is(BlockTags.COPPER_ORES)
                || state.is(BlockTags.GOLD_ORES)
                || state.is(BlockTags.REDSTONE_ORES)
                || state.is(BlockTags.LAPIS_ORES)
                || state.is(Blocks.NETHER_QUARTZ_ORE)
                || state.is(Blocks.NETHER_GOLD_ORE)
                || state.is(Blocks.ANCIENT_DEBRIS);
    }

    /**
     * 这些方块再炸也不动：只剩世界底板、屏障、命令方块、传送门这类「拆了会出大事」的。
     *
     * <p>上一版这里还列着一长串核爆自己烧出来的方块（焦土、辐射焦土、污染土、烧结砂、
     * 焦木、辐射尘、残骸、燃料棒残桩），本意是「第二发别把第一发的废墟抹掉」，
     * 结果它们成了打不烂的无敌方块：第二发炸上去，方块原地不动，只把底下那层换成焦土。
     * 现在这份名单只剩真正不能拆的几种——核爆留下的废土跟普通地貌一样，该挖就挖、该烧就烧。
     */
    private static boolean isProtected(BlockState state) {
        return state.is(Blocks.BEDROCK)
                || state.is(Blocks.BARRIER)
                || state.is(Blocks.STRUCTURE_BLOCK)
                || state.is(Blocks.JIGSAW)
                || state.is(Blocks.COMMAND_BLOCK)
                || state.is(Blocks.CHAIN_COMMAND_BLOCK)
                || state.is(Blocks.REPEATING_COMMAND_BLOCK)
                || state.is(Blocks.END_PORTAL)
                || state.is(Blocks.END_PORTAL_FRAME)
                || state.is(Blocks.END_GATEWAY);
    }

    /**
     * 核爆自己留下的废土：焦土、辐射焦土、污染土、烧结砂、焦木、辐射尘、堆芯残骸、燃料棒残桩。
     *
     * <p>这些方块<b>不再是无敌的</b>——挖掘那一步照挖，挖掘队列照清。
     * 这个判断只用在「烤焦」这一步：碰到上一发留下的废土，要穿过去接着烤下面的土、沙、石头，
     * 而不是当成石头以外的陌生物块直接停手。不这样做的话，第二发炸在新焦土上，
     * 焦土底下那层又原地留着，看着还是「炸不透」。
     */
    private static boolean isBlastDebris(BlockState state) {
        return state.is(ModBlocks.CORE_REMNANT.get())
                || state.is(ModBlocks.CONTAMINATED_SOIL.get())
                || state.is(ModBlocks.SCORCHED_SAND.get())
                || state.is(ModBlocks.CHARRED_LOG.get())
                || state.is(ModBlocks.SCORCHED_EARTH.get())
                || state.is(ModBlocks.RADIOACTIVE_SCORCHED_EARTH.get())
                || state.is(ModBlocks.RADIOACTIVE_DUST.get())
                || state.is(ModBlocks.MELTED_FUEL_ROD_STUB.get());
    }

    /**
     * 烧焦之后变成什么：树变焦木、树叶花草烧没、土变污染土、沙变烧结砂。
     *
     * <p>爆心 100 格以内狠一档：不管原来是土、沙还是石头，全都变成焦土 / 辐射焦土。
     * 100~130 格柔和一点：七成概率换，三成留着。
     *
     * <p>其它方块（石头以外的机器、水）返回 null，表示「就这么留着」。
     */
    @Nullable
    private static BlockState burnt(BlockState state, double distance, double scorchR, RandomSource random) {
        if (state.is(BlockTags.LOGS)) {
            return distance <= scorchR ? Blocks.AIR.defaultBlockState() : charred(state);
        }
        if (isBurnablePlant(state)) {
            return Blocks.AIR.defaultBlockState();
        }
        if (isSoil(state) || isSand(state) || isCraterRock(state)) {
            if (distance <= scorchR) {
                return scorchedEarth(random);
            }
            // 过渡带：只有七成会换，剩下三成原地留着，看着才像「边缘还没烧透」
            BlockState softened = transitionGround(state);
            return softened != null && random.nextInt(100) < TRANSITION_PERCENT ? softened : null;
        }
        return null;
    }

    /** 爆心的焦土：焦土和辐射焦土掺着铺（三成半是更黑的辐射焦土）。 */
    private static BlockState scorchedEarth(RandomSource random) {
        return random.nextInt(100) < 35
                ? ModBlocks.RADIOACTIVE_SCORCHED_EARTH.get().defaultBlockState()
                : ModBlocks.SCORCHED_EARTH.get().defaultBlockState();
    }

    /** 过渡带的七成：土变污染土、沙变烧结砂、裸岩变污染土。 */
    @Nullable
    private static BlockState transitionGround(BlockState state) {
        if (isSoil(state) || isCraterRock(state)) {
            return ModBlocks.CONTAMINATED_SOIL.get().defaultBlockState();
        }
        if (isSand(state)) {
            return ModBlocks.SCORCHED_SAND.get().defaultBlockState();
        }
        return null;
    }

    /**
     * 算「一层地面」的方块：土、沙、石头。
     *
     * <p>烤三层焦壳时只数这三种。所有植物——树叶、树干、花草、海带、海草、海泡菜、珊瑚——
     * 一律不算层，于是焦土能一路烧到海底的沙子，以后再加什么水下植物也不会再卡住。
     */
    private static boolean isGroundLayer(BlockState state) {
        return isSoil(state) || isSand(state) || isCraterRock(state);
    }

    /** 会流动的液体：水、核废水、核熔废水、岩浆。烤焦 / 换地面的时候一律穿过去，也算不上一层。 */
    private static boolean isFluid(BlockState state) {
        return state.is(Blocks.WATER)
                || state.is(Blocks.LAVA)
                || state.is(ModBlocks.NUCLEAR_WASTEWATER_FLUID.get())
                || state.is(ModBlocks.NUCLEAR_MOLTEN_WASTE_FLUID.get());
    }

    /**
     * 长在水里的植物：海带、海草、高海草、海泡菜、珊瑚、珊瑚扇、气泡柱。
     *
     * <p>换水那一趟会把它们<b>删掉</b>：留着的话，海面上会立着一根「植物 + 清水」的柱子，
     * 周围全变黑了就它还绿着。删的时候要是那一格本来泡着水，就直接灌成核废水，不留清水孔。
     * 烤焦的时候按「烧得掉的植物」处理，也是直接烧没。
     */
    private static boolean isWaterPlant(BlockState state) {
        return state.is(Blocks.KELP)
                || state.is(Blocks.KELP_PLANT)
                || state.is(Blocks.SEAGRASS)
                || state.is(Blocks.TALL_SEAGRASS)
                || state.is(Blocks.SEA_PICKLE)
                || state.is(Blocks.BUBBLE_COLUMN)
                || state.is(BlockTags.CORAL_PLANTS)
                || state.is(BlockTags.WALL_CORALS);
    }

    /**
     * 这格方块里「泡着水」吗（英文叫 waterlogged）？
     *
     * <p>滴水石锥、发光地衣、海草、含水楼梯、栅栏都是「方块本身还在、水泡在方块里」，
     * 方块名永远不是「水」。上一版只认方块名正好是「水」的那一种，这些位置的水
     * 既删不掉、也不会变黑，还一直在给旁边供水——玩家看到的「水一直消失又一直出现」
     * 「发光地衣流出来的水不变核废水」都是这一条造成的。
     */
    private static boolean isWaterlogged(BlockState state) {
        return state.hasProperty(BlockStateProperties.WATERLOGGED)
                && state.getValue(BlockStateProperties.WATERLOGGED);
    }

    /**
     * 把泡着水的方块放干：方块本身留着，只把里面的水放掉。
     *
     * <p>用于抽干区里的建筑类含水方块（含水楼梯、栅栏、台阶）。只放水不删方块，
     * 玩家还能认出「这里原来有座楼梯」。没泡水的方块返回 {@code null}，表示不用动。
     */
    @Nullable
    private static BlockState drainWaterlogged(BlockState state) {
        if (!isWaterlogged(state)) {
            return null;
        }
        return state.setValue(BlockStateProperties.WATERLOGGED, false);
    }

    /**
     * 泡着水、而且会不停往外渗水的植物：发光地衣。
     *
     * <p>跟海草不太一样：海草长在水里，删掉就完事；发光地衣是贴在石头、天花板上的，
     * 含水的发光地衣会一直把水往旁边推，光把水放干下一秒又灌满，所以整格删掉。
     */
    private static boolean isBleedingWaterloggedPlant(BlockState state) {
        return state.is(Blocks.GLOW_LICHEN) && isWaterlogged(state);
    }

    /**
     * 换水要找的东西：水，或者泡在水里的植物。
     *
     * <p>只用来给 {@code LevelChunkSection.maybeHas} 判「这一整段 16 格要不要细看」——
     * 一段石头里一格水都没有，就直接跳过，省下四百格里的三百多格。
     * 含水的滴水石锥、发光地衣也算进来，不然整段会被误判成干的，直接跳过。
     */
    private static boolean isWetState(BlockState state) {
        return state.is(Blocks.WATER) || isWaterlogged(state) || isWaterPlant(state);
    }

    /**
     * 水，或者核废水。
     *
     * <p>抽干巡检见到这两种就删成空气——中心区里不管是没来得及换的清水，
     * 还是从隔离带外面渗回来的核废水，一律不留。含水的方块也算「有水」，
     * 只是处理方式不同：纯水整格删掉，含水方块把水放干。
     */
    private static boolean isWateryState(BlockState state) {
        return state.is(Blocks.WATER)
                || state.is(ModBlocks.NUCLEAR_WASTEWATER_FLUID.get())
                || isWaterlogged(state)
                || isWaterPlant(state);
    }

    /** 会被高温直接烧没、也不会掉东西的植物。 */
    private static boolean isBurnablePlant(BlockState state) {
        return state.is(BlockTags.LEAVES)
                || state.is(BlockTags.FLOWERS)
                || state.is(BlockTags.SAPLINGS)
                || state.is(BlockTags.CROPS)
                || state.is(Blocks.SHORT_GRASS)
                || state.is(Blocks.TALL_GRASS)
                || state.is(Blocks.FERN)
                || state.is(Blocks.LARGE_FERN)
                || state.is(Blocks.DEAD_BUSH)
                || state.is(Blocks.VINE)
                || state.is(Blocks.SNOW)
                || state.is(Blocks.SNOW_BLOCK)
                || state.is(Blocks.BAMBOO_SAPLING)
                // 水下植物：海带、海草、高海草、海泡菜、珊瑚
                || isWaterPlant(state);
    }

    /** 可以「让位」给辐射尘的小植物。 */
    private static boolean isReplaceablePlant(BlockState state) {
        return isBurnablePlant(state);
    }

    /** 树干 → 焦木，保留原木的朝向，树不会歪。 */
    private static BlockState charred(BlockState state) {
        BlockState charred = ModBlocks.CHARRED_LOG.get().defaultBlockState();
        if (state.hasProperty(RotatedPillarBlock.AXIS)) {
            charred = charred.setValue(RotatedPillarBlock.AXIS, state.getValue(RotatedPillarBlock.AXIS));
        }
        return charred;
    }

    /**
     * 坑底和坑壁上会露出来的天然岩层：也铺成污染土（爆心那一圈则换成焦土）。
     *
     * <p>不铺的话坑底就是一圈干净的石头，中间一块脏土，看着像是没炸透。
     *
     * <p>滴水石锥（尖的那根）也算石头：它以前不在名单里，烤焦时被当成「不认识的方块」直接
     * 停手，于是它下面那块滴水石块一辈子变不成焦土——玩家反馈的就是这个。
     */
    private static boolean isCraterRock(BlockState state) {
        return state.is(Blocks.STONE)
                || state.is(Blocks.COBBLESTONE)
                || state.is(Blocks.DEEPSLATE)
                || state.is(Blocks.COBBLED_DEEPSLATE)
                || state.is(Blocks.ANDESITE)
                || state.is(Blocks.GRANITE)
                || state.is(Blocks.DIORITE)
                || state.is(Blocks.TUFF)
                || state.is(Blocks.CALCITE)
                || state.is(Blocks.DRIPSTONE_BLOCK)
                || state.is(Blocks.POINTED_DRIPSTONE)
                || state.is(Blocks.NETHERRACK);
    }

    /** 这几种算「土」：烧完变污染土。 */
    private static boolean isSoil(BlockState state) {
        return state.is(Blocks.GRASS_BLOCK)
                || state.is(Blocks.DIRT)
                || state.is(Blocks.COARSE_DIRT)
                || state.is(Blocks.ROOTED_DIRT)
                || state.is(Blocks.PODZOL)
                || state.is(Blocks.MYCELIUM)
                || state.is(Blocks.MOSS_BLOCK)
                || state.is(Blocks.FARMLAND)
                || state.is(Blocks.DIRT_PATH);
    }

    /** 这几种算「沙」：高温烧结成硬壳，变烧结砂。
     *
     * <p>以前这段是「沙子变玻璃」，问题是玻璃透光又反光，炸完地上一大片亮晶晶，
     * 跟核废土完全不搭。烧结砂是不透光的灰紫色硬块，踩上去还是沙子的声音。
     */
    private static boolean isSand(BlockState state) {
        return state.is(BlockTags.SAND)
                || state.is(Blocks.GRAVEL)
                || state.is(Blocks.SANDSTONE)
                || state.is(Blocks.RED_SANDSTONE)
                || state.is(Blocks.CLAY)
                || state.is(Blocks.TERRACOTTA);
    }

    /** 能落辐射尘的天然地面（树上、石头建筑上不落）。 */
    private static boolean isNaturalGround(BlockState state) {
        return isSoil(state) || isSand(state) || isCraterRock(state);
    }
}
