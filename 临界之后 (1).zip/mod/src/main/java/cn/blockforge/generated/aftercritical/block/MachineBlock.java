package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.MachineBlockEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 三台机器共用的方块骨架。
 *
 * <p>它统一处理：右键打开 GUI、每 tick 驱动方块实体、被拆掉时把里面的东西吐出来、
 * 以及物品栏里显示的「LV / 功率」提示。
 */
public abstract class MachineBlock extends BaseEntityBlock {

    protected MachineBlock(Properties properties) {
        super(properties);
    }

    /** 这台机器的额定功率，FE/t；GUI 和物品提示都会用到。 */
    protected abstract int energyPerTick();

    /** 物品提示里那句「这台机器能加工什么」的语言键。 */
    protected abstract String recipeHintKey();

    /** 这台机器的电压等级，默认 LV；压块机之类的 MV 机器覆盖它。 */
    protected String tier() {
        return "LV";
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    /** 只有服务端需要每 tick 跑逻辑。 */
    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return (tickLevel, pos, tickState, blockEntity) -> {
            if (blockEntity instanceof MachineBlockEntity machine) {
                machine.serverTick();
            }
        };
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MachineBlockEntity machine) {
            player.openMenu(machine, pos);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** 方块被拆掉（或替换）时，把里面的物品掉出来，避免东西被吞。 */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide
                && level.getBlockEntity(pos) instanceof Container container) {
            Containers.dropContents(level, pos, container);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    /** 物品栏提示：LV 等级 + 运行功率 + 能加工什么。 */
    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.tier", tier()).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.energy_per_tick", energyPerTick())
                .withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable(recipeHintKey()).withStyle(ChatFormatting.GRAY));
    }
}
