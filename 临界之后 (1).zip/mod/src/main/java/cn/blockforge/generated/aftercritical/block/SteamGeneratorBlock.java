package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.SteamGeneratorBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

/**
 * 汽轮发电机：把蒸汽的压力变成电。
 *
 * <p>单台最大 2,000 FE/t，正好吃掉 1,000 mB/s（50 mB/t）蒸汽，吐出同样多的乏蒸汽。
 * 乏蒸汽要接去冷凝器换回水，整条压水堆回路才闭合。
 */
public class SteamGeneratorBlock extends TickingMachineBlock {

    public static final String DESCRIPTION = "block.aftercritical.steam_generator.desc";

    public SteamGeneratorBlock(Properties properties) {
        super(properties, "HV", "tooltip.aftercritical.output_per_tick",
                SteamGeneratorBlockEntity.OUTPUT_PER_TICK, DESCRIPTION);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(SteamGeneratorBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new SteamGeneratorBlockEntity(pos, state);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MenuProvider provider) {
            player.openMenu(provider, pos);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MenuProvider provider) {
            player.openMenu(provider, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
