package cn.blockforge.generated.aftercritical.registry;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.blockentity.FluidMachineKind;
import cn.blockforge.generated.aftercritical.blockentity.ItemMachineKind;
import cn.blockforge.generated.aftercritical.blockentity.ReactorKind;
import cn.blockforge.generated.aftercritical.menu.AssemblerT1Menu;
import cn.blockforge.generated.aftercritical.menu.AssemblerT2Menu;
import cn.blockforge.generated.aftercritical.menu.AssemblerT3Menu;
import cn.blockforge.generated.aftercritical.menu.BallMillMenu;
import cn.blockforge.generated.aftercritical.menu.BatteryLvMenu;
import cn.blockforge.generated.aftercritical.menu.BatteryMvMenu;
import cn.blockforge.generated.aftercritical.menu.CascadeControllerMenu;
import cn.blockforge.generated.aftercritical.menu.CrusherMenu;
import cn.blockforge.generated.aftercritical.menu.CompactorMenu;
import cn.blockforge.generated.aftercritical.menu.ForgingPressMenu;
import cn.blockforge.generated.aftercritical.menu.FastReactorMenu;
import cn.blockforge.generated.aftercritical.menu.FluidIdentifierMenu;
import cn.blockforge.generated.aftercritical.menu.FluidMachineMenu;
import cn.blockforge.generated.aftercritical.menu.FuelPortMenu;
import cn.blockforge.generated.aftercritical.menu.GeneratorMenu;
import cn.blockforge.generated.aftercritical.menu.GiantBatteryMenu;
import cn.blockforge.generated.aftercritical.menu.HotCellArmMenu;
import cn.blockforge.generated.aftercritical.menu.ItemMachineMenu;
import cn.blockforge.generated.aftercritical.menu.LogisticsControllerMenu;
import cn.blockforge.generated.aftercritical.menu.NeutronFluxRecorderMenu;
import cn.blockforge.generated.aftercritical.menu.NukeMenu;
import cn.blockforge.generated.aftercritical.menu.PwrControllerMenu;
import cn.blockforge.generated.aftercritical.menu.ReactorMenu;
import cn.blockforge.generated.aftercritical.menu.ResearchReactorMenu;
import cn.blockforge.generated.aftercritical.menu.SodiumSteamGeneratorMenu;
import cn.blockforge.generated.aftercritical.menu.SteamGeneratorMenu;
import cn.blockforge.generated.aftercritical.menu.TankControllerMenu;
import cn.blockforge.generated.aftercritical.menu.TokamakMenu;
import cn.blockforge.generated.aftercritical.menu.TransmutatorMenu;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * GUI 菜单类型的注册表。
 *
 * <p>用 NeoForge 的 {@code IMenuTypeExtension} 建菜单，这样可以额外把方块坐标发给客户端，
 * 客户端才知道该打开哪个方块的界面。
 */
public final class ModMenus {

    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, AfterCritical.MOD_ID);

    public static final DeferredHolder<MenuType<?>, MenuType<CrusherMenu>> CRUSHER =
            MENUS.register("crusher", () -> IMenuTypeExtension.create(CrusherMenu::fromNetwork));

    public static final DeferredHolder<MenuType<?>, MenuType<BallMillMenu>> BALL_MILL =
            MENUS.register("ball_mill", () -> IMenuTypeExtension.create(BallMillMenu::fromNetwork));

    public static final DeferredHolder<MenuType<?>, MenuType<ForgingPressMenu>> FORGING_PRESS =
            MENUS.register("forging_press", () -> IMenuTypeExtension.create(ForgingPressMenu::fromNetwork));

    /** 压块机的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<CompactorMenu>> COMPACTOR =
            MENUS.register("compactor", () -> IMenuTypeExtension.create(CompactorMenu::fromNetwork));

    /** 装配机 T1 的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<AssemblerT1Menu>> ASSEMBLER_T1 =
            MENUS.register("assembler_t1", () -> IMenuTypeExtension.create(AssemblerT1Menu::fromNetwork));

    /** 装配机 T2 的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<AssemblerT2Menu>> ASSEMBLER_T2 =
            MENUS.register("assembler_t2", () -> IMenuTypeExtension.create(AssemblerT2Menu::fromNetwork));

    /** 燃烧发电机的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<GeneratorMenu>> COMBUSTION_GENERATOR =
            MENUS.register("combustion_generator", () -> IMenuTypeExtension.create(
                    (id, inventory, buffer) -> GeneratorMenu.fromNetwork(
                            ModMenus.COMBUSTION_GENERATOR.get(), id, inventory, buffer)));

    /** 燃料棒发电机的界面（和燃烧发电机共用同一个菜单类）。 */
    public static final DeferredHolder<MenuType<?>, MenuType<GeneratorMenu>> FUEL_ROD_GENERATOR =
            MENUS.register("fuel_rod_generator", () -> IMenuTypeExtension.create(
                    (id, inventory, buffer) -> GeneratorMenu.fromNetwork(
                            ModMenus.FUEL_ROD_GENERATOR.get(), id, inventory, buffer)));

    /** 电池 LV 的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<BatteryLvMenu>> BATTERY_LV =
            MENUS.register("battery_lv", () -> IMenuTypeExtension.create(BatteryLvMenu::fromNetwork));

    /** 电解槽的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> ELECTROLYZER =
            MENUS.register("electrolyzer", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.ELECTROLYZER.get(), id, inventory, buffer,
                            FluidMachineKind.ELECTROLYZER)));

    /** 化工厂的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> CHEMICAL_PLANT =
            MENUS.register("chemical_plant", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.CHEMICAL_PLANT.get(), id, inventory, buffer,
                            FluidMachineKind.CHEMICAL_PLANT)));

    /** 空气分离器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> AIR_SEPARATOR =
            MENUS.register("air_separator", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.AIR_SEPARATOR.get(), id, inventory, buffer,
                            FluidMachineKind.AIR_SEPARATOR)));

    /** 地下水开采机的界面（一根出液长条 + 操作 / 返还槽）。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> GROUNDWATER_PUMP =
            MENUS.register("groundwater_pump", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.GROUNDWATER_PUMP.get(), id, inventory, buffer,
                            FluidMachineKind.GROUNDWATER_PUMP)));

    /** 浸出槽的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> LEACHING_TANK =
            MENUS.register("leaching_tank", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.LEACHING_TANK.get(), id, inventory, buffer,
                            FluidMachineKind.LEACHING_TANK)));

    /** 沉淀槽的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> PRECIPITATION_TANK =
            MENUS.register("precipitation_tank", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.PRECIPITATION_TANK.get(), id, inventory, buffer,
                            FluidMachineKind.PRECIPITATION_TANK)));

    /** 干燥炉的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> DRYING_OVEN =
            MENUS.register("drying_oven", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.DRYING_OVEN.get(), id, inventory, buffer,
                            FluidMachineKind.DRYING_OVEN)));

    /** 转化炉的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> CONVERTER =
            MENUS.register("converter", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.CONVERTER.get(), id, inventory, buffer,
                            FluidMachineKind.CONVERTER)));

    /** 氟化反应器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> FLUORINATION_REACTOR =
            MENUS.register("fluorination_reactor", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.FLUORINATION_REACTOR.get(), id, inventory, buffer,
                            FluidMachineKind.FLUORINATION_REACTOR)));

    /** 气体离心机的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> GAS_CENTRIFUGE =
            MENUS.register("gas_centrifuge", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.GAS_CENTRIFUGE.get(), id, inventory, buffer,
                            FluidMachineKind.GAS_CENTRIFUGE)));

    /** 水解反应器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> HYDROLYSIS_REACTOR =
            MENUS.register("hydrolysis_reactor", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.HYDROLYSIS_REACTOR.get(), id, inventory, buffer,
                            FluidMachineKind.HYDROLYSIS_REACTOR)));

    /** 辐照靶冷却池的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> IRRADIATION_POOL =
            MENUS.register("irradiation_pool", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.IRRADIATION_POOL.get(), id, inventory, buffer,
                            FluidMachineKind.IRRADIATION_POOL)));

    /** 冷凝器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> CONDENSER =
            MENUS.register("condenser", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.CONDENSER.get(), id, inventory, buffer,
                            FluidMachineKind.CONDENSER)));

    // ------------------------------------------------------------------
    // 阶段 6：乏燃料后处理线的五台流体机器
    // ------------------------------------------------------------------

    /** 乏燃料冷却池的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> SPENT_FUEL_POOL =
            MENUS.register("spent_fuel_pool", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.SPENT_FUEL_POOL.get(), id, inventory, buffer,
                            FluidMachineKind.SPENT_FUEL_POOL)));

    /** 溶解槽的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> DISSOLUTION_TANK =
            MENUS.register("dissolution_tank", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.DISSOLUTION_TANK.get(), id, inventory, buffer,
                            FluidMachineKind.DISSOLUTION_TANK)));

    /** 萃取柱的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> EXTRACTION_COLUMN =
            MENUS.register("extraction_column", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.EXTRACTION_COLUMN.get(), id, inventory, buffer,
                            FluidMachineKind.EXTRACTION_COLUMN)));

    /** 离心萃取器的界面（三格产物槽）。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> CENTRIFUGAL_EXTRACTOR =
            MENUS.register("centrifugal_extractor", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.CENTRIFUGAL_EXTRACTOR.get(), id, inventory, buffer,
                            FluidMachineKind.CENTRIFUGAL_EXTRACTOR)));

    /** 玻璃固化炉的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidMachineMenu>> VITRIFICATION_FURNACE =
            MENUS.register("vitrification_furnace", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    FluidMachineMenu.fromNetwork(ModMenus.VITRIFICATION_FURNACE.get(), id, inventory, buffer,
                            FluidMachineKind.VITRIFICATION_FURNACE)));

    /** 级联控制器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<CascadeControllerMenu>> CASCADE_CONTROLLER =
            MENUS.register("cascade_controller", () -> IMenuTypeExtension.create(CascadeControllerMenu::fromNetwork));

    /** 烧结炉的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<ItemMachineMenu>> SINTERING_FURNACE =
            MENUS.register("sintering_furnace", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    ItemMachineMenu.fromNetwork(ModMenus.SINTERING_FURNACE.get(), id, inventory, buffer,
                            ItemMachineKind.SINTERING_FURNACE)));

    /** 磨削机的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<ItemMachineMenu>> GRINDING_MACHINE =
            MENUS.register("grinding_machine", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    ItemMachineMenu.fromNetwork(ModMenus.GRINDING_MACHINE.get(), id, inventory, buffer,
                            ItemMachineKind.GRINDING_MACHINE)));

    /** 焊接机的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<ItemMachineMenu>> WELDING_MACHINE =
            MENUS.register("welding_machine", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    ItemMachineMenu.fromNetwork(ModMenus.WELDING_MACHINE.get(), id, inventory, buffer,
                            ItemMachineKind.WELDING_MACHINE)));

    /** 伽马辐照器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<ItemMachineMenu>> GAMMA_IRRADIATOR =
            MENUS.register("gamma_irradiator", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    ItemMachineMenu.fromNetwork(ModMenus.GAMMA_IRRADIATOR.get(), id, inventory, buffer,
                            ItemMachineKind.GAMMA_IRRADIATOR)));

    /** 核装置总装台的界面（4 进 1 出，武器线专用）。 */
    public static final DeferredHolder<MenuType<?>, MenuType<ItemMachineMenu>> WARHEAD_ASSEMBLER =
            MENUS.register("warhead_assembler", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    ItemMachineMenu.fromNetwork(ModMenus.WARHEAD_ASSEMBLER.get(), id, inventory, buffer,
                            ItemMachineKind.WARHEAD_ASSEMBLY)));

    /** 剪切机的界面（1 进 2 出）。 */
    public static final DeferredHolder<MenuType<?>, MenuType<ItemMachineMenu>> SHEARING_MACHINE =
            MENUS.register("shearing_machine", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    ItemMachineMenu.fromNetwork(ModMenus.SHEARING_MACHINE.get(), id, inventory, buffer,
                            ItemMachineKind.SHEARING_MACHINE)));

    /** 物流控制器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<LogisticsControllerMenu>> LOGISTICS_CONTROLLER =
            MENUS.register("logistics_controller", () -> IMenuTypeExtension.create(
                    LogisticsControllerMenu::fromNetwork));

    /** 三台物品机器共用一套菜单代码，打开时按型号拿对应的菜单类型。 */
    public static MenuType<?> menuForItemMachine(ItemMachineKind kind) {
        return switch (kind) {
            case SINTERING_FURNACE -> SINTERING_FURNACE.get();
            case GRINDING_MACHINE -> GRINDING_MACHINE.get();
            case WELDING_MACHINE -> WELDING_MACHINE.get();
            case GAMMA_IRRADIATOR -> GAMMA_IRRADIATOR.get();
            case SHEARING_MACHINE -> SHEARING_MACHINE.get();
            case WARHEAD_ASSEMBLY -> WARHEAD_ASSEMBLER.get();
        };
    }

    /** 流体识别码的界面（选流体、给罐子预设）。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FluidIdentifierMenu>> FLUID_IDENTIFIER =
            MENUS.register("fluid_identifier", () -> IMenuTypeExtension.create(
                    (id, inventory, buffer) -> new FluidIdentifierMenu(id, inventory)));

    /** 储罐多方块控制器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<TankControllerMenu>> TANK_CONTROLLER =
            MENUS.register("tank_controller", () -> IMenuTypeExtension.create(TankControllerMenu::fromNetwork));

    /** 十台流体机器共用一套菜单代码，打开时按型号拿对应的菜单类型。 */
    public static MenuType<?> menuFor(FluidMachineKind kind) {
        return switch (kind) {
            case ELECTROLYZER -> ELECTROLYZER.get();
            case CHEMICAL_PLANT -> CHEMICAL_PLANT.get();
            case AIR_SEPARATOR -> AIR_SEPARATOR.get();
            case GROUNDWATER_PUMP -> GROUNDWATER_PUMP.get();
            case LEACHING_TANK -> LEACHING_TANK.get();
            case PRECIPITATION_TANK -> PRECIPITATION_TANK.get();
            case DRYING_OVEN -> DRYING_OVEN.get();
            case CONVERTER -> CONVERTER.get();
            case FLUORINATION_REACTOR -> FLUORINATION_REACTOR.get();
            case GAS_CENTRIFUGE -> GAS_CENTRIFUGE.get();
            case HYDROLYSIS_REACTOR -> HYDROLYSIS_REACTOR.get();
            case IRRADIATION_POOL -> IRRADIATION_POOL.get();
            case CONDENSER -> CONDENSER.get();
            case SPENT_FUEL_POOL -> SPENT_FUEL_POOL.get();
            case DISSOLUTION_TANK -> DISSOLUTION_TANK.get();
            case EXTRACTION_COLUMN -> EXTRACTION_COLUMN.get();
            case CENTRIFUGAL_EXTRACTOR -> CENTRIFUGAL_EXTRACTOR.get();
            case VITRIFICATION_FURNACE -> VITRIFICATION_FURNACE.get();
        };
    }

    // ------------------------------------------------------------------
    // 阶段 3：两种反应堆控制器 + 中子通量记录仪
    // ------------------------------------------------------------------

    /** 次临界增殖装置控制器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<ReactorMenu>> SUBCRITICAL_CONTROLLER =
            MENUS.register("subcritical_controller", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    ReactorMenu.fromNetwork(ModMenus.SUBCRITICAL_CONTROLLER.get(), ReactorKind.SUBCRITICAL,
                            id, inventory, buffer)));

    /** 临界实验堆控制器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<ReactorMenu>> CRITICAL_REACTOR_CONTROLLER =
            MENUS.register("critical_reactor_controller", () -> IMenuTypeExtension.create((id, inventory, buffer) ->
                    ReactorMenu.fromNetwork(ModMenus.CRITICAL_REACTOR_CONTROLLER.get(), ReactorKind.CRITICAL,
                            id, inventory, buffer)));

    /** 中子通量记录仪的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<NeutronFluxRecorderMenu>> NEUTRON_FLUX_RECORDER =
            MENUS.register("neutron_flux_recorder", () -> IMenuTypeExtension.create(
                    NeutronFluxRecorderMenu::fromNetwork));

    /** 两种反应堆共用一套菜单代码，打开时按型号拿对应的菜单类型。 */
    public static MenuType<?> reactorMenuFor(ReactorKind kind) {
        return switch (kind) {
            case SUBCRITICAL -> SUBCRITICAL_CONTROLLER.get();
            case CRITICAL -> CRITICAL_REACTOR_CONTROLLER.get();
        };
    }

    // ------------------------------------------------------------------
    // 阶段 4：装配机 T3 + 研究堆控制器
    // ------------------------------------------------------------------

    /** 装配机 T3 的界面（3 进 1 出）。 */
    public static final DeferredHolder<MenuType<?>, MenuType<AssemblerT3Menu>> ASSEMBLER_T3 =
            MENUS.register("assembler_t3", () -> IMenuTypeExtension.create(AssemblerT3Menu::fromNetwork));

    /** 研究堆控制器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<ResearchReactorMenu>> RESEARCH_REACTOR =
            MENUS.register("research_reactor", () -> IMenuTypeExtension.create(ResearchReactorMenu::fromNetwork));

    // ------------------------------------------------------------------
    // 阶段 5：热室机械臂 + 压水堆 + 汽轮发电机
    // ------------------------------------------------------------------

    /** 热室机械臂的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<HotCellArmMenu>> HOT_CELL_ARM =
            MENUS.register("hot_cell_arm", () -> IMenuTypeExtension.create(HotCellArmMenu::fromNetwork));

    /** 压水堆控制器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<PwrControllerMenu>> PWR_CONTROLLER =
            MENUS.register("pwr_controller", () -> IMenuTypeExtension.create(PwrControllerMenu::fromNetwork));

    /** 汽轮发电机的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<SteamGeneratorMenu>> STEAM_GENERATOR =
            MENUS.register("steam_generator", () -> IMenuTypeExtension.create(SteamGeneratorMenu::fromNetwork));

    /** 燃料端口的界面：8 个燃料格 + 燃烧进度。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FuelPortMenu>> FUEL_PORT =
            MENUS.register("fuel_port", () -> IMenuTypeExtension.create(FuelPortMenu::fromNetwork));

    // ------------------------------------------------------------------
    // 阶段 6：钠冷快堆
    // ------------------------------------------------------------------

    /** 钠冷快堆控制器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<FastReactorMenu>> FAST_REACTOR_CONTROLLER =
            MENUS.register("fast_reactor_controller", () -> IMenuTypeExtension.create(
                    FastReactorMenu::fromNetwork));

    /** 钠-水蒸汽发生器的界面（水进、乏蒸汽出、电从旁边送走）。 */
    public static final DeferredHolder<MenuType<?>, MenuType<SodiumSteamGeneratorMenu>> SODIUM_STEAM_GENERATOR =
            MENUS.register("sodium_steam_generator", () -> IMenuTypeExtension.create(
                    SodiumSteamGeneratorMenu::fromNetwork));

    // ------------------------------------------------------------------
    // 阶段 7：托卡马克与物质嬗变器
    // ------------------------------------------------------------------

    /** 托卡马克控制器的界面（燃料 + 氚 + 点火按钮）。 */
    public static final DeferredHolder<MenuType<?>, MenuType<TokamakMenu>> TOKAMAK_CONTROLLER =
            MENUS.register("tokamak_controller", () -> IMenuTypeExtension.create(TokamakMenu::fromNetwork));

    /** 电池 MV 的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<BatteryMvMenu>> BATTERY_MV =
            MENUS.register("battery_mv", () -> IMenuTypeExtension.create(BatteryMvMenu::fromNetwork));

    /** 巨型储能库的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<GiantBatteryMenu>> GIANT_BATTERY =
            MENUS.register("giant_battery", () -> IMenuTypeExtension.create(GiantBatteryMenu::fromNetwork));

    /** 物质嬗变器控制器的界面。 */
    public static final DeferredHolder<MenuType<?>, MenuType<TransmutatorMenu>> TRANSMUTATOR_CONTROLLER =
            MENUS.register("transmutator_controller", () -> IMenuTypeExtension.create(
                    TransmutatorMenu::fromNetwork));

    /** 核弹装配界面：六个模块化组件槽。 */
    public static final DeferredHolder<MenuType<?>, MenuType<NukeMenu>> NUKE =
            MENUS.register("nuke", () -> IMenuTypeExtension.create(NukeMenu::fromNetwork));

    private ModMenus() {}
}
