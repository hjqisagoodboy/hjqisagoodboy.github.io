package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.blockentity.TokamakControllerBlockEntity;
import cn.blockforge.generated.aftercritical.menu.TokamakMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;

/**
 * 托卡马克控制器的界面：燃料格下面一个「点火」按钮，底下一串读数。
 *
 * <p>读数先告诉玩家还差哪几块结构，再说电攒够没有、氚槽满没满、无线往几个端口送电，
 * 最后一行才是状态。这样新手照着数字补方块就行，不用猜。
 */
public class TokamakScreen extends StatPanelScreen<TokamakMenu> {

    private static final int BUTTON_X = 30;
    private static final int BUTTON_Y = 48;
    private static final int BUTTON_W = 60;
    private static final int BUTTON_H = 14;

    public TokamakScreen(TokamakMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected List<Line> statLines() {
        List<Line> lines = new ArrayList<>(TokamakMenu.STAT_LINES);

        boolean formed = this.menu.isFormed();
        lines.add(new Line(Component.translatable(formed
                ? "gui.aftercritical.reactor.structure_ok"
                : "gui.aftercritical.reactor.structure_missing"), formed ? TEXT_OK : TEXT_BAD));

        lines.add(new Line(Component.translatable("gui.aftercritical.tokamak.parts1",
                this.menu.casing(), TokamakControllerBlockEntity.MIN_CASING,
                this.menu.coils(), TokamakControllerBlockEntity.MIN_COILS,
                this.menu.blankets(), TokamakControllerBlockEntity.MIN_BLANKETS), TEXT_GRAY));

        lines.add(new Line(Component.translatable("gui.aftercritical.tokamak.parts2",
                this.menu.injectors(), TokamakControllerBlockEntity.MIN_INJECTORS,
                this.menu.diagnostics(), TokamakControllerBlockEntity.MIN_DIAGNOSTICS,
                this.menu.coolers(), TokamakControllerBlockEntity.MIN_COOLERS,
                this.menu.logic(), TokamakControllerBlockEntity.MIN_LOGIC), TEXT_GRAY));

        lines.add(new Line(Component.translatable("gui.aftercritical.tokamak.power",
                this.menu.getEnergyStored(), TokamakControllerBlockEntity.ENERGY_CAPACITY,
                this.menu.wirelessSent(), this.menu.portsInRange()), TEXT_DARK));

        lines.add(new Line(Component.translatable("gui.aftercritical.tokamak.fuel",
                this.menu.fuel(), this.menu.tritium(), this.menu.ignitionPercent(),
                this.menu.fuelPercent()), this.menu.breedBlocked() ? TEXT_WARN : TEXT_DARK));

        lines.add(new Line(Component.translatable("gui.aftercritical.tokamak.status." + this.menu.status()),
                statusColorOf(this.menu.status())));
        return lines;
    }

    private static int statusColorOf(int status) {
        return switch (status) {
            case TokamakControllerBlockEntity.STATUS_RUNNING -> TEXT_OK;
            case TokamakControllerBlockEntity.STATUS_NO_FUEL,
                 TokamakControllerBlockEntity.STATUS_CHARGING -> TEXT_WARN;
            case TokamakControllerBlockEntity.STATUS_UNFORMED -> TEXT_BAD;
            default -> TEXT_GRAY;
        };
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        super.renderBg(guiGraphics, partialTick, mouseX, mouseY);
        int x = this.leftPos + BUTTON_X;
        int y = this.topPos + BUTTON_Y;
        guiGraphics.fill(x, y, x + BUTTON_W, y + BUTTON_H, PANEL_BG);
        guiGraphics.fill(x, y, x + BUTTON_W, y + 1, PANEL_LIGHT);
        guiGraphics.fill(x, y + BUTTON_H - 1, x + BUTTON_W, y + BUTTON_H, PANEL_DARK);
        guiGraphics.fill(x, y, x + 1, y + BUTTON_H, PANEL_LIGHT);
        guiGraphics.fill(x + BUTTON_W - 1, y, x + BUTTON_W, y + BUTTON_H, PANEL_DARK);
        Component label = Component.translatable("gui.aftercritical.tokamak.ignite");
        int textWidth = this.font.width(label);
        guiGraphics.drawString(this.font, label,
                x + (BUTTON_W - textWidth) / 2, y + (BUTTON_H - 8) / 2 + 1, TEXT_DARK, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && this.minecraft != null && this.minecraft.gameMode != null) {
            int x = (int) mouseX - this.leftPos;
            int y = (int) mouseY - this.topPos;
            if (x >= BUTTON_X && x < BUTTON_X + BUTTON_W && y >= BUTTON_Y && y < BUTTON_Y + BUTTON_H) {
                this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId,
                        TokamakMenu.BUTTON_IGNITE);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
}
