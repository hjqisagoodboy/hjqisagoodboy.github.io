package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.block.CriticalAlarmBlock;
import cn.blockforge.generated.aftercritical.block.NeutronDetectorBlock;
import cn.blockforge.generated.aftercritical.block.ReactorControllerBlock;
import cn.blockforge.generated.aftercritical.itemhandler.ContainerItemHandler;
import cn.blockforge.generated.aftercritical.menu.ReactorMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModBlocks;
import cn.blockforge.generated.aftercritical.registry.ModEffects;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import cn.blockforge.generated.aftercritical.world.MushroomCloud;
import cn.blockforge.generated.aftercritical.world.NuclearBlast;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;
import net.neoforged.neoforge.items.IItemHandler;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 阶段 3 两个多方块反应堆的大脑：结构检测 + 中子物理 + 界面数据。
 *
 * <p>两种反应堆共用这一个方块实体，差别在 {@link ReactorKind}：尺寸、材料数量、槽位、
 * 物理公式各走各的分支，和阶段 1 十台流体机器共用一个方块实体是一个思路。
 *
 * <h2>结构怎么数</h2>
 * 控制器贴在结构的「正面墙、贴地那一排的正中间」。方块朝哪（放下时玩家看的方向），
 * 立方体就往哪长：宽 = 边长（左右各伸出 (边长-1)/2）、深 = 边长、高 = 边长。
 * 所以 5×5×5 是 125 格、7×7×7 是 343 格——整块立方体都要有东西，
 * 里面放什么由玩家决定，但石墨 / 反射层 / 屏蔽 / 玻璃 / 探测器必须够数。
 *
 * <h2>物理</h2>
 * 只算两件事：有效增殖系数 k_eff 和中子通量。这一版不做氙中毒。
 * <ul>
 *   <li><b>次临界增殖装置</b>：k = 1 - (1 - 0.85) × e^(-B / 0.0177)，B 是石墨和反射层的溢出加成。
 *       越接近 1 越难再往上加，但永远到不了 1；通量 = 150 / (1 - k)，所以也不会爆。</li>
 *   <li><b>临界实验堆</b>：k = 基础反应性 - 控制棒吸收 - 硼酸吸收；
 *       通量按 dΦ/dt = Φ·(k-1)·0.1 走，k > 1 就指数上涨。
 *       k > 1.05 连续 10 秒、或者堆芯烧到 1000 °C，堆芯就熔毁：整个堆炸开，
 *       控制器变成「堆芯残骸」，周围的地变成「污染土」。</li>
 * </ul>
 */
public class ReactorControllerBlockEntity extends BlockEntity
        implements MenuProvider, TickableBlockEntity, Container {

    // ------------------------------------------------------------------
    // 槽位：0 燃料 / 1 核心部件（中子源或控制棒组件）/ 2 输出（熔毁后的燃料棒）
    // ------------------------------------------------------------------

    /** 燃料槽。次临界装置放天然铀棒束，实验堆放密封燃料棒。 */
    public static final int SLOT_FUEL = 0;
    /** 核心部件槽：次临界装置放中子源，实验堆放控制棒组件。 */
    public static final int SLOT_AUX = 1;
    /** 输出槽：只有实验堆用，熔毁的燃料棒掉这里。 */
    public static final int SLOT_OUT = 2;

    // ------------------------------------------------------------------
    // 次临界增殖装置的物理常数
    // ------------------------------------------------------------------

    /** 结构齐了、中子源放好之后的固定 k（设计值）。 */
    public static final double SUBCRITICAL_BASE_K = 0.85;
    /**
     * 次临界 k_eff 的渐近形状：k = 1 - (1 - 0.85) × e^(-B / 0.0177)。
     *
     * <p>B 是「多出来的石墨 × 0.0005 + 多出来的反射层 × 0.001」。
     * 这就是次临界倍增的样子：越接近 1 越难再往上加，但永远到不了 1。
     * <ul>
     *   <li>只满足最低要求（B = 0）：0.850</li>
     *   <li>石墨 32 / 反射 64（B = 0.048）：0.990</li>
     *   <li>5×5×5 里塞满反射层（B = 0.108）：0.99966</li>
     * </ul>
     * 想让 k 更贴近 1 就把这个数调小（比如 0.01，满反射能到 0.999998）。
     */
    public static final double SUBCRITICAL_ASYMPTOTE_SCALE = 0.0177;
    /**
     * 次临界 k 的硬上限：公式本身永远到不了 1，这里再留一点浮点余量，
     * 免得 150 / (1 - k) 除出无穷大。
     */
    public static final double SUBCRITICAL_MAX_K = 1.0 - 1.0E-6;
    /** 一炉要点几捆天然铀棒束。 */
    public static final int SUBCRITICAL_FUEL_NEEDED = 16;
    /** 每多一块石墨慢化剂，k 涨多少。 */
    public static final double SUBCRITICAL_GRAPHITE_BONUS = 0.0005;
    /** 每多一块反射层，k 涨多少。 */
    public static final double SUBCRITICAL_REFLECTOR_BONUS = 0.001;
    /** 通量基准：k = 0.85 时通量正好 1000（150 / (1 - 0.85)）。 */
    public static final double SUBCRITICAL_FLUX_SOURCE = 150.0;
    /** 次临界的「满刻度」通量：等于下面临界实验堆的 MAX_FLUX（1,000,000）。 */
    public static final double SUBCRITICAL_TEMP_SCALE_FLUX = 1_000_000.0;
    /** 次临界堆芯温度的封顶：240 °C（次临界不会熔毁，只是数字别离谱）。 */
    public static final double SUBCRITICAL_TEMP_MAX = 240.0;

    // ------------------------------------------------------------------
    // 临界实验堆的物理常数
    // ------------------------------------------------------------------

    /** 8 根密封燃料棒时的基础反应性。 */
    public static final double CRITICAL_BASE_K_MIN = 1.05;
    /** 24 根密封燃料棒时的基础反应性。 */
    public static final double CRITICAL_BASE_K_MAX = 1.15;
    /** 一炉至少几根密封燃料棒。 */
    public static final int CRITICAL_MIN_RODS = 8;
    /** 一炉最多算几根密封燃料棒。 */
    public static final int CRITICAL_MAX_RODS = 24;
    /** 控制棒端口数量（控制器自动开 4 个）。 */
    public static final int CONTROL_ROD_PORTS = 4;
    /** 一根控制棒组件、100% 插入时吸收多少反应性。 */
    public static final double ROD_ABSORPTION_EACH = 0.02;
    /** 硼酸注满 1000 mB 时吸收多少反应性。 */
    public static final double BORIC_ABSORPTION_MAX = 0.08;
    /** 硼酸罐容量（硼酸储罐、控制器内部各 1000 mB）。 */
    public static final int BORIC_CAPACITY = 1000;
    /** k 超过 1.05 多少 tick 算熔毁（200 tick = 10 秒）。 */
    public static final int MELTDOWN_TICKS = 200;
    /** 到这个 k 就算「超临界得太厉害」。 */
    public static final double MELTDOWN_K = 1.05;
    /** 堆芯温度到多少度熔毁。 */
    public static final double MELTDOWN_TEMPERATURE = 1000.0;
    /** 中子通量的显示上限。 */
    public static final double MAX_FLUX = 1_000_000.0;
    /** 硼酸消耗速度：每 20 tick 烧 1 mB（一罐能撑 1000 秒）。 */
    private static final int BORIC_DRAIN_INTERVAL = 20;

    // ------------------------------------------------------------------
    // 熔毁之后留下的烂摊子
    // ------------------------------------------------------------------

    /** 熔毁瞬间给多少格以内的玩家挂辐射（跟核爆半径一样大）。 */
    public static final double MELTDOWN_RADIATION_RADIUS = NuclearBlast.DESTROY_RADIUS;

    // ------------------------------------------------------------------
    // 界面上的状态码
    // ------------------------------------------------------------------

    /** 结构没搭好。 */
    public static final int STATUS_UNFORMED = 0;
    /** 结构好了但没燃料 / 没中子源，没启动。 */
    public static final int STATUS_IDLE = 1;
    /** 次临界：k < 1，通量稳定。 */
    public static final int STATUS_SUBCRITICAL = 2;
    /** 正好临界：k ≈ 1.000。 */
    public static final int STATUS_CRITICAL = 3;
    /** 超临界：k > 1，通量在指数上涨。 */
    public static final int STATUS_SUPERCRITICAL = 4;
    /** 燃料已经熔毁。 */
    public static final int STATUS_MELTED = 5;

    /** 多久重新检查一次结构（tick）。 */
    public static final int VALIDATE_INTERVAL = 40;

    private final NonNullList<ItemStack> items;

    /** 控制器内部那一小罐硼酸：管道从硼酸储罐抽过来就倒在这里。 */
    private final FluidTank boricTank = new FluidTank(BORIC_CAPACITY) {
        @Override
        public boolean isFluidValid(FluidStack stack) {
            return stack.getFluid() == ModFluids.BORIC_ACID.source.get();
        }
    };

    private final IItemHandler itemHandler = new ContainerItemHandler(this,
            slot -> slot == SLOT_FUEL || slot == SLOT_AUX,
            slot -> slot == SLOT_OUT,
            slot -> getMaxStackSize());

    private final IFluidHandler fluidHandler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return 1;
        }

        @Override
        public FluidStack getFluidInTank(int tank) {
            return ReactorControllerBlockEntity.this.boricTank.getFluid();
        }

        @Override
        public int getTankCapacity(int tank) {
            return BORIC_CAPACITY;
        }

        @Override
        public boolean isFluidValid(int tank, FluidStack stack) {
            return stack.getFluid() == ModFluids.BORIC_ACID.source.get();
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            int filled = ReactorControllerBlockEntity.this.boricTank.fill(resource, action);
            if (filled > 0 && action.execute()) {
                setChanged();
            }
            return filled;
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            FluidStack drained = ReactorControllerBlockEntity.this.boricTank.drain(resource, action);
            if (!drained.isEmpty() && action.execute()) {
                setChanged();
            }
            return drained;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            FluidStack drained = ReactorControllerBlockEntity.this.boricTank.drain(maxDrain, action);
            if (!drained.isEmpty() && action.execute()) {
                setChanged();
            }
            return drained;
        }
    };

    // 结构计数（每 2 秒刷新一次，界面直接读）
    private boolean formed;
    private int graphiteCount;
    private int reflectorCount;
    private int shieldCount;
    private int glassCount;
    private int detectorCount;
    private final List<BlockPos> detectorPositions = new ArrayList<>();
    private final List<BlockPos> alarmPositions = new ArrayList<>();

    // 物理状态
    private double kEff;
    private double flux;
    private double temperature = 20.0;
    private int rodDepth;
    private int overCriticalTicks;
    private int status = STATUS_UNFORMED;
    private int ticks;
    private int validateTimer;

    /** 成就用的两个一次性开关：通量起来、k 到 1.0，各自只记一次。 */
    private boolean subcriticalMilestoneFired;
    private boolean criticalMilestoneFired;

    public ReactorControllerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.REACTOR_CONTROLLER.get(), pos, state);
        this.items = NonNullList.withSize(slotCount(state), ItemStack.EMPTY);
    }

    /** 这个方块是哪种反应堆。 */
    public ReactorKind kind() {
        if (getBlockState().getBlock() instanceof ReactorControllerBlock block) {
            return block.kind();
        }
        return ReactorKind.SUBCRITICAL;
    }

    /** 槽位数：次临界装置两个（燃料 + 中子源），实验堆三个（多一个输出）。 */
    public static int slotCount(BlockState state) {
        return state.getBlock() instanceof ReactorControllerBlock block
                ? (block.kind() == ReactorKind.SUBCRITICAL ? 2 : 3)
                : 2;
    }

    public IItemHandler getItemHandler() {
        return this.itemHandler;
    }

    public IFluidHandler getFluidHandler() {
        return this.fluidHandler;
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        this.ticks++;
        if (++this.validateTimer >= VALIDATE_INTERVAL) {
            this.validateTimer = 0;
            validateStructure();
        }
        tickPhysics();
        pushOutputs();
    }

    /** 有空的时候立刻重查一遍结构（放方块、拆方块时调用）。 */
    public void validateSoon() {
        this.validateTimer = VALIDATE_INTERVAL - 1;
    }

    // ------------------------------------------------------------------
    // 结构检测
    // ------------------------------------------------------------------

    /**
     * 数一遍整个立方体里的材料。
     *
     * <p>控制器自己那一格算「控制器」，别的格子按方块类型分别计数；
     * 空气和其它方块不计数（但也不拦着——玩家往里填石头也行）。
     */
    public void validateStructure() {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        ReactorKind kind = kind();
        Direction facing = facing();
        // 与朝向垂直的水平方向：把朝向转 90°
        int px = facing.getStepZ();
        int pz = -facing.getStepX();
        int radius = (kind.size() - 1) / 2;

        int graphite = 0;
        int reflector = 0;
        int shield = 0;
        int glass = 0;
        int detectors = 0;
        List<BlockPos> foundDetectors = new ArrayList<>();
        List<BlockPos> foundAlarms = new ArrayList<>();
        boolean complete = true;

        for (int depth = 0; depth < kind.size() && complete; depth++) {
            for (int side = -radius; side <= radius && complete; side++) {
                for (int up = 0; up < kind.size() && complete; up++) {
                    BlockPos pos = this.worldPosition.offset(
                            facing.getStepX() * depth + px * side, up, facing.getStepZ() * depth + pz * side);
                    if (!server.isLoaded(pos)) {
                        complete = false;
                        break;
                    }
                    if (pos.equals(this.worldPosition)) {
                        continue;
                    }
                    BlockState state = server.getBlockState(pos);
                    Block block = state.getBlock();
                    if (block == ModBlocks.GRAPHITE_MODERATOR.get()) {
                        graphite++;
                    } else if (block == ModBlocks.BERYLLIUM_REFLECTOR.get()) {
                        reflector++;
                    } else if (block == ModBlocks.RADIATION_SHIELD.get()) {
                        shield++;
                    } else if (state.is(Blocks.GLASS)) {
                        glass++;
                    } else if (block == ModBlocks.NEUTRON_DETECTOR.get()) {
                        detectors++;
                        foundDetectors.add(pos.immutable());
                    } else if (block == ModBlocks.CRITICAL_ALARM.get()) {
                        foundAlarms.add(pos.immutable());
                    }
                }
            }
        }

        boolean nowFormed = complete
                && graphite >= kind.minGraphite()
                && reflector >= kind.minReflector()
                && shield >= kind.minShield()
                && glass >= kind.minGlass()
                && detectors >= kind.minDetectors();

        boolean changed = nowFormed != this.formed
                || graphite != this.graphiteCount
                || reflector != this.reflectorCount
                || shield != this.shieldCount
                || glass != this.glassCount
                || detectors != this.detectorCount
                || !foundDetectors.equals(this.detectorPositions)
                || !foundAlarms.equals(this.alarmPositions);

        this.formed = nowFormed;
        this.graphiteCount = graphite;
        this.reflectorCount = reflector;
        this.shieldCount = shield;
        this.glassCount = glass;
        this.detectorCount = detectors;
        this.detectorPositions.clear();
        this.detectorPositions.addAll(foundDetectors);
        this.alarmPositions.clear();
        this.alarmPositions.addAll(foundAlarms);
        if (changed) {
            setChanged();
        }
    }

    /** 方块朝哪（放下时玩家看的方向），结构就往哪长。 */
    private Direction facing() {
        BlockState state = getBlockState();
        if (state.hasProperty(ReactorControllerBlock.FACING)) {
            return state.getValue(ReactorControllerBlock.FACING);
        }
        return Direction.NORTH;
    }

    // ------------------------------------------------------------------
    // 物理
    // ------------------------------------------------------------------

    private void tickPhysics() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        if (!this.formed) {
            windDown();
            this.status = STATUS_UNFORMED;
            return;
        }
        ReactorKind kind = kind();
        if (kind == ReactorKind.SUBCRITICAL) {
            tickSubcritical(kind);
        } else {
            tickCritical();
        }
        // 温度跟着通量走。实验堆是线性的：通量 1000 大概 70 °C，20 万就到 1000 °C。
        // 次临界通量能到几十万，线性算会显示成 2000 多度，改成对数式、封顶 240 °C——
        // 次临界本来就不会熔毁，这个数字只是给玩家一个「堆里越来越亮」的感觉。
        double target = kind() == ReactorKind.SUBCRITICAL
                ? subcriticalTemperature(this.flux)
                : 20.0 + this.flux / 200.0;
        this.temperature += (target - this.temperature) * 0.02;
        if (this.temperature < 20.0) {
            this.temperature = 20.0;
        }
    }

    /**
     * 次临界堆芯温度：20 °C 起，按通量的对数往上爬。
     *
     * <p>通量 1000（k = 0.85）≈ 130 °C；通量 44 万（k = 0.99966）≈ 227 °C；
     * 通量到 1,000,000 就封顶 240 °C。永远不会熔毁。
     */
    public static double subcriticalTemperature(double flux) {
        double ratio = Math.log10(1.0 + Math.max(0.0, flux))
                / Math.log10(1.0 + SUBCRITICAL_TEMP_SCALE_FLUX);
        double clamped = Math.max(0.0, Math.min(1.0, ratio));
        return 20.0 + (SUBCRITICAL_TEMP_MAX - 20.0) * clamped;
    }

    /** 停堆：k 记 0，通量指数衰减到 0，温度回落到室温。 */
    private void windDown() {
        this.kEff = 0.0;
        this.flux *= 0.98;
        if (this.flux < 0.5) {
            this.flux = 0.0;
        }
        this.temperature += (20.0 - this.temperature) * 0.02;
        this.overCriticalTicks = 0;
    }

    private void tickSubcritical(ReactorKind kind) {
        int fuel = countItems(SLOT_FUEL);
        boolean hasSource = !this.items.get(SLOT_AUX).isEmpty();
        if (!hasSource || fuel < SUBCRITICAL_FUEL_NEEDED) {
            windDown();
            this.status = STATUS_IDLE;
            return;
        }
        double graphiteBonus = Math.max(0, this.graphiteCount - kind.minGraphite())
                * SUBCRITICAL_GRAPHITE_BONUS;
        double reflectorBonus = Math.max(0, this.reflectorCount - kind.minReflector())
                * SUBCRITICAL_REFLECTOR_BONUS;
        // 次临界倍增的渐近式：k = 1 - (1 - 0.85) × e^(-B / 0.0177)。
        // 多出来的慢化剂 / 反射层越多，k 越靠近 1，但永远不到 1（所以永远炸不了）。
        double bonus = graphiteBonus + reflectorBonus;
        this.kEff = Math.min(SUBCRITICAL_MAX_K,
                1.0 - (1.0 - SUBCRITICAL_BASE_K) * Math.exp(-bonus / SUBCRITICAL_ASYMPTOTE_SCALE));
        // 次临界的通量正比于 1/(1-k)：k 越接近 1，堆里越「亮」，但永远不会自己跑飞
        double target = Math.min(MAX_FLUX, SUBCRITICAL_FLUX_SOURCE / (1.0 - this.kEff));
        this.flux += (target - this.flux) * 0.05;
        this.status = STATUS_SUBCRITICAL;

        // 通量爬过 500 就点亮成就「慢中子的嗡鸣」，只记一次
        if (!this.subcriticalMilestoneFired && this.flux >= 500.0) {
            this.subcriticalMilestoneFired = true;
            ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 48.0,
                    ModAdvancementTriggers.SUBCRITICAL_FLUX);
        }
    }

    private void tickCritical() {
        int fuel = Math.min(CRITICAL_MAX_RODS, countItems(SLOT_FUEL));
        int rods = Math.min(CONTROL_ROD_PORTS, countItems(SLOT_AUX));
        if (fuel < CRITICAL_MIN_RODS) {
            windDown();
            this.status = hasMeltedFuel() ? STATUS_MELTED : STATUS_IDLE;
            return;
        }
        // 基础反应性：8 根 1.05，24 根 1.15，中间按根数线性插值
        double base = CRITICAL_BASE_K_MIN
                + (fuel - CRITICAL_MIN_RODS)
                * (CRITICAL_BASE_K_MAX - CRITICAL_BASE_K_MIN) / (CRITICAL_MAX_RODS - CRITICAL_MIN_RODS);
        double rodAbsorption = ROD_ABSORPTION_EACH * rods * (this.rodDepth / 100.0);
        double boricAbsorption = BORIC_ABSORPTION_MAX
                * (this.boricTank.getFluidAmount() / (double) BORIC_CAPACITY);
        this.kEff = base - rodAbsorption - boricAbsorption;

        // 硼酸不是白给的：一边吸收中子一边被消耗，玩家得靠管道不停补
        if (this.boricTank.getFluidAmount() > 0 && this.ticks % BORIC_DRAIN_INTERVAL == 0) {
            this.boricTank.drain(1, IFluidHandler.FluidAction.EXECUTE);
            setChanged();
        }

        double reactivity = this.kEff - 1.0;
        this.flux += this.flux * reactivity * 0.1 + 10.0;
        if (this.flux < 0.0) {
            this.flux = 0.0;
        }
        if (this.flux > MAX_FLUX) {
            this.flux = MAX_FLUX;
        }

        if (this.kEff > 1.0) {
            this.status = STATUS_SUPERCRITICAL;
        } else if (this.kEff >= 0.9995) {
            this.status = STATUS_CRITICAL;
        } else {
            this.status = STATUS_SUBCRITICAL;
        }

        // 第一次把 k_eff 拉上 1.0：成就「首次临界」，只记一次
        if (!this.criticalMilestoneFired && this.kEff >= 1.0) {
            this.criticalMilestoneFired = true;
            ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 48.0,
                    ModAdvancementTriggers.FISSION_CRITICAL);
        }

        if (this.kEff > MELTDOWN_K) {
            this.overCriticalTicks++;
        } else {
            this.overCriticalTicks = 0;
        }
        checkMeltdown();
    }

    /** 两种熔毁条件：超临界太久，或者堆芯太烫。 */
    private void checkMeltdown() {
        if (this.overCriticalTicks < MELTDOWN_TICKS && this.temperature < MELTDOWN_TEMPERATURE) {
            return;
        }
        meltDown();
    }

    /**
     * 熔毁：以堆芯为中心起一场 120 格的核爆，控制器变成「堆芯残骸」。
     *
     * <p>顺序不能乱：
     * <ol>
     *   <li>先把槽里的东西接出来、清空槽位——爆炸会把控制器掀掉，
     *       方块实体一没，槽里的东西就跟着没了；</li>
     *   <li>控制器那一格先换成堆芯残骸（没有燃料槽、打不开界面，只能拆了重造），
     *       它抗爆 1200，后面的挖掘会绕开它；</li>
     *   <li>把核爆排进队列：<b>冲击波当场结算</b>（伤害、辐射、巨响、全屏爆闪），
     *       地形破坏分好几百 tick 慢慢推平——详见 {@link NuclearBlast}；</li>
     *   <li>挖完之后的收尾：悬在空中的这块残骸会被挪到地上，爆心 10 格内再撒几块新的；
     *       烧坏的燃料棒被炸飞、一截截插进 30 格内的焦土里；200 格内的掉落物全部清掉。
     *       「核废土下的清道夫」成就还是看背包里有没有残骸和熔毁的燃料棒——这两样现在
     *       都得玩家自己去废墟里掰；</li>
     *   <li>蘑菇云由 {@link MushroomCloud} 单独跑 30 秒，跟挖掘进度无关。</li>
     * </ol>
     *
     * <p>注意：这已经<b>不是</b>原版爆炸了。原版威力开到 120 会在一 tick 内扫描上百万格，
     * 直接把服务器卡死；现在的做法是「一列一列从中心往外塌」，所以玩家会看到地面
     * 像被撕开一样一圈圈陷下去。
     */
    private void meltDown() {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        int count = countItems(SLOT_FUEL);
        if (count <= 0) {
            return;
        }

        // 1) 要吐出来的东西先收好，再把槽位清空：这样后面炸掉方块时不会再掉一遍。
        //    注意烧坏的燃料棒不在这里：它们会被炸飞、插进爆心 30 格内的焦土里，
        //    变成一截截可以掰下来的「熔毁的燃料棒残桩」，不再是满地乱滚的掉落物。
        List<ItemStack> drops = new ArrayList<>();
        for (int slot = SLOT_AUX; slot <= SLOT_OUT && slot < this.items.size(); slot++) {
            ItemStack stack = this.items.get(slot);
            if (!stack.isEmpty()) {
                drops.add(stack.copy());
            }
        }
        this.items.clear();

        BlockPos controllerPos = this.worldPosition.immutable();
        // 朝向和堆芯位置都在爆炸之前算好：爆炸之后方块实体已经被移除，
        // 再去问「我朝哪」就不保险了
        Direction facing = facing();
        BlockPos core = coreCenter();
        this.overCriticalTicks = 0;
        this.flux = 0.0;
        this.kEff = 0.0;
        this.temperature = 20.0;
        this.status = STATUS_MELTED;
        setChanged();

        // 2) 控制器那一格换成堆芯残骸：不能再用，只能拆掉重造
        server.setBlock(controllerPos, ModBlocks.CORE_REMNANT.get().defaultBlockState(), Block.UPDATE_ALL);
        if (server.getBlockEntity(controllerPos) instanceof CoreRemnantBlockEntity remnant) {
            remnant.startMushroomCloud();
        }

        // 3) 剩下的杂物（控制棒组件之类）先放在残骸前面。它们最后会被核爆的清场
        //    一起扫掉，这里只是「先让东西有个地方去」，不至于因为清槽而凭空消失。
        BlockPos dropPos = controllerPos.relative(facing);
        if (!server.getBlockState(dropPos).isAir()) {
            dropPos = core;
        }
        for (ItemStack stack : drops) {
            Block.popResource(server, dropPos, stack);
        }

        // 4) 核爆：冲击波当场结算，地形破坏排进队列慢慢挖；
        //    残骸的位置传进去，挖完之后会把它挪到地上，再在爆心 10 格内撒几块新的；
        //    count 是烧坏的燃料棒数量，挖完之后插成 30 格内的残桩
        NuclearBlast.start(server, core, controllerPos, NuclearBlast.DESTROY_RADIUS, count);

        // 5) 成就「堆芯熔毁」：熔毁本身一炉只发生一次，直接记，不用开关
        ModAdvancementTriggers.fireNearby(this.level, core, NuclearBlast.DESTROY_RADIUS,
                ModAdvancementTriggers.FISSION_MELTDOWN);
    }

    /** 堆芯中心：立方体正中（控制器贴在底边，所以是往前、往上各让出半个边长）。 */
    public BlockPos coreCenter() {
        Direction facing = facing();
        int radius = (kind().size() - 1) / 2;
        return this.worldPosition.offset(facing.getStepX() * radius, radius, facing.getStepZ() * radius);
    }

    /** 输出槽里有没有熔毁的燃料棒（用来区分「没燃料」和「熔毁了」）。 */
    public boolean hasMeltedFuel() {
        return this.items.get(SLOT_OUT).is(ModItems.MELTED_FUEL_ROD.get());
    }

    /** 某个槽里一共几个物品。 */
    private int countItems(int slot) {
        if (slot >= this.items.size()) {
            return 0;
        }
        ItemStack stack = this.items.get(slot);
        return stack.isEmpty() ? 0 : stack.getCount();
    }

    // ------------------------------------------------------------------
    // 探测器 / 报警器
    // ------------------------------------------------------------------

    /**
     * 把当前通量写进结构里的中子探测器，把「超临界了没有」写进临界报警器。
     *
     * <p>探测器是个带红石强度的普通方块：控制器每 tick 只在与上一 tick 不同的时候改它一次，
     * 不会把区块更新刷爆。
     */
    private void pushOutputs() {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        int power = redstoneFromFlux(this.flux);
        for (BlockPos pos : this.detectorPositions) {
            BlockState state = server.getBlockState(pos);
            IntegerProperty property = NeutronDetectorBlock.POWER;
            if (!state.hasProperty(property)) {
                continue;
            }
            if (state.getValue(property) != power) {
                server.setBlock(pos, state.setValue(property, power), Block.UPDATE_ALL);
            }
        }
        boolean alarmOn = this.kEff > 1.0;
        for (BlockPos pos : this.alarmPositions) {
            BlockState state = server.getBlockState(pos);
            BooleanProperty property = CriticalAlarmBlock.POWERED;
            if (!state.hasProperty(property)) {
                continue;
            }
            boolean currentlyOn = state.getValue(property);
            if (currentlyOn != alarmOn) {
                server.setBlock(pos, state.setValue(property, alarmOn), Block.UPDATE_ALL);
            }
            if (alarmOn && this.ticks % 20 == 0) {
                server.playSound(null, pos, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS,
                        0.8F, 0.7F);
            }
        }
    }

    /** 通量 → 红石强度 0~15：按数量级走，通量 1000 大概 6 格，一百万满格。 */
    public static int redstoneFromFlux(double flux) {
        if (flux < 10.0) {
            return 0;
        }
        double magnitude = Math.log10(flux);
        return (int) Math.max(1, Math.min(15, Math.round((magnitude - 1.0) * 3.0)));
    }

    // ------------------------------------------------------------------
    // 界面要读的数字
    // ------------------------------------------------------------------

    public boolean isFormed() {
        return this.formed;
    }

    /**
     * k_eff 的同步刻度：k × 100000，方便走整数的数据同步（105000 = 1.05）。
     *
     * <p>用 10 万而不是 1 万，是因为次临界能到 0.99966 这种数字，
     * 只留四位小数的话界面会把它显示成 0.9997，看不出离 1 还有多远。
     */
    public static final int KEFF_SYNC_SCALE = 100_000;

    /** k_eff × {@link #KEFF_SYNC_SCALE}。 */
    public int kEffScaled() {
        return (int) Math.round(this.kEff * KEFF_SYNC_SCALE);
    }

    public double kEff() {
        return this.kEff;
    }

    public double flux() {
        return this.flux;
    }

    public int fluxInt() {
        return (int) Math.round(this.flux);
    }

    public int temperatureInt() {
        return (int) Math.round(this.temperature);
    }

    public int rodDepth() {
        return this.rodDepth;
    }

    /** 界面上的「−5% / +5% / 直接拖到某个深度」按钮。 */
    public void setRodDepth(int percent) {
        int clamped = Math.max(0, Math.min(100, percent));
        if (clamped == this.rodDepth) {
            return;
        }
        this.rodDepth = clamped;
        setChanged();
    }

    public int fuelCount() {
        return countItems(SLOT_FUEL);
    }

    public int auxCount() {
        return countItems(SLOT_AUX);
    }

    public int boricAmount() {
        return this.boricTank.getFluidAmount();
    }

    public int statusCode() {
        return this.status;
    }

    public int graphiteCount() {
        return this.graphiteCount;
    }

    public int reflectorCount() {
        return this.reflectorCount;
    }

    public int shieldCount() {
        return this.shieldCount;
    }

    public int glassCount() {
        return this.glassCount;
    }

    public int detectorCount() {
        return this.detectorCount;
    }

    // ------------------------------------------------------------------
    // 界面
    // ------------------------------------------------------------------

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new ReactorMenu(containerId, playerInventory, this);
    }

    @Override
    public Component getDisplayName() {
        return kind().displayName();
    }

    // ------------------------------------------------------------------
    // 物品槽
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return this.items.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        stack.limitSize(getMaxStackSize(stack));
        setChanged();
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        ReactorKind kind = kind();
        if (slot == SLOT_FUEL) {
            return kind == ReactorKind.SUBCRITICAL
                    ? stack.is(ModItems.NATURAL_URANIUM_ROD_BUNDLE.get())
                    : stack.is(ModItems.SEALED_FUEL_ROD.get());
        }
        if (slot == SLOT_AUX) {
            return kind == ReactorKind.SUBCRITICAL
                    ? stack.is(ModItems.NEUTRON_SOURCE.get())
                    : stack.is(ModItems.CONTROL_ROD.get());
        }
        return false;
    }

    @Override
    public int getMaxStackSize() {
        return 64;
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        ContainerHelper.saveAllItems(tag, this.items, registries);
        tag.put("BoricTank", this.boricTank.writeToNBT(registries, new CompoundTag()));
        tag.putDouble("KEff", this.kEff);
        tag.putDouble("Flux", this.flux);
        tag.putDouble("Temperature", this.temperature);
        tag.putInt("RodDepth", this.rodDepth);
        tag.putInt("OverCritical", this.overCriticalTicks);
        tag.putInt("Status", this.status);
        tag.putBoolean("Formed", this.formed);
        tag.putInt("Graphite", this.graphiteCount);
        tag.putInt("Reflector", this.reflectorCount);
        tag.putInt("Shield", this.shieldCount);
        tag.putInt("Glass", this.glassCount);
        tag.putInt("Detectors", this.detectorCount);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        ContainerHelper.loadAllItems(tag, this.items, registries);
        this.boricTank.readFromNBT(registries, tag.getCompound("BoricTank"));
        this.kEff = tag.getDouble("KEff");
        this.flux = tag.getDouble("Flux");
        this.temperature = Math.max(20.0, tag.getDouble("Temperature"));
        this.rodDepth = Math.max(0, Math.min(100, tag.getInt("RodDepth")));
        this.overCriticalTicks = tag.getInt("OverCritical");
        this.status = tag.getInt("Status");
        this.formed = tag.getBoolean("Formed");
        this.graphiteCount = tag.getInt("Graphite");
        this.reflectorCount = tag.getInt("Reflector");
        this.shieldCount = tag.getInt("Shield");
        this.glassCount = tag.getInt("Glass");
        this.detectorCount = tag.getInt("Detectors");
        this.validateTimer = VALIDATE_INTERVAL - 1;
    }

    @Override
    public void setLevel(Level level) {
        super.setLevel(level);
        if (!level.isClientSide) {
            this.validateTimer = VALIDATE_INTERVAL - 1;
        }
    }
}
