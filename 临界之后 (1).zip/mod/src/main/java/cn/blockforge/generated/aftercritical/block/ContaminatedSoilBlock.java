package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.effect.RadiationAura;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

/**
 * 污染土：堆芯熔毁炸出来的脏土。
 *
 * <p>什么时候站在上面，就一直吃辐射沾染；<b>永久</b>存在，不会自己变回泥土，
 * 想清干净只能一铲一铲挖走（挖掉掉的是普通泥土）。
 *
 * <p>光秃秃的土方块，没有界面、不存东西，唯一的逻辑就是踩上去那一刻的辐射。
 */
public class ContaminatedSoilBlock extends Block {

    public ContaminatedSoilBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        if (!level.isClientSide && entity instanceof LivingEntity living) {
            RadiationAura.apply(living);
        }
        super.stepOn(level, pos, state, entity);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.contaminated_soil.radiation")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.contaminated_soil.permanent")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
