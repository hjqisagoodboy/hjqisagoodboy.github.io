package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * 控制棒端口：一个端口插一根控制棒组件。
 *
 * <p>手拿控制棒右键插进去，空手右键拔出来。压水堆要把控制棒插深一点才能压住功率，
 * 但插得太浅（或者干脆没插）会一路烧到超温。
 */
public class ControlRodPortBlockEntity extends BlockEntity implements Container, TickableBlockEntity {

    public static final int SLOT = 0;
    public static final int SLOTS = 1;

    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOTS, ItemStack.EMPTY);

    public ControlRodPortBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CONTROL_ROD_PORT.get(), pos, state);
    }

    /** 这个端口里有没有插着控制棒。 */
    public boolean hasRod() {
        return this.items.get(SLOT).is(ModItems.CONTROL_ROD.get());
    }

    public boolean insertFromHand(Player player, ItemStack held) {
        if (!held.is(ModItems.CONTROL_ROD.get())) {
            return false;
        }
        if (!this.items.get(SLOT).isEmpty()) {
            player.displayClientMessage(Component.translatable("message.aftercritical.rod_port.full"), true);
            return false;
        }
        this.items.set(SLOT, held.copyWithCount(1));
        held.shrink(1);
        setChanged();
        player.displayClientMessage(Component.translatable("message.aftercritical.rod_port.inserted"), true);
        return true;
    }

    public boolean takeOut(Player player) {
        ItemStack stack = this.items.get(SLOT);
        if (stack.isEmpty()) {
            return false;
        }
        if (!player.getInventory().add(stack.copy())) {
            player.drop(stack.copy(), false);
        }
        this.items.set(SLOT, ItemStack.EMPTY);
        setChanged();
        player.displayClientMessage(Component.translatable("message.aftercritical.rod_port.taken"), true);
        return true;
    }

    // ------------------------------------------------------------------
    // Container
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return SLOTS;
    }

    @Override
    public boolean isEmpty() {
        return this.items.get(SLOT).isEmpty();
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        setChanged();
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return stack.is(ModItems.CONTROL_ROD.get());
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    @Override
    public void serverTick() {
        // 控制器会主动来数，不用自己 tick。
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        ContainerHelper.saveAllItems(tag, this.items, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        ContainerHelper.loadAllItems(tag, this.items, registries);
    }
}
