package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.blockentity.FluidMachineKind;
import cn.blockforge.generated.aftercritical.menu.FluidMachineMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * 十台流体机器共用的界面：电解槽、化工厂、空气分离器，以及阶段 1 的浸出槽、沉淀槽、
 * 干燥炉、转化炉、氟化反应器、气体离心机、水解反应器。
 *
 * <p>面板、能量条、箭头、流体长条全部在 {@link AbstractMachineScreen} 里画，
 * 这里只补两句这台机器专属的提示：右边两格是干什么的、长条是进液还是出液。
 */
public class FluidMachineScreen extends AbstractMachineScreen<FluidMachineMenu> {

    public FluidMachineScreen(FluidMachineMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    /** 第三行提示：罐子槽怎么用；地下水开采机换成「电越多越快」的说明。 */
    @Override
    protected Component hintLine() {
        if (this.menu.getTankCount() <= 0) {
            return null;
        }
        if (this.menu.kind() == FluidMachineKind.GROUNDWATER_PUMP) {
            return Component.translatable("gui.aftercritical.groundwater_pump.hint",
                    FluidMachineKind.GROUNDWATER_PUMP.energyPerTick(),
                    FluidMachineKind.GROUNDWATER_PUMP.maxEnergyPerTick());
        }
        if (this.menu.kind() == FluidMachineKind.AIR_SEPARATOR) {
            return Component.translatable("gui.aftercritical.air_separator.hint");
        }
        if (this.menu.kind() == FluidMachineKind.ELECTROLYZER) {
            return Component.translatable("gui.aftercritical.electrolyzer.hint");
        }
        return Component.translatable("gui.aftercritical.fluid.jar_hint");
    }
}
