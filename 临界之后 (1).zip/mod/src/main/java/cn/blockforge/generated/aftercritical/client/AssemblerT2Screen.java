package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.AssemblerT2Menu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * 装配机 T2 的界面：版式和 T1 完全一样，只是能做 T1 做不了的二级配方
 * （JSON 里写着 {@code "tier": 2} 的那些）。
 */
public class AssemblerT2Screen extends AbstractMachineScreen<AssemblerT2Menu> {

    public AssemblerT2Screen(AssemblerT2Menu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected Component hintLine() {
        return Component.translatable("gui.aftercritical.assembler.hint");
    }
}
