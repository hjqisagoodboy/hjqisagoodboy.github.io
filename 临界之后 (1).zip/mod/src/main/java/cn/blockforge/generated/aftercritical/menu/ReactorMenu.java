package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.ReactorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.ReactorKind;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 两种反应堆控制器共用的界面：左边一个 k_eff 仪表，中间燃料 / 核心部件槽，
 * 右边一根硼酸长条（只有实验堆有），底下一排读数。
 *
 * <p>控制棒插入深度用界面上的「−5% / +5%」和那根滑块条调：
 * 按钮走的是 {@code clickMenuButton}，服务端直接改方块实体里的深度，不碰物品。
 */
public class ReactorMenu extends AbstractMachineMenu implements FluidBarHost {

    /** 硼酸长条的位置（只有实验堆会画）。 */
    public static final int BAR_X = MachineLayout.FLUID_X;
    public static final int BAR_Y = MachineLayout.FLUID_TOP;
    public static final int BAR_W = 12;
    public static final int BAR_H = 40;

    /** 底部读数一共几行。 */
    public static final int STAT_LINES = 6;

    /** 按钮编号：0 = 少 5%，1 = 多 5%，100+ = 直接设成这个深度。 */
    public static final int BUTTON_ROD_LESS = 0;
    public static final int BUTTON_ROD_MORE = 1;
    public static final int BUTTON_ROD_ABSOLUTE = 100;

    private static final int DATA_KEFF = 0;
    private static final int DATA_FLUX = 1;
    private static final int DATA_TEMPERATURE = 2;
    private static final int DATA_FUEL = 3;
    private static final int DATA_AUX = 4;
    private static final int DATA_DEPTH = 5;
    private static final int DATA_BORIC = 6;
    private static final int DATA_FORMED = 7;
    private static final int DATA_STATUS = 8;
    private static final int DATA_GRAPHITE = 9;
    private static final int DATA_REFLECTOR = 10;
    private static final int DATA_SHIELD = 11;
    private static final int DATA_GLASS = 12;
    private static final int DATA_DETECTORS = 13;
    private static final int DATA_COUNT = 14;

    private final ReactorKind kind;
    @Nullable
    private final ReactorControllerBlockEntity controller;

    private int kScaled;
    private int flux;
    private int temperature;
    private int fuel;
    private int aux;
    private int depth;
    private int boric;
    private boolean formed;
    private int status;
    private int graphite;
    private int reflector;
    private int shield;
    private int glass;
    private int detectors;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case DATA_KEFF -> kScaled;
                case DATA_FLUX -> flux;
                case DATA_TEMPERATURE -> temperature;
                case DATA_FUEL -> fuel;
                case DATA_AUX -> aux;
                case DATA_DEPTH -> depth;
                case DATA_BORIC -> boric;
                case DATA_FORMED -> formed ? 1 : 0;
                case DATA_STATUS -> status;
                case DATA_GRAPHITE -> graphite;
                case DATA_REFLECTOR -> reflector;
                case DATA_SHIELD -> shield;
                case DATA_GLASS -> glass;
                case DATA_DETECTORS -> detectors;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case DATA_KEFF -> kScaled = value;
                case DATA_FLUX -> flux = value;
                case DATA_TEMPERATURE -> temperature = value;
                case DATA_FUEL -> fuel = value;
                case DATA_AUX -> aux = value;
                case DATA_DEPTH -> depth = value;
                case DATA_BORIC -> boric = value;
                case DATA_FORMED -> formed = value != 0;
                case DATA_STATUS -> status = value;
                case DATA_GRAPHITE -> graphite = value;
                case DATA_REFLECTOR -> reflector = value;
                case DATA_SHIELD -> shield = value;
                case DATA_GLASS -> glass = value;
                case DATA_DETECTORS -> detectors = value;
                default -> {
                }
            }
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    /** 服务端用。 */
    public ReactorMenu(int containerId, Inventory playerInventory, ReactorControllerBlockEntity controller) {
        this(ModMenus.reactorMenuFor(controller.kind()), containerId, playerInventory,
                controller, controller, controller.getContainerSize());
    }

    private ReactorMenu(MenuType<?> type, int containerId, Inventory playerInventory,
                        Container container, @Nullable ReactorControllerBlockEntity controller, int slotCount) {
        super(type, containerId, playerInventory, slotCount, null,
                controller != null && controller.kind() == ReactorKind.CRITICAL ? 1 : 0);
        this.kind = controller == null ? ReactorKind.SUBCRITICAL : controller.kind();
        this.controller = controller;

        this.addSlot(new FuelSlot(container, ReactorControllerBlockEntity.SLOT_FUEL, slotX(0), slotY(), this.kind));
        this.addSlot(new AuxSlot(container, ReactorControllerBlockEntity.SLOT_AUX, slotX(1), slotY(), this.kind));
        if (slotCount > ReactorControllerBlockEntity.SLOT_OUT) {
            this.addSlot(new OutputSlot(container, ReactorControllerBlockEntity.SLOT_OUT, slotX(2), slotY()));
        }
        this.addPlayerInventory(playerInventory, inventoryY());
        this.addDataSlots(this.data);
    }

    public static int slotX(int index) {
        return MachineLayout.ITEM_X + index * MachineLayout.ITEM_STEP;
    }

    public static int slotY() {
        return MachineLayout.ITEM_Y;
    }

    /** 客户端收到「打开菜单」的包后调用。 */
    public static ReactorMenu fromNetwork(MenuType<?> type, ReactorKind kind, int containerId,
                                          Inventory playerInventory, RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof ReactorControllerBlockEntity controller) {
            return new ReactorMenu(type, containerId, playerInventory, controller, controller,
                    controller.getContainerSize());
        }
        int slots = kind == ReactorKind.SUBCRITICAL ? 2 : 3;
        return new ReactorMenu(type, containerId, playerInventory, new SimpleContainer(slots), null, slots);
    }

    @Override
    public void broadcastChanges() {
        if (this.controller != null) {
            this.kScaled = this.controller.kEffScaled();
            this.flux = this.controller.fluxInt();
            this.temperature = this.controller.temperatureInt();
            this.fuel = this.controller.fuelCount();
            this.aux = this.controller.auxCount();
            this.depth = this.controller.rodDepth();
            this.boric = this.controller.boricAmount();
            this.formed = this.controller.isFormed();
            this.status = this.controller.statusCode();
            this.graphite = this.controller.graphiteCount();
            this.reflector = this.controller.reflectorCount();
            this.shield = this.controller.shieldCount();
            this.glass = this.controller.glassCount();
            this.detectors = this.controller.detectorCount();
        }
        super.broadcastChanges();
    }

    /** 界面上的「−5% / +5% / 拖到某个深度」按钮。 */
    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (this.controller == null) {
            return false;
        }
        if (id <= BUTTON_ROD_MORE) {
            int step = id == BUTTON_ROD_MORE ? 5 : -5;
            this.controller.setRodDepth(this.controller.rodDepth() + step);
        } else {
            this.controller.setRodDepth(id - BUTTON_ROD_ABSOLUTE);
        }
        return true;
    }

    public ReactorKind kind() {
        return this.kind;
    }

    public int kScaled() {
        return this.kScaled;
    }

    public int flux() {
        return this.flux;
    }

    public int temperature() {
        return this.temperature;
    }

    public int fuel() {
        return this.fuel;
    }

    public int aux() {
        return this.aux;
    }

    public int rodDepth() {
        return this.depth;
    }

    public int boric() {
        return this.boric;
    }

    public boolean isFormed() {
        return this.formed;
    }

    public int status() {
        return this.status;
    }

    public int graphite() {
        return this.graphite;
    }

    public int reflector() {
        return this.reflector;
    }

    public int shield() {
        return this.shield;
    }

    public int glass() {
        return this.glass;
    }

    public int detectors() {
        return this.detectors;
    }

    @Override
    public boolean stillValid(Player player) {
        return this.controller == null || this.controller.stillValid(player);
    }

    // ------------------------------------------------------------------
    // 版式：底部读数比别的机器多两行，面板也跟着长高一点
    // ------------------------------------------------------------------

    @Override
    public int textY() {
        return MachineLayout.textY(0);
    }

    @Override
    public int inventoryLabelY() {
        return textY() + STAT_LINES * MachineLayout.TEXT_STEP + 3;
    }

    @Override
    public int inventoryY() {
        return inventoryLabelY() + 10;
    }

    @Override
    public int guiHeight() {
        return inventoryY() + 58 + 18 + 6;
    }

    // ------------------------------------------------------------------
    // FluidBarHost：实验堆那根硼酸长条
    // ------------------------------------------------------------------

    @Override
    public int barCount() {
        return this.kind == ReactorKind.CRITICAL ? 1 : 0;
    }

    @Override
    public int barX(int index) {
        return BAR_X;
    }

    @Override
    public int barY(int index) {
        return BAR_Y;
    }

    @Override
    public int barWidth(int index) {
        return BAR_W;
    }

    @Override
    public int barHeight(int index) {
        return BAR_H;
    }

    @Override
    public int barAmount(int index) {
        return this.boric;
    }

    @Override
    public int barFluidId(int index) {
        return this.boric > 0
                ? net.minecraft.core.registries.BuiltInRegistries.FLUID.getId(
                        cn.blockforge.generated.aftercritical.registry.ModFluids.BORIC_ACID.source.get())
                : -1;
    }

    @Override
    public int barCapacity() {
        return ReactorControllerBlockEntity.BORIC_CAPACITY;
    }

    @Override
    public boolean barIsInput(int index) {
        return true;
    }

    // ------------------------------------------------------------------
    // 槽位
    // ------------------------------------------------------------------

    /** 燃料槽：次临界装置放天然铀棒束，实验堆放密封燃料棒。 */
    public static class FuelSlot extends Slot {

        private final ReactorKind kind;

        public FuelSlot(Container container, int slot, int x, int y, ReactorKind kind) {
            super(container, slot, x, y);
            this.kind = kind;
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return this.kind == ReactorKind.SUBCRITICAL
                    ? stack.is(ModItems.NATURAL_URANIUM_ROD_BUNDLE.get())
                    : stack.is(ModItems.SEALED_FUEL_ROD.get());
        }
    }

    /** 核心部件槽：中子源（次临界装置）或控制棒组件（实验堆）。 */
    public static class AuxSlot extends Slot {

        private final ReactorKind kind;

        public AuxSlot(Container container, int slot, int x, int y, ReactorKind kind) {
            super(container, slot, x, y);
            this.kind = kind;
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return this.kind == ReactorKind.SUBCRITICAL
                    ? stack.is(ModItems.NEUTRON_SOURCE.get())
                    : stack.is(ModItems.CONTROL_ROD.get());
        }
    }
}
