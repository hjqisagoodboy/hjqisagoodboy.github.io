package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.BallMillBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 球磨机 GUI 的菜单：机器槽 2 个（输入、输出）+ 玩家背包。
 *
 * <p>坐标全部来自 {@link MachineLayout}，和破碎机长得一模一样。
 */
public class BallMillMenu extends AbstractMachineMenu {

    public static final int INPUT_X = 30;
    public static final int INPUT_Y = 30;
    public static final int OUTPUT_X = 118;
    public static final int OUTPUT_Y = 30;

    /** 输入 → 输出那段箭头。 */
    public static final MachineLayout.Arrow ARROW = new MachineLayout.Arrow(52, 38, 62);

    /** 服务端用：直接拿方块实体当容器。 */
    public BallMillMenu(int containerId, Inventory playerInventory, BallMillBlockEntity machine) {
        this(containerId, playerInventory, machine, machine);
    }

    /** 客户端用：拿不到方块实体时，容器可以是个空壳，内容由同步包填。 */
    public BallMillMenu(int containerId, Inventory playerInventory, Container container,
                        @Nullable EnergyMachineHost machine) {
        super(ModMenus.BALL_MILL.get(), containerId, playerInventory, BallMillBlockEntity.SLOT_COUNT, machine);
        this.addSlot(new InputSlot(container, BallMillBlockEntity.SLOT_INPUT, INPUT_X, INPUT_Y));
        this.addSlot(new OutputSlot(container, BallMillBlockEntity.SLOT_OUTPUT, OUTPUT_X, OUTPUT_Y));
        this.addPlayerInventory(playerInventory);
    }

    @Override
    public MachineLayout.Arrow arrowGeometry() {
        return ARROW;
    }

    /** 客户端收到「打开菜单」的包后调用：从包里的坐标找回方块实体。 */
    public static BallMillMenu fromNetwork(int containerId, Inventory playerInventory, RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof BallMillBlockEntity ballMill) {
            return new BallMillMenu(containerId, playerInventory, ballMill);
        }
        return new BallMillMenu(containerId, playerInventory,
                new SimpleContainer(BallMillBlockEntity.SLOT_COUNT), null);
    }
}
