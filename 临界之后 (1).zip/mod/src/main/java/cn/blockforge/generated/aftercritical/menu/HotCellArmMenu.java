package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.blockentity.HotCellArmBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

import javax.annotation.Nullable;

/**
 * 热室机械臂的界面：左边 1 格放冷却的靶材，箭头指向右边 1 格产物。
 *
 * <p>没有流体、没有额外按钮，箭头里灌的就是机械臂拆解的进度。
 */
public class HotCellArmMenu extends AbstractMachineMenu {

    public static final int INPUT_X = 30;
    public static final int INPUT_Y = 30;
    public static final int OUTPUT_X = 118;
    public static final int OUTPUT_Y = 30;

    /** 输入 → 输出那段箭头。 */
    public static final MachineLayout.Arrow ARROW = new MachineLayout.Arrow(52, 38, 62);

    /** 服务端用。 */
    public HotCellArmMenu(int containerId, Inventory playerInventory, HotCellArmBlockEntity machine) {
        this(containerId, playerInventory, machine, machine);
    }

    /** 客户端用：拿不到方块实体时容器是个空壳。 */
    public HotCellArmMenu(int containerId, Inventory playerInventory, Container container,
                          @Nullable EnergyMachineHost machine) {
        super(ModMenus.HOT_CELL_ARM.get(), containerId, playerInventory,
                HotCellArmBlockEntity.SLOT_COUNT, machine);
        this.addSlot(new CooledTargetSlot(container, HotCellArmBlockEntity.SLOT_INPUT, INPUT_X, INPUT_Y));
        this.addSlot(new OutputSlot(container, HotCellArmBlockEntity.SLOT_OUTPUT, OUTPUT_X, OUTPUT_Y));
        this.addPlayerInventory(playerInventory);
    }

    @Override
    public MachineLayout.Arrow arrowGeometry() {
        return ARROW;
    }

    /** 输入槽：只认 7 种「冷却的靶材」，别的物品拖进来会被弹回去。 */
    public static class CooledTargetSlot extends Slot {

        public CooledTargetSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return HotCellArmBlockEntity.COOLED_TARGETS.contains(stack.getItem());
        }
    }

    /** 客户端收到「打开菜单」的包后调用。 */
    public static HotCellArmMenu fromNetwork(int containerId, Inventory playerInventory,
                                             RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof HotCellArmBlockEntity machine) {
            return new HotCellArmMenu(containerId, playerInventory, machine);
        }
        return new HotCellArmMenu(containerId, playerInventory,
                new SimpleContainer(HotCellArmBlockEntity.SLOT_COUNT), null);
    }
}
