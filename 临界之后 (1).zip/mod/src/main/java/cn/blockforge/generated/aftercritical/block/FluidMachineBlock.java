package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.FluidMachineBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.FluidMachineKind;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

/**
 * 三台流体机器共用的方块：电解槽、化工厂、空气分离器。
 *
 * <p>右键空手打开界面；右键时手上要是装着水的桶（或硫酸桶），
 * 就先把液体灌进机器的进液罐，不会弹出界面。
 */
public class FluidMachineBlock extends TickingMachineBlock {

    private final FluidMachineKind kind;

    public FluidMachineBlock(Properties properties, FluidMachineKind kind) {
        super(properties, kind.tier(), "tooltip.aftercritical.energy_per_tick", kind.energyPerTick(),
                kind.descriptionKey());
        this.kind = kind;
    }

    public FluidMachineKind kind() {
        return this.kind;
    }

    /** 功率是个范围的机器（地下水开采机 30~120 FE/t）在物品提示里显示成「运行功率：30 ~ 120 FE/t」。 */
    @Override
    protected int maxPowerValue() {
        return this.kind.maxEnergyPerTick();
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(properties -> new FluidMachineBlock(properties, this.kind));
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new FluidMachineBlockEntity(pos, state);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                             Player player, InteractionHand hand, BlockHitResult hitResult) {
        // 通用流体罐、原版空桶、任意装满的桶（水、岩浆）都走「倒进 / 舀出」这条路
        if (stack.getItem() instanceof UniversalTankItem) {
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof FluidMachineBlockEntity machine
                    && machine.handleFluidInteraction(player, hand)) {
                return ItemInteractionResult.sidedSuccess(false);
            }
            // 手里这东西在这台机器上倒不进也舀不出（比如拿满水桶点地下水开采机）：
            // 那就当成普通右键，直接把界面打开，省得玩家对着机器发呆
            return super.useItemOn(stack, state, level, pos, player, hand, hitResult);
        }
        boolean bucket = stack.is(Items.BUCKET) || stack.getItem() instanceof BucketItem;
        if (bucket) {
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof FluidMachineBlockEntity machine
                    && machine.handleFluidInteraction(player, hand)) {
                return ItemInteractionResult.sidedSuccess(false);
            }
            return super.useItemOn(stack, state, level, pos, player, hand, hitResult);
        }
        return super.useItemOn(stack, state, level, pos, player, hand, hitResult);
    }

    /** 空手右键也走一遍（部分情况下会走这个入口）。 */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof FluidMachineBlockEntity machine) {
            player.openMenu(machine, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
