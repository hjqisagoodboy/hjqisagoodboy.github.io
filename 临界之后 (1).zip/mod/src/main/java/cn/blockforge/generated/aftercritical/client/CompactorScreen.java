package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.CompactorMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** 压块机的界面：左边一堆原料、右边一堆成品，中间一根箭头。 */
public class CompactorScreen extends AbstractMachineScreen<CompactorMenu> {

    public CompactorScreen(CompactorMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }
}
