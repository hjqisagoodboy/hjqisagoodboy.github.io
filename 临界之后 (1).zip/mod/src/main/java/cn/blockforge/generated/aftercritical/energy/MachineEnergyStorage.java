package cn.blockforge.generated.aftercritical.energy;

import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * 机器的 FE（Forge Energy）能量缓存。
 *
 * <p>这是全模组唯一的能量单位：FE。不引入任何自定义 EU 系统。
 *
 * <p>约定：
 * <ul>
 *   <li>只进不出：机器不会把自己的电再往外送（{@link #extractEnergy} 恒为 0）。</li>
 *   <li>每 tick 能收多少由 {@code maxReceive} 限制，避免瞬间灌满。</li>
 *   <li>数值一旦变化就回调 {@code onChange}，让方块实体标记「已修改」以便存档。</li>
 * </ul>
 */
public final class MachineEnergyStorage implements IEnergyStorage {

    private final int capacity;
    private final int maxReceive;
    private final Runnable onChange;
    private int energy;

    public MachineEnergyStorage(int capacity, int maxReceive, Runnable onChange) {
        this.capacity = capacity;
        this.maxReceive = maxReceive;
        this.onChange = onChange;
    }

    /**
     * 从外界（线缆、其他机器）接入 FE。
     *
     * @param toReceive 对方想送进来的量
     * @param simulate  true 表示只试算不真正存
     * @return 实际接收入库的量
     */
    @Override
    public int receiveEnergy(int toReceive, boolean simulate) {
        if (toReceive <= 0 || this.energy >= this.capacity) {
            return 0;
        }
        int accepted = Math.min(Math.min(toReceive, this.maxReceive), this.capacity - this.energy);
        if (accepted <= 0) {
            return 0;
        }
        if (!simulate) {
            this.energy += accepted;
            this.onChange.run();
        }
        return accepted;
    }

    /** 机器只耗电，不对外供电，所以这里永远返回 0。 */
    @Override
    public int extractEnergy(int toExtract, boolean simulate) {
        return 0;
    }

    @Override
    public int getEnergyStored() {
        return this.energy;
    }

    @Override
    public int getMaxEnergyStored() {
        return this.capacity;
    }

    @Override
    public boolean canExtract() {
        return false;
    }

    @Override
    public boolean canReceive() {
        return this.energy < this.capacity;
    }

    /**
     * 机器自己运行时扣电（不走 {@link IEnergyStorage} 接口，因为那不是「被外界抽取」）。
     *
     * @return 电量够并已扣除时为 {@code true}
     */
    public boolean consume(int amount) {
        if (amount <= 0) {
            return true;
        }
        if (this.energy < amount) {
            return false;
        }
        this.energy -= amount;
        return true;
    }

    /** 还能再装多少 FE。 */
    public int getFreeSpace() {
        return this.capacity - this.energy;
    }

    /**
     * 不经管道、直接往缓存里补电（人力或特殊来源补电这类非管道输入用）。
     *
     * <p>和 {@link #receiveEnergy(int, boolean)} 的区别：不受每 tick 接收上限限制，
     * 但同样会被容量夹住。
     *
     * @return 实际补进去的量
     */
    public int charge(int toAdd) {
        if (toAdd <= 0 || this.energy >= this.capacity) {
            return 0;
        }
        int accepted = Math.min(toAdd, this.capacity - this.energy);
        this.energy += accepted;
        this.onChange.run();
        return accepted;
    }

    /** 读档时用：直接设置已存电量（自动夹在 0 ~ 容量之间）。 */
    public void setEnergy(int value) {
        this.energy = Math.max(0, Math.min(value, this.capacity));
    }
}
