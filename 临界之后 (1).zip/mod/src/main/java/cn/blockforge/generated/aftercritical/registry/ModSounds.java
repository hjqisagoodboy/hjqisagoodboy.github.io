package cn.blockforge.generated.aftercritical.registry;

import cn.blockforge.generated.aftercritical.AfterCritical;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 本模组自己的声音。
 *
 * <p>核爆用的那一段 70 秒录音是用户自己录的，所以必须注册成「本模组的声音」，
 * 原版 {@code SoundEvents} 里没有它。
 *
 * <p>用「可变距离」的那种（{@link SoundEvent#createVariableRangeEvent}）：
 * 音量传多大就能传多远，不写死成一个固定范围；具体多远见
 * {@code assets/aftercritical/sounds.json} 里的 {@code attenuation_distance}。
 */
public final class ModSounds {

    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(Registries.SOUND_EVENT, AfterCritical.MOD_ID);

    /**
     * 核爆：一整段 70 秒的主冲击 + 余震 + 低频隆隆 + 尾音。
     *
     * <p>名字和 ogg 文件同名（{@code sounds/nuke_explosion.ogg}），
     * 客户端只认 sounds.json 里写的那条路径。
     */
    public static final DeferredHolder<SoundEvent, SoundEvent> NUKE_EXPLOSION =
            SOUND_EVENTS.register("nuke_explosion", () -> SoundEvent.createVariableRangeEvent(
                    ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "nuke_explosion")));

    private ModSounds() {}
}
