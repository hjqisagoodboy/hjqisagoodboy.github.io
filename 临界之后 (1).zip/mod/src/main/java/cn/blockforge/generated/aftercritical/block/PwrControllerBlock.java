package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.PwrControllerBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.List;

/**
 * 压水堆控制器：7 宽 × 7 深 × 8 高的多方块心脏。
 *
 * <p>和阶段 3、4 的反应堆一样：控制器贴在正面墙、贴地那一排的正中间，
 * 方块朝哪堆就往哪长。右键开界面，里面调控制棒插入深度、看燃料和温度。
 *
 * <p>结构里要数够：压力壳 ≥92、铅块 ≥24、混凝土 ≥48、玻璃 ≥8，
 * 另外燃料端口 ≥1、控制棒端口 ≥4、冷却剂端口 ≥2。
 */
public class PwrControllerBlock extends TickablePartBlock {

    public static final String DESCRIPTION = "block.aftercritical.pwr_controller.desc";

    /** 方块朝哪 = 结构往哪长。只有水平四个方向。 */
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    public PwrControllerBlock(Properties properties) {
        super(properties, DESCRIPTION);
        registerDefaultState(defaultBlockState().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(PwrControllerBlock::new);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection());
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PwrControllerBlockEntity(pos, state);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MenuProvider provider) {
            player.openMenu(provider, pos);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MenuProvider provider) {
            player.openMenu(provider, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** 旁边多一块少一块就立刻重查结构，不用干等两秒。 */
    @Override
    protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighbor,
                                   BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighbor, neighborPos, movedByPiston);
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof PwrControllerBlockEntity controller) {
            controller.validateSoon();
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.aftercritical.pwr.size",
                PwrControllerBlockEntity.SIZE_W, PwrControllerBlockEntity.SIZE_H,
                PwrControllerBlockEntity.SIZE_D).withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.pwr.materials",
                PwrControllerBlockEntity.MIN_SHELL, PwrControllerBlockEntity.MIN_LEAD,
                PwrControllerBlockEntity.MIN_CONCRETE, PwrControllerBlockEntity.MIN_GLASS)
                .withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.pwr.ports",
                PwrControllerBlockEntity.MIN_ROD_PORTS, PwrControllerBlockEntity.MIN_COOLANT_PORTS)
                .withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.pwr.build").withStyle(ChatFormatting.GRAY));
    }
}
