package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.blockentity.TransmutatorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.menu.TransmutatorMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;

/**
 * 物质嬗变器的界面：只有两格物品，重点全在底下那串读数上——
 * 结构、能量（1,000,000 FE 一次）、能量端口、进度、状态。
 */
public class TransmutatorScreen extends StatPanelScreen<TransmutatorMenu> {

    public TransmutatorScreen(TransmutatorMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected List<Line> statLines() {
        List<Line> lines = new ArrayList<>(TransmutatorMenu.STAT_LINES);

        boolean formed = this.menu.isFormed();
        lines.add(new Line(Component.translatable(formed
                ? "gui.aftercritical.reactor.structure_ok"
                : "gui.aftercritical.reactor.structure_missing"), formed ? TEXT_OK : TEXT_BAD));

        lines.add(new Line(Component.translatable("gui.aftercritical.transmutator.parts",
                this.menu.casing(), TransmutatorControllerBlockEntity.MIN_CASING,
                this.menu.coils(), TransmutatorControllerBlockEntity.MIN_COILS,
                this.menu.ports(), TransmutatorControllerBlockEntity.MIN_PORTS), TEXT_GRAY));

        lines.add(new Line(Component.translatable("gui.aftercritical.transmutator.power",
                this.menu.getEnergyStored(), TransmutatorControllerBlockEntity.ENERGY_CAPACITY,
                TransmutatorControllerBlockEntity.COST), TEXT_DARK));

        lines.add(new Line(Component.translatable("gui.aftercritical.transmutator.progress",
                this.menu.input(), this.menu.progressPercent()), TEXT_DARK));

        lines.add(new Line(Component.translatable("gui.aftercritical.transmutator.status." + this.menu.status()),
                statusColorOf(this.menu.status())));
        return lines;
    }

    private static int statusColorOf(int status) {
        return switch (status) {
            case TransmutatorControllerBlockEntity.STATUS_RUNNING -> TEXT_OK;
            case TransmutatorControllerBlockEntity.STATUS_NO_ENERGY,
                 TransmutatorControllerBlockEntity.STATUS_NO_INPUT,
                 TransmutatorControllerBlockEntity.STATUS_OUTPUT_FULL -> TEXT_WARN;
            case TransmutatorControllerBlockEntity.STATUS_UNFORMED -> TEXT_BAD;
            default -> TEXT_GRAY;
        };
    }
}
