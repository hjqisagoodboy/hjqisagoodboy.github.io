package cn.blockforge.generated.aftercritical.energy;

import cn.blockforge.generated.aftercritical.blockentity.CableBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * 机器和邻居之间搬电的工具。
 *
 * <p>这个模组自己不做线缆，所以「线缆」就是任何对外暴露 FE 接口的方块——
 * 原版没有这种方块，别的科技模组的线缆也算，我们的发电机和电池彼此也算。
 */
public final class EnergyTransfer {

    private EnergyTransfer() {}

    /**
     * 从六个方向的邻居身上抽电，灌进 {@code target}。返回实际搬到的量。
     *
     * @param maxMove 这一 tick 最多搬多少
     */
    public static int pull(Level level, BlockPos pos, IEnergyStorage target, int maxMove) {
        int budget = Math.min(maxMove, target.getMaxEnergyStored() - target.getEnergyStored());
        if (budget <= 0) {
            return 0;
        }
        int total = 0;
        for (Direction side : Direction.values()) {
            if (budget <= 0) {
                break;
            }
            IEnergyStorage source = level.getCapability(
                    Capabilities.EnergyStorage.BLOCK, pos.relative(side), side.getOpposite());
            if (source == null || !source.canExtract()) {
                continue;
            }
            int moved = source.extractEnergy(budget, true);
            if (moved <= 0) {
                continue;
            }
            moved = source.extractEnergy(moved, false);
            if (moved > 0) {
                int stored = target.receiveEnergy(moved, false);
                total += stored;
                budget -= moved;
            }
        }
        return total;
    }

    /**
     * 电池专用：从六个方向抽电给自己充电。返回实际充进来的量。
     *
     * <p><b>跳过线缆</b>。线缆里的电由 {@link CableNetwork} 整网统一分配：
     * 先送给贴着的机器，剩下的才拿来给电池充。电池如果自己也去抽线缆，
     * 就会变成「这一 tick 抽 20000、下一 tick 又推回去 20000」——
     * 玩家看到的就是「接了线缆永远是放电中」，而且电永远存不进去。
     *
     * <p>也只从「只出不进」的电源（发电机）抽，不从另一块电池、变压器这类
     * <b>能充也能放</b>的方块抽：两块电池互相抽来抽去只会让数字乱跳。
     */
    public static int pullForCharging(Level level, BlockPos pos, IEnergyStorage target, int maxMove) {
        int budget = Math.min(maxMove, target.getMaxEnergyStored() - target.getEnergyStored());
        if (budget <= 0) {
            return 0;
        }
        int total = 0;
        for (Direction side : Direction.values()) {
            if (budget <= 0) {
                break;
            }
            BlockPos neighbour = pos.relative(side);
            if (level.getBlockEntity(neighbour) instanceof CableBlockEntity) {
                continue;
            }
            IEnergyStorage source = level.getCapability(
                    Capabilities.EnergyStorage.BLOCK, neighbour, side.getOpposite());
            if (source == null || !source.canExtract() || canRecharge(source)) {
                continue;
            }
            // 先问自己吃不吃得下，再动手抽，避免抽多了还不回去（发电机是不收电的）
            int available = Math.min(source.extractEnergy(budget, true), budget);
            if (available <= 0) {
                continue;
            }
            int accepted = target.receiveEnergy(available, true);
            if (accepted <= 0) {
                continue;
            }
            int moved = source.extractEnergy(accepted, false);
            if (moved <= 0) {
                continue;
            }
            total += target.receiveEnergy(moved, false);
            budget -= moved;
        }
        return total;
    }

    /**
     * 这个接口「能不能被充电」。
     *
     * <p>本模组的缓存要看配置值，不能看当前电量：电池充满了 {@code canReceive()} 会变成
     * false，只看动态值的话满电池会被当成发电机，另一块电池就会去抽它，两块电池互相倒电。
     *
     * @return true 表示它自己也能存电（电池、变压器），电池不该抽它、也不该给它送电
     */
    private static boolean canRecharge(IEnergyStorage storage) {
        if (storage instanceof BufferedEnergyStorage buffered) {
            return buffered.getMaxReceive() > 0;
        }
        return storage.canReceive();
    }

    /**
     * 电池专用：把电送给「这一 tick 真的只进不出」的机器。返回实际送出去的量。
     *
     * <p>跳过两类邻居：
     * <ul>
     *   <li><b>线缆</b>：交给 {@link CableNetwork} 统一调度，电池不直接往线缆里塞电；</li>
     *   <li><b>发电机 / 别的电池</b>：它们自己能往外送电（{@code canExtract}），
     *       给它们送电只会让电来回倒，不解决任何问题。</li>
     * </ul>
     *
     * <p>注意「能不能往外送电」是<b>问方块当下这一 tick 的状态</b>，不是问它是什么方块：
     * 托卡马克点火前对外是「只进不出」，点火后才变成发电机。所以这里不用额外判断，
     * 点火前的托卡马克会正常收到电。
     */
    public static int pushToConsumers(Level level, BlockPos pos, IEnergyStorage source, int maxMove) {
        int budget = Math.min(maxMove, source.getEnergyStored());
        if (budget <= 0) {
            return 0;
        }
        int total = 0;
        for (Direction side : Direction.values()) {
            if (budget <= 0) {
                break;
            }
            BlockPos neighbour = pos.relative(side);
            if (level.getBlockEntity(neighbour) instanceof CableBlockEntity) {
                continue;
            }
            IEnergyStorage sink = level.getCapability(
                    Capabilities.EnergyStorage.BLOCK, neighbour, side.getOpposite());
            if (sink == null || !sink.canReceive() || canOutput(sink)) {
                continue;
            }
            int offered = Math.min(source.extractEnergy(budget, true), budget);
            if (offered <= 0) {
                continue;
            }
            int accepted = sink.receiveEnergy(offered, false);
            if (accepted > 0) {
                source.extractEnergy(accepted, false);
                total += accepted;
                budget -= accepted;
            }
        }
        return total;
    }

    /**
     * 这个接口「能不能往外送电」。
     *
     * <p>同样要看配置值：电池放空了 {@code canExtract()} 会变成 false，
     * 只看动态值的话空电池会被当成「只会吃电的机器」，另一块电池就往里灌电了。
     */
    private static boolean canOutput(IEnergyStorage storage) {
        if (storage instanceof BufferedEnergyStorage buffered) {
            return buffered.getMaxExtract() > 0;
        }
        return storage.canExtract();
    }

    /**
     * 把 {@code source} 里的电送给六个方向的邻居（发电机用）。返回实际送出去的量。
     *
     * <p>邻居必须「愿意收电」（{@code canReceive}），普通方块和已经装满的机器都会被跳过。
     * 线缆、电池、机器都在这个范围里：所以发电机贴着线缆、电池、机器都能直接送电。
     */
    public static int push(Level level, BlockPos pos, IEnergyStorage source, int maxMove) {
        int budget = Math.min(maxMove, source.getEnergyStored());
        if (budget <= 0) {
            return 0;
        }
        int total = 0;
        for (Direction side : Direction.values()) {
            if (budget <= 0) {
                break;
            }
            IEnergyStorage sink = level.getCapability(
                    Capabilities.EnergyStorage.BLOCK, pos.relative(side), side.getOpposite());
            if (sink == null || !sink.canReceive()) {
                continue;
            }
            int offered = Math.min(source.extractEnergy(budget, true), budget);
            if (offered <= 0) {
                continue;
            }
            int accepted = sink.receiveEnergy(offered, false);
            if (accepted > 0) {
                source.extractEnergy(accepted, false);
                total += accepted;
                budget -= accepted;
            }
        }
        return total;
    }
}
