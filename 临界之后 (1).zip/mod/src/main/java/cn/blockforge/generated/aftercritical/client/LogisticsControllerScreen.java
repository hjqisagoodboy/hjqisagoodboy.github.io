package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.LogisticsControllerMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * 物流控制器的界面：九格缓冲 + 底部一句「已连接 n 个方向」。
 *
 * <p>它没有「输入 → 输出」那根箭头，进度也是 0，所以画面比机器朴素，
 * 剩下的全交给 {@link AbstractMachineScreen} 的统一面板。
 */
public class LogisticsControllerScreen extends AbstractMachineScreen<LogisticsControllerMenu> {

    public LogisticsControllerScreen(LogisticsControllerMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected Component statusLine() {
        Component base = super.statusLine();
        return Component.literal(base.getString() + "  ·  "
                + Component.translatable("gui.aftercritical.logistics.connected",
                this.menu.getConnected()).getString());
    }

    @Override
    protected Component hintLine() {
        return Component.translatable("gui.aftercritical.logistics.hint");
    }
}
