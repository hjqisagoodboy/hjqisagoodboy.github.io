package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.NukeBlockEntity;
import cn.blockforge.generated.aftercritical.item.NukeComponentItem;
import cn.blockforge.generated.aftercritical.nuke.NukeComponent;
import cn.blockforge.generated.aftercritical.nuke.NukeKind;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * 核弹的装配界面：槽位由这颗弹自己的装配图决定。
 *
 * <p>六颗弹的界面不是同一个版式：枪式的小男孩是一根长管子、组件顺着弹体一字排开；
 * 内爆的胖子、邱小姐是一个球，核心在正中间；两颗氢弹是「初级 + 次级」两节。
 * 槽的坐标、每格收哪种组件，全部写在 {@link NukeKind#slots()} 里，
 * 这里只是照着摆，顺带把玩家背包放好。
 *
 * <p>没有按钮、没有开关——放进去的组件立刻生效（半径、坑深、辐射、引信都在
 * 界面里实时算出来），起爆是拿着起爆器在外面点的。
 */
public class NukeMenu extends AbstractContainerMenu {

    public static final int IMAGE_WIDTH = 176;
    public static final int IMAGE_HEIGHT = 262;

    /** 玩家背包第一行的 y。 */
    public static final int INVENTORY_Y = 180;
    public static final int INVENTORY_LABEL_Y = 170;
    public static final int HOTBAR_Y = INVENTORY_Y + 58;

    private final Container container;
    private final NukeKind kind;

    /** 服务端：直接拿方块实体当容器。 */
    public NukeMenu(int containerId, Inventory playerInventory, NukeBlockEntity nuke) {
        this(containerId, playerInventory, nuke, nuke.kind());
    }

    /** 客户端兜底 / 服务端通用：容器可能是空壳，内容由同步包填。 */
    public NukeMenu(int containerId, Inventory playerInventory, Container container, NukeKind kind) {
        super(ModMenus.NUKE.get(), containerId);
        this.container = container;
        this.kind = kind;
        List<NukeKind.NukeSlot> layout = kind.slots();
        for (int index = 0; index < layout.size(); index++) {
            NukeKind.NukeSlot slot = layout.get(index);
            this.addSlot(new ComponentSlot(container, index, slot.x(), slot.y(), slot.component()));
        }
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                this.addSlot(new Slot(playerInventory, column + row * 9 + 9,
                        8 + column * 18, INVENTORY_Y + row * 18));
            }
        }
        for (int column = 0; column < 9; column++) {
            this.addSlot(new Slot(playerInventory, column, 8 + column * 18, HOTBAR_Y));
        }
    }

    public NukeKind kind() {
        return this.kind;
    }

    /** 这颗弹一共几个组件槽。 */
    public int componentSlots() {
        return this.kind.componentCount();
    }

    /** 客户端收到「打开菜单」的包后调用：从包里的坐标找回方块实体。 */
    public static NukeMenu fromNetwork(int containerId, Inventory playerInventory, RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof NukeBlockEntity nuke) {
            return new NukeMenu(containerId, playerInventory, nuke);
        }
        return new NukeMenu(containerId, playerInventory,
                new SimpleContainer(NukeBlockEntity.MAX_SLOTS), NukeKind.LITTLE_BOY);
    }

    @Override
    public boolean stillValid(Player player) {
        return this.container.stillValid(player);
    }

    /** Shift 点击：组件槽 ↔ 背包。 */
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack copy = stack.copy();
        int machineSlots = componentSlots();
        if (index < machineSlots) {
            if (!this.moveItemStackTo(stack, machineSlots, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else if (stack.getItem() instanceof NukeComponentItem) {
            if (!this.moveItemStackTo(stack, 0, machineSlots, false)) {
                return ItemStack.EMPTY;
            }
        } else {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return copy;
    }

    /** 组件槽：只收这个格子上写的那一种组件，一格一个。 */
    public static class ComponentSlot extends Slot {

        private final NukeComponent required;

        public ComponentSlot(Container container, int slot, int x, int y, NukeComponent required) {
            super(container, slot, x, y);
            this.required = required;
        }

        /** 这个格子要装的是哪种组件（界面上鼠标停上去会显示名字）。 */
        public NukeComponent required() {
            return this.required;
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            NukeComponent component = NukeComponentItem.componentOf(stack);
            return component != null && component == this.required;
        }

        @Override
        public int getMaxStackSize() {
            return 1;
        }
    }

    /** 界面上实时显示的「当前装了什么」——给屏幕用。 */
    public List<ItemStack> installedComponents() {
        List<ItemStack> list = new ArrayList<>(componentSlots());
        for (int index = 0; index < componentSlots(); index++) {
            list.add(this.slots.get(index).getItem());
        }
        return list;
    }
}
