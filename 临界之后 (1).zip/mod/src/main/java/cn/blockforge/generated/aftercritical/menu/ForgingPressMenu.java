package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.ForgingPressBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 锻压机 GUI 的菜单：机器槽 3 个（模具、输入、输出）+ 玩家背包。
 *
 * <p>从左到右：模具 → 原料 → 箭头 → 成品，坐标全部来自 {@link MachineLayout}。
 * 工具槽只认模具（{@link MoldSlot}），输入槽反过来不收模具（{@link InputSlot}），
 * 模具拖到输入槽会被弹回去。
 */
public class ForgingPressMenu extends AbstractMachineMenu {

    public static final int MOLD_X = 30;
    public static final int MOLD_Y = 30;
    public static final int INPUT_X = 54;
    public static final int INPUT_Y = 30;
    public static final int OUTPUT_X = 118;
    public static final int OUTPUT_Y = 30;

    /** 原料 → 成品那段箭头。 */
    public static final MachineLayout.Arrow ARROW = new MachineLayout.Arrow(78, 38, 34);

    /** 服务端用：直接拿方块实体当容器。 */
    public ForgingPressMenu(int containerId, Inventory playerInventory, ForgingPressBlockEntity machine) {
        this(containerId, playerInventory, machine, machine);
    }

    /** 客户端用：拿不到方块实体时，容器可以是个空壳，内容由同步包填。 */
    public ForgingPressMenu(int containerId, Inventory playerInventory, Container container,
                            @Nullable EnergyMachineHost machine) {
        super(ModMenus.FORGING_PRESS.get(), containerId, playerInventory,
                ForgingPressBlockEntity.SLOT_COUNT, machine);
        this.addSlot(new MoldSlot(container, ForgingPressBlockEntity.SLOT_MOLD, MOLD_X, MOLD_Y));
        this.addSlot(new InputSlot(container, ForgingPressBlockEntity.SLOT_INPUT, INPUT_X, INPUT_Y));
        this.addSlot(new OutputSlot(container, ForgingPressBlockEntity.SLOT_OUTPUT, OUTPUT_X, OUTPUT_Y));
        this.addPlayerInventory(playerInventory);
    }

    @Override
    public MachineLayout.Arrow arrowGeometry() {
        return ARROW;
    }

    /** 客户端收到「打开菜单」的包后调用：从包里的坐标找回方块实体。 */
    public static ForgingPressMenu fromNetwork(int containerId, Inventory playerInventory,
                                               RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof ForgingPressBlockEntity press) {
            return new ForgingPressMenu(containerId, playerInventory, press);
        }
        return new ForgingPressMenu(containerId, playerInventory,
                new SimpleContainer(ForgingPressBlockEntity.SLOT_COUNT), null);
    }
}
