package cn.blockforge.generated.aftercritical.blockentity;

/**
 * 「电量可以整个抄走 / 抄回来」的方块实体。
 *
 * <p>目前只有三种电池实现它：挖掉时把电量写进掉落物，放下时再读回来，
 * 玩家挪电池不会白丢 1.2 亿 FE。
 *
 * <p>机器（破碎机、装配机这些）不实现：它们那点缓存挖掉就挖掉了，
 * 也不该把电带着满世界跑。
 */
public interface EnergyStorable {

    /** 现在存了多少 FE。 */
    int getStoredEnergy();

    /** 直接设成这个数（会被容量夹住），用于放置时从物品还原。 */
    void setStoredEnergy(int value);
}
