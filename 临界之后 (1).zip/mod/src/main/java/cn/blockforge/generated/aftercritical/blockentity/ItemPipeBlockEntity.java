package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.block.AbstractPipeBlock;
import cn.blockforge.generated.aftercritical.itemhandler.ContainerItemHandler;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.items.IItemHandler;

import javax.annotation.Nullable;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Set;

/**
 * 物品管道的方块实体：一次搬 1 个物品。
 *
 * <p>每 tick 干三件事：
 * <ol>
 *   <li>手里空着 → 从相邻的方块里抽 1 个物品（机器的输出槽、箱子、漏斗……只要它愿意给）；</li>
 *   <li>手里有东西 → 顺着连在一起的管道找一圈，塞进最近一个愿意收的方块（机器的输入槽、箱子）；</li>
 *   <li>每 20 tick 重算一次六个方向的接头。</li>
 * </ol>
 *
 * <p>管道之间不会互相「抽」，而是把连在一起的管道当成一张网：抽到东西的那根管道
 * 直接往网里任何一天能收下的方块送货。这样连着放好几根管道也能一路送下去，
 * 又不会出现两根管道来回倒腾同一个物品的怪事。
 *
 * <p>不做路径规划、不做优先级、不做过滤——本轮就是最简单的「相邻推拉」。
 */
public class ItemPipeBlockEntity extends BlockEntity implements TickableBlockEntity {

    /** 每 tick 从邻居抽几个物品。 */
    public static final int PULL_PER_TICK = 1;
    /** 手里最多攒多少（一个格子），攒着的东西会存进存档，不会因为拆管道消失。 */
    public static final int BUFFER_SIZE = 1;
    /** 一张管道网最多找多少个方块，防止玩家铺上几千根管道把服务器拖死。 */
    private static final int MAX_NETWORK_SIZE = 128;
    /** 接头多久重算一次（tick）。 */
    private static final int CONNECTION_REFRESH_INTERVAL = 20;

    /** 一个格子的中转缓存。 */
    private final NonNullList<ItemStack> buffer = NonNullList.withSize(BUFFER_SIZE, ItemStack.EMPTY);

    /** 这个东西是从哪一面抽来的：送货时先跳过那一面，免得刚抽出来又原样塞回去。 */
    @Nullable
    private Direction sourceDirection;

    private int refreshTimer;

    public ItemPipeBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ITEM_PIPE.get(), pos, state);
    }

    /** 手里有没有东西（GUI 用不到，测试和调试时有用）。 */
    public ItemStack getBuffered() {
        return this.buffer.get(0);
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        if (++this.refreshTimer >= CONNECTION_REFRESH_INTERVAL) {
            this.refreshTimer = 0;
            refreshConnections();
        }
        if (this.buffer.get(0).isEmpty()) {
            pullOne();
        }
        if (!this.buffer.get(0).isEmpty()) {
            deliver();
        }
    }

    /** 从六个方向的邻居里抽 1 个物品。抽的是「能抽的那一格」：机器的输出槽。 */
    private void pullOne() {
        if (this.level == null) {
            return;
        }
        for (Direction side : Direction.values()) {
            BlockPos neighbourPos = this.worldPosition.relative(side);
            // 管道之间不互相抽：一根管道单独负责「从机器/箱子拿货」，送货时再穿过整张网
            if (this.level.getBlockEntity(neighbourPos) instanceof ItemPipeBlockEntity) {
                continue;
            }
            IItemHandler handler = handlerAt(neighbourPos, side.getOpposite());
            if (handler == null) {
                continue;
            }
            for (int slot = 0; slot < handler.getSlots(); slot++) {
                ItemStack probe = handler.extractItem(slot, PULL_PER_TICK, true);
                if (probe.isEmpty()) {
                    continue;
                }
                ItemStack taken = handler.extractItem(slot, probe.getCount(), false);
                if (taken.isEmpty()) {
                    continue;
                }
                this.buffer.set(0, taken.copy());
                this.sourceDirection = side;
                setChanged();
                return;
            }
        }
    }

    /** 把手里这个物品送到管道网里第一个愿意收的方块。 */
    private void deliver() {
        if (this.level == null) {
            return;
        }
        ItemStack carried = this.buffer.get(0);
        if (carried.isEmpty()) {
            return;
        }

        Deque<BlockPos> queue = new ArrayDeque<>();
        Set<BlockPos> visited = new HashSet<>();
        queue.add(this.worldPosition);
        visited.add(this.worldPosition);

        while (!queue.isEmpty() && visited.size() <= MAX_NETWORK_SIZE) {
            BlockPos pipePos = queue.poll();
            boolean origin = pipePos.equals(this.worldPosition);
            for (Direction side : Direction.values()) {
                if (origin && side == this.sourceDirection) {
                    continue;
                }
                BlockPos neighbourPos = pipePos.relative(side);
                if (this.level.getBlockEntity(neighbourPos) instanceof ItemPipeBlockEntity) {
                    if (visited.size() < MAX_NETWORK_SIZE && visited.add(neighbourPos)) {
                        queue.add(neighbourPos);
                    }
                    continue;
                }
                IItemHandler handler = handlerAt(neighbourPos, side.getOpposite());
                if (handler == null) {
                    continue;
                }
                ItemStack leftover = insertInto(handler, carried);
                if (leftover.getCount() < carried.getCount()) {
                    this.buffer.set(0, leftover);
                    if (leftover.isEmpty()) {
                        this.sourceDirection = null;
                    }
                    setChanged();
                    if (leftover.isEmpty()) {
                        return;
                    }
                    carried = leftover;
                }
            }
        }
    }

    /** 往一个物品接口里塞，返回塞不下的部分。 */
    private static ItemStack insertInto(IItemHandler handler, ItemStack stack) {
        ItemStack remaining = stack.copy();
        for (int slot = 0; slot < handler.getSlots() && !remaining.isEmpty(); slot++) {
            remaining = handler.insertItem(slot, remaining, false);
        }
        return remaining;
    }

    /**
     * 拿到某个位置物品接口。
     *
     * <p>优先用 NeoForge 的物品接口（箱子、漏斗、别的模组的机器都走这条）；
     * 万一邻居只实现了原版的 {@link Container}，就临时包一层，保证「能塞能抽」。
     */
    @Nullable
    private IItemHandler handlerAt(BlockPos pos, Direction face) {
        if (this.level == null) {
            return null;
        }
        IItemHandler handler = this.level.getCapability(Capabilities.ItemHandler.BLOCK, pos, face);
        if (handler != null) {
            return handler;
        }
        BlockEntity neighbour = this.level.getBlockEntity(pos);
        if (neighbour instanceof Container container) {
            return new ContainerItemHandler(container, slot -> true, slot -> true);
        }
        return null;
    }

    /** 每 20 tick 重算一次接头，补上能力系统还没来得及通知的情况。 */
    private void refreshConnections() {
        if (this.level == null) {
            return;
        }
        BlockState state = getBlockState();
        if (!(state.getBlock() instanceof AbstractPipeBlock pipe)) {
            return;
        }
        BlockState updated = pipe.refreshConnections(this.level, this.worldPosition, state);
        if (!updated.equals(state)) {
            this.level.setBlock(this.worldPosition, updated, Block.UPDATE_ALL);
        }
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        CompoundTag bufferTag = new CompoundTag();
        ContainerHelper.saveAllItems(bufferTag, this.buffer, registries);
        tag.put("Buffer", bufferTag);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        ContainerHelper.loadAllItems(tag.getCompound("Buffer"), this.buffer, registries);
    }
}
