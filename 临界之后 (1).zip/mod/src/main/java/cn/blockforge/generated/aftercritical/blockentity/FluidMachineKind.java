package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.recipe.FluidProcessRecipe;
import cn.blockforge.generated.aftercritical.registry.ModRecipes;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.crafting.RecipeType;

/**
 * 十台流体机器的「型号说明书」。
 *
 * <p>电解槽、化工厂、空气分离器，加上阶段 1 的浸出槽、沉淀槽、干燥炉、转化炉、氟化反应器，
 * 用的是同一个方块实体类和同一套界面，差别只有：
 * 等级、功率、几个物品槽、几个流体罐、看哪一类配方。
 * 把这些数字集中写在这里，方块实体和界面直接读，就不用为每台机器各写一份代码。
 */
public enum FluidMachineKind {

    // ------------------------------------------------------------------
    // 阶段 0 的三台
    // ------------------------------------------------------------------

    /**
     * 电解槽：LV，40 FE/t，2 个物品槽 + 1 个进液罐 + 3 个出液罐（水 → 氢 + 氧 + 氘）。
     *
     * <p>两个物品槽的分工：1 号放原料（海带），2 号放催化剂（钯合金膜）。
     * 「水 → 氘 + 氢 + 氧」那条配方的 {@code catalyst} 就是钯合金膜，
     * 所以槽里有膜才出氘、没有就老老实实只出氢和氧——两条配方不再互相抢，
     * 也不用再靠「产物多的优先」这种运气。膜是装配出来的贵重部件，验过之后不消耗。
     */
    ELECTROLYZER("LV", 40, 2, 1, 0, 3,
            "block.aftercritical.electrolyzer.desc", "container.aftercritical.electrolyzer"),

    /** 化工厂：MV，80 FE/t，2 个物品槽 + 3 个进液罐 + 1 个产物槽 + 2 个出液罐。 */
    CHEMICAL_PLANT("MV", 80, 2, 3, 1, 2,
            "block.aftercritical.chemical_plant.desc", "container.aftercritical.chemical_plant"),

    /**
     * 空气分离器：MV，120 FE/t，2 个物品槽 + 0 个进液罐 + 2 个出液罐。
     *
     * <p>两个物品槽放【碳分子筛】和【钯合金膜】。这两样是机器的「常驻部件」，
     * 放进去就不会被消耗——机器只要通电、槽里有它们，就一直把空气分成氮和氧。
     */
    AIR_SEPARATOR("MV", 120, 2, 0, 0, 2,
            "block.aftercritical.air_separator.desc", "container.aftercritical.air_separator"),

    /**
     * 地下水开采机：LV，最低 30 FE/t，不要任何原料，1 个出液罐（一直出水）。
     *
     * <p>这是全模组唯一一台「电通得越多、干得越快」的机器：30 FE/t 时 10 秒出 200 mB，
     * 给到 120 FE/t 就是 4 倍速（2.5 秒 200 mB）。每 200 mB 固定花 200 × 30 = 6000 FE，
     * 快只是快，不会更省电也不会更费电。数值写在
     * {@code data/aftercritical/recipe/groundwater/water.json}。
     */
    GROUNDWATER_PUMP("LV", 30, 0, 0, 0, 1,
            "block.aftercritical.groundwater_pump.desc", "container.aftercritical.groundwater_pump"),

    // ------------------------------------------------------------------
    // 阶段 1 的五台
    // ------------------------------------------------------------------

    /** 浸出槽：LV，50 FE/t，1 个物品槽（矿粉）+ 2 个进液罐（硫酸、水）→ 1 个产物槽（矿渣）+ 2 个出液罐。 */
    LEACHING_TANK("LV", 50, 1, 2, 1, 2,
            "block.aftercritical.leaching_tank.desc", "container.aftercritical.leaching_tank"),

    /** 沉淀槽：LV，40 FE/t，3 个进液罐（铀酰溶液 + 氨 + 过氧化氢）→ 1 个产物槽（黄饼）+ 1 个出液罐（废液）。 */
    PRECIPITATION_TANK("LV", 40, 0, 3, 1, 1,
            "block.aftercritical.precipitation_tank.desc", "container.aftercritical.precipitation_tank"),

    /** 干燥炉：LV，60 FE/t，只烤物品：1 个物品槽进，1 个产物槽出，不碰流体。 */
    DRYING_OVEN("LV", 60, 1, 0, 1, 0,
            "block.aftercritical.drying_oven.desc", "container.aftercritical.drying_oven"),

    /** 转化炉：MV，120 FE/t，1 个物品槽 + 2 个进液罐 → 1 个产物槽 + 2 个出液罐。 */
    CONVERTER("MV", 120, 1, 2, 1, 2,
            "block.aftercritical.converter.desc", "container.aftercritical.converter"),

    /** 氟化反应器：MV，160 FE/t，1 个物品槽 + 1 个进液罐（氟气）→ 1 个出液罐（六氟化铀）。 */
    FLUORINATION_REACTOR("MV", 160, 1, 1, 0, 1,
            "block.aftercritical.fluorination_reactor.desc", "container.aftercritical.fluorination_reactor"),

    // ------------------------------------------------------------------
    // 阶段 2 的两台
    // ------------------------------------------------------------------

    /** 气体离心机：MV，200 FE/t，1 物品进 / 2 物品出 + 1 进液（六氟化铀）→ 2 出液（低浓缩 + 贫铀）。 */
    GAS_CENTRIFUGE("MV", 200, 1, 1, 2, 2,
            "block.aftercritical.gas_centrifuge.desc", "container.aftercritical.gas_centrifuge"),

    /** 水解反应器：MV，80 FE/t，0 物品进 / 1 物品出 + 2 进液（六氟化铀、水）→ 1 出液（氢氟酸）。 */
    HYDROLYSIS_REACTOR("MV", 80, 0, 2, 1, 1,
            "block.aftercritical.hydrolysis_reactor.desc", "container.aftercritical.hydrolysis_reactor"),

    // ------------------------------------------------------------------
    // 阶段 4 的一台
    // ------------------------------------------------------------------

    /**
     * 辐照靶冷却池：HV，60 FE/t，1 个物品槽进 / 1 个物品槽出 + 1 个进液罐（水）。
     *
     * <p>刚从研究堆拔出来的辐照靶烫手，得在池子里泡 5 分钟水才能变成能用的同位素。
     * 水会随着冷却一起被消耗，所以得拿管道或通用流体罐一直补。
     */
    IRRADIATION_POOL("HV", 60, 1, 1, 1, 0,
            "block.aftercritical.irradiation_pool.desc", "container.aftercritical.irradiation_pool"),

    // ------------------------------------------------------------------
    // 阶段 5 的一台
    // ------------------------------------------------------------------

    /**
     * 冷凝器：HV，32 FE/t，1 个进液罐（乏蒸汽）→ 1 个出液罐（水）。
     *
     * <p>不烧物品，纯粹把乏蒸汽冷凝成水，好让水重新泵回压水堆。
     */
    CONDENSER("HV", 32, 0, 1, 0, 1,
            "block.aftercritical.condenser.desc", "container.aftercritical.condenser"),

    // ------------------------------------------------------------------
    // 阶段 6：乏燃料后处理线
    // ------------------------------------------------------------------

    /**
     * 乏燃料冷却池：HV，80 FE/t，1 物品进 / 1 物品出 + 1 个进水罐。
     *
     * <p>反应堆里拿出来的乏燃料组件还是「热」的（辐射强、自己会发热），
     * 得在池子里泡够 10 分钟水才能送去剪切。水会跟着一起消耗，所以要一直补。
     */
    SPENT_FUEL_POOL("HV", 80, 1, 1, 1, 0,
            "block.aftercritical.spent_fuel_pool.desc", "container.aftercritical.spent_fuel_pool"),

    /**
     * 溶解槽：HV，250 FE/t，1 物品进 / 1 物品出 + 2 进液罐 + 1 出液罐。
     *
     * <p>剪碎的乏燃料用硝酸泡开，变成一锅深绿色的溶解液，剩下的空壳当壳渣吐出来。
     */
    DISSOLUTION_TANK("HV", 250, 1, 2, 1, 1,
            "block.aftercritical.dissolution_tank.desc", "container.aftercritical.dissolution_tank"),

    /**
     * 萃取柱：HV，300 FE/t，0 物品 + 2 进液罐 → 2 出液罐。
     *
     * <p>溶解液从下往上、TBP 有机相从上往下，两股液体在柱子里对流，
     * 铀和钚被 TBP 带走，裂变产物留在原来的水相里。
     */
    EXTRACTION_COLUMN("HV", 300, 0, 2, 0, 2,
            "block.aftercritical.extraction_column.desc", "container.aftercritical.extraction_column"),

    /**
     * 离心萃取器：HV，350 FE/t，1 个物品槽 + 1 进液罐 → 3 个产物槽 + 1 出液罐。
     *
     * <p>把萃取液甩成两样固体（钚239 + 回收铀）；高放废液则被甩成
     * 锶90、铯137、锕系元素三样固体，剩下的废液从出液罐流走。
     * 三样固体要三个产物槽，所以这台机器比别的多两格。
     */
    CENTRIFUGAL_EXTRACTOR("HV", 350, 1, 1, 3, 1,
            "block.aftercritical.centrifugal_extractor.desc", "container.aftercritical.centrifugal_extractor"),

    /**
     * 玻璃固化炉：HV，300 FE/t，3 物品进 / 1 物品出 + 1 进液罐。
     *
     * <p>高放废液掺进玻璃和铅板里烧成一整块【固化玻璃】，
     * 放射性就被封在玻璃里了，可以找地方埋起来。
     */
    VITRIFICATION_FURNACE("HV", 300, 3, 1, 1, 0,
            "block.aftercritical.vitrification_furnace.desc", "container.aftercritical.vitrification_furnace");

    private final String tier;
    private final int energyPerTick;
    private final int itemInputSlots;
    private final int fluidInputTanks;
    private final int itemOutputSlots;
    private final int fluidOutputTanks;
    private final String descriptionKey;
    private final String titleKey;

    FluidMachineKind(String tier, int energyPerTick, int itemInputSlots, int fluidInputTanks,
                     int itemOutputSlots, int fluidOutputTanks, String descriptionKey, String titleKey) {
        this.tier = tier;
        this.energyPerTick = energyPerTick;
        this.itemInputSlots = itemInputSlots;
        this.fluidInputTanks = fluidInputTanks;
        this.itemOutputSlots = itemOutputSlots;
        this.fluidOutputTanks = fluidOutputTanks;
        this.descriptionKey = descriptionKey;
        this.titleKey = titleKey;
    }

    public String tier() {
        return this.tier;
    }

    public int energyPerTick() {
        return this.energyPerTick;
    }

    /**
     * 这台机器最多能吃几倍的最低功率。
     *
     * <p>绝大多数机器是 1：给够额定功率就干活，给多也没地方用。
     * 地下水开采机是 4：电通得越多，同一时间干得越多（见 {@link #GROUNDWATER_PUMP}）。
     */
    public int maxSpeedMultiplier() {
        return this == GROUNDWATER_PUMP ? 4 : 1;
    }

    /** 满速时每 tick 要吃多少 FE：普通机器就是额定功率，开采机是 30 × 4 = 120。 */
    public int maxEnergyPerTick() {
        return this.energyPerTick * maxSpeedMultiplier();
    }

    /**
     * 干完一次活之后，要不要把物品输入扣掉。
     *
     * <p>几乎所有机器都是 {@code true}：原料当然会被吃掉。
     * 只有空气分离器是 {@code false}：碳分子筛和钯合金膜是装在机器里的固定部件，
     * 配方只检查它们在不在，生产完不会少。
     */
    public boolean consumesItemInputs() {
        return this != AIR_SEPARATOR;
    }

    /**
     * 产物放不下时的态度。
     *
     * <p>老机器（如电解槽）是 {@code false}：多出来的液体直接排掉，免得阶段 0 没管道时卡死。
     * 地下水开采机是 {@code true}：水攒满就停机等玩家来接，不来就把水当白开水倒掉太浪费电。
     */
    public boolean stallsWhenFluidOutputFull() {
        return this == GROUNDWATER_PUMP;
    }

    public int itemInputSlots() {
        return this.itemInputSlots;
    }

    public int fluidInputTanks() {
        return this.fluidInputTanks;
    }

    public int itemOutputSlots() {
        return this.itemOutputSlots;
    }

    public int fluidOutputTanks() {
        return this.fluidOutputTanks;
    }

    public String descriptionKey() {
        return this.descriptionKey;
    }

    /** 界面顶上的标题。 */
    public Component displayName() {
        return Component.translatable(this.titleKey);
    }

    /** 这台机器去配方管理器里找哪一类配方。 */
    public RecipeType<FluidProcessRecipe> recipeType() {
        return switch (this) {
            case ELECTROLYZER -> ModRecipes.ELECTROLYSIS;
            case CHEMICAL_PLANT -> ModRecipes.CHEMICAL_PLANT;
            case AIR_SEPARATOR -> ModRecipes.AIR_SEPARATION;
            case GROUNDWATER_PUMP -> ModRecipes.GROUNDWATER;
            case LEACHING_TANK -> ModRecipes.LEACHING;
            case PRECIPITATION_TANK -> ModRecipes.PRECIPITATION;
            case DRYING_OVEN -> ModRecipes.DRYING;
            case CONVERTER -> ModRecipes.CONVERSION;
            case FLUORINATION_REACTOR -> ModRecipes.FLUORINATION;
            case GAS_CENTRIFUGE -> ModRecipes.CENTRIFUGE;
            case HYDROLYSIS_REACTOR -> ModRecipes.HYDROLYSIS;
            case IRRADIATION_POOL -> ModRecipes.COOLING;
            case CONDENSER -> ModRecipes.CONDENSATION;
            case SPENT_FUEL_POOL -> ModRecipes.SPENT_FUEL_COOLING;
            case DISSOLUTION_TANK -> ModRecipes.DISSOLUTION;
            case EXTRACTION_COLUMN -> ModRecipes.EXTRACTION;
            case CENTRIFUGAL_EXTRACTOR -> ModRecipes.FISSION_SEPARATION;
            case VITRIFICATION_FURNACE -> ModRecipes.VITRIFICATION;
        };
    }
}
