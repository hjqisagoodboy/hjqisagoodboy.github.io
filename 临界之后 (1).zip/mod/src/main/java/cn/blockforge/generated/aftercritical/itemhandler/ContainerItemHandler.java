package cn.blockforge.generated.aftercritical.itemhandler;

import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.items.IItemHandler;

import java.util.function.IntPredicate;
import java.util.function.IntUnaryOperator;

/**
 * 把机器自己的槽位包装成 NeoForge 的物品接口（{@link IItemHandler}）。
 *
 * <p>为什么需要它：物品管道、漏斗这类「自动化搬运工」只认 {@code IItemHandler}，
 * 而我们的机器内部用的是原版的 {@link Container}（玩家开 GUI 用的那套槽位）。
 * 这个包装类把两者对接起来，同时告诉搬运工两个关键规矩：
 * <ul>
 *   <li>{@code insertFilter}：哪些槽能往里塞（机器的输入槽、工具槽）；</li>
 *   <li>{@code extractFilter}：哪些槽能被抽走（基本只有输出槽）。</li>
 * </ul>
 *
 * <p>这样一来，管道不会把玩家放在输入槽里的矿石又抽走，
 * 也不会把锻压机工具槽里的模具偷走。
 */
public final class ContainerItemHandler implements IItemHandler {

    private final Container container;
    private final IntPredicate insertFilter;
    private final IntPredicate extractFilter;
    private final IntUnaryOperator slotLimit;

    public ContainerItemHandler(Container container, IntPredicate insertFilter, IntPredicate extractFilter) {
        this(container, insertFilter, extractFilter, slot -> container.getMaxStackSize());
    }

    /**
     * 带「每格最多放几个」的版本。
     *
     * <p>流体机器的罐子槽一格只放得下 1 个罐子，管道往里塞的时候也得按这个规矩来，
     * 不然一塞就是 64 个，机器没地方放第二叠，东西就没了。
     */
    public ContainerItemHandler(Container container, IntPredicate insertFilter, IntPredicate extractFilter,
                                IntUnaryOperator slotLimit) {
        this.container = container;
        this.insertFilter = insertFilter;
        this.extractFilter = extractFilter;
        this.slotLimit = slotLimit;
    }

    @Override
    public int getSlots() {
        return this.container.getContainerSize();
    }

    @Override
    public ItemStack getStackInSlot(int slot) {
        return this.container.getItem(slot);
    }

    @Override
    public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
        if (stack.isEmpty() || !isItemValid(slot, stack)) {
            return stack;
        }
        ItemStack existing = this.container.getItem(slot);
        int limit = Math.min(this.slotLimit.applyAsInt(slot), stack.getMaxStackSize());
        if (!existing.isEmpty()) {
            if (!ItemStack.isSameItemSameComponents(existing, stack)) {
                return stack;
            }
            limit -= existing.getCount();
        }
        if (limit <= 0) {
            return stack;
        }
        int inserted = Math.min(limit, stack.getCount());
        if (!simulate) {
            if (existing.isEmpty()) {
                this.container.setItem(slot, stack.copyWithCount(inserted));
            } else {
                existing.grow(inserted);
                this.container.setChanged();
            }
        }
        return stack.copyWithCount(stack.getCount() - inserted);
    }

    @Override
    public ItemStack extractItem(int slot, int amount, boolean simulate) {
        if (amount <= 0 || slot < 0 || slot >= getSlots() || !this.extractFilter.test(slot)) {
            return ItemStack.EMPTY;
        }
        ItemStack existing = this.container.getItem(slot);
        if (existing.isEmpty()) {
            return ItemStack.EMPTY;
        }
        int extracted = Math.min(amount, existing.getCount());
        if (simulate) {
            return existing.copyWithCount(extracted);
        }
        return this.container.removeItem(slot, extracted);
    }

    @Override
    public int getSlotLimit(int slot) {
        return this.slotLimit.applyAsInt(slot);
    }

    @Override
    public boolean isItemValid(int slot, ItemStack stack) {
        return slot >= 0 && slot < getSlots()
                && this.insertFilter.test(slot)
                && this.container.canPlaceItem(slot, stack);
    }
}
