package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.block.TokamakControllerBlock;
import cn.blockforge.generated.aftercritical.energy.BufferedEnergyStorage;
import cn.blockforge.generated.aftercritical.energy.WirelessEnergyGrid;
import cn.blockforge.generated.aftercritical.itemhandler.ContainerItemHandler;
import cn.blockforge.generated.aftercritical.menu.TokamakMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModBlocks;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.items.IItemHandler;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 托卡马克控制器：阶段 7 的 9×9×9 多方块，整个模组的「无限电」来源。
 *
 * <p>结构和快堆一个套路：控制器贴在正面墙、贴地那排正中间，方块朝哪堆就往哪长。
 *
 * <p>玩法（定稿 v4）：
 * <ol>
 *   <li>外壳用【聚变环外壳】≥64 块，里面塞【超导线圈】≥32、【增殖包层模块】≥4、
 *       【燃料注入端口】≥2、【等离子体诊断器】1、【低温冷却器】1、【聚变控制逻辑】1；</li>
 *   <li>将 8 台电池 MV 并联用 HV 线缆接到控制器，界面里放【氘氚燃料单元】，按「点火」；</li>
 *   <li>点火一次性抽 72,000 FE，之后 30 秒预热；点着以后每 10 秒烧掉 1 个氘氚燃料单元，
 *       稳定输出 <b>20,000 FE/t</b>；</li>
 *   <li>4 个增殖包层模块每 30 秒各产 1 个氚（每 30 秒合计 4 个），氚进机器的产物槽；</li>
 *   <li>输出的电既可以用 HV 线缆从控制器接走，也会自动无线送给 256 格内的【能量端口】。</li>
 * </ol>
 */
public class TokamakControllerBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity
        implements Container, net.minecraft.world.MenuProvider, TickableBlockEntity, EnergyMachineHost {

    // ------------------------------------------------------------------
    // 结构
    // ------------------------------------------------------------------

    /** 9×9×9 的正方体。 */
    public static final int SIZE = 9;

    /** 外壳（聚变环外壳）至少多少块。 */
    public static final int MIN_CASING = 64;
    /** 超导线圈至少多少块。 */
    public static final int MIN_COILS = 32;
    /** 增殖包层模块至少多少块。 */
    public static final int MIN_BLANKETS = 4;
    /** 燃料注入端口至少几个。 */
    public static final int MIN_INJECTORS = 2;
    /** 等离子体诊断器至少几个。 */
    public static final int MIN_DIAGNOSTICS = 1;
    /** 低温冷却器至少几个。 */
    public static final int MIN_COOLERS = 1;
    /** 聚变控制逻辑至少几个。 */
    public static final int MIN_LOGIC = 1;

    /** 结构每 2 秒重查一次。 */
    public static final int VALIDATE_INTERVAL = 40;

    // ------------------------------------------------------------------
    // 数值（定稿 v4）
    // ------------------------------------------------------------------

    /** 稳定运行时的净输出。 */
    public static final int OUTPUT_FE = 20_000;
    /** 点火预热时长（30 秒）。 */
    public static final int STARTUP_TICKS = 600;
    /** 点火总共要消耗的电（v4：2,400 FE/t × 30 秒，等效 72,000 FE）。 */
    public static final int STARTUP_FE = 72_000;
    /** 预热期间每 tick 消耗（72,000 ÷ 600 = 120 FE/t，也就是每秒 2,400 FE）。 */
    public static final int STARTUP_PER_TICK = STARTUP_FE / STARTUP_TICKS;

    /** 燃料槽：4 个氘氚燃料单元。 */
    public static final int FUEL_SLOTS = 4;
    /** 产物槽：增殖包层产出的氚。 */
    public static final int SLOT_OUTPUT = FUEL_SLOTS;
    public static final int SLOT_COUNT = FUEL_SLOTS + 1;
    /** 每 10 秒烧 1 个氘氚燃料单元。 */
    public static final int FUEL_INTERVAL = 200;
    /** 连续稳态多少 tick 算「稳态运行」（60 秒，成就用）。 */
    public static final int STEADY_MILESTONE_TICKS = 1200;
    /** 每 30 秒一轮氚增殖。 */
    public static final int TRITIUM_INTERVAL = 600;
    /** 4 个增殖包层模块，一轮产 4 个氚。 */
    public static final int TRITIUM_PER_CYCLE = 4;

    /** 内部储能：1,600,000 FE。 */
    public static final int ENERGY_CAPACITY = 1_600_000;
    /** 没点火时从电网里抽电的速度（v4 的 2,400 FE/t）。 */
    public static final int CHARGE_PER_TICK = 2_400;
    /** 无线供电半径（格）。 */
    public static final int WIRELESS_RANGE = 256;

    // ------------------------------------------------------------------
    // 界面状态码
    // ------------------------------------------------------------------

    public static final int STATUS_UNFORMED = 0;
    public static final int STATUS_NO_FUEL = 1;
    public static final int STATUS_CHARGING = 2;
    public static final int STATUS_IGNITING = 3;
    public static final int STATUS_RUNNING = 4;
    public static final int STATUS_IDLE = 5;

    // ------------------------------------------------------------------
    // 状态
    // ------------------------------------------------------------------

    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);

    private final IItemHandler itemHandler = new ContainerItemHandler(this,
            slot -> slot >= 0 && slot < FUEL_SLOTS,
            slot -> slot == SLOT_OUTPUT);

    private final BufferedEnergyStorage energy =
            new BufferedEnergyStorage(ENERGY_CAPACITY, OUTPUT_FE, OUTPUT_FE, this::setChanged);

    /**
     * 对外暴露的 FE 接口。
     *
     * <p>它和内部缓存只差一句话：<b>没点火、没预热的时候，别人不许从这里抽电</b>。
     *
     * <p>为什么要卡这一句：托卡马克本来就「既能收也能放」。如果 {@code canExtract()} 一直是 true，
     * 它在电池和线缆网眼里就是「一块电池」，于是——
     * <ul>
     *   <li>电池只肯给「只吃不吐的机器」送电，看到它是电池就跳过；</li>
     *   <li>线缆网只在「机器缺电」时才从电池组放电，而托卡马克不算机器，永远排不进缺电名单。</li>
     * </ul>
     * 结果就是点火前那 72,000 FE 怎么都送不进去。点火前老老实实当「机器」，点火后才当「发电机」。
     */
    private final IEnergyStorage port = new IEnergyStorage() {
        @Override
        public int receiveEnergy(int toReceive, boolean simulate) {
            return energy.receiveEnergy(toReceive, simulate);
        }

        @Override
        public int extractEnergy(int toExtract, boolean simulate) {
            return canExtract() ? energy.extractEnergy(toExtract, simulate) : 0;
        }

        @Override
        public int getEnergyStored() {
            return energy.getEnergyStored();
        }

        @Override
        public int getMaxEnergyStored() {
            return energy.getMaxEnergyStored();
        }

        /** 只有点着火（预热或稳态）才允许别人把电抽走；平时这块「电池」是只进的。 */
        @Override
        public boolean canExtract() {
            return running || igniting;
        }

        @Override
        public boolean canReceive() {
            return energy.canReceive();
        }
    };

    private boolean formed;
    private int casingCount;
    private int coilCount;
    private int blanketCount;
    private int injectorCount;
    private int diagnosticCount;
    private int coolerCount;
    private int logicCount;
    private int validateTimer;

    private boolean running;
    private boolean igniting;
    private int ignitionTicks;
    private int fuelTimer;
    /** 稳态跑了多少 tick（成就「稳态 20,000」用）。 */
    private int steadyTicks;
    private int breedTimer;
    private int fuelCount;
    private int tritiumCount;
    private boolean breedBlocked;
    private int wirelessSent;
    private int portsInRange;
    private int status = STATUS_UNFORMED;

    public TokamakControllerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.TOKAMAK_CONTROLLER.get(), pos, state);
    }

    public IItemHandler getItemHandler() {
        return this.itemHandler;
    }

    public IEnergyStorage getEnergyStorage() {
        return this.port;
    }

    public void validateSoon() {
        this.validateTimer = 1;
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        if (--this.validateTimer <= 0) {
            this.validateTimer = VALIDATE_INTERVAL;
            validateStructure();
            this.portsInRange = WirelessEnergyGrid.portsInRange(this.level, this.worldPosition,
                    WIRELESS_RANGE).size();
        }
        if (!this.formed) {
            this.running = false;
            this.igniting = false;
            this.ignitionTicks = 0;
        }

        pullEnergyFromNeighbours();
        this.fuelCount = countFuel();

        if (this.igniting) {
            // 预热 30 秒，期间按 120 FE/t 匀速烧电（30 秒正好 72,000 FE）
            if (!this.formed || this.fuelCount <= 0 || !this.energy.consume(STARTUP_PER_TICK)) {
                this.igniting = false;
                this.ignitionTicks = 0;
            } else if (--this.ignitionTicks <= 0) {
                this.igniting = false;
                this.running = true;
                playIgnitionSound();
                // 成就「点火」：等离子体第一次自持
                ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 96.0,
                        ModAdvancementTriggers.TOKAMAK_IGNITE);
            }
        }

        if (this.running) {
            if (!this.formed || this.fuelCount <= 0) {
                this.running = false;
                this.fuelTimer = 0;
                this.steadyTicks = 0;
            } else {
                if (++this.fuelTimer >= FUEL_INTERVAL) {
                    this.fuelTimer = 0;
                    consumeFuelCell();
                }
                breedTritium();
                this.energy.grow(OUTPUT_FE);
                spawnPlasmaParticles();
                // 稳着烧满一分钟（1200 tick）＝ 成就「稳态 20,000」
                if (++this.steadyTicks == STEADY_MILESTONE_TICKS) {
                    ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 96.0,
                            ModAdvancementTriggers.TOKAMAK_STEADY);
                }
            }
        }

        this.wirelessSent = this.running ? sendWireless(OUTPUT_FE) : 0;

        int newStatus = computeStatus();
        if (this.status != newStatus) {
            this.status = newStatus;
            setChanged();
        }
        this.tritiumCount = countTritium();
        setChanged();
    }

    /** 把电无线送给 256 格内的能量端口。 */
    private int sendWireless(int budget) {
        if (this.level == null) {
            return 0;
        }
        int available = Math.min(budget, this.energy.getEnergyStored());
        if (available <= 0) {
            return 0;
        }
        int sent = 0;
        for (EnergyPortBlockEntity port : WirelessEnergyGrid.portsInRange(this.level, this.worldPosition,
                WIRELESS_RANGE)) {
            if (sent >= available) {
                break;
            }
            int room = port.freeSpace();
            if (room <= 0) {
                continue;
            }
            int moved = port.receiveWireless(Math.min(available - sent, room));
            if (moved > 0) {
                sent += moved;
            }
        }
        if (sent > 0) {
            this.energy.extractEnergy(sent, false);
        }
        return sent;
    }

    /** 没点火时从六个方向的电网里抽电（速度上限 2,400 FE/t）。 */
    private void pullEnergyFromNeighbours() {
        if (this.level == null || this.running || this.igniting) {
            return;
        }
        int budget = Math.min(this.energy.getFreeSpace(), CHARGE_PER_TICK);
        for (Direction side : Direction.values()) {
            if (budget <= 0) {
                break;
            }
            IEnergyStorage source = this.level.getCapability(Capabilities.EnergyStorage.BLOCK,
                    this.worldPosition.relative(side), side.getOpposite());
            if (source == null || !source.canExtract()) {
                continue;
            }
            int moved = source.extractEnergy(Math.min(budget, source.getEnergyStored()), true);
            if (moved <= 0) {
                continue;
            }
            moved = source.extractEnergy(moved, false);
            if (moved > 0) {
                this.energy.receiveEnergy(moved, false);
                budget -= moved;
            }
        }
    }

    /**
     * 点火：界面上的按钮调这个。
     *
     * <p>储能必须先攒够 {@link #STARTUP_FE}（不然预热到一半会断电），
     * 真正扣电是预热那 30 秒里匀速扣的。
     *
     * @return 真的点着了（开始预热）返回 true
     */
    public boolean ignite() {
        if (!this.formed || this.running || this.igniting || this.fuelCount <= 0) {
            return false;
        }
        if (this.energy.getEnergyStored() < STARTUP_FE) {
            return false;
        }
        this.igniting = true;
        this.ignitionTicks = STARTUP_TICKS;
        this.fuelTimer = 0;
        this.breedTimer = 0;
        setChanged();
        return true;
    }

    private void consumeFuelCell() {
        for (int i = 0; i < FUEL_SLOTS; i++) {
            ItemStack stack = this.items.get(i);
            if (!stack.is(ModItems.DT_FUEL_CELL.get())) {
                continue;
            }
            stack.shrink(1);
            if (stack.isEmpty()) {
                this.items.set(i, ItemStack.EMPTY);
            }
            setChanged();
            return;
        }
    }

    /** 每 30 秒一轮：4 个增殖包层模块各产 1 个氚。 */
    private void breedTritium() {
        this.breedTimer++;
        if (this.breedTimer < TRITIUM_INTERVAL) {
            this.breedBlocked = false;
            return;
        }
        if (!canAcceptTritium(TRITIUM_PER_CYCLE)) {
            // 产物槽满了：先不推进计时，等玩家把氚取走再接着增殖
            this.breedBlocked = true;
            return;
        }
        this.breedTimer = 0;
        this.breedBlocked = false;
        ItemStack out = this.items.get(SLOT_OUTPUT);
        if (out.isEmpty()) {
            this.items.set(SLOT_OUTPUT, new ItemStack(ModItems.TRITIUM.get(), TRITIUM_PER_CYCLE));
        } else {
            out.grow(TRITIUM_PER_CYCLE);
        }
        setChanged();
    }

    private boolean canAcceptTritium(int amount) {
        ItemStack out = this.items.get(SLOT_OUTPUT);
        if (out.isEmpty()) {
            return true;
        }
        if (!out.is(ModItems.TRITIUM.get())) {
            return false;
        }
        return out.getCount() + amount <= out.getMaxStackSize();
    }

    private int countFuel() {
        int total = 0;
        for (int i = 0; i < FUEL_SLOTS; i++) {
            ItemStack stack = this.items.get(i);
            if (stack.is(ModItems.DT_FUEL_CELL.get())) {
                total += stack.getCount();
            }
        }
        return total;
    }

    private int countTritium() {
        ItemStack out = this.items.get(SLOT_OUTPUT);
        return out.is(ModItems.TRITIUM.get()) ? out.getCount() : 0;
    }

    private void playIgnitionSound() {
        if (this.level instanceof ServerLevel server) {
            server.playSound(null, this.worldPosition, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 0.7F, 1.2F);
        }
    }

    private void spawnPlasmaParticles() {
        if (!(this.level instanceof ServerLevel server) || server.getGameTime() % 5 != 0) {
            return;
        }
        server.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 1.0,
                this.worldPosition.getZ() + 0.5, 3, 0.5, 0.3, 0.5, 0.01);
    }

    private int computeStatus() {
        if (!this.formed) {
            return STATUS_UNFORMED;
        }
        if (this.running) {
            return STATUS_RUNNING;
        }
        if (this.igniting) {
            return STATUS_IGNITING;
        }
        if (this.fuelCount <= 0) {
            return STATUS_NO_FUEL;
        }
        if (this.energy.getEnergyStored() < STARTUP_FE) {
            return STATUS_CHARGING;
        }
        return STATUS_IDLE;
    }

    // ------------------------------------------------------------------
    // 结构检测
    // ------------------------------------------------------------------

    /** 数一遍 9×9×9 的区域。 */
    public void validateStructure() {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        Direction facing = facing();
        int px = facing.getStepZ();
        int pz = -facing.getStepX();
        int radius = (SIZE - 1) / 2;

        int casing = 0;
        int coils = 0;
        int blankets = 0;
        int injectors = 0;
        int diagnostics = 0;
        int coolers = 0;
        int logic = 0;
        boolean complete = true;

        for (int depth = 0; depth < SIZE && complete; depth++) {
            for (int side = -radius; side <= radius && complete; side++) {
                for (int up = 0; up < SIZE && complete; up++) {
                    BlockPos pos = this.worldPosition.offset(
                            facing.getStepX() * depth + px * side, up, facing.getStepZ() * depth + pz * side);
                    if (!server.isLoaded(pos)) {
                        complete = false;
                        break;
                    }
                    if (pos.equals(this.worldPosition)) {
                        continue;
                    }
                    Block block = server.getBlockState(pos).getBlock();
                    if (block == ModBlocks.FUSION_RING_CASING.get()) {
                        casing++;
                    } else if (block == ModBlocks.SUPERCONDUCTING_COIL.get()) {
                        coils++;
                    } else if (block == ModBlocks.BREEDING_BLANKET.get()) {
                        blankets++;
                    } else if (block == ModBlocks.FUEL_INJECTOR_PORT.get()) {
                        injectors++;
                    } else if (block == ModBlocks.PLASMA_DIAGNOSTIC.get()) {
                        diagnostics++;
                    } else if (block == ModBlocks.CRYOGENIC_COOLER.get()) {
                        coolers++;
                    } else if (block == ModBlocks.FUSION_CONTROL_LOGIC.get()) {
                        logic++;
                    }
                }
            }
        }

        this.formed = complete && casing >= MIN_CASING && coils >= MIN_COILS && blankets >= MIN_BLANKETS
                && injectors >= MIN_INJECTORS && diagnostics >= MIN_DIAGNOSTICS && coolers >= MIN_COOLERS
                && logic >= MIN_LOGIC;
        this.casingCount = casing;
        this.coilCount = coils;
        this.blanketCount = blankets;
        this.injectorCount = injectors;
        this.diagnosticCount = diagnostics;
        this.coolerCount = coolers;
        this.logicCount = logic;
        setChanged();
    }

    private Direction facing() {
        BlockState state = getBlockState();
        if (state.hasProperty(TokamakControllerBlock.FACING)) {
            return state.getValue(TokamakControllerBlock.FACING);
        }
        return Direction.NORTH;
    }

    // ------------------------------------------------------------------
    // 给界面看的数
    // ------------------------------------------------------------------

    public boolean isFormed() {
        return this.formed;
    }

    public boolean isRunning() {
        return this.running;
    }

    public boolean isIgniting() {
        return this.igniting;
    }

    public int casingCount() {
        return this.casingCount;
    }

    public int coilCount() {
        return this.coilCount;
    }

    public int blanketCount() {
        return this.blanketCount;
    }

    public int injectorCount() {
        return this.injectorCount;
    }

    public int diagnosticCount() {
        return this.diagnosticCount;
    }

    public int coolerCount() {
        return this.coolerCount;
    }

    public int logicCount() {
        return this.logicCount;
    }

    public int fuelCount() {
        return this.fuelCount;
    }

    public int tritiumCount() {
        return this.tritiumCount;
    }

    public boolean breedBlocked() {
        return this.breedBlocked;
    }

    public int wirelessSent() {
        return this.wirelessSent;
    }

    public int portsInRange() {
        return this.portsInRange;
    }

    /** 点火预热进度 0~100。 */
    public int ignitionPercent() {
        if (!this.igniting) {
            return this.running ? 100 : 0;
        }
        return Math.round(100.0F * (STARTUP_TICKS - this.ignitionTicks) / STARTUP_TICKS);
    }

    /** 这一轮燃料烧到百分之几（0~100）。 */
    public int fuelPercent() {
        return Math.round(100.0F * Math.max(0, this.fuelTimer) / FUEL_INTERVAL);
    }

    public int statusCode() {
        return this.status;
    }

    // ------------------------------------------------------------------
    // EnergyMachineHost
    // ------------------------------------------------------------------

    @Override
    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    @Override
    public int getEnergyCapacity() {
        return ENERGY_CAPACITY;
    }

    @Override
    public int getStatus() {
        return this.status;
    }

    @Override
    public int getProgress() {
        return this.igniting ? (STARTUP_TICKS - this.ignitionTicks) : this.fuelTimer;
    }

    @Override
    public int getMaxProgress() {
        return this.igniting ? STARTUP_TICKS : FUEL_INTERVAL;
    }

    // ------------------------------------------------------------------
    // 菜单 / 物品槽
    // ------------------------------------------------------------------

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.tokamak_controller");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new TokamakMenu(containerId, playerInventory, this);
    }

    @Override
    public int getContainerSize() {
        return this.items.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        stack.limitSize(getMaxStackSize(stack));
        setChanged();
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot >= 0 && slot < FUEL_SLOTS && stack.is(ModItems.DT_FUEL_CELL.get());
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
        tag.putBoolean("Running", this.running);
        tag.putBoolean("Igniting", this.igniting);
        tag.putInt("IgnitionTicks", this.ignitionTicks);
        tag.putInt("FuelTimer", this.fuelTimer);
        tag.putInt("BreedTimer", this.breedTimer);
        ContainerHelper.saveAllItems(tag, this.items, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
        this.running = tag.getBoolean("Running");
        this.igniting = tag.getBoolean("Igniting");
        this.ignitionTicks = tag.getInt("IgnitionTicks");
        this.fuelTimer = tag.getInt("FuelTimer");
        this.breedTimer = tag.getInt("BreedTimer");
        ContainerHelper.loadAllItems(tag, this.items, registries);
    }

    /** 调试 / JEI 用：这台堆一轮氚增殖的说明数字。 */
    public static List<Integer> breedingStats() {
        List<Integer> stats = new ArrayList<>();
        stats.add(TRITIUM_PER_CYCLE);
        stats.add(TRITIUM_INTERVAL / 20);
        return stats;
    }
}
