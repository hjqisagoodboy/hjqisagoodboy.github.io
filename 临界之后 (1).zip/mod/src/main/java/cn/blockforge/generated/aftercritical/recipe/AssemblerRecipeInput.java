package cn.blockforge.generated.aftercritical.recipe;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeInput;

import java.util.List;

/**
 * 装配机的「原料快照」：把 7 个输入槽里的东西打包成一个整体交给配方去比对。
 *
 * <p>原版的配方输入只认「一个格子」，装配机要同时看好几格，所以自己做一个。
 */
public final class AssemblerRecipeInput implements RecipeInput {

    private final List<ItemStack> stacks;

    public AssemblerRecipeInput(List<ItemStack> stacks) {
        this.stacks = stacks;
    }

    @Override
    public ItemStack getItem(int index) {
        return index >= 0 && index < this.stacks.size() ? this.stacks.get(index) : ItemStack.EMPTY;
    }

    @Override
    public int size() {
        return this.stacks.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.stacks) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }
}
