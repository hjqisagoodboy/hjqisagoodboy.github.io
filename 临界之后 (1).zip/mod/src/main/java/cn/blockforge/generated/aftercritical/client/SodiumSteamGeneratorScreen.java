package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.SodiumSteamGeneratorMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;

/**
 * 钠-水蒸汽发生器的界面：左边能量条，右边水 / 乏蒸汽两根长条，底下四行读数。
 *
 * <p>它自己不烧东西：热量全靠快堆控制器递过来，所以状态里会明说「等待快堆热量」。
 */
public class SodiumSteamGeneratorScreen extends StatPanelScreen<SodiumSteamGeneratorMenu> {

    public SodiumSteamGeneratorScreen(SodiumSteamGeneratorMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected List<Line> statLines() {
        List<Line> lines = new ArrayList<>(SodiumSteamGeneratorMenu.STAT_LINES);
        lines.add(new Line(statusLine(), statusColor()));

        lines.add(new Line(Component.translatable("gui.aftercritical.sodium_steam.rate",
                this.menu.waterPerTick(), this.menu.outputFePerTick(), this.menu.heatPercent()), TEXT_DARK));

        lines.add(new Line(Component.translatable("gui.aftercritical.sodium_steam.tanks",
                this.menu.barAmount(0), this.menu.barAmount(1), this.menu.tankCapacity()), TEXT_DARK));

        lines.add(new Line(Component.translatable("gui.aftercritical.sodium_steam.hint"), TEXT_GRAY));
        return lines;
    }
}
