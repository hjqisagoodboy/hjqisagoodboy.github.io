package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.AssemblerT1BlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/** 装配机 T1 方块：LV，50 FE/t，用多原料配方做高级零件和机器。 */
public class AssemblerT1Block extends TickingMachineBlock {

    public AssemblerT1Block(Properties properties) {
        super(properties, "LV", "tooltip.aftercritical.energy_per_tick",
                AssemblerT1BlockEntity.ENERGY_PER_TICK, "block.aftercritical.assembler_t1.desc");
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(AssemblerT1Block::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AssemblerT1BlockEntity(pos, state);
    }
}
