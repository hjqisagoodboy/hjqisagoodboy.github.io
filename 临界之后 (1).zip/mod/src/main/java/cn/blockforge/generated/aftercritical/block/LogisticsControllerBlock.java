package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.LogisticsControllerBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 物流控制器的方块：右键开界面，物品管道能把货推进它的九格缓冲。
 *
 * <p>它把收到的货朝六个方向轮流分发，避免一条管道上「第一台机器吃撑、后面的饿着」。
 */
public class LogisticsControllerBlock extends TickingMachineBlock {

    public LogisticsControllerBlock(Properties properties) {
        super(properties, "MV", "tooltip.aftercritical.energy_per_tick",
                LogisticsControllerBlockEntity.ENERGY_PER_TICK,
                "block.aftercritical.logistics_controller.desc");
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(LogisticsControllerBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new LogisticsControllerBlockEntity(pos, state);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.aftercritical.logistics_controller.flow")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.logistics_controller.hint")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
