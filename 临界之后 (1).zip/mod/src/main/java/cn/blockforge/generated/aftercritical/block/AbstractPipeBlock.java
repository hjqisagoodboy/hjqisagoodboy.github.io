package cn.blockforge.generated.aftercritical.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.EnumMap;
import java.util.Map;

/**
 * 管道的公共骨架：物品管道、流体管道都长这样。
 *
 * <p>一根管道就是六个方向上的「接口」：哪边挨着同种管道、或者挨着能装东西的方块，
 * 那一面就伸出一小段接头；其它面缩在中间。连接状态用六个布尔属性记录：
 * {@code connected_north}、{@code connected_south}、{@code connected_east}、
 * {@code connected_west}、{@code connected_up}、{@code connected_down}，
 * 方块状态文件（blockstates/item_pipe.json 等）用 multipart 按这六个属性拼模型。
 *
 * <p>子类只需要回答一个问题：那一面的邻居算不算「能接上」。
 */
public abstract class AbstractPipeBlock extends BaseEntityBlock {

    public static final BooleanProperty CONNECTED_NORTH = BooleanProperty.create("connected_north");
    public static final BooleanProperty CONNECTED_EAST = BooleanProperty.create("connected_east");
    public static final BooleanProperty CONNECTED_SOUTH = BooleanProperty.create("connected_south");
    public static final BooleanProperty CONNECTED_WEST = BooleanProperty.create("connected_west");
    public static final BooleanProperty CONNECTED_UP = BooleanProperty.create("connected_up");
    public static final BooleanProperty CONNECTED_DOWN = BooleanProperty.create("connected_down");

    /** 「方向 → 对应的方块状态属性」，省得写六个 switch。 */
    public static final Map<Direction, BooleanProperty> CONNECTIONS = buildConnectionMap();

    /** 管道的碰撞箱：中间那一小段，玩家可以踩过去也能穿过去。 */
    private static final VoxelShape CORE_SHAPE = Block.box(5.0D, 5.0D, 5.0D, 11.0D, 11.0D, 11.0D);

    protected AbstractPipeBlock(Properties properties) {
        super(properties);
        BlockState state = this.stateDefinition.any();
        for (BooleanProperty property : CONNECTIONS.values()) {
            state = state.setValue(property, Boolean.FALSE);
        }
        this.registerDefaultState(state);
    }

    /**
     * 那一面的邻居算不算接上了。
     *
     * @param level           方块所在的世界（放方块时给的是 {@link LevelAccessor}，拿不到方块实体的能力接口）
     * @param selfPos         管道自己所在的坐标（判断「我」盖了什么章时要用）
     * @param neighbourPos    那一面的邻居坐标
     * @param faceOfNeighbour 邻居朝着我们的那一面
     */
    protected abstract boolean canConnectTo(LevelAccessor level, BlockPos selfPos, BlockPos neighbourPos,
                                            Direction faceOfNeighbour);

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(CONNECTED_NORTH, CONNECTED_EAST, CONNECTED_SOUTH, CONNECTED_WEST, CONNECTED_UP, CONNECTED_DOWN);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return CORE_SHAPE;
    }

    /** 放下时先算一遍六个方向。 */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return refreshConnections(context.getLevel(), context.getClickedPos(), defaultBlockState());
    }

    /**
     * 邻居变了（放下机器、拆掉管道……）就重算这一面的接头。
     *
     * <p>{@code direction} 是从本方块指向邻居的方向；邻居朝向我们的那面是它的反方向。
     */
    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighbourState,
                                     LevelAccessor level, BlockPos pos, BlockPos neighbourPos) {
        return state.setValue(CONNECTIONS.get(direction),
                canConnectTo(level, pos, neighbourPos, direction.getOpposite()));
    }

    /** 把六个方向重新算一遍，返回新的方块状态（不改世界，调用方自己决定要不要 setBlock）。 */
    public BlockState refreshConnections(LevelAccessor level, BlockPos pos, BlockState state) {
        BlockState result = state;
        for (Direction direction : Direction.values()) {
            result = result.setValue(CONNECTIONS.get(direction),
                    canConnectTo(level, pos, pos.relative(direction), direction.getOpposite()));
        }
        return result;
    }

    private static Map<Direction, BooleanProperty> buildConnectionMap() {
        Map<Direction, BooleanProperty> map = new EnumMap<>(Direction.class);
        map.put(Direction.NORTH, CONNECTED_NORTH);
        map.put(Direction.EAST, CONNECTED_EAST);
        map.put(Direction.SOUTH, CONNECTED_SOUTH);
        map.put(Direction.WEST, CONNECTED_WEST);
        map.put(Direction.UP, CONNECTED_UP);
        map.put(Direction.DOWN, CONNECTED_DOWN);
        return map;
    }
}
