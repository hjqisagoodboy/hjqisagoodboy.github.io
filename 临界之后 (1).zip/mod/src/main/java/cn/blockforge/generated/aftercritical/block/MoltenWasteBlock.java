package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.effect.RadiationAura;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FlowingFluid;

/**
 * 核熔废水方块：深绿色、发光的「脏岩浆」，核爆把岩浆掺脏之后剩下的东西。
 *
 * <p>它本身看着和岩浆一样亮（方块光 15，属性在 {@code ModBlocks} 里设），
 * 这里补上岩浆真正要命的两件事：
 * <ol>
 *   <li><b>灼烧</b>：贴着它的生物会被点着，并且按岩浆的量掉血。写法照着原版
 *       {@code Entity#lavaHurt}：只有身上没着火的时候才点一次火 + 结算一次伤害，
 *       剩下交给燃烧自己跳伤害，不会一 tick 掉四颗心；</li>
 *   <li><b>辐射</b>：和核废水一样，泡在里面持续沾染辐射，穿齐防护服免疫。</li>
 * </ol>
 *
 * <p>为什么不直接把它挂进原版岩浆的流体标签：1.21.1 里「是不是站在岩浆里」
 * （{@code Entity#isInLava}）认的是岩浆那种流体类型本身，不是标签，
 * 自己注册的流体挂标签也进不去，所以灼烧只能在这里自己写。
 */
public class MoltenWasteBlock extends LiquidBlock {

    /** 一次点着多少 tick（15 秒，跟原版岩浆一样）。 */
    private static final int FIRE_TICKS = 300;
    /** 一次结算多少伤害（原版岩浆也是 4 点 = 两颗心）。 */
    private static final float LAVA_DAMAGE = 4.0F;

    public MoltenWasteBlock(FlowingFluid fluid, Properties properties) {
        super(fluid, properties);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!level.isClientSide && entity instanceof LivingEntity living) {
            // 只有还没着火才点一次：一个方块里每 tick 会被调好几次，
            // 不加这个门槛就是一 tick 结算好几次伤害，玩家一碰就死
            if (living.getRemainingFireTicks() <= 0) {
                living.setRemainingFireTicks(FIRE_TICKS);
                living.hurt(level.damageSources().lava(), LAVA_DAMAGE);
            }
            RadiationAura.apply(living);
        }
        super.entityInside(state, level, pos, entity);
    }
}
