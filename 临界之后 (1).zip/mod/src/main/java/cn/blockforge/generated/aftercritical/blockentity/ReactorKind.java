package cn.blockforge.generated.aftercritical.blockentity;

import net.minecraft.network.chat.Component;

/**
 * 阶段 3 的两种多方块反应堆的「型号表」。
 *
 * <p>和 {@link ItemMachineKind} 一个套路：方块、方块实体、界面、JEI 都读这一份数字，
 * 不然后面改个需求就得满工程找「5」「7」「32」这些散落的常数。
 *
 * <p>结构怎么摆（两个都一样）：
 * <pre>
 *   控制器贴在结构「正面墙上、贴地那一排的正中间」，
 *   方块上写着它朝哪，结构就朝那个方向长：
 *   宽 = 边长（左右各伸出 (边长-1)/2 格）、深 = 边长、高 = 边长。
 *   整个立方体是实心的，材料数量按这个立方体里数。
 * </pre>
 */
public enum ReactorKind {

    /**
     * 次临界增殖装置：5×5×5，天然铀棒束放在次临界下增殖，永远不会爆。
     */
    SUBCRITICAL("subcritical", 5, 32, 16, 24, 0, 4, 0,
            "5×5×5", "container.aftercritical.subcritical_controller",
            "block.aftercritical.subcritical_controller.desc"),

    /**
     * 临界实验堆：7×7×7，用控制棒和硼酸把 k_eff 稳在 1.000 附近。
     */
    CRITICAL("critical", 7, 64, 32, 48, 8, 6, 4,
            "7×7×7", "container.aftercritical.critical_reactor_controller",
            "block.aftercritical.critical_reactor_controller.desc");

    /** 注册名里的那一段（subcritical / critical）。 */
    private final String id;
    /** 立方体边长。 */
    private final int size;
    /** 至少几块石墨慢化剂块。 */
    private final int minGraphite;
    /** 至少几块反射层块（铍）。 */
    private final int minReflector;
    /** 至少几块辐射屏蔽块（铅 + 混凝土）。 */
    private final int minShield;
    /** 至少几块玻璃。 */
    private final int minGlass;
    /** 至少几个中子探测器。 */
    private final int minDetectors;
    /** 控制棒端口数量（控制器自动开这么多）。 */
    private final int rodPorts;
    /** 给玩家看的尺寸文字，比如 5×5×5。 */
    private final String sizeText;
    private final String titleKey;
    private final String descriptionKey;

    ReactorKind(String id, int size, int minGraphite, int minReflector, int minShield, int minGlass,
                int minDetectors, int rodPorts, String sizeText, String titleKey, String descriptionKey) {
        this.id = id;
        this.size = size;
        this.minGraphite = minGraphite;
        this.minReflector = minReflector;
        this.minShield = minShield;
        this.minGlass = minGlass;
        this.minDetectors = minDetectors;
        this.rodPorts = rodPorts;
        this.sizeText = sizeText;
        this.titleKey = titleKey;
        this.descriptionKey = descriptionKey;
    }

    public String id() {
        return this.id;
    }

    public int size() {
        return this.size;
    }

    /** 立方体里一共多少格（5×5×5 = 125，7×7×7 = 343）。 */
    public int volume() {
        return this.size * this.size * this.size;
    }

    public int minGraphite() {
        return this.minGraphite;
    }

    public int minReflector() {
        return this.minReflector;
    }

    public int minShield() {
        return this.minShield;
    }

    public int minGlass() {
        return this.minGlass;
    }

    public int minDetectors() {
        return this.minDetectors;
    }

    public int rodPorts() {
        return this.rodPorts;
    }

    public String sizeText() {
        return this.sizeText;
    }

    public Component displayName() {
        return Component.translatable(this.titleKey);
    }

    public String titleKey() {
        return this.titleKey;
    }

    public String descriptionKey() {
        return this.descriptionKey;
    }
}
