package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.FuelPortBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

/**
 * 燃料端口：压水堆上插燃料组件的地方。
 *
 * <p>玩家手上拿着【LEU 燃料组件】右键，就会一支一支插进去（一个端口最多 8 支）；
 * 空手右键再把里面的东西取回背包。一个堆的所有燃料端口加起来要有 4~8 支燃料。
 */
public class FuelPortBlock extends TickablePartBlock {

    public static final String DESCRIPTION = "block.aftercritical.fuel_port.desc";

    public FuelPortBlock(Properties properties) {
        super(properties, DESCRIPTION);
    }

    @Override
    protected MapCodec<? extends net.minecraft.world.level.block.BaseEntityBlock> codec() {
        return simpleCodec(FuelPortBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new FuelPortBlockEntity(pos, state);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof FuelPortBlockEntity port) {
            // 手拿 LEU 组件：直接一支支插进去（快）；拿别的（或端口塞满了）：打开界面
            if (!port.insertFromHand(player, stack)) {
                player.openMenu(port, pos);
            }
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof FuelPortBlockEntity port) {
            player.openMenu(port, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
