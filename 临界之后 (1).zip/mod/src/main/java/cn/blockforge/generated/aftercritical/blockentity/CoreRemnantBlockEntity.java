package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.effect.RadiationAura;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * 堆芯残骸的方块实体：只干两件事——冒烟、周围散辐射。
 *
 * <p>熔毁的那一刻控制器把自己换成了残骸，然后喊 {@link #startMushroomCloud()}。
 * 大蘑菇云是 {@code MushroomCloud} 负责的（那是全服的粒子任务，跟这里无关），
 * 残骸自己只管「这堆炉渣还烫着」这种小烟：开场 10 秒喷得猛一点，
 * 之后就一直慢慢飘，让几十年后还看得出这里炸过。
 *
 * <p>烟是服务端发粒子包（{@code sendParticles}），所以专用服务器、多人游戏里也看得到。
 */
public class CoreRemnantBlockEntity extends BlockEntity implements TickableBlockEntity {

    /** 熔毁之后喷猛烟多久（200 tick = 10 秒）。 */
    public static final int SMOKE_BOOST_TICKS = 200;
    /** 残骸周围的辐射半径（格）：靠近就一直沾染。 */
    public static final double RADIATION_RADIUS = 6.0;
    /** 每 20 tick 查一次周围的玩家。 */
    private static final int RADIATION_INTERVAL = 20;
    /** 平时每 10 tick 飘一缕烟。 */
    private static final int SMOLDER_INTERVAL = 10;

    /** 还剩多少 tick 的「猛烟」。 */
    private int smokeBoost;
    private int smolderTimer;
    private int radiationTimer;

    public CoreRemnantBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CORE_REMNANT.get(), pos, state);
    }

    /** 熔毁时调用：接下来 10 秒喷得浓一点。 */
    public void startMushroomCloud() {
        this.smokeBoost = SMOKE_BOOST_TICKS;
        setChanged();
    }

    @Override
    public void serverTick() {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        if (++this.radiationTimer >= RADIATION_INTERVAL) {
            this.radiationTimer = 0;
            radiate(server);
        }
        if (this.smokeBoost > 0) {
            this.smokeBoost--;
            heavySmoke(server);
            if (this.smokeBoost == 0) {
                setChanged();
            }
            return;
        }
        if (++this.smolderTimer >= SMOLDER_INTERVAL) {
            this.smolderTimer = 0;
            wisp(server);
        }
    }

    /** 残骸一直在散辐射：6 格内的玩家每进一次就续一次沾染。 */
    private void radiate(ServerLevel server) {
        AABB area = new AABB(this.worldPosition).inflate(RADIATION_RADIUS);
        for (Player player : server.getEntitiesOfClass(Player.class, area)) {
            RadiationAura.apply(player);
        }
    }

    /** 开场那 10 秒：一柱浓烟往上冒，边上飘灰。 */
    private void heavySmoke(ServerLevel server) {
        RandomSource random = server.random;
        double x = this.worldPosition.getX() + 0.5;
        double y = this.worldPosition.getY() + 1.0;
        double z = this.worldPosition.getZ() + 0.5;
        for (int i = 0; i < 3; i++) {
            double height = y + 0.3 + random.nextDouble() * 9.0;
            server.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                    x + (random.nextDouble() - 0.5) * 1.2, height,
                    z + (random.nextDouble() - 0.5) * 1.2,
                    1, 0.15, 0.03, 0.15, 0.01);
        }
        if (this.smokeBoost % 4 == 0) {
            server.sendParticles(ParticleTypes.ASH,
                    x + (random.nextDouble() - 0.5) * 5.0,
                    y + 2.0 + random.nextDouble() * 4.0,
                    z + (random.nextDouble() - 0.5) * 5.0,
                    1, 0.4, 0.2, 0.4, 0.0);
        }
    }

    /** 平时：安安静静飘一缕，说明炉渣还热着。 */
    private void wisp(ServerLevel server) {
        RandomSource random = server.random;
        double x = this.worldPosition.getX() + 0.5;
        double y = this.worldPosition.getY() + 1.0;
        double z = this.worldPosition.getZ() + 0.5;
        server.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                x + (random.nextDouble() - 0.5) * 0.5, y,
                z + (random.nextDouble() - 0.5) * 0.5,
                1, 0.05, 0.0, 0.05, 0.0);
        if (random.nextInt(3) == 0) {
            server.sendParticles(ParticleTypes.ASH,
                    x + (random.nextDouble() - 0.5) * 3.0,
                    y + 1.5 + random.nextDouble() * 2.0,
                    z + (random.nextDouble() - 0.5) * 3.0,
                    1, 0.2, 0.1, 0.2, 0.0);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("SmokeBoost", this.smokeBoost);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.smokeBoost = Math.max(0, Math.min(SMOKE_BOOST_TICKS, tag.getInt("SmokeBoost")));
    }
}
