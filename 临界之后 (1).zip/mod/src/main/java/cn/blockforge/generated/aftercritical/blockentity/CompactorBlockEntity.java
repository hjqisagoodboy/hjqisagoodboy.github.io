package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.menu.CompactorMenu;
import cn.blockforge.generated.aftercritical.recipe.MachineRecipe;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModRecipes;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 压块机方块实体：MV，运行功率 100 FE/t，10,000 FE 缓存，<b>6 个输入槽 + 6 个输出槽</b>。
 *
 * <p>槽位安排：0~5 是输入槽，6~11 是输出槽。
 * 原料往输入槽里随便放（比如煤放 4 格、粘土球放 1 格），机器会把 6 个输入槽加起来算总数；
 * 产物从第一个空着的（或同一种还没堆满的）输出槽开始放，堆满了自动换下一个。
 *
 * <p>配方来自 {@link ModRecipes#COMPACTING}（JSON 在 {@code data/aftercritical/recipe/compacting/}），
 * 加工方式和其他矿机一样，只是更费电、更慢，换来的是一坨压得结结实实的成品。
 */
public class CompactorBlockEntity extends MachineBlockEntity {

    /** 输入槽数量。 */
    public static final int INPUT_SLOTS = 6;
    /** 输出槽数量。 */
    public static final int OUTPUT_SLOTS = 6;
    /** 第一个输入槽的槽号。 */
    public static final int FIRST_INPUT_SLOT = 0;
    /** 第一个输出槽的槽号（紧跟在输入槽后面）。 */
    public static final int FIRST_OUTPUT_SLOT = FIRST_INPUT_SLOT + INPUT_SLOTS;
    /** 机器自己的槽位总数（不含玩家背包）。 */
    public static final int SLOT_COUNT = INPUT_SLOTS + OUTPUT_SLOTS;

    /** 输入槽槽号：0、1、2、3、4、5。 */
    public static final int[] INPUT_SLOT_INDEXES = {0, 1, 2, 3, 4, 5};
    /** 输出槽槽号：6、7、8、9、10、11。 */
    public static final int[] OUTPUT_SLOT_INDEXES = {6, 7, 8, 9, 10, 11};

    /** 额定运行功率：100 FE/t（MV 档）。 */
    public static final int ENERGY_PER_TICK = 100;

    public CompactorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.COMPACTOR.get(), pos, state, SLOT_COUNT, ENERGY_PER_TICK);
    }

    @Override
    protected int[] inputSlots() {
        return INPUT_SLOT_INDEXES;
    }

    @Override
    protected int[] outputSlots() {
        return OUTPUT_SLOT_INDEXES;
    }

    @Override
    protected RecipeType<MachineRecipe> recipeType() {
        return ModRecipes.COMPACTING;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.compactor");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new CompactorMenu(containerId, playerInventory, this);
    }
}
