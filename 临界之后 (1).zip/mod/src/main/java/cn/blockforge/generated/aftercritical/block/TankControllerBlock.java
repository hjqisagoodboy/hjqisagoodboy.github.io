package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.TankControllerBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 储罐多方块的控制器：3×3×3 外壳的心脏。
 *
 * <p>外壳用铅块和玻璃围出 3×3×3（中间那格留空），控制器、流体输入口、流体输出口各一个，
 * 装在任意一面墙上。结构凑齐之后：
 * <ul>
 *   <li>右键控制器打开界面：看里面装了什么流体、装了多少 / 64,000 mB；</li>
 *   <li>界面上有罐子槽，通用流体罐放进去自动装 / 卸；拿着罐子右键方块也能直接灌或舀；</li>
 *   <li>流体输入口能被智能流体管道灌、输出口能被抽——管道得先用识别码盖上同一种流体。</li>
 * </ul>
 *
 * <p>结构不完整时罐子还在（不会漏东西），但两个口不工作，界面会写「结构不完整」。
 */
public class TankControllerBlock extends BaseEntityBlock {

    public TankControllerBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(TankControllerBlock::new);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new TankControllerBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                  BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return (tickLevel, pos, tickState, blockEntity) -> {
            if (blockEntity instanceof TankControllerBlockEntity controller) {
                controller.serverTick();
            }
        };
    }

    /**
     * 拿着流体容器右键：先灌 / 舀，不弹界面。
     *
     * <p>控制器本身没有对外暴露流体接口（接口长在两个口上），所以罐子的自动逻辑走不到这里，
     * 得由方块自己转交给方块实体。
     */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof TankControllerBlockEntity controller) {
            if (controller.handleFluidInteraction(player, hand)) {
                return ItemInteractionResult.sidedSuccess(false);
            }
            // 打开界面前先检查一遍外壳，玩家刚砌好就能看到「结构完整」
            controller.validateStructure();
            player.openMenu(controller, pos);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** 旁边有方块变了就立刻重新检查一遍外壳，不用等 2 秒的轮询。 */
    @Override
    protected void neighborChanged(BlockState state, Level level, BlockPos pos,
                                   net.minecraft.world.level.block.Block neighbor, BlockPos neighborPos,
                                   boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighbor, neighborPos, movedByPiston);
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof TankControllerBlockEntity controller) {
            controller.validateStructure();
        }
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MenuProvider provider) {
            player.openMenu(provider, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** 被拆掉时把罐子槽里的容器吐出来（里头的流体跟方块一起消失，提示里写了）。 */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide
                && level.getBlockEntity(pos) instanceof Container container) {
            Containers.dropContents(level, pos, container);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.tank_controller.capacity",
                TankControllerBlockEntity.CAPACITY).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.tank_controller.structure").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.tank_controller.ports").withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.tank_controller.warning").withStyle(ChatFormatting.DARK_GRAY));
    }
}
