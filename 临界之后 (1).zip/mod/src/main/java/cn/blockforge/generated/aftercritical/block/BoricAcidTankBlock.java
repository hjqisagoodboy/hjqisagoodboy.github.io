package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.BoricAcidTankBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 旧版硼酸储罐留下的「兼容壳」。
 *
 * <p>这个方块已经从物品、配方和创造栏里删掉了——新玩家拿不到它，存量的硼酸改由
 * {@link UniversalTankBlock 通用储罐} 装。这里保留方块本体和流体接口，
 * 只是为了让<b>老存档里已经摆着的硼酸储罐</b>还能正常加载，不会因为缺方块把区块读坏。
 *
 * <p>老罐子仍然能灌 / 舀 / 接管子，空手右键也能看还剩多少；挖掉之后不掉东西，
 * 想继续用就换通用储罐。
 */
public class BoricAcidTankBlock extends BaseEntityBlock {

    public BoricAcidTankBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(BoricAcidTankBlock::new);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new BoricAcidTankBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                  BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return (tickLevel, pos, tickState, blockEntity) -> {
            if (blockEntity instanceof BoricAcidTankBlockEntity tank) {
                tank.serverTick();
            }
        };
    }

    /** 手里拿着东西（通用流体罐）时，交给罐子自己走流体接口，不弹别的界面。 */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** 空手右键：在动作条上报一下还剩多少硼酸。 */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof BoricAcidTankBlockEntity tank) {
            player.displayClientMessage(Component.translatable("message.aftercritical.boric_acid_tank",
                    tank.amount(), BoricAcidTankBlockEntity.CAPACITY), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.boric_acid_tank.capacity",
                BoricAcidTankBlockEntity.CAPACITY).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.boric_acid_tank.hint")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
