package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.ItemMachineBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.ItemMachineKind;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 烧结炉 / 磨削机 / 焊接机共用的方块。
 *
 * <p>三台机器长得、用起来都一样（右键开界面），只有型号不同，
 * 所以共用一个方块类，具体是哪台由 {@link ItemMachineKind} 决定。
 */
public class ItemMachineBlock extends TickingMachineBlock {

    private final ItemMachineKind kind;

    public ItemMachineBlock(Properties properties, ItemMachineKind kind) {
        super(properties, kind.tier(), "tooltip.aftercritical.energy_per_tick", kind.energyPerTick(),
                kind.descriptionKey());
        this.kind = kind;
    }

    public ItemMachineKind kind() {
        return this.kind;
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(properties -> new ItemMachineBlock(properties, this.kind));
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ItemMachineBlockEntity(pos, state);
    }
}
