package cn.blockforge.generated.aftercritical.fluid;

import net.minecraft.world.level.material.Fluid;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

import javax.annotation.Nullable;

/**
 * 一组罐子怎么分工——一个罐只装一种液体，罐里装着什么它就归什么，罐一空位置立刻让出来。
 *
 * <p>进液罐、出液罐、级联控制器的产物罐都走这一份规矩。以前每台机器还各自记一张
 * 「这个罐认领了哪种液体」的小表，罐子空了认领还留着（或者过期要好几十秒），
 * 于是出现了玩家反馈的那几出戏：三个进液罐全变水、两个出液罐全变过氧化氢。
 * 现在认领表整个删掉了——<b>状态只存在罐子里</b>，罐子和表格就不可能对不上。
 *
 * <p>唯一的坚持是「同一种液体不拆两罐」：1 号罐装水装满了、2 号罐空着，
 * 水也<b>不会</b>溢到 2 号罐去。一旦溢过去，玩家接走 1 号罐之后 2 号罐还占着水，
 * 想换产线就得多抽一次——这正是玩家反馈过的毛病。宁可在罐满的时候把多出来的排掉，
 * 也不让同一种液体占两个罐。
 */
public final class TankGroup {

    private TankGroup() {}

    /** 这种液体该进第几号罐；整组罐子都被别的液体占着就返回 -1。 */
    public static int targetOf(FluidTank[] tanks, @Nullable Fluid fluid) {
        return targetOf(tanks, 0, tanks.length, fluid);
    }

    /**
     * 在 {@code [from, to)} 这一段罐子里挑一个给 {@code fluid}。
     *
     * <ol>
     *   <li>已经有这种液体的罐 —— 就是它。哪怕它满了也不换罐，
     *       换罐只会把同一锅液体拆成两罐，玩家又得抽两次；</li>
     *   <li>第一个空罐 —— 空罐不归谁，谁先来谁用；</li>
     *   <li>没有空罐 —— 返回 -1，调用方自己决定「排掉」还是「停机等」。</li>
     * </ol>
     */
    public static int targetOf(FluidTank[] tanks, int from, int to, @Nullable Fluid fluid) {
        if (fluid == null) {
            return -1;
        }
        int start = Math.max(0, from);
        int end = Math.min(to, tanks.length);
        for (int i = start; i < end; i++) {
            if (!tanks[i].isEmpty() && tanks[i].getFluid().getFluid() == fluid) {
                return i;
            }
        }
        for (int i = start; i < end; i++) {
            if (tanks[i].isEmpty()) {
                return i;
            }
        }
        return -1;
    }

    /** 往这组罐子里灌，只灌 {@link #targetOf} 选中的那一个罐。 */
    public static int insert(FluidTank[] tanks, FluidStack stack, boolean execute) {
        return insert(tanks, 0, tanks.length, stack, execute);
    }

    /**
     * 往 {@code [from, to)} 这一段罐子里灌。
     *
     * @return 实际灌进去多少 mB（没罐子能收、或者那一罐已经满了就返回 0）
     */
    public static int insert(FluidTank[] tanks, int from, int to, FluidStack stack, boolean execute) {
        if (stack.isEmpty()) {
            return 0;
        }
        int index = targetOf(tanks, from, to, stack.getFluid());
        if (index < 0) {
            return 0;
        }
        return tanks[index].fill(stack, execute ? IFluidHandler.FluidAction.EXECUTE
                : IFluidHandler.FluidAction.SIMULATE);
    }

    /** 同一组里好几个罐装着同一种液体：并到编号小的那个罐里。 */
    public static void mergeDuplicates(FluidTank[] tanks) {
        mergeDuplicates(tanks, 0, tanks.length);
    }

    /**
     * 旧存档修复：好几个罐各自装着同一种液体时，并到编号最小的那个罐里。
     *
     * <p>读档时调一次。以前「三个进液罐都是水」「两个出液罐都是过氧化氢」的存档，
     * 开一次世界就会自动变成「1 号一罐 + 后面的空罐」，腾出来的罐立刻能用。
     * 前面那个罐装不下的部分留在原罐里，<b>不丢液体</b>。
     *
     * @return 真的挪过东西就返回 true
     */
    public static boolean mergeDuplicates(FluidTank[] tanks, int from, int to) {
        int start = Math.max(0, from);
        int end = Math.min(to, tanks.length);
        boolean moved = false;
        for (int i = start; i < end; i++) {
            if (tanks[i].isEmpty()) {
                continue;
            }
            Fluid fluid = tanks[i].getFluid().getFluid();
            for (int j = i + 1; j < end; j++) {
                if (tanks[j].isEmpty() || tanks[j].getFluid().getFluid() != fluid) {
                    continue;
                }
                int space = tanks[i].getCapacity() - tanks[i].getFluidAmount();
                if (space <= 0) {
                    // 前面的罐装不下了，剩下的留在原罐里（宁可多占一个罐，也不丢液体）
                    break;
                }
                int wanted = Math.min(space, tanks[j].getFluidAmount());
                FluidStack drained = tanks[j].drain(wanted, IFluidHandler.FluidAction.EXECUTE);
                if (drained.isEmpty()) {
                    continue;
                }
                int filled = tanks[i].fill(drained, IFluidHandler.FluidAction.EXECUTE);
                if (filled > 0) {
                    moved = true;
                }
                if (filled < drained.getAmount()) {
                    // 理论上不会发生（上面按剩余空间取的量），保守起见把缺口还回去
                    tanks[j].fill(drained.copyWithAmount(drained.getAmount() - filled),
                            IFluidHandler.FluidAction.EXECUTE);
                }
            }
        }
        return moved;
    }
}
