package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.SodiumSteamGeneratorBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

/**
 * 钠-水蒸汽发生器：快堆的二回路换热 + 发电方块。
 *
 * <p>一格就能放，放在快堆的 7×7×7 壳体里（至少 2 台）。控制器会把热量递过来，
 * 它自己从旁边的管道抽水、吐乏蒸汽、往旁边的线缆送电——满热 3,000 FE/t。
 */
public class SodiumSteamGeneratorBlock extends TickingMachineBlock {

    public static final String DESCRIPTION = "block.aftercritical.sodium_steam_generator.desc";

    public SodiumSteamGeneratorBlock(Properties properties) {
        super(properties, "HV", "tooltip.aftercritical.output_per_tick",
                SodiumSteamGeneratorBlockEntity.OUTPUT_PER_TICK, DESCRIPTION);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(SodiumSteamGeneratorBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new SodiumSteamGeneratorBlockEntity(pos, state);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        // 手拿装水的通用流体罐：先灌水，再考虑开界面
        if (stack.getItem() instanceof cn.blockforge.generated.aftercritical.item.UniversalTankItem
                && !level.isClientSide
                && level.getBlockEntity(pos) instanceof SodiumSteamGeneratorBlockEntity generator
                && generator.fillWaterFromHand(player, hand)) {
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        return super.useItemOn(stack, state, level, pos, player, hand, hitResult);
    }
}
