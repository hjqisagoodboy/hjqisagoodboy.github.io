package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.UniversalTankBlockEntity;
import cn.blockforge.generated.aftercritical.fluid.TankContent;
import cn.blockforge.generated.aftercritical.item.FluidIdentifierItem;
import cn.blockforge.generated.aftercritical.registry.ModDataComponents;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.BlockHitResult;
import net.neoforged.neoforge.fluids.FluidStack;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 通用储罐：一个 32,000 mB 的方块罐子，什么流体都能装。
 *
 * <p>它取代了原来那个只能装硼酸的「硼酸储罐」。用法：
 * <ul>
 *   <li>拿绑好的流体识别码右键 → 绑定这种流体，以后只收它；</li>
 *   <li>空罐子直接接管道 → 第一次灌进来的是什么就自动绑什么；</li>
 *   <li>拿通用流体罐右键 → 灌 / 舀（这条路是罐子物品自己走的，走标准流体接口）；</li>
 *   <li>空手右键 → 在动作条上报还剩多少 mB、绑的是哪种流体；</li>
 *   <li>空手潜行右键 → 罐子空的时候解绑（想换一种流体时用）；</li>
 *   <li>挖掉 → 里面的流体和绑定跟着方块物品走，重新放下还在。</li>
 * </ul>
 */
public class UniversalTankBlock extends BaseEntityBlock {

    public UniversalTankBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(UniversalTankBlock::new);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new UniversalTankBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                  BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return (tickLevel, pos, tickState, blockEntity) -> {
            if (blockEntity instanceof UniversalTankBlockEntity tank) {
                tank.serverTick();
            }
        };
    }

    // ------------------------------------------------------------------
    // 右键：流体识别码给罐子盖章
    // ------------------------------------------------------------------

    /**
     * 拿流体识别码右键罐子 = 把罐子绑到识别码上那种流体。
     *
     * <p>识别码自己也会先试一次（{@code onItemUseFirst}）：罐子里要是有液体，
     * 它会把识别码反过来绑成罐子里那种——那是「从罐子读章」，不冲突。
     * 罐子是空的时候，识别码读不到东西，就轮到这里把识别码上的章盖到罐子上。
     */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!(stack.getItem() instanceof FluidIdentifierItem)) {
            // 别的物品（比如通用流体罐）交给它们自己的右键逻辑
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof UniversalTankBlockEntity tank) {
            Fluid bound = FluidIdentifierItem.boundFluid(stack);
            if (bound == null) {
                player.displayClientMessage(
                        Component.translatable("message.aftercritical.universal_tank.no_identifier"), true);
            } else if (!tank.bind(bound)) {
                player.displayClientMessage(Component.translatable(
                        "message.aftercritical.universal_tank.locked",
                        tank.stored().getHoverName()), true);
            } else {
                player.displayClientMessage(Component.translatable(
                        "message.aftercritical.universal_tank.bound",
                        new FluidStack(bound, 1).getHoverName()), true);
                level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME,
                        SoundSource.PLAYERS, 0.7F, 1.4F);
            }
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** 空手右键：报一下装了多少；潜行右键是「空的就解绑」。 */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof UniversalTankBlockEntity tank) {
            if (player.isShiftKeyDown()) {
                if (tank.boundFluid() == null) {
                    player.displayClientMessage(Component.translatable(
                            "message.aftercritical.universal_tank.not_bound"), true);
                } else if (!tank.bind(null)) {
                    player.displayClientMessage(Component.translatable(
                            "message.aftercritical.universal_tank.need_empty"), true);
                } else {
                    player.displayClientMessage(Component.translatable(
                            "message.aftercritical.universal_tank.unbound"), true);
                }
            } else {
                Fluid bound = tank.boundFluid();
                Component boundName = bound == null
                        ? Component.translatable("message.aftercritical.universal_tank.any_fluid")
                        : new FluidStack(bound, 1).getHoverName();
                player.displayClientMessage(Component.translatable(
                        "message.aftercritical.universal_tank.content",
                        tank.amount(), UniversalTankBlockEntity.CAPACITY, boundName), true);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    // ------------------------------------------------------------------
    // 挖掉时把内容和绑定带走，放下时装回来
    // ------------------------------------------------------------------

    /**
     * 掉落物上挂两种组件之一：
     * <ul>
     *   <li>罐子里有东西 → {@code FLUID}（种类 + mB），重新放下时原样装回去；</li>
     *   <li>罐子是空的但绑了流体 → {@code PRESET_FLUID}，只记住绑定。</li>
     * </ul>
     */
    @Override
    protected List<ItemStack> getDrops(BlockState state, LootParams.Builder params) {
        List<ItemStack> drops = super.getDrops(state, params);
        Object raw = params.getOptionalParameter(LootContextParams.BLOCK_ENTITY);
        if (!(raw instanceof UniversalTankBlockEntity tank)) {
            return drops;
        }
        FluidStack stored = tank.stored();
        TankContent content = TankContent.of(stored);
        Fluid bound = tank.boundFluid();
        for (ItemStack drop : drops) {
            if (!drop.is(asItem())) {
                continue;
            }
            if (content != null) {
                drop.set(ModDataComponents.FLUID.get(), content);
            } else if (bound != null) {
                drop.set(ModDataComponents.PRESET_FLUID.get(), new TankContent(bound.builtInRegistryHolder(), 1));
            }
        }
        return drops;
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer,
                            ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof UniversalTankBlockEntity tank) {
            tank.loadFromItem(stack);
        }
    }

    // ------------------------------------------------------------------
    // 物品提示
    // ------------------------------------------------------------------

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.universal_tank_block.capacity",
                UniversalTankBlockEntity.CAPACITY).withStyle(ChatFormatting.GRAY));

        TankContent content = stack.get(ModDataComponents.FLUID.get());
        if (content != null) {
            FluidStack stored = content.toStack();
            tooltip.add(Component.translatable("tooltip.aftercritical.universal_tank_block.content",
                            stored.getHoverName().getString(), stored.getAmount(),
                            UniversalTankBlockEntity.CAPACITY)
                    .withStyle(ChatFormatting.AQUA));
        }
        TankContent preset = stack.get(ModDataComponents.PRESET_FLUID.get());
        if (preset != null) {
            tooltip.add(Component.translatable("tooltip.aftercritical.universal_tank_block.bound",
                            new FluidStack(preset.fluidValue(), 1).getHoverName().getString())
                    .withStyle(ChatFormatting.AQUA));
        }
        tooltip.add(Component.translatable("tooltip.aftercritical.universal_tank_block.hint")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
