package cn.blockforge.generated.aftercritical.client.cloud;

import cn.blockforge.generated.aftercritical.AfterCritical;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import org.joml.Matrix4f;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 蘑菇云模型的「数据 + 骨骼变换」。
 *
 * <p>数据来自用户在 Blockbench 里做的 {@code 蘑菇云.bbmodel}，由
 * {@code tools/import_mushroom_cloud.py} 烘焙成 {@code assets/aftercritical/mushroom_cloud.json}：
 * 骨骼（group）名字和轴心、每个骨骼的三角形、三个动画（grow / idle / die）的关键帧。
 *
 * <p>为什么不用原版的实体模型系统：Java 版的实体模型（{@code ModelPart}）只会画轴对齐的
 * 方盒子，用户这份是自由网格（曲面），只能用顶点自己画。所以这里只负责「算出每个骨骼
 * 这一帧的矩阵」，真正往屏幕上画在 {@link MushroomCloudRenderer} 里。
 */
public final class MushroomCloudModel {

    private static final Logger LOGGER = LoggerFactory.getLogger("aftercritical/mushroom-cloud");

    /** 数据文件位置（客户端资源里）。 */
    private static final ResourceLocation DATA =
            ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "mushroom_cloud.json");

    /** 一根骨骼（Blockbench 的 group）：轴心 + 父骨骼。 */
    public record Bone(String name, float ox, float oy, float oz, int parent) {}

    /** 一块可以直接提交给显卡的三角形数据（同一个骨骼 + 同一张贴图）。 */
    public static final class Part {
        public final int bone;
        public final RenderType layer;
        /** 这张贴图在 {@link #layers()} 里的下标（渲染时按层分批，省得来回切渲染层）。 */
        public final int layerIndex;
        public final float[] verts;
        public final float[] uvs;
        public final int[] indices;

        private Part(int bone, RenderType layer, int layerIndex, float[] verts, float[] uvs, int[] indices) {
            this.bone = bone;
            this.layer = layer;
            this.layerIndex = layerIndex;
            this.verts = verts;
            this.uvs = uvs;
            this.indices = indices;
        }
    }

    /** 一根骨骼的动画：位置（格）、旋转（度）、缩放。都是 [时间, x, y, z, ...] 的拍平数组。 */
    public static final class Track {
        public final int bone;
        public final float[] pos;
        public final float[] rot;
        public final float[] scale;

        private Track(int bone, float[] pos, float[] rot, float[] scale) {
            this.bone = bone;
            this.pos = pos;
            this.rot = rot;
            this.scale = scale;
        }
    }

    /** 一段动画。 */
    public static final class Anim {
        public final String name;
        public final float length;
        public final boolean loop;
        public final Track[] byBone;

        private Anim(String name, float length, boolean loop, Track[] byBone) {
            this.name = name;
            this.length = length;
            this.loop = loop;
            this.byBone = byBone;
        }
    }

    private final Bone[] bones;
    private final Part[] parts;
    private final Map<String, Anim> anims;
    private final RenderType[] layers;

    private MushroomCloudModel(Bone[] bones, Part[] parts, Map<String, Anim> anims, RenderType[] layers) {
        this.bones = bones;
        this.parts = parts;
        this.anims = anims;
        this.layers = layers;
    }

    public Bone[] bones() {
        return this.bones;
    }

    public Part[] parts() {
        return this.parts;
    }

    /** 所有用到的渲染层（渲染完要挨个 flush）。 */
    public RenderType[] layers() {
        return this.layers;
    }

    public Anim anim(String name) {
        return this.anims.get(name);
    }

    /** 从客户端资源里读出来；资源没打包好会返回 null（渲染时就不画，游戏不崩）。 */
    public static MushroomCloudModel load(ResourceManager resources) {
        try {
            Optional<Resource> resource = resources.getResource(DATA);
            if (resource.isEmpty()) {
                LOGGER.error("找不到蘑菇云模型数据 {}，这朵云画不出来", DATA);
                return null;
            }
            try (Reader reader = new InputStreamReader(resource.get().open(), StandardCharsets.UTF_8)) {
                MushroomCloudModel parsed = parse(JsonParser.parseReader(reader).getAsJsonObject());
                // 一行日志：万一以后哪台机器上又画不出来，看日志就知道是「没读到」还是「读到了但没画」
                LOGGER.info("蘑菇云模型读入成功：{} 根骨骼、{} 个部件、{} 段动画",
                        parsed.bones.length, parsed.parts.length, parsed.anims.size());
                return parsed;
            }
        } catch (IOException | RuntimeException exception) {
            LOGGER.error("蘑菇云模型数据读取失败", exception);
            return null;
        }
    }

    private static MushroomCloudModel parse(JsonObject root) {
        JsonArray boneArray = root.getAsJsonArray("bones");
        Bone[] bones = new Bone[boneArray.size()];
        for (int i = 0; i < boneArray.size(); i++) {
            JsonObject bone = boneArray.get(i).getAsJsonObject();
            JsonArray origin = bone.getAsJsonArray("origin");
            bones[i] = new Bone(
                    bone.get("name").getAsString(),
                    origin.get(0).getAsFloat(), origin.get(1).getAsFloat(), origin.get(2).getAsFloat(),
                    bone.get("parent").getAsInt());
        }

        // 贴图 → 渲染层：一张贴图一个 RenderType，用发光半透明（不受光照影响、不挡后面的东西）
        JsonArray textureArray = root.getAsJsonArray("textures");
        Map<String, RenderType> layerByName = new LinkedHashMap<>();
        Map<String, Integer> layerIndexByName = new LinkedHashMap<>();
        for (JsonElement element : textureArray) {
            String name = element.getAsString();
            ResourceLocation texture = ResourceLocation.fromNamespaceAndPath(
                    AfterCritical.MOD_ID, "textures/entity/" + name + ".png");
            layerIndexByName.put(name, layerByName.size());
            layerByName.put(name, RenderType.entityTranslucentEmissive(texture));
        }

        JsonArray partArray = root.getAsJsonArray("parts");
        List<Part> parts = new ArrayList<>(partArray.size());
        for (JsonElement element : partArray) {
            JsonObject part = element.getAsJsonObject();
            String textureName = part.get("tex").getAsString();
            RenderType layer = layerByName.get(textureName);
            Integer layerIndex = layerIndexByName.get(textureName);
            if (layer == null || layerIndex == null) {
                continue;
            }
            parts.add(new Part(
                    part.get("bone").getAsInt(),
                    layer,
                    layerIndex,
                    floats(part.getAsJsonArray("v")),
                    floats(part.getAsJsonArray("uv")),
                    ints(part.getAsJsonArray("idx"))));
        }

        JsonArray animArray = root.getAsJsonArray("anims");
        Map<String, Anim> anims = new LinkedHashMap<>();
        for (JsonElement element : animArray) {
            JsonObject anim = element.getAsJsonObject();
            Track[] byBone = new Track[bones.length];
            for (JsonElement trackElement : anim.getAsJsonArray("tracks")) {
                JsonObject track = trackElement.getAsJsonObject();
                int bone = track.get("bone").getAsInt();
                if (bone < 0 || bone >= bones.length) {
                    continue;
                }
                byBone[bone] = new Track(bone,
                        track.has("pos") ? floats(track.getAsJsonArray("pos")) : null,
                        track.has("rot") ? floats(track.getAsJsonArray("rot")) : null,
                        track.has("scale") ? floats(track.getAsJsonArray("scale")) : null);
            }
            String name = anim.get("name").getAsString();
            anims.put(name, new Anim(name, anim.get("length").getAsFloat(),
                    "loop".equals(anim.get("loop").getAsString()), byBone));
        }

        return new MushroomCloudModel(bones, parts.toArray(new Part[0]), anims,
                layerByName.values().toArray(new RenderType[0]));
    }

    /**
     * 读一个浮点数组，顺手把嵌套的拍平。
     *
     * <p>几何（{@code v} / {@code uv}）是拍平的一维数组，但动画关键帧是「一行一个关键帧」
     * 的二维数组（{@code [[时间, x, y, z], [时间, x, y, z], ...]}）。两种都收，
     * 拍平之后正好是 {@link #sample} 要的 {@code [t, x, y, z, t, x, y, z, ...]}。
     *
     * <p>以前这里只认一维，读到关键帧就会抛异常，整个模型被判成「读不出来」，
     * 结果核爆完屏幕上啥都没有——数据本身一直是好的。
     */
    private static float[] floats(JsonArray array) {
        List<Float> values = new ArrayList<>(array.size());
        appendFloats(array, values);
        float[] out = new float[values.size()];
        for (int i = 0; i < out.length; i++) {
            out[i] = values.get(i);
        }
        return out;
    }

    /** 递归收集数字，遇到子数组就钻进去（未知形状的成员直接跳过，绝不抛异常）。 */
    private static void appendFloats(JsonArray array, List<Float> out) {
        for (JsonElement element : array) {
            if (element.isJsonArray()) {
                appendFloats(element.getAsJsonArray(), out);
            } else if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
                out.add(element.getAsFloat());
            }
        }
    }

    private static int[] ints(JsonArray array) {
        int[] values = new int[array.size()];
        for (int i = 0; i < values.length; i++) {
            values[i] = array.get(i).getAsInt();
        }
        return values;
    }

    /**
     * 这一帧每根骨骼的矩阵：绕自己的轴心缩放、旋转，再沿父骨骼链叠上去。
     *
     * <p>和 Blockbench 里预览的算法一致；空动画（还没播）就是原样。
     */
    public Matrix4f[] boneMatrices(Anim anim, float time) {
        Matrix4f[] out = new Matrix4f[this.bones.length];
        float[] pos = new float[3];
        float[] rot = new float[3];
        float[] scale = new float[3];
        for (int i = 0; i < this.bones.length; i++) {
            Bone bone = this.bones[i];
            Track track = anim == null ? null : anim.byBone[i];
            pos[0] = pos[1] = pos[2] = 0.0F;
            rot[0] = rot[1] = rot[2] = 0.0F;
            scale[0] = scale[1] = scale[2] = 1.0F;
            if (track != null) {
                sample(track.pos, time, pos);
                sample(track.rot, time, rot);
                sample(track.scale, time, scale);
            }
            Matrix4f local = new Matrix4f()
                    .translate(bone.ox + pos[0], bone.oy + pos[1], bone.oz + pos[2])
                    .rotateZ((float) Math.toRadians(rot[2]))
                    .rotateY((float) Math.toRadians(rot[1]))
                    .rotateX((float) Math.toRadians(rot[0]))
                    .scale(scale[0], scale[1], scale[2])
                    .translate(-bone.ox, -bone.oy, -bone.oz);
            out[i] = bone.parent >= 0 ? new Matrix4f(out[bone.parent]).mul(local) : local;
        }
        return out;
    }

    /** 在关键帧之间线性插值；越界就夹到首/尾那一帧。 */
    private static void sample(float[] track, float time, float[] out) {
        if (track == null || track.length < 4) {
            return;
        }
        int count = track.length / 4;
        if (time <= track[0]) {
            out[0] = track[1];
            out[1] = track[2];
            out[2] = track[3];
            return;
        }
        for (int i = 1; i < count; i++) {
            float t0 = track[i * 4];
            if (time < t0) {
                int p = (i - 1) * 4;
                float span = t0 - track[p];
                float k = span <= 0.0F ? 0.0F : (time - track[p]) / span;
                out[0] = track[p + 1] + (track[i * 4 + 1] - track[p + 1]) * k;
                out[1] = track[p + 2] + (track[i * 4 + 2] - track[p + 2]) * k;
                out[2] = track[p + 3] + (track[i * 4 + 3] - track[p + 3]) * k;
                return;
            }
        }
        int last = (count - 1) * 4;
        out[0] = track[last + 1];
        out[1] = track[last + 2];
        out[2] = track[last + 3];
    }
}
