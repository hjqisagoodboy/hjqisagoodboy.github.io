package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

/**
 * 旧版硼酸储罐的方块实体（兼容壳，只为老存档保留）。
 *
 * <p>这个方块已经没有物品了，新玩家拿不到；<b>老世界里已经摆着的</b>硼酸储罐靠它继续工作：
 * 对外还是一个标准的流体接口，管道和通用流体罐都能直接接。
 */
public class BoricAcidTankBlockEntity extends BlockEntity implements TickableBlockEntity {

    /** 容量：1 桶。 */
    public static final int CAPACITY = 1000;

    private final FluidTank tank = new FluidTank(CAPACITY) {
        @Override
        public boolean isFluidValid(FluidStack stack) {
            return stack.getFluid() == ModFluids.BORIC_ACID.source.get();
        }
    };

    private final IFluidHandler fluidHandler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return 1;
        }

        @Override
        public FluidStack getFluidInTank(int index) {
            return BoricAcidTankBlockEntity.this.tank.getFluid();
        }

        @Override
        public int getTankCapacity(int index) {
            return CAPACITY;
        }

        @Override
        public boolean isFluidValid(int index, FluidStack stack) {
            return stack.getFluid() == ModFluids.BORIC_ACID.source.get();
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            int filled = BoricAcidTankBlockEntity.this.tank.fill(resource, action);
            if (filled > 0 && action.execute()) {
                setChanged();
            }
            return filled;
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            FluidStack drained = BoricAcidTankBlockEntity.this.tank.drain(resource, action);
            if (!drained.isEmpty() && action.execute()) {
                setChanged();
            }
            return drained;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            FluidStack drained = BoricAcidTankBlockEntity.this.tank.drain(maxDrain, action);
            if (!drained.isEmpty() && action.execute()) {
                setChanged();
            }
            return drained;
        }
    };

    public BoricAcidTankBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.BORIC_ACID_TANK.get(), pos, state);
    }

    public IFluidHandler getFluidHandler() {
        return this.fluidHandler;
    }

    public int amount() {
        return this.tank.getFluidAmount();
    }

    public FluidTank tank() {
        return this.tank;
    }

    /** 这个罐子没有每 tick 的活，接口留着是为了跟别的方块一样的写法。 */
    @Override
    public void serverTick() {
        // 什么都不用做：进出全靠外部的管道和罐子
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Tank", this.tank.writeToNBT(registries, new CompoundTag()));
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.tank.readFromNBT(registries, tag.getCompound("Tank"));
    }
}
