package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.HotCellArmMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * 热室机械臂的界面：面板、能量条、箭头全部继承自 {@link AbstractMachineScreen}，
 * 底下多写一句「只能放冷却的靶材」的提示。
 */
public class HotCellArmScreen extends AbstractMachineScreen<HotCellArmMenu> {

    public HotCellArmScreen(HotCellArmMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected Component hintLine() {
        return Component.translatable("gui.aftercritical.hot_cell_arm.hint");
    }
}
