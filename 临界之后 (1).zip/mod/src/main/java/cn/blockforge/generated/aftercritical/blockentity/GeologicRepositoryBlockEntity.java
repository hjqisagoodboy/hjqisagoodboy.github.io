package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * 地质处置库的方块实体：只记一件事——已经封存了多少块固化玻璃。
 *
 * <p>没有槽位、没有界面，塞进去就再也拿不出来，这也是路线 A 的代价：
 * 安全、干净、但没有半点收益。
 */
public class GeologicRepositoryBlockEntity extends BlockEntity {

    private int stored;

    public GeologicRepositoryBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.GEOLOGIC_REPOSITORY.get(), pos, state);
    }

    /** 封存 {@code amount} 块，返回真正收下的数量。 */
    public int store(int amount) {
        if (amount <= 0) {
            return 0;
        }
        this.stored += amount;
        setChanged();
        return amount;
    }

    public int stored() {
        return this.stored;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Stored", this.stored);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.stored = tag.getInt("Stored");
    }
}
