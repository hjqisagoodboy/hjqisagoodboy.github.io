package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.blockentity.GeologicRepositoryBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.CriterionProgress;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 地质处置库：结局路线 A 的「深埋点」。
 *
 * <p>拿【固化玻璃】右键，玻璃就被封进这座混凝土 + 铅 + 钢的库房里，再也拿不出来——
 * 换来的是一劳永逸的安全：不会泄漏、不用清洗、也不会有任何副作用。
 * 空手右键可以看已经封存了多少块。
 *
 * <p>结局成就「结局·深埋」要求玻璃固化炉的两条工艺（废液路线、同位素路线）各烧出过一次固化玻璃，
 * 再把玻璃封进来；条件没齐时封存会直接在聊天栏里说清楚还差哪条。
 *
 * <p>路线 B（离心萃取器回收短寿命同位素）能拿铂族金属和稀有同位素，
 * 但每次都会在周围留下一片辐射污染，得拿双氧水擦干净。
 */
public class GeologicRepositoryBlock extends BaseEntityBlock {

    public static final String DESCRIPTION = "block.aftercritical.geologic_repository.desc";

    /** 结局成就的编号，以及成就里「固化玻璃两条工艺」两个条件的名字；必须和 ending_burial.json 一字不差。 */
    private static final String ENDING_BURIAL_ID = "ending_burial";
    private static final String CRITERION_ISOTOPE = "vitrify_isotope";
    private static final String CRITERION_WASTE = "vitrify_waste";

    public GeologicRepositoryBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(GeologicRepositoryBlock::new);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new GeologicRepositoryBlockEntity(pos, state);
    }

    /** 手拿固化玻璃：整叠封存进去。 */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!stack.is(ModItems.SOLIDIFIED_GLASS.get())) {
            return super.useItemOn(stack, state, level, pos, player, hand, hitResult);
        }
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof GeologicRepositoryBlockEntity repository) {
            int stored = repository.store(stack.getCount());
            stack.shrink(stored);
            level.playSound(null, pos, SoundEvents.STONE_PLACE, SoundSource.BLOCKS, 0.8F, 0.7F);
            player.displayClientMessage(Component.translatable("gui.aftercritical.repository.stored",
                    repository.stored(), stored).withStyle(ChatFormatting.GRAY), true);
            // 成就「深埋」：结局 A 的收尾动作
            if (stored > 0) {
                ModAdvancementTriggers.fire(player, ModAdvancementTriggers.BURIAL);
                // 两条固化玻璃工艺没各做一次的话，成就还不会亮——这里直接告诉玩家差哪条
                hintMissingVitrification(level, player);
            }
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /**
     * 封存之后如果结局成就还没亮，把「差哪条工艺」直接说给玩家听。
     *
     * <p>成就本身是三条条件同时满足才算：废液路线烧过一次、同位素路线烧过一次、把玻璃封进来。
     * 前两条分别记在成就的两个条件里（见 ending_burial.json），这里只读进度、不改进度。
     */
    private static void hintMissingVitrification(Level level, Player player) {
        if (!(level instanceof ServerLevel server) || !(player instanceof ServerPlayer serverPlayer)) {
            return;
        }
        AdvancementHolder holder = server.getServer().getAdvancements()
                .get(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, ENDING_BURIAL_ID));
        if (holder == null) {
            return;
        }
        AdvancementProgress progress = serverPlayer.getAdvancements().getOrStartProgress(holder);
        // 刚 fire 过事件，三条都齐的玩家这时候已经拿到了，不用再念叨
        if (progress.isDone()) {
            return;
        }
        boolean isotope = isCriterionDone(progress, CRITERION_ISOTOPE);
        boolean waste = isCriterionDone(progress, CRITERION_WASTE);
        String key;
        if (!isotope && !waste) {
            key = "gui.aftercritical.repository.needs_both_routes";
        } else if (!waste) {
            key = "gui.aftercritical.repository.needs_waste_route";
        } else {
            key = "gui.aftercritical.repository.needs_isotope_route";
        }
        serverPlayer.sendSystemMessage(Component.translatable(key).withStyle(ChatFormatting.YELLOW));
    }

    /** 成就里某个条件打勾了没有；条件名在 ending_burial.json 里写着。 */
    private static boolean isCriterionDone(AdvancementProgress progress, String criterion) {
        CriterionProgress criterionProgress = progress.getCriterion(criterion);
        return criterionProgress != null && criterionProgress.isDone();
    }

    /** 空手右键：看已经封存多少块。 */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof GeologicRepositoryBlockEntity repository) {
            player.displayClientMessage(Component.translatable("gui.aftercritical.repository.count",
                    repository.stored()).withStyle(ChatFormatting.GRAY), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        tooltip.add(Component.translatable(DESCRIPTION).withStyle(ChatFormatting.GRAY));
    }
}
