package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.FuelPortBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 燃料端口的界面：8 个燃料格 + 一条燃烧进度箭头。
 *
 * <p>这是玩家唯一能「看见」乏燃料是怎么来的地方：箭杆里灌的是当前这一支 LEU 的燃烧进度，
 * 由压水堆控制器每 tick 推过来。烧满了箭头就灌满，端口里的燃料会原地变成乏燃料组件，
 * 关掉界面就能把它取走送进冷却池。
 *
 * <p>这个窗口没有电、没有流体，所以左边的能量条和右边的流体长条都不会画出来。
 */
public class FuelPortMenu extends AbstractMachineMenu {

    /** 8 个燃料格摆成 4 列 × 2 行。 */
    public static final int SLOT_X = MachineLayout.ITEM_X;
    public static final int SLOT_Y = MachineLayout.ITEM_Y;
    public static final int COLUMNS = 4;
    public static final int ROWS = 2;

    /** 进度箭头的位置（在燃料格下面）。 */
    public static final int ARROW_X = SLOT_X;
    public static final int ARROW_Y = SLOT_Y + ROWS * MachineLayout.ITEM_STEP + 8;
    public static final int ARROW_LENGTH = 84;

    private static final int DATA_BURN = 0;
    private static final int DATA_BURN_MAX = 1;
    private static final int DATA_FUEL = 2;

    @Nullable
    private final FuelPortBlockEntity port;

    private int burn;
    private int burnMax;
    private int fuel;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case DATA_BURN -> burn;
                case DATA_BURN_MAX -> burnMax;
                case DATA_FUEL -> fuel;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case DATA_BURN -> burn = value;
                case DATA_BURN_MAX -> burnMax = value;
                case DATA_FUEL -> fuel = value;
                default -> {
                }
            }
        }

        @Override
        public int getCount() {
            return 3;
        }
    };

    /** 服务端用。 */
    public FuelPortMenu(int containerId, Inventory playerInventory, FuelPortBlockEntity port) {
        this(ModMenus.FUEL_PORT.get(), containerId, playerInventory, port, port);
    }

    private FuelPortMenu(net.minecraft.world.inventory.MenuType<?> type, int containerId,
                         Inventory playerInventory, Container container, @Nullable FuelPortBlockEntity port) {
        super(type, containerId, playerInventory, FuelPortBlockEntity.SLOTS, null, 0);
        this.port = port;
        for (int row = 0; row < ROWS; row++) {
            for (int column = 0; column < COLUMNS; column++) {
                int index = row * COLUMNS + column;
                this.addSlot(new FuelSlot(container, index,
                        SLOT_X + column * MachineLayout.ITEM_STEP,
                        SLOT_Y + row * MachineLayout.ITEM_STEP));
            }
        }
        this.addPlayerInventory(playerInventory);
        this.addDataSlots(this.data);
    }

    /** 客户端收到「打开菜单」的包后调用。 */
    public static FuelPortMenu fromNetwork(int containerId, Inventory playerInventory,
                                           RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof FuelPortBlockEntity port) {
            return new FuelPortMenu(ModMenus.FUEL_PORT.get(), containerId, playerInventory, port, port);
        }
        return new FuelPortMenu(ModMenus.FUEL_PORT.get(), containerId, playerInventory,
                new SimpleContainer(FuelPortBlockEntity.SLOTS), null);
    }

    @Override
    public void broadcastChanges() {
        if (this.port != null) {
            this.burn = this.port.burnProgress();
            this.burnMax = this.port.burnMax();
            this.fuel = this.port.refreshFuelCount();
        }
        super.broadcastChanges();
    }

    /** 这个端口接上压水堆了吗。 */
    public boolean isLinked() {
        return this.burnMax > 0;
    }

    /** 里面还有几支能烧的燃料。 */
    public int fuelCount() {
        return this.fuel;
    }

    /** 进度条画的是「这一支燃料烧了多少」，所以借基因的箭头来用。 */
    @Override
    public int getProgress() {
        return this.burn;
    }

    @Override
    public int getMaxProgress() {
        return this.burnMax;
    }

    @Override
    public MachineLayout.Arrow arrowGeometry() {
        return new MachineLayout.Arrow(ARROW_X, ARROW_Y, ARROW_LENGTH);
    }

    @Override
    public boolean stillValid(net.minecraft.world.entity.player.Player player) {
        return this.port == null || this.port.stillValid(player);
    }

    /** 燃料格：只收 LEU 燃料组件；里面的乏燃料、熔毁燃料棒随时可以拿走。 */
    public static class FuelSlot extends Slot {

        public FuelSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.is(ModItems.LEU_FUEL_ASSEMBLY.get());
        }
    }
}
