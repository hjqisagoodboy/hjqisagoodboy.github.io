package cn.blockforge.generated.aftercritical.registry;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.block.AbstractPipeBlock;
import cn.blockforge.generated.aftercritical.block.CableBlock;
import cn.blockforge.generated.aftercritical.block.TransformerBlock;
import cn.blockforge.generated.aftercritical.block.UraniumOreBlock;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * 创造模式物品栏：五个标签页，每一页里的东西还按用途分了小组。
 *
 * <p>分类是<b>全自动</b>的：不写死「哪个物品放第几格」，而是每次打开物品栏时把
 * {@link ModItems#ITEMS} 里登记过的物品挨个问一遍「你属于哪一类、哪一组」，
 * 再按小组顺序摆好。以后加新物品（往 ModItems 里注册一个就行）会自动出现，
 * 名字能对上规则就进对应小组，对不上就落到这一页的最后。
 *
 * <p>排序靠的是 {@link #groupIndex}：先算出一个「小组编号」，再按编号稳定排序，
 * 所以同一组里保持注册顺序（源码里写的顺序）。
 */
public final class ModCreativeTabs {

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AfterCritical.MOD_ID);

    /**
     * 物品栏的五个分类。
     *
     * <p>每个分类一个语言键 {@code itemGroup.aftercritical.<id>}，中英文都在 lang 文件里。
     */
    public enum Category {
        /** 矿石、金属块、反应堆结构方块——「往世界里摆的东西」。 */
        WORLD("world"),
        /** 单方块机器：矿机、装配机、化工厂、发电机、辐照设备。 */
        MACHINES("machines"),
        /** 反应堆与核：多方块控制器、探测器、核燃料、靶材、同位素。 */
        REACTORS("reactors"),
        /** 线缆、管道、变压器、储罐、流体容器。 */
        LOGISTICS("logistics"),
        /** 板材、锭、粉、零件、模具、工具。 */
        MATERIALS("materials"),
        /** 武器：六颗核弹、模块化组件、起爆器。 */
        WEAPONS("weapons");

        /** 分类编号（注册名和语言键都用它）。 */
        public final String id;

        Category(String id) {
            this.id = id;
        }

        String titleKey() {
            return "itemGroup.aftercritical." + this.id;
        }
    }

    /** 矿石与世界。 */
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> WORLD = register(
            Category.WORLD, () -> new ItemStack(ModBlocks.URANIUM_ORE.get()));

    /** 机器。 */
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MACHINES = register(
            Category.MACHINES, () -> new ItemStack(ModBlocks.CRUSHER.get()));

    /** 反应堆与核。 */
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> REACTORS = register(
            Category.REACTORS, () -> new ItemStack(ModBlocks.CRITICAL_REACTOR_CONTROLLER.get()));

    /** 物流与流体。 */
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> LOGISTICS = register(
            Category.LOGISTICS, () -> new ItemStack(ModItems.UNIVERSAL_FLUID_TANK.get()));

    /** 材料与零件。 */
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MATERIALS = register(
            Category.MATERIALS, () -> new ItemStack(ModItems.IRON_PLATE.get()));

    /** 武器：按当量从小到大排的六颗核弹 + 组件 + 起爆器。 */
    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> WEAPONS = register(
            Category.WEAPONS, () -> new ItemStack(ModItems.NUKE_TSAR.get()));

    private ModCreativeTabs() {}

    /** 建一个标签页：图标 + 「把本类的物品都吐出来」的生成器。 */
    private static DeferredHolder<CreativeModeTab, CreativeModeTab> register(Category category,
                                                                            Supplier<ItemStack> icon) {
        return TABS.register(category.id, () -> CreativeModeTab.builder()
                .title(Component.translatable(category.titleKey()))
                .icon(icon)
                .displayItems((parameters, output) -> fill(output, category))
                .build());
    }

    // ------------------------------------------------------------------
    // 每页的小组
    // ------------------------------------------------------------------

    /** 一条小组规则：名字叫 {@code name}（调试用），路径满足 {@code test} 的进这一组。 */
    private record Group(String name, Predicate<String> test) {

        boolean matches(String path) {
            return this.test.test(path);
        }
    }

    /**
     * 每一页的小组顺序。
     *
     * <p>写在最前面的先出现；一条都不匹配的物品落到这一页最末尾的「其它」里。
     * 想让某样东西换个位置，改这里的顺序或者加一条规则就行。
     */
    private static final Map<Category, List<Group>> GROUPS = buildGroups();

    private static Map<Category, List<Group>> buildGroups() {
        Map<Category, List<Group>> map = new LinkedHashMap<>();

        // ---- 矿石与世界 ----
        map.put(Category.WORLD, List.of(
                new Group("ores", path -> path.endsWith("_ore")),
                new Group("storage blocks", oneOf("graphite_block", "steel_block", "lead_block")),
                new Group("reactor building blocks",
                        oneOf("graphite_moderator", "beryllium_reflector", "radiation_shield",
                                "contaminated_soil")),
                // 核爆之后留下的东西：焦土、辐射焦土、烧结砂、焦木、辐射尘
                new Group("nuclear wasteland", oneOf("scorched_earth", "radioactive_scorched_earth",
                        "scorched_sand", "charred_log", "radioactive_dust")),
                new Group("pwr hull",
                        oneOf("reactor_pressure_vessel", "cooling_tower")),
                // 阶段 7：托卡马克 / 嬗变器的结构方块
                new Group("fusion hull", oneOf("fusion_ring_casing", "superconducting_coil",
                        "breeding_blanket", "fuel_injector_port", "plasma_diagnostic",
                        "cryogenic_cooler", "fusion_control_logic", "transmutator_casing"))));

        // ---- 机器（按「你大致什么时候会造它」排）----
        map.put(Category.MACHINES, List.of(
                new Group("grinding line", oneOf("crusher", "ball_mill", "grinding_machine")),
                new Group("forming line",
                        oneOf("forging_press", "compactor", "welding_machine", "sintering_furnace")),
                new Group("assemblers", oneOf("assembler_t1", "assembler_t2", "assembler_t3")),
                new Group("chemical plants", oneOf("electrolyzer", "chemical_plant", "air_separator",
                        "groundwater_pump",
                        "leaching_tank", "precipitation_tank", "drying_oven", "converter",
                        "fluorination_reactor", "gas_centrifuge", "hydrolysis_reactor")),
                new Group("power", oneOf("combustion_generator", "fuel_rod_generator", "battery_lv", "battery_mv",
                        "giant_battery")),
                new Group("steam power", oneOf("steam_generator", "condenser")),
                new Group("irradiation", oneOf("gamma_irradiator", "irradiation_pool")),
                // 阶段 6：乏燃料后处理线，按工艺流程排：冷却 → 剪切 → 溶解 → 萃取 → 离心 → 固化
                new Group("reprocessing line",
                        oneOf("spent_fuel_pool", "shearing_machine", "dissolution_tank",
                                "extraction_column", "centrifugal_extractor",
                                "vitrification_furnace"))));

        // ---- 反应堆与核 ----
        map.put(Category.REACTORS, List.of(
                // 阶段 7：聚变与终局机器放在最前面
                new Group("fusion machines", oneOf("tokamak_controller", "transmutator_controller",
                        "energy_port", "geologic_repository")),
                new Group("controllers", path -> path.endsWith("_controller")
                        && !path.equals("logistics_controller") && !path.equals("tank_controller")
                        && !path.equals("cascade_controller")),
                new Group("reactor parts", oneOf("neutron_detector", "neutron_flux_recorder",
                        "critical_alarm", "irradiation_channel", "hot_cell_arm",
                        "fuel_port", "control_rod_port", "coolant_port",
                        "fast_neutron_detector", "sodium_steam_generator",
                        "control_rod_driver", "core_remnant")),
                new Group("nuclear fuel", oneOf("neutron_source", "control_rod", "fuel_rod",
                        "sealed_fuel_rod", "leu_fuel_assembly", "melted_fuel_rod",
                        "natural_uranium_rod", "natural_uranium_rod_bundle", "coal_fuel_rod",
                        "radium_source")),
                // 阶段 6：MOX 燃料单独一组（芯块坯 → 烧结芯块 → 棒 → 组件）
                new Group("mox fuel", path -> path.startsWith("mox_")),
                new Group("targets", path -> path.endsWith("_target")
                        && !path.startsWith("cooled_")),
                new Group("irradiated targets", path -> path.startsWith("irradiated_")),
                new Group("cooled targets", path -> path.startsWith("cooled_")
                        && !path.endsWith("_assembly")),
                // 阶段 6：乏燃料与后处理产物
                new Group("reprocessed fuel", oneOf("spent_fuel_assembly", "cooled_spent_fuel_assembly",
                        "spent_fuel_fragment", "empty_fuel_frame", "shell_slag",
                        "recovered_uranium", "solidified_glass",
                        "fast_spent_assembly", "cooled_fast_spent_assembly")),
                new Group("isotopes", oneOf("cobalt60_source", "cesium137", "strontium90",
                        "phosphorus32", "plutonium239", "actinides", "lithium6", "tritium")),
                // 阶段 7：聚变燃料与终局产物
                new Group("fusion fuel", oneOf("fusion_fuel_cell", "deuterium_cell", "tritium_cell",
                        "dt_fuel_cell", "lithium7")),
                new Group("endgame", oneOf("short_lived_isotope", "platinum_group_metal",
                        "rare_isotope"))));

        // ---- 物流与流体 ----
        map.put(Category.LOGISTICS, List.of(
                new Group("cables", path -> path.endsWith("_cable")
                        && !path.equals("mv_cable_core")),
                new Group("transformers", path -> path.startsWith("transformer")),
                new Group("pipes and ducts",
                        oneOf("item_pipe", "smart_fluid_duct", "tank_input_port", "tank_output_port")),
                new Group("tanks", path -> path.contains("tank") || path.contains("bucket")
                        || path.contains("identifier"))));

        // ---- 材料与零件 ----
        map.put(Category.MATERIALS, List.of(
                new Group("plates", path -> path.endsWith("_plate")),
                new Group("ingots", path -> path.endsWith("_ingot")
                        || oneOf("high_carbon_iron").test(path)),
                new Group("dusts", path -> path.endsWith("_dust")
                        || oneOf("yellowcake", "dried_yellowcake", "uranium_slag").test(path)),
                new Group("parts", path -> path.startsWith("motor_") || path.startsWith("pump_")
                        || path.startsWith("robot_arm_") || path.startsWith("heater_")
                        || path.startsWith("circuit_board_")
                        || oneOf("gear", "sensor", "copper_wire", "copper_coil", "copper_pipe",
                        "valve", "mv_cable_core", "insulation_cloth", "binder",
                        "steam_turbine", "sodium_pump_hv").test(path)),
                new Group("pipe and frame",
                        oneOf("zirconium_alloy_pipe", "zirconium_alloy_frame", "end_plug")),
                new Group("radiation protection", path -> path.startsWith("radiation_suit")),
                new Group("tools and molds", path -> path.endsWith("_mold")
                        || oneOf("hammer").test(path))));

        // ---- 武器 ----
        map.put(Category.WEAPONS, List.of(
                new Group("warheads", oneOf("nuke_little_boy", "nuke_fat_man", "nuke_qiu",
                        "nuke_639", "nuke_ivy_mike", "nuke_tsar")),
                // 组件按「哪颗弹用得上」排：先是六颗通用的，再是枪式、内爆式、氢弹专用的
                new Group("common components", oneOf("nuke_fuze", "nuke_initiator", "nuke_primary",
                        "nuke_booster", "nuke_reflector", "nuke_tamper", "nuke_cobalt_shell")),
                new Group("gun-type components", oneOf("nuke_gun_barrel", "nuke_uranium_target")),
                new Group("implosion components", oneOf("nuke_explosive_lens", "nuke_plutonium_pit",
                        "nuke_uranium_pit")),
                new Group("thermonuclear components", oneOf("nuke_deuterium_lithium",
                        "nuke_cryostat", "nuke_parachute")),
                new Group("assembly", oneOf("warhead_assembler")),
                new Group("materials", oneOf("nuke_casing", "high_explosive", "weapon_grade_uranium",
                        "nuclear_diamond_crystal", "nuclear_emerald_crystal")),
                new Group("detonator", oneOf("detonator"))));

        return map;
    }

    // ------------------------------------------------------------------
    // 往标签页里塞东西
    // ------------------------------------------------------------------

    /**
     * 把一个分类的物品全部塞进去：先按小组编号排序，同组保持注册顺序。
     */
    private static void fill(CreativeModeTab.Output output, Category category) {
        List<DeferredHolder<Item, ? extends Item>> matched = new ArrayList<>();
        for (DeferredHolder<Item, ? extends Item> holder : ModItems.ITEMS.getEntries()) {
            if (!holder.isBound()) {
                continue;
            }
            if (categoryOf(holder.getId().getPath(), holder.get()) == category) {
                matched.add(holder);
            }
        }
        // List.sort 是稳定排序：小组编号相同的物品保持原来的注册顺序。
        matched.sort(Comparator.comparingInt(
                (DeferredHolder<Item, ? extends Item> holder) ->
                        groupIndex(category, holder.getId().getPath())));

        for (DeferredHolder<Item, ? extends Item> holder : matched) {
            output.accept(holder.get());
        }

        // 通用流体罐只有<b>一个</b>物品 id，但创造模式里给每种流体摆一格成品，
        // 方便直接拿去测试（它们都是同一件物品，只是数据组件里写着不同的流体）。
        if (category == Category.LOGISTICS) {
            output.accept(UniversalTankItem.create(net.minecraft.world.level.material.Fluids.WATER,
                    UniversalTankItem.CAPACITY));
            for (ModFluids.FluidSet set : ModFluids.allFluids()) {
                output.accept(UniversalTankItem.create(set.source.get(), UniversalTankItem.CAPACITY));
            }
        }
    }

    /** 这个物品在它那一页里属于第几组（没有规则匹配就是最后一组）。 */
    private static int groupIndex(Category category, String path) {
        List<Group> groups = GROUPS.get(category);
        if (groups == null) {
            return 0;
        }
        for (int i = 0; i < groups.size(); i++) {
            if (groups.get(i).matches(path)) {
                return i;
            }
        }
        return groups.size();
    }

    // ------------------------------------------------------------------
    // 归到哪一页
    // ------------------------------------------------------------------

    /**
     * 这个物品属于哪一类。
     *
     * <p>规则是「看形状，不看名单」：
     * <ol>
     *   <li>方块物品：管道/线缆/变压器/储罐接口 → 物流；矿石 → 世界；
     *       带方块实体（也就是各种机器）→ 机器，但反应堆和核相关的那几样 → 反应堆与核；
     *       其它方块 → 世界；</li>
     *   <li>普通物品：名字里带 bucket / tank / canister / duct / identifier / cell → 物流；
     *       燃料棒、控制棒、中子源、靶材、同位素 → 反应堆与核；
     *       剩下的（板、锭、零件、矿粉、工具、模具）→ 材料。</li>
     * </ol>
     *
     * <p>以后新加的东西如果名字实在看不出类别，就在最前面加一条判断把它点名。
     */
    public static Category categoryOf(String path, Item item) {
        // 武器整页点名：核弹（方块物品和组件同名开头）、起爆器、总装台和武器线原料。
        // 原料（高能炸药、武器级铀、两种核熔晶体）名字看不出是武器，所以在这里点名。
        if (path.startsWith("nuke_") || WEAPON_ONLY.contains(path)) {
            return Category.WEAPONS;
        }
        if (item instanceof BlockItem blockItem) {
            Block block = blockItem.getBlock();
            if (block instanceof AbstractPipeBlock || block instanceof CableBlock
                    || block instanceof TransformerBlock
                    // 只有储罐的两个口算「物流接口」；反应堆的端口是核部件，另算
                    || path.equals("tank_input_port") || path.equals("tank_output_port")
                    // 通用储罐是存流体的方块，归物流页
                    || path.equals("universal_tank")) {
                return Category.LOGISTICS;
            }
            if (block instanceof UraniumOreBlock || path.endsWith("_ore")) {
                return Category.WORLD;
            }
            // 反应堆结构方块：慢化剂、反射层、辐射屏蔽，盖房子用的，放「矿石与世界」
            if (NUCLEAR_STRUCTURE.contains(path)) {
                return Category.WORLD;
            }
            // 核相关的机器和部件（控制器、探测器、辐照孔道、热室机械臂……）单独一页
            if (NUCLEAR_BLOCKS.contains(path)) {
                return Category.REACTORS;
            }
            if (block instanceof BaseEntityBlock) {
                return Category.MACHINES;
            }
            return Category.WORLD;
        }
        if ((path.contains("bucket") || path.contains("tank") || path.contains("canister")
                || path.contains("duct") || path.contains("identifier") || path.contains("cell"))
                && !NUCLEAR_ITEMS.contains(path)) {
            return Category.LOGISTICS;
        }
        if (NUCLEAR_ITEMS.contains(path) || path.endsWith("_target")
                || path.startsWith("irradiated_") || path.startsWith("cooled_")) {
            return Category.REACTORS;
        }
        return Category.MATERIALS;
    }

    /**
     * 名字里看不出是武器、但要放进「武器」页的东西：总装台和它的原料。
     */
    private static final List<String> WEAPON_ONLY = List.of(
            "warhead_assembler", "nuke_casing", "high_explosive", "weapon_grade_uranium",
            "nuclear_diamond_crystal", "nuclear_emerald_crystal");

    /** 反应堆结构方块（盖堆用的建材，归「矿石与世界」）。 */
    private static final List<String> NUCLEAR_STRUCTURE = List.of(
            "graphite_moderator", "beryllium_reflector", "radiation_shield",
            "reactor_pressure_vessel", "cooling_tower",
            "fusion_ring_casing", "superconducting_coil", "breeding_blanket",
            "fuel_injector_port", "plasma_diagnostic", "cryogenic_cooler",
            "fusion_control_logic", "transmutator_casing");

    /** 反应堆/核相关的机器与部件（归「反应堆与核」）。 */
    private static final List<String> NUCLEAR_BLOCKS = List.of(
            "subcritical_controller", "critical_reactor_controller", "research_reactor_controller",
            "neutron_detector", "neutron_flux_recorder", "critical_alarm",
            "irradiation_channel", "hot_cell_arm",
            "pwr_controller", "fuel_port", "control_rod_port", "coolant_port",
            "fast_reactor_controller", "fast_neutron_detector", "sodium_steam_generator",
            "tokamak_controller", "transmutator_controller", "energy_port", "geologic_repository",
            "core_remnant");

    /** 反应堆/核相关的物品（归「反应堆与核」）。 */
    private static final List<String> NUCLEAR_ITEMS = List.of(
            "neutron_source", "control_rod", "radium_source",
            "fuel_rod", "sealed_fuel_rod", "leu_fuel_assembly", "melted_fuel_rod",
            "natural_uranium_rod", "natural_uranium_rod_bundle", "coal_fuel_rod",
            "cobalt60_source", "cesium137", "strontium90", "phosphorus32",
            "plutonium239", "actinides", "lithium6", "tritium",
            // 阶段 6：乏燃料、后处理产物与 MOX 燃料
            "spent_fuel_assembly", "cooled_spent_fuel_assembly", "spent_fuel_fragment",
            "empty_fuel_frame", "shell_slag", "recovered_uranium", "solidified_glass",
            "mox_pellet_blank", "sintered_mox_pellet", "mox_fuel_rod", "mox_fuel_assembly",
            "fast_spent_assembly", "cooled_fast_spent_assembly", "control_rod_driver",
            // 阶段 7：聚变燃料与终局产物
            "fusion_fuel_cell", "deuterium_cell", "tritium_cell", "dt_fuel_cell", "lithium7",
            "short_lived_isotope", "platinum_group_metal", "rare_isotope");

    /** 便利：一串名字里有没有 {@code path}。 */
    private static Predicate<String> oneOf(String... names) {
        List<String> list = List.of(names);
        return list::contains;
    }
}
