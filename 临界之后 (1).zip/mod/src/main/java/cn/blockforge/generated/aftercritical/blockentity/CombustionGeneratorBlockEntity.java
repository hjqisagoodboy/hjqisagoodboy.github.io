package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.menu.GeneratorMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 燃烧发电机：烧煤、木炭、木板、原木，输出 80 FE/t。
 *
 * <p>燃料数值（严格按定稿 v4）：
 * <ul>
 *   <li>煤 / 木炭：600 tick（30 秒）= 48,000 FE</li>
 *   <li>木板：150 tick（7.5 秒）= 12,000 FE</li>
 *   <li>原木：300 tick（15 秒）= 24,000 FE</li>
 * </ul>
 */
public class CombustionGeneratorBlockEntity extends AbstractGeneratorBlockEntity {

    /** 输出功率：80 FE/t。 */
    public static final int OUTPUT_PER_TICK = 80;

    public CombustionGeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.COMBUSTION_GENERATOR.get(), pos, state, OUTPUT_PER_TICK);
    }

    @Override
    protected int burnTicks(ItemStack stack) {
        if (stack.is(Items.COAL) || stack.is(Items.CHARCOAL)) {
            return 600;
        }
        if (stack.is(ItemTags.PLANKS)) {
            return 150;
        }
        if (stack.is(ItemTags.LOGS)) {
            return 300;
        }
        return 0;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.combustion_generator");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new GeneratorMenu(ModMenus.COMBUSTION_GENERATOR.get(), containerId, playerInventory, this, this);
    }
}
