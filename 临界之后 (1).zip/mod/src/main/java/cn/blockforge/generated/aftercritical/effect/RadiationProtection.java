package cn.blockforge.generated.aftercritical.effect;

import cn.blockforge.generated.aftercritical.registry.ModArmorMaterials;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;

/**
 * 辐射防护服算账的地方：把「身上穿了几件」换成防护比例。
 *
 * <p>规则（越往下一档越难，穿齐才算完整防护）：
 * <ul>
 *   <li>一件不穿：辐射按原样扣血；</li>
 *   <li>每多一件：辐射伤害少 25%（三件就是 75%）；</li>
 *   <li>四件穿齐：<b>完全不沾染</b>——{@link RadiationAura} 直接不给你挂效果，
 *       连挖掘变慢都没有；</li>
 *   <li>四件穿齐时核爆的冲击伤害也只吃 35%，勉强能在爆心附近活下来。</li>
 * </ul>
 *
 * <p>判断「是不是防护服」不用物品表，而是看护甲材质：这样以后加别的防护装备
 * （比如铅围裙、防毒面具）只要共用同一套材质就自动算数。
 */
public final class RadiationProtection {

    /** 一件防护服抵掉多少辐射伤害（0.25 = 25%）。 */
    private static final double PIECE_REDUCTION = 0.25D;
    /** 四件穿齐时核爆冲击伤害还剩多少（35%）。 */
    private static final double FULL_SUIT_BLAST = 0.35D;
    /** 差一件时核爆伤害每件少 10%。 */
    private static final double PIECE_BLAST = 0.10D;
    /** 一套几件。 */
    public static final int FULL_SET = 4;

    private RadiationProtection() {}

    /** 身上穿了几件防护服（0~4）。 */
    public static int pieces(LivingEntity entity) {
        int count = 0;
        for (ItemStack stack : entity.getArmorSlots()) {
            if (isSuitPiece(stack)) {
                count++;
            }
        }
        return count;
    }

    /** 四件齐了没有。 */
    public static boolean isFullSuit(LivingEntity entity) {
        return pieces(entity) >= FULL_SET;
    }

    /** 辐射伤害的倍数：0 件 1.0，四件 0.0。 */
    public static double radiationMultiplier(LivingEntity entity) {
        return Math.max(0.0D, 1.0D - PIECE_REDUCTION * pieces(entity));
    }

    /** 核爆冲击伤害的倍数：四件 0.35，三件 0.7，一件不穿 1.0。 */
    public static double blastMultiplier(LivingEntity entity) {
        int pieces = pieces(entity);
        if (pieces >= FULL_SET) {
            return FULL_SUIT_BLAST;
        }
        return Math.max(0.0D, 1.0D - PIECE_BLAST * pieces);
    }

    /** 这一件是不是防护服。 */
    private static boolean isSuitPiece(ItemStack stack) {
        return stack.getItem() instanceof ArmorItem armor
                && armor.getMaterial().is(ModArmorMaterials.RADIATION_SUIT.getKey());
    }
}
