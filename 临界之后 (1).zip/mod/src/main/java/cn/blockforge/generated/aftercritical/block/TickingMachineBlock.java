package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.EnergyStorable;
import cn.blockforge.generated.aftercritical.blockentity.TickableBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModDataComponents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 新一轮机器（装配机、发电机、电池）共用的方块骨架。
 *
 * <p>和老的 {@link MachineBlock} 做同样四件事：右键开界面、每 tick 驱动方块实体、
 * 拆掉时把里面的东西吐出来、物品栏里显示等级和功率；
 * 区别是它认的是更通用的 {@link TickableBlockEntity}，不绑定加工机器。
 */
public abstract class TickingMachineBlock extends BaseEntityBlock {

    private final String tier;
    private final String powerLineKey;
    private final int powerValue;
    private final String descriptionKey;

    /**
     * @param tier         等级文字，例如 "LV" / "MV"
     * @param powerLineKey 功率那一行的语言键（"运行功率：%s FE/t" 或 "输出功率：%s FE/t"）
     * @param powerValue   填进 %s 的数字
     * @param descriptionKey 这台机器干什么用的语言键
     */
    protected TickingMachineBlock(Properties properties, String tier, String powerLineKey, int powerValue,
                                  String descriptionKey) {
        super(properties);
        this.tier = tier;
        this.powerLineKey = powerLineKey;
        this.powerValue = powerValue;
        this.descriptionKey = descriptionKey;
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return (tickLevel, pos, tickState, blockEntity) -> {
            if (blockEntity instanceof TickableBlockEntity tickable) {
                tickable.serverTick();
            }
        };
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MenuProvider provider) {
            player.openMenu(provider, pos);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** 老版本用的空手右键（部分情况下会走这里）。 */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MenuProvider provider) {
            player.openMenu(provider, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide
                && level.getBlockEntity(pos) instanceof Container container) {
            Containers.dropContents(level, pos, container);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    /**
     * 挖掉时把电池里的电写进掉落物。
     *
     * <p>只有 {@link EnergyStorable}（三种电池）这么做；发电机和机器挖掉就是空的。
     * 电量写在物品的 {@code aftercritical:energy} 组件上，跟通用储罐存流体的做法一样。
     */
    @Override
    protected List<ItemStack> getDrops(BlockState state, LootParams.Builder params) {
        List<ItemStack> drops = super.getDrops(state, params);
        Object raw = params.getOptionalParameter(LootContextParams.BLOCK_ENTITY);
        if (!(raw instanceof EnergyStorable storable)) {
            return drops;
        }
        int stored = storable.getStoredEnergy();
        if (stored <= 0) {
            return drops;
        }
        for (ItemStack drop : drops) {
            if (drop.is(asItem())) {
                drop.set(ModDataComponents.ENERGY.get(), stored);
            }
        }
        return drops;
    }

    /** 放下电池时把掉落物上带着的电量装回去（和挖掉时的写入对称）。 */
    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer,
                            ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level.isClientSide) {
            return;
        }
        Integer stored = stack.get(ModDataComponents.ENERGY.get());
        if (stored == null || stored <= 0) {
            return;
        }
        if (level.getBlockEntity(pos) instanceof EnergyStorable storable) {
            storable.setStoredEnergy(stored);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.tier", this.tier).withStyle(ChatFormatting.GRAY));
        int max = maxPowerValue();
        if (max > this.powerValue) {
            // 功率会随通电量变化的机器（地下水开采机）：显示成「30 ~ 120 FE/t」而不是一个死数字
            tooltip.add(Component.translatable("tooltip.aftercritical.power_range", this.powerValue, max)
                    .withStyle(ChatFormatting.DARK_GRAY));
        } else {
            tooltip.add(Component.translatable(this.powerLineKey, this.powerValue)
                    .withStyle(ChatFormatting.DARK_GRAY));
        }
        tooltip.add(Component.translatable(this.descriptionKey).withStyle(ChatFormatting.GRAY));
        Integer stored = stack.get(ModDataComponents.ENERGY.get());
        if (stored != null && stored > 0) {
            tooltip.add(Component.translatable("tooltip.aftercritical.stored_energy", stored)
                    .withStyle(ChatFormatting.AQUA));
        }
    }

    /**
     * 功率上限：只有「电越多干得越快」的机器才比额定功率高。
     *
     * @return 0（或不大于额定值）表示这台机器功率固定，物品提示照老样子写
     */
    protected int maxPowerValue() {
        return 0;
    }
}
