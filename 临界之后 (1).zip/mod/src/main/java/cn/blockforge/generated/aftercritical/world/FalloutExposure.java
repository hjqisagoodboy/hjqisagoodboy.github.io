package cn.blockforge.generated.aftercritical.world;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.effect.RadiationAura;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;

/**
 * 「把辐射尘带在身上会吃辐射」这件事的结算器。
 *
 * <p>每秒（20 tick）查一遍所有玩家：
 * <ul>
 *   <li>背包里有辐射尘、或者手上正拿着 → 续一次辐射沾染（穿齐防护服则不沾）；</li>
 *   <li>手上正拿着 → 记一次「这是雪吗？」成就。</li>
 * </ul>
 *
 * <p>为什么不写在方块里：人把尘撸下来装进背包之后，方块早没了，
 * 只能靠玩家自己身上挂一个定时检查。放在服务端 tick 里，是因为一次核爆有 5 分钟的
 * 粉尘任务在跑，这里搭个顺风车，不用再注册一个事件监听。
 */
public final class FalloutExposure {

    /** 每 20 tick（1 秒）查一次。 */
    private static final int INTERVAL = 20;

    private static int timer;

    private FalloutExposure() {}

    /** 服务端每 tick 调一次（由 {@link NuclearBlast#onServerTick} 带上）。 */
    public static void tick(MinecraftServer server) {
        if (++timer < INTERVAL) {
            return;
        }
        timer = 0;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            boolean holding = player.getMainHandItem().is(ModItems.RADIOACTIVE_DUST.get())
                    || player.getOffhandItem().is(ModItems.RADIOACTIVE_DUST.get());
            boolean carrying = holding || carryingDust(player.getInventory());
            if (carrying) {
                RadiationAura.apply(player);
            }
            if (holding) {
                ModAdvancementTriggers.fire(player, ModAdvancementTriggers.HOLD_RADIOACTIVE_DUST);
            }
        }
    }

    /** 背包（含护甲、副手）里有没有辐射尘。 */
    private static boolean carryingDust(Inventory inventory) {
        for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
            if (inventory.getItem(slot).is(ModItems.RADIOACTIVE_DUST.get())) {
                return true;
            }
        }
        return false;
    }
}
