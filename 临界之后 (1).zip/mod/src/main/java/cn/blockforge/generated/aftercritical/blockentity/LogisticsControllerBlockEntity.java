package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.energy.MachineEnergyStorage;
import cn.blockforge.generated.aftercritical.energy.RatedEnergyConsumer;
import cn.blockforge.generated.aftercritical.itemhandler.ContainerItemHandler;
import cn.blockforge.generated.aftercritical.menu.LogisticsControllerMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.items.IItemHandler;

import javax.annotation.Nullable;

/**
 * 物流控制器：管物品管道「把货分匀」的那台总台。
 *
 * <p>物品管道送货的规则是「塞进第一个愿意收的方块」，所以一条线上挂好几台机器时，
 * 排在前面的那台会被塞满，后面的机器饿死——这就是玩家说的「堵」。
 * 物流控制器换了个办法：
 * <ol>
 *   <li>物品管道把货推进控制器的 9 格缓冲（它对外就是一个普通容器，管道认得）；</li>
 *   <li>控制器每 tick 花 {@value #ENERGY_PER_TICK} FE，从缓冲里拿 1 个物品，
 *       按「上一次送给谁」的下一个方向开始试，谁收得下就给谁；</li>
 *   <li>送成功一次就转一格方向，于是货会六个方向轮着走，不会全堆在第一台机器里。</li>
 * </ol>
 *
 * <p>它只往外送，不从邻居抽——抽货还得靠管道，不然会和管道抢同一件东西。
 */
public class LogisticsControllerBlockEntity extends BlockEntity
        implements MenuProvider, TickableBlockEntity, Container, RatedEnergyConsumer, EnergyMachineHost {

    /** 9 格缓冲（3×3），接口和普通箱子一样。 */
    public static final int SLOT_COUNT = 9;

    /** 运行耗电：16 FE/t（每送 1 个物品算一次）。 */
    public static final int ENERGY_PER_TICK = 16;
    public static final int ENERGY_CAPACITY = 10_000;
    public static final int MAX_PULL_PER_TICK = 512;

    /** 每 tick 最多送出去几个物品（1 个，够了——管道本身也只有 1 个/tick）。 */
    public static final int ITEMS_PER_TICK = 1;

    private final MachineEnergyStorage energy =
            new MachineEnergyStorage(ENERGY_CAPACITY, MAX_PULL_PER_TICK, this::setChanged);
    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);

    /** 只许往里塞、不许往外抽：搬货是控制器的活，管道别来抢。 */
    private final IItemHandler itemHandler = new ContainerItemHandler(this,
            slot -> true, slot -> false);

    /** 下一次从哪个方向开始试（六个方向轮流来，这就是「分匀」）。 */
    private int nextSide;

    /** 六个方向里有几个真的接上了能收东西的容器（界面显示用）。 */
    private int connected;

    private int status = STATUS_IDLE;

    public LogisticsControllerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.LOGISTICS_CONTROLLER.get(), pos, state);
    }

    public IEnergyStorage getEnergyStorage() {
        return this.energy;
    }

    public IItemHandler getItemHandler() {
        return this.itemHandler;
    }

    @Override
    public int ratedEnergyPerTick() {
        return ENERGY_PER_TICK;
    }

    public int getStatus() {
        return this.status;
    }

    public int getConnected() {
        return this.connected;
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        pullEnergyFromNeighbours();
        this.connected = countConnected();

        int newStatus;
        if (firstNonEmptySlot() < 0) {
            newStatus = STATUS_IDLE;
        } else if (this.energy.getEnergyStored() < ENERGY_PER_TICK) {
            newStatus = STATUS_NO_ENERGY;
        } else if (distributeOne()) {
            this.energy.consume(ENERGY_PER_TICK);
            newStatus = STATUS_RUNNING;
        } else {
            newStatus = STATUS_OUTPUT_BLOCKED;
        }

        if (this.status != newStatus) {
            this.status = newStatus;
            setChanged();
        }
    }

    /** 缓冲里第一个有东西的槽；全空返回 -1。 */
    private int firstNonEmptySlot() {
        for (int slot = 0; slot < SLOT_COUNT; slot++) {
            if (!this.items.get(slot).isEmpty()) {
                return slot;
            }
        }
        return -1;
    }

    /**
     * 送出去 1 个物品：从 {@link #nextSide} 开始绕一圈，谁收得下就给谁。
     *
     * <p>成功之后把 {@code nextSide} 往后挪一格，下一次从下一个方向开始，
     * 这样六个方向轮着收货，不会出现「第一台机器撑死、第二台饿死」。
     *
     * @return 有没有送出去
     */
    private boolean distributeOne() {
        if (this.level == null) {
            return false;
        }
        int slot = firstNonEmptySlot();
        if (slot < 0) {
            return false;
        }
        ItemStack buffer = this.items.get(slot);
        Direction[] sides = Direction.values();
        for (int offset = 0; offset < sides.length; offset++) {
            Direction side = sides[(this.nextSide + offset) % sides.length];
            IItemHandler target = handlerAt(side);
            if (target == null) {
                continue;
            }
            ItemStack single = buffer.copyWithCount(1);
            boolean accepted = false;
            for (int targetSlot = 0; targetSlot < target.getSlots(); targetSlot++) {
                ItemStack leftover = target.insertItem(targetSlot, single, true);
                if (leftover.getCount() < single.getCount()) {
                    target.insertItem(targetSlot, single, false);
                    accepted = true;
                    break;
                }
            }
            if (!accepted) {
                continue;
            }
            buffer.shrink(1);
            if (buffer.isEmpty()) {
                this.items.set(slot, ItemStack.EMPTY);
            }
            this.nextSide = (this.nextSide + offset + 1) % sides.length;
            setChanged();
            return true;
        }
        return false;
    }

    /** 这个方向上的邻居能不能收东西。 */
    @Nullable
    private IItemHandler handlerAt(Direction side) {
        if (this.level == null) {
            return null;
        }
        BlockPos neighbourPos = this.worldPosition.relative(side);
        IItemHandler handler = this.level.getCapability(Capabilities.ItemHandler.BLOCK, neighbourPos,
                side.getOpposite());
        if (handler != null) {
            return handler;
        }
        // 只实现了原版 Container 的方块（箱子之类，极少见）也认
        if (this.level.getBlockEntity(neighbourPos) instanceof Container container) {
            return new ContainerItemHandler(container, s -> true, s -> true);
        }
        return null;
    }

    /** 六个方向里接上了几个容器。 */
    private int countConnected() {
        int count = 0;
        for (Direction side : Direction.values()) {
            if (handlerAt(side) != null) {
                count++;
            }
        }
        return count;
    }

    /** 从六个方向挨个问邻居要电，能抽多少算多少。 */
    private void pullEnergyFromNeighbours() {
        if (this.level == null) {
            return;
        }
        int space = this.energy.getFreeSpace();
        if (space <= 0) {
            return;
        }
        int budget = Math.min(space, MAX_PULL_PER_TICK);
        for (Direction side : Direction.values()) {
            if (budget <= 0) {
                break;
            }
            IEnergyStorage source = this.level.getCapability(
                    Capabilities.EnergyStorage.BLOCK, this.worldPosition.relative(side), side.getOpposite());
            if (source == null || !source.canExtract()) {
                continue;
            }
            int moved = source.extractEnergy(budget, true);
            if (moved <= 0) {
                continue;
            }
            moved = source.extractEnergy(moved, false);
            if (moved > 0) {
                this.energy.receiveEnergy(moved, false);
                budget -= moved;
            }
        }
    }

    // ------------------------------------------------------------------
    // GUI 数据
    // ------------------------------------------------------------------

    @Override
    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    @Override
    public int getEnergyCapacity() {
        return this.energy.getMaxEnergyStored();
    }

    @Override
    public int getProgress() {
        return 0;
    }

    @Override
    public int getMaxProgress() {
        return 0;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.logistics_controller");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new LogisticsControllerMenu(containerId, playerInventory, this);
    }

    // ------------------------------------------------------------------
    // 物品槽
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return SLOT_COUNT;
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        stack.limitSize(getMaxStackSize(stack));
        setChanged();
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
        tag.putInt("Status", this.status);
        tag.putInt("NextSide", this.nextSide);
        ContainerHelper.saveAllItems(tag, this.items, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
        this.status = tag.getInt("Status");
        this.nextSide = tag.getInt("NextSide");
        ContainerHelper.loadAllItems(tag, this.items, registries);
    }
}
