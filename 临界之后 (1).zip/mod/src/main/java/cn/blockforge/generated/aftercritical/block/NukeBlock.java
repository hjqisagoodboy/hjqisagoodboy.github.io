package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.NukeBlockEntity;
import cn.blockforge.generated.aftercritical.item.DetonatorItem;
import cn.blockforge.generated.aftercritical.nuke.NukeKind;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 核弹方块：放在地上是一枚横躺的核弹（模型不是方块，超出自己那一格），
 * 右键打开装配界面，拿着起爆器潜行右键绑定。
 *
 * <p>「是哪一颗」不用在方块里存一份：注册名去掉 {@code nuke_} 就是
 * {@link NukeKind#id}，{@link #kind()} 现场查注册表，少一处会写歪的地方。
 */
public class NukeBlock extends BaseEntityBlock {

    /** 弹头朝向：放下时背对玩家，和原版朝向类方块一致。 */
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

    public NukeBlock(Properties properties) {
        super(properties);
        registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(NukeBlock::new);
    }

    /** 这颗弹的档案（半径、坑深、辐射时长）。 */
    public NukeKind kind() {
        String path = BuiltInRegistries.BLOCK.getKey(this).getPath();
        return NukeKind.byId(path.startsWith("nuke_") ? path.substring("nuke_".length()) : path);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new NukeBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                  BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return (tickLevel, pos, tickState, blockEntity) -> {
            if (blockEntity instanceof NukeBlockEntity nuke) {
                nuke.serverTick();
            }
        };
    }

    // ------------------------------------------------------------------
    // 右键
    // ------------------------------------------------------------------

    /**
     * 空手 / 普通物品右键 → 打开装配界面。
     *
     * <p>起爆器潜行右键要让给物品自己处理（绑定），所以这里直接放行。
     */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (stack.getItem() instanceof DetonatorItem && player.isShiftKeyDown()) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        open(level, pos, player);
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        open(level, pos, player);
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** 打开装配界面（只在服务端真正做事，客户端等着收包）。 */
    private static void open(Level level, BlockPos pos, Player player) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof NukeBlockEntity nuke) {
            player.openMenu(nuke, pos);
        }
    }

    /** 拆掉核弹时把里面的组件吐出来，别吞了玩家的东西。 */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide
                && level.getBlockEntity(pos) instanceof Container container) {
            Containers.dropContents(level, pos, container);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        NukeKind kind = kind();
        tooltip.add(Component.translatable(kind.yieldKey()).withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("tooltip.aftercritical.nuke.stats", kind.radius, kind.depth)
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.nuke.modules", kind.componentCount())
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.nuke.usage")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
