package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.block.PwrControllerBlock;
import cn.blockforge.generated.aftercritical.menu.PwrControllerMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModBlocks;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 压水堆控制器：阶段 5 的 7×7×8 多方块。
 *
 * <p>这一台和前面几台反应堆不一样：它不调 k_eff，也不做氙中毒，只做最朴素的热工：
 * <ol>
 *   <li>燃料端口里插 4~8 支 LEU 燃料组件 → 产生热量；</li>
 *   <li>控制棒端口插 ≥4 根控制棒，界面上调「插入深度」→ 插得越深、功率越低；</li>
 *   <li>热量把冷却剂端口送来的水烧成蒸汽（1 mB 蒸汽 = 40 FE 的热能）；</li>
 *   <li>蒸汽接去汽轮发电机发电，乏蒸汽接去冷凝器换回水，再泵回来——闭环；</li>
 *   <li>水不够 → 温度飙升，超过 1,200 °C 太久会把燃料烧成【熔毁的燃料棒】。</li>
 * </ol>
 *
 * <p>结构（7 宽 × 7 深 × 8 高，控制器贴在正面墙、贴地那一排正中间，方块朝哪堆就往哪长）：
 * 压力壳 ≥92、铅块 ≥24、混凝土 ≥48、玻璃 ≥8；燃料端口 ≥1、控制棒端口 ≥4、冷却剂端口 ≥2。
 */
public class PwrControllerBlockEntity extends BlockEntity
        implements net.minecraft.world.MenuProvider, TickableBlockEntity {

    // ------------------------------------------------------------------
    // 结构（定稿 v4 第 2 步）
    // ------------------------------------------------------------------

    public static final int SIZE_W = 7;
    public static final int SIZE_D = 7;
    public static final int SIZE_H = 8;

    public static final int MIN_SHELL = 92;
    public static final int MIN_LEAD = 24;
    public static final int MIN_CONCRETE = 48;
    public static final int MIN_GLASS = 8;
    public static final int MIN_FUEL_PORTS = 1;
    public static final int MIN_ROD_PORTS = 4;
    public static final int MIN_COOLANT_PORTS = 2;

    /** 结构每 2 秒重查一次。 */
    public static final int VALIDATE_INTERVAL = 40;

    // ------------------------------------------------------------------
    // 热工数值
    // ------------------------------------------------------------------

    /** 每支燃料满功率贡献 250 FE/t 的热能。 */
    public static final int THERMAL_PER_FUEL = 250;
    /** 最多按 8 支燃料算（多放的只当备用）。 */
    public static final int MAX_FUEL = 8;
    /** 至少 4 支燃料才能启动。 */
    public static final int MIN_FUEL = 4;
    /** 至少 4 根控制棒才能启动。 */
    public static final int MIN_RODS = 4;
    /** 控制棒全插到底时，功率压到 25%。 */
    public static final double ROD_REDUCTION = 0.75D;
    /** 1 mB 蒸汽对应的热能（和汽轮发电机对齐：50 mB/t → 2,000 FE/t）。 */
    public static final int FE_PER_MB = 40;
    /** 满功率时每 tick 产多少蒸汽。 */
    public static final int MAX_STEAM_PER_TICK = 2_000 / FE_PER_MB;

    /** 水罐 / 蒸汽罐容量。 */
    public static final int WATER_CAPACITY = 16_000;
    public static final int STEAM_CAPACITY = 16_000;

    /** 常温、超温阈值、上限（摄氏度）。 */
    public static final double TEMP_AMBIENT = 20.0D;
    public static final double TEMP_DAMAGE = 1_200.0D;
    public static final double TEMP_MAX = 2_000.0D;
    /** 过温自保：温度到这里就自动停堆（还没到 1,200 °C 的烧燃料线）。 */
    public static final double TEMP_SCRAM = 1_050.0D;
    /** 自保停堆以后，温度降到这以下才自动恢复运行。 */
    public static final double TEMP_SCRAM_RESET = 900.0D;
    /** 连续超温多少 tick 烧坏一支燃料。 */
    public static final int DAMAGE_TICKS = 100;
    /** 一支 LEU 燃料组件烧满多少 tick 变成乏燃料（6 分钟，和后处理线的时间尺度对齐）。 */
    public static final int BURN_TICKS = 7_200;

    // ------------------------------------------------------------------
    // 界面状态码
    // ------------------------------------------------------------------

    public static final int STATUS_UNFORMED = 0;
    public static final int STATUS_IDLE = 1;
    public static final int STATUS_NO_FUEL = 2;
    public static final int STATUS_NO_RODS = 3;
    public static final int STATUS_NO_WATER = 4;
    public static final int STATUS_RUNNING = 5;
    public static final int STATUS_OVERHEAT = 6;
    public static final int STATUS_NO_SPACE = 7;
    /** 过温自保已经触发：堆自动停了，等温度降下来。 */
    public static final int STATUS_SCRAM = 8;

    // ------------------------------------------------------------------
    // 状态
    // ------------------------------------------------------------------

    private boolean formed;
    private int shellCount;
    private int leadCount;
    private int concreteCount;
    private int glassCount;
    private int validateTimer;

    private List<BlockPos> fuelPorts = List.of();
    private List<BlockPos> rodPorts = List.of();
    private List<BlockPos> coolantPorts = List.of();

    private final FluidTank waterTank = new FluidTank(WATER_CAPACITY);
    private final FluidTank steamTank = new FluidTank(STEAM_CAPACITY);

    /** 控制棒插入深度 0~100%。 */
    private int rodDepth;
    /** 堆芯温度（摄氏度）。 */
    private double temperature = TEMP_AMBIENT;
    private int overheatTicks;
    /** 过温自保是不是正在起作用（自动停堆中）。 */
    private boolean scrammed;

    private int fuelCount;
    private int rodCount;
    /** 当前这一支 LEU 已经烧了多少 tick。 */
    private int burnProgress;
    private int desiredSteam;
    private int actualSteam;
    private int status = STATUS_UNFORMED;

    /** 成就「蒸汽上线」只记一次。 */
    private boolean steamMilestoneFired;

    public PwrControllerBlockEntity(BlockPos pos, BlockState state) {
        this(ModBlockEntities.PWR_CONTROLLER.get(), pos, state);
    }

    protected PwrControllerBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    public void validateSoon() {
        this.validateTimer = 1;
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        if (--this.validateTimer <= 0) {
            this.validateTimer = VALIDATE_INTERVAL;
            validateStructure();
        }

        this.fuelCount = countFuel();
        this.rodCount = countRods();
        pullWaterFromPorts();
        pushSteamToPorts();
        updateScram();

        boolean canRun = this.formed && this.fuelCount >= MIN_FUEL && this.rodCount >= MIN_RODS
                && !this.scrammed;
        this.desiredSteam = canRun ? desiredSteam() : 0;

        int actual = 0;
        if (canRun) {
            int water = this.waterTank.getFluidAmount();
            int space = this.steamTank.getCapacity() - this.steamTank.getFluidAmount();
            actual = Math.min(this.desiredSteam, Math.min(water, space));
            if (actual > 0) {
                this.waterTank.drain(actual, IFluidHandler.FluidAction.EXECUTE);
                this.steamTank.fill(new FluidStack(ModFluids.STEAM.source.get(), actual),
                        IFluidHandler.FluidAction.EXECUTE);
            }
        }
        this.actualSteam = actual;
        if (!this.steamMilestoneFired && actual > 0) {
            this.steamMilestoneFired = true;
            ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 48.0,
                    ModAdvancementTriggers.PWR_STEAM);
        }
        updateFuelBurn(actual);
        syncBurnToPorts();
        updateTemperature(canRun);
        this.status = computeStatus(canRun);
        setChanged();
    }

    /**
     * 把「这一支烧到哪了」推给每个燃料端口，端口界面的进度条就靠它。
     *
     * <p>端口自己不存这些数字，控制器每 tick 顺手推一遍：用不着为它单独存盘，
     * 也不会出现「界面上的进度和实际进度对不上」。
     */
    private void syncBurnToPorts() {
        if (this.level == null) {
            return;
        }
        for (BlockPos pos : this.fuelPorts) {
            if (this.level.getBlockEntity(pos) instanceof FuelPortBlockEntity port) {
                port.setBurnState(this.burnProgress, BURN_TICKS);
            }
        }
    }

    /** 现在这台堆每 tick 想产多少蒸汽（mB）。 */
    private int desiredSteam() {
        int fuel = Math.min(this.fuelCount, MAX_FUEL);
        double thermal = THERMAL_PER_FUEL * fuel * (1.0D - ROD_REDUCTION * this.rodDepth / 100.0D);
        return (int) Math.round(thermal / FE_PER_MB);
    }

    /**
     * 燃料消耗：堆在正常产蒸汽的时候，燃料组件一点一点「烧到白头」，
     * 烧满 6 分钟就地变成一块【乏燃料组件】——后处理线就是从这儿拿原料的。
     */
    private void updateFuelBurn(int steam) {
        if (steam <= 0) {
            return;
        }
        this.burnProgress++;
        if (this.burnProgress < BURN_TICKS) {
            return;
        }
        this.burnProgress = 0;
        for (BlockPos pos : this.fuelPorts) {
            if (this.level.getBlockEntity(pos) instanceof FuelPortBlockEntity port && port.burnOneFuel()) {
                if (this.level instanceof ServerLevel server) {
                    server.playSound(null, pos, net.minecraft.sounds.SoundEvents.NETHERITE_BLOCK_PLACE,
                            net.minecraft.sounds.SoundSource.BLOCKS, 0.8F, 0.9F);
                }
                setChanged();
                return;
            }
        }
    }

    /**
     * 过温自保（第 3 层防线）：温度摸到 1,050 °C 就自动停堆。
     *
     * <p>停堆 = 这台堆把自己当成「控制棒全插到底」：不产蒸汽、不烧燃料，
     * 温度每 tick 往下掉 2 °C。等降到 900 °C 以下再自动恢复。
     *
     * <p>为什么要有它：汽轮机电满 → 蒸汽堵 → 压水堆的蒸汽罐也满 → 温度每 tick +1 °C，
     * 一分钟就冲到 1,200 °C 开始烧燃料。自保停堆把这条链子截断在烧燃料之前，
     * 玩家有足够时间去看「蒸汽排不出去」的提示、加电池或开弃电保汽。
     */
    private void updateScram() {
        if (!this.scrammed && this.temperature >= TEMP_SCRAM) {
            this.scrammed = true;
            setChanged();
        } else if (this.scrammed && this.temperature <= TEMP_SCRAM_RESET) {
            this.scrammed = false;
            setChanged();
        }
    }

    /** 温度：水不够就升温，水够就慢慢降温；超过 1,200 °C 太久烧坏燃料。 */
    private void updateTemperature(boolean canRun) {
        int deficit = Math.max(0, this.desiredSteam - this.actualSteam);
        if (canRun && deficit > 0) {
            this.temperature = Math.min(TEMP_MAX, this.temperature + deficit * 0.02D);
        } else {
            double cooling = canRun ? 0.6D : 2.0D;
            this.temperature = Math.max(TEMP_AMBIENT, this.temperature - cooling);
        }

        if (this.temperature >= TEMP_DAMAGE) {
            this.overheatTicks++;
            if (this.overheatTicks >= DAMAGE_TICKS) {
                this.overheatTicks = 0;
                damageFuel();
            }
        } else if (this.overheatTicks > 0) {
            this.overheatTicks = Math.max(0, this.overheatTicks - 2);
        }
    }

    /** 超温惩罚：把一支燃料烧成熔毁的燃料棒。 */
    private void damageFuel() {
        for (BlockPos pos : this.fuelPorts) {
            if (this.level.getBlockEntity(pos) instanceof FuelPortBlockEntity port && port.damageOneFuel()) {
                if (this.level instanceof ServerLevel server) {
                    server.sendParticles(ParticleTypes.LARGE_SMOKE,
                            pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5,
                            20, 0.5, 0.5, 0.5, 0.02);
                    server.playSound(null, pos, net.minecraft.sounds.SoundEvents.FIRE_EXTINGUISH,
                            net.minecraft.sounds.SoundSource.BLOCKS, 1.0F, 0.6F);
                }
                setChanged();
                return;
            }
        }
    }

    private int computeStatus(boolean canRun) {
        if (!this.formed) {
            return STATUS_UNFORMED;
        }
        if (this.scrammed) {
            return STATUS_SCRAM;
        }
        if (this.fuelCount < MIN_FUEL) {
            return STATUS_NO_FUEL;
        }
        if (this.rodCount < MIN_RODS) {
            return STATUS_NO_RODS;
        }
        if (this.temperature >= TEMP_DAMAGE) {
            return STATUS_OVERHEAT;
        }
        if (this.desiredSteam > 0 && this.actualSteam <= 0) {
            return this.steamTank.getCapacity() - this.steamTank.getFluidAmount() <= 0
                    ? STATUS_NO_SPACE : STATUS_NO_WATER;
        }
        return this.actualSteam > 0 ? STATUS_RUNNING : STATUS_IDLE;
    }

    // ------------------------------------------------------------------
    // 和冷却剂端口交换流体
    // ------------------------------------------------------------------

    /** 从每个冷却剂端口的进水罐往内部水罐抽水（最多抽到水罐满）。 */
    private void pullWaterFromPorts() {
        int room = this.waterTank.getCapacity() - this.waterTank.getFluidAmount();
        if (room <= 0) {
            return;
        }
        for (BlockPos pos : this.coolantPorts) {
            if (room <= 0) {
                return;
            }
            if (this.level.getBlockEntity(pos) instanceof CoolantPortBlockEntity port) {
                FluidStack taken = port.waterTank().drain(Math.min(room, 200),
                        IFluidHandler.FluidAction.EXECUTE);
                if (!taken.isEmpty()) {
                    this.waterTank.fill(taken, IFluidHandler.FluidAction.EXECUTE);
                    room -= taken.getAmount();
                    port.setChanged();
                }
            }
        }
    }

    /** 把内部蒸汽罐里的蒸汽灌进各冷却剂端口的出汽罐（管道会从那边抽走）。 */
    private void pushSteamToPorts() {
        if (this.steamTank.isEmpty()) {
            return;
        }
        for (BlockPos pos : this.coolantPorts) {
            if (this.steamTank.isEmpty()) {
                return;
            }
            if (this.level.getBlockEntity(pos) instanceof CoolantPortBlockEntity port) {
                int space = port.steamTank().getCapacity() - port.steamTank().getFluidAmount();
                if (space <= 0) {
                    continue;
                }
                int moved = Math.min(space, Math.min(200, this.steamTank.getFluidAmount()));
                FluidStack drained = this.steamTank.drain(moved, IFluidHandler.FluidAction.EXECUTE);
                if (!drained.isEmpty()) {
                    port.steamTank().fill(drained, IFluidHandler.FluidAction.EXECUTE);
                    port.setChanged();
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // 结构检测
    // ------------------------------------------------------------------

    /** 数一遍 7×7×8 的区域，同时把三种端口的位置记下来。 */
    public void validateStructure() {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        Direction facing = facing();
        int px = facing.getStepZ();
        int pz = -facing.getStepX();
        int radius = (SIZE_W - 1) / 2;

        int shell = 0;
        int lead = 0;
        int concrete = 0;
        int glass = 0;
        List<BlockPos> fuels = new ArrayList<>();
        List<BlockPos> rods = new ArrayList<>();
        List<BlockPos> coolants = new ArrayList<>();
        boolean complete = true;

        for (int depth = 0; depth < SIZE_D && complete; depth++) {
            for (int side = -radius; side <= radius && complete; side++) {
                for (int up = 0; up < SIZE_H && complete; up++) {
                    BlockPos pos = this.worldPosition.offset(
                            facing.getStepX() * depth + px * side, up, facing.getStepZ() * depth + pz * side);
                    if (!server.isLoaded(pos)) {
                        complete = false;
                        break;
                    }
                    if (pos.equals(this.worldPosition)) {
                        continue;
                    }
                    BlockState state = server.getBlockState(pos);
                    Block block = state.getBlock();
                    if (block == ModBlocks.REACTOR_PRESSURE_VESSEL.get()) {
                        shell++;
                    } else if (block == ModBlocks.LEAD_BLOCK.get()) {
                        lead++;
                    } else if (isConcrete(block)) {
                        concrete++;
                    } else if (state.is(Blocks.GLASS)) {
                        glass++;
                    } else if (block == ModBlocks.FUEL_PORT.get()) {
                        fuels.add(pos);
                    } else if (block == ModBlocks.CONTROL_ROD_PORT.get()) {
                        rods.add(pos);
                    } else if (block == ModBlocks.COOLANT_PORT.get()) {
                        coolants.add(pos);
                    }
                }
            }
        }

        boolean nowFormed = complete
                && shell >= MIN_SHELL && lead >= MIN_LEAD && concrete >= MIN_CONCRETE && glass >= MIN_GLASS
                && fuels.size() >= MIN_FUEL_PORTS && rods.size() >= MIN_ROD_PORTS
                && coolants.size() >= MIN_COOLANT_PORTS;

        this.formed = nowFormed;
        this.shellCount = shell;
        this.leadCount = lead;
        this.concreteCount = concrete;
        this.glassCount = glass;
        this.fuelPorts = List.copyOf(fuels);
        this.rodPorts = List.copyOf(rods);
        this.coolantPorts = List.copyOf(coolants);
        setChanged();
    }

    /** 所有颜色的混凝土都算（灰色最常见，但别逼玩家非得用灰色）。 */
    private static boolean isConcrete(Block block) {
        if (block == Blocks.GRAY_CONCRETE) {
            return true;
        }
        var id = BuiltInRegistries.BLOCK.getKey(block);
        return id != null && id.getPath().endsWith("_concrete");
    }

    /** 方块朝哪，结构就往哪长。 */
    private Direction facing() {
        BlockState state = getBlockState();
        if (state.hasProperty(PwrControllerBlock.FACING)) {
            return state.getValue(PwrControllerBlock.FACING);
        }
        return Direction.NORTH;
    }

    // ------------------------------------------------------------------
    // 给界面看的数
    // ------------------------------------------------------------------

    private int countFuel() {
        int total = 0;
        for (BlockPos pos : this.fuelPorts) {
            if (this.level != null && this.level.getBlockEntity(pos) instanceof FuelPortBlockEntity port) {
                total += port.fuelCount();
            }
        }
        return total;
    }

    private int countRods() {
        int total = 0;
        for (BlockPos pos : this.rodPorts) {
            if (this.level != null && this.level.getBlockEntity(pos) instanceof ControlRodPortBlockEntity port
                    && port.hasRod()) {
                total++;
            }
        }
        return total;
    }

    public boolean isFormed() {
        return this.formed;
    }

    public int shellCount() {
        return this.shellCount;
    }

    public int leadCount() {
        return this.leadCount;
    }

    public int concreteCount() {
        return this.concreteCount;
    }

    public int glassCount() {
        return this.glassCount;
    }

    public int fuelPortCount() {
        return this.fuelPorts.size();
    }

    public int rodPortCount() {
        return this.rodPorts.size();
    }

    public int coolantPortCount() {
        return this.coolantPorts.size();
    }

    public int fuelCount() {
        return this.fuelCount;
    }

    public int rodCount() {
        return this.rodCount;
    }

    public int rodDepth() {
        return this.rodDepth;
    }

    public void setRodDepth(int depth) {
        this.rodDepth = Math.max(0, Math.min(100, depth));
        setChanged();
    }

    public int temperatureInt() {
        return (int) Math.round(this.temperature);
    }

    /** 过温自保是不是正在起作用（界面状态行用）。 */
    public boolean isScrammed() {
        return this.scrammed;
    }

    public int waterAmount() {
        return this.waterTank.getFluidAmount();
    }

    public int steamAmount() {
        return this.steamTank.getFluidAmount();
    }

    public int waterCapacity() {
        return WATER_CAPACITY;
    }

    public int steamCapacity() {
        return STEAM_CAPACITY;
    }

    /** 满功率时的热功率（FE/t 当量），界面上写「热能」。 */
    public int thermalPower() {
        return this.desiredSteam * FE_PER_MB;
    }

    /** 上一 tick 实际产了多少蒸汽（mB/t）。 */
    public int steamPerTick() {
        return this.actualSteam;
    }

    public int statusCode() {
        return this.status;
    }

    /** 燃料已经烧坏了几个（熔毁的燃料棒数量）。 */
    public int meltedCount() {
        int total = 0;
        for (BlockPos pos : this.fuelPorts) {
            if (this.level != null && this.level.getBlockEntity(pos) instanceof FuelPortBlockEntity port) {
                for (int i = 0; i < FuelPortBlockEntity.SLOTS; i++) {
                    if (port.getItem(i).is(cn.blockforge.generated.aftercritical.registry.ModItems
                            .MELTED_FUEL_ROD.get())) {
                        total++;
                    }
                }
            }
        }
        return total;
    }

    // ------------------------------------------------------------------
    // 菜单
    // ------------------------------------------------------------------

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.pwr_controller");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new PwrControllerMenu(containerId, playerInventory, this);
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("RodDepth", this.rodDepth);
        tag.putDouble("Temperature", this.temperature);
        tag.putInt("OverheatTicks", this.overheatTicks);
        tag.putBoolean("Scrammed", this.scrammed);
        tag.putInt("BurnProgress", this.burnProgress);
        tag.put("Water", this.waterTank.writeToNBT(registries, new CompoundTag()));
        tag.put("Steam", this.steamTank.writeToNBT(registries, new CompoundTag()));
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.rodDepth = tag.getInt("RodDepth");
        this.temperature = tag.contains("Temperature") ? tag.getDouble("Temperature") : TEMP_AMBIENT;
        this.overheatTicks = tag.getInt("OverheatTicks");
        this.scrammed = tag.getBoolean("Scrammed");
        this.burnProgress = tag.getInt("BurnProgress");
        this.waterTank.readFromNBT(registries, tag.getCompound("Water"));
        this.steamTank.readFromNBT(registries, tag.getCompound("Steam"));
    }
}
