package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.AssemblerT3Menu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * 装配机 T3 的界面。
 *
 * <p>面板、能量条、箭头、底部文字全部继承自 {@link AbstractMachineScreen}，
 * 这里只写左下角那句提示。
 */
public class AssemblerT3Screen extends AbstractMachineScreen<AssemblerT3Menu> {

    public AssemblerT3Screen(AssemblerT3Menu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected Component hintLine() {
        return Component.translatable("gui.aftercritical.assembler_t3.hint");
    }
}
