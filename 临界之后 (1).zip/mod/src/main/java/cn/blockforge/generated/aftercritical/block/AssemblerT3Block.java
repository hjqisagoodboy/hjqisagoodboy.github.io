package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.AssemblerT3BlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/** 装配机 T3 方块：HV，300 FE/t，能做三级配方。 */
public class AssemblerT3Block extends TickingMachineBlock {

    public AssemblerT3Block(Properties properties) {
        super(properties, "HV", "tooltip.aftercritical.energy_per_tick",
                AssemblerT3BlockEntity.ENERGY_PER_TICK, "block.aftercritical.assembler_t3.desc");
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(AssemblerT3Block::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AssemblerT3BlockEntity(pos, state);
    }
}
