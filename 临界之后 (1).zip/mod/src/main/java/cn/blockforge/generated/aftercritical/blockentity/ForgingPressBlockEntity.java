package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.menu.ForgingPressMenu;
import cn.blockforge.generated.aftercritical.recipe.MachineRecipe;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModRecipes;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 锻压机方块实体：LV，运行功率 40 FE/t，10,000 FE 缓存，3 个槽。
 *
 * <p>槽位安排：槽 0 = 工具槽（放板材模具或线材模具，不消耗耐久），
 * 槽 1 = 物品输入槽，槽 2 = 物品输出槽。
 *
 * <p>配方来自 {@link ModRecipes#FORGING}，每条配方都规定了要用哪个模具：
 * 装板材模具压锭成板（2 个锭 → 1 块板）、4 个铁锭 → 1 个齿轮；
 * 装线材模具把铜锭拉成 4 根铜线。工具槽空着时锻压机不工作。
 */
public class ForgingPressBlockEntity extends MachineBlockEntity {

    /** 工具槽：放模具。 */
    public static final int SLOT_MOLD = 0;
    /** 物品输入槽。 */
    public static final int SLOT_INPUT = 1;
    /** 物品输出槽。 */
    public static final int SLOT_OUTPUT = 2;
    public static final int SLOT_COUNT = 3;

    /** 额定运行功率：40 FE/t（最终定稿 v4）。 */
    public static final int ENERGY_PER_TICK = 40;

    public ForgingPressBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.FORGING_PRESS.get(), pos, state, SLOT_COUNT, ENERGY_PER_TICK);
    }

    @Override
    protected int[] inputSlots() {
        return new int[]{SLOT_INPUT};
    }

    @Override
    protected int[] outputSlots() {
        return new int[]{SLOT_OUTPUT};
    }

    @Override
    protected int moldSlot() {
        return SLOT_MOLD;
    }

    @Override
    protected RecipeType<MachineRecipe> recipeType() {
        return ModRecipes.FORGING;
    }

    /** 工具槽里的模具必须和配方要的模具一致，否则这条配方不算数。 */
    @Override
    protected boolean isRecipeUsable(MachineRecipe recipe) {
        return recipe.moldMatches(getItem(SLOT_MOLD));
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.forging_press");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new ForgingPressMenu(containerId, playerInventory, this);
    }
}
