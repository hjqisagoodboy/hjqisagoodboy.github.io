package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.energy.BufferedEnergyStorage;
import cn.blockforge.generated.aftercritical.energy.WirelessEnergyGrid;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.IEnergyStorage;

import javax.annotation.Nullable;

/**
 * 能量端口的方块实体：一个 1,000,000 FE 的缓冲 + 一块「最近收到过无线供电」的登记。
 *
 * <p>托卡马克每 tick 直接把电推进来（{@link #receiveWireless(int)}），
 * 嬗变器控制器再从这儿抽走（{@link #takeEnergy(int)}）。
 * 方块本身没有界面，右键会在物品栏上方闪一行状态。
 */
public class EnergyPortBlockEntity extends BlockEntity {

    /** 缓冲容量：1,000,000 FE，刚好够嬗变器攒一次。 */
    public static final int CAPACITY = 1_000_000;
    /** 每 tick 最多收 / 送多少 FE（和托卡马克的无线功率对齐）。 */
    public static final int TRANSFER = 20_000;
    /** 多久没收到无线供电就算「断开」（tick）。 */
    private static final int LINK_TIMEOUT = 40;

    private final BufferedEnergyStorage energy =
            new BufferedEnergyStorage(CAPACITY, TRANSFER, TRANSFER, this::setChanged);

    /** 最后一次收到无线供电的游戏时间。 */
    private long lastWirelessTick = Long.MIN_VALUE;

    public EnergyPortBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ENERGY_PORT.get(), pos, state);
    }

    @Override
    public void onLoad() {
        super.onLoad();
        WirelessEnergyGrid.register(this);
    }

    @Override
    public void setRemoved() {
        WirelessEnergyGrid.unregister(this);
        super.setRemoved();
    }

    /** 给托卡马克调用的：无线灌电。返回真正收下的量。 */
    public int receiveWireless(int amount) {
        int accepted = this.energy.receiveEnergy(amount, false);
        if (accepted > 0 && this.level != null) {
            this.lastWirelessTick = this.level.getGameTime();
            setChanged();
        }
        return accepted;
    }

    /** 给嬗变器调用的：从端口里抽电。 */
    public int takeEnergy(int amount) {
        int taken = this.energy.extractEnergy(amount, false);
        if (taken > 0) {
            setChanged();
        }
        return taken;
    }

    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    public int capacity() {
        return CAPACITY;
    }

    public int freeSpace() {
        return this.energy.getFreeSpace();
    }

    /** 最近 2 秒内收到过无线供电就算「在线」。 */
    public boolean linkActive() {
        if (this.level == null || this.lastWirelessTick == Long.MIN_VALUE) {
            return false;
        }
        return this.level.getGameTime() - this.lastWirelessTick <= LINK_TIMEOUT;
    }

    /** 能力注册用。 */
    public IEnergyStorage getEnergyStorage() {
        return this.energy;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
    }

    /** 方便别的地方判空。 */
    public static boolean isPort(@Nullable BlockEntity blockEntity) {
        return blockEntity instanceof EnergyPortBlockEntity;
    }
}
