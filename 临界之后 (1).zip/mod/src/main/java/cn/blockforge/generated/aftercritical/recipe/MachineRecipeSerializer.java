package cn.blockforge.generated.aftercritical.recipe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * {@link MachineRecipe} 的读写器：负责把 JSON / 网络包和配方对象互相转换。
 *
 * <p>同一个读写器被所有「单进多出式」机器（破碎、球磨、锻压、压块）共用，
 * 区别只在构造时传进来的 {@code type}，这样这些机器可以用同一种配方格式。
 *
 * <p>原料有两种写法，读的时候都认：
 * <pre>{@code
 * // 新写法：多种原料（压块机 4 煤 + 1 粘土球）
 * "ingredients": [
 *   {"ingredient": {"item": "minecraft:coal"}, "count": 4},
 *   {"ingredient": {"item": "minecraft:clay_ball"}, "count": 1}
 * ]
 *
 * // 老写法：只有一种原料（破碎机 1 矿石）
 * "ingredient": {"item": "aftercritical:uranium_ore"},
 * "count": 1
 * }</pre>
 * 写出去的时候统一用新写法。
 */
public final class MachineRecipeSerializer implements RecipeSerializer<MachineRecipe> {

    /** JSON / 网络包里「一种原料 + 要几个」。 */
    private static final Codec<AssemblerIngredient> INGREDIENT_CODEC = RecordCodecBuilder.create(instance ->
            instance.group(
                    Ingredient.CODEC_NONEMPTY.fieldOf("ingredient").forGetter(AssemblerIngredient::ingredient),
                    Codec.INT.optionalFieldOf("count", 1).forGetter(AssemblerIngredient::count)
            ).apply(instance, AssemblerIngredient::new));

    private final RecipeType<MachineRecipe> type;
    private final MapCodec<MachineRecipe> codec;
    private final StreamCodec<RegistryFriendlyByteBuf, MachineRecipe> streamCodec;

    public MachineRecipeSerializer(RecipeType<MachineRecipe> type) {
        this.type = type;

        this.codec = RecordCodecBuilder.mapCodec(instance -> instance.group(
                INGREDIENT_CODEC.listOf().optionalFieldOf("ingredients", List.of())
                        .forGetter(MachineRecipe::ingredients),
                ItemStack.CODEC.fieldOf("result").forGetter(MachineRecipe::result),
                // 副产物（可选）：磨削机除了芯块还会掉一点废粉
                ItemStack.CODEC.optionalFieldOf("byproduct", ItemStack.EMPTY).forGetter(MachineRecipe::byproduct),
                Codec.INT.optionalFieldOf("time", 100).forGetter(MachineRecipe::duration),
                Ingredient.CODEC.optionalFieldOf("mold").forGetter(MachineRecipe::mold),
                // 老写法只读不写：这里给 getter 返回空，避免重新序列化时两种格式混在一起。
                Ingredient.CODEC.optionalFieldOf("ingredient").forGetter(recipe -> Optional.empty()),
                Codec.INT.optionalFieldOf("count", 1).forGetter(recipe -> 1)
        ).apply(instance, (ingredients, result, byproduct, time, mold, legacyIngredient, legacyCount) -> {
            List<AssemblerIngredient> resolved = new ArrayList<>(ingredients);
            if (resolved.isEmpty()) {
                legacyIngredient.ifPresent(ingredient ->
                        resolved.add(new AssemblerIngredient(ingredient, legacyCount)));
            }
            return new MachineRecipe(resolved, result, byproduct, time, mold, this);
        }));

        this.streamCodec = StreamCodec.of(
                (RegistryFriendlyByteBuf buf, MachineRecipe recipe) -> {
                    buf.writeVarInt(recipe.ingredients().size());
                    for (AssemblerIngredient spec : recipe.ingredients()) {
                        Ingredient.CONTENTS_STREAM_CODEC.encode(buf, spec.ingredient());
                        buf.writeVarInt(spec.count());
                    }
                    ItemStack.STREAM_CODEC.encode(buf, recipe.result());
                    buf.writeBoolean(!recipe.byproduct().isEmpty());
                    if (!recipe.byproduct().isEmpty()) {
                        ItemStack.STREAM_CODEC.encode(buf, recipe.byproduct());
                    }
                    buf.writeVarInt(recipe.duration());
                    buf.writeBoolean(recipe.mold().isPresent());
                    recipe.mold().ifPresent(mold -> Ingredient.CONTENTS_STREAM_CODEC.encode(buf, mold));
                },
                (RegistryFriendlyByteBuf buf) -> {
                    List<AssemblerIngredient> ingredients = new ArrayList<>();
                    for (int i = 0, size = buf.readVarInt(); i < size; i++) {
                        Ingredient ingredient = Ingredient.CONTENTS_STREAM_CODEC.decode(buf);
                        ingredients.add(new AssemblerIngredient(ingredient, buf.readVarInt()));
                    }
                    ItemStack result = ItemStack.STREAM_CODEC.decode(buf);
                    ItemStack byproduct = buf.readBoolean() ? ItemStack.STREAM_CODEC.decode(buf) : ItemStack.EMPTY;
                    int duration = buf.readVarInt();
                    Optional<Ingredient> mold = buf.readBoolean()
                            ? Optional.of(Ingredient.CONTENTS_STREAM_CODEC.decode(buf))
                            : Optional.empty();
                    return new MachineRecipe(ingredients, result, byproduct, duration, mold,
                            MachineRecipeSerializer.this);
                });
    }

    @Override
    public MapCodec<MachineRecipe> codec() {
        return this.codec;
    }

    @Override
    public StreamCodec<RegistryFriendlyByteBuf, MachineRecipe> streamCodec() {
        return this.streamCodec;
    }

    /** 这个读写器服务的配方类型（配方对象靠它回答 {@code getType()}）。 */
    public RecipeType<MachineRecipe> type() {
        return this.type;
    }
}
