package cn.blockforge.generated.aftercritical.recipe;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;

/**
 * 装配机配方里的「一种原料 + 要几个」。
 *
 * <p>破碎机、球磨机、锻压机一次只吃一种原料，所以它们的配方里只有一个 ingredient；
 * 装配机一次要吃好几种（电路板、金粒、红石、玻璃……），所以用这个类型组成一个列表。
 */
public record AssemblerIngredient(Ingredient ingredient, int count) {

    public AssemblerIngredient {
        count = Math.max(1, count);
    }

    /** 这一格里的物品够不够（种类对、数量够）。 */
    public boolean test(ItemStack stack) {
        return !stack.isEmpty() && this.ingredient.test(stack) && stack.getCount() >= this.count;
    }
}
