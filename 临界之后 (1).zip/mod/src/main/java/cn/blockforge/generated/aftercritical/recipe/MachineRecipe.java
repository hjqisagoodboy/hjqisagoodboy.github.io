package cn.blockforge.generated.aftercritical.recipe;

import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.Optional;

/**
 * 矿机/压块机共用的一种加工配方。
 *
 * <p>一条配方要写清楚四件事：放什么原料（{@code ingredients}，可以有好几种）、
 * 每种要几个（每种自带 {@code count}）、出什么东西（{@code result}）、
 * 加工多少 tick（{@code time}，20 tick = 1 秒）。
 *
 * <p>原料从「所有输入槽加起来」去凑：压块机 6 个输入槽，煤放哪几格、粘土球放哪一格都行，
 * 只要总数够。老格式（单个 {@code ingredient} + {@code count}）照样能读，不用改老配方。
 *
 * <p>锻压机多一个 {@code mold} 字段：这条配方要用哪个模具。模具只当工具用，加工时不会被消耗。
 *
 * <p>配方内容全部写在数据包里的 JSON 里（{@code data/aftercritical/recipe/} 目录），
 * 想加新配方只要加一个 JSON 文件，不用改代码。
 */
public final class MachineRecipe implements Recipe<MachineRecipeInput> {

    private final List<AssemblerIngredient> ingredients;
    private final ItemStack result;
    /** 副产物：除了 {@link #result} 之外额外掉的一份东西，没有就是空。磨削机掉废粉就是它。 */
    private final ItemStack byproduct;
    private final int duration;
    private final Optional<Ingredient> mold;
    private final MachineRecipeSerializer serializer;

    public MachineRecipe(List<AssemblerIngredient> ingredients, ItemStack result, int duration,
                         Optional<Ingredient> mold, MachineRecipeSerializer serializer) {
        this(ingredients, result, ItemStack.EMPTY, duration, mold, serializer);
    }

    /**
     * 带副产物的构造器。
     *
     * <p>磨削机磨完一份芯块会掉一点废粉，一份配方要吐两样东西，
     * 所以产物从「一个 ItemStack」改成「主产物 + 可选副产物」。
     * 其它机器的配方不写副产物，行为和老版本完全一样。
     */
    public MachineRecipe(List<AssemblerIngredient> ingredients, ItemStack result, ItemStack byproduct,
                         int duration, Optional<Ingredient> mold, MachineRecipeSerializer serializer) {
        this.ingredients = List.copyOf(ingredients);
        this.result = result;
        this.byproduct = byproduct == null ? ItemStack.EMPTY : byproduct;
        this.duration = Math.max(1, duration);
        this.mold = mold;
        this.serializer = serializer;
    }

    /** 老格式的便利构造：只有一种原料。 */
    public MachineRecipe(Ingredient ingredient, int count, ItemStack result, int duration,
                         Optional<Ingredient> mold, MachineRecipeSerializer serializer) {
        this(List.of(new AssemblerIngredient(ingredient, count)), result, duration, mold, serializer);
    }

    /**
     * 输入槽加起来凑得齐这条配方吗（种类对、数量够）。
     *
     * <p>一种原料一种原料地凑：先给第一种原料从各槽里凑够它要的数量，再凑下一种。
     * 同一个槽可以被多种原料共用（比如一槽煤先分给第一种原料）。
     * 模具不参与这里，由 {@link #moldMatches} 单独判断。
     */
    @Override
    public boolean matches(MachineRecipeInput input, Level level) {
        if (this.ingredients.isEmpty()) {
            return false;
        }
        for (AssemblerIngredient spec : this.ingredients) {
            int needed = spec.count();
            for (int i = 0; i < input.size() && needed > 0; i++) {
                ItemStack stack = input.getItem(i);
                if (!stack.isEmpty() && spec.ingredient().test(stack)) {
                    needed -= Math.min(needed, stack.getCount());
                }
            }
            if (needed > 0) {
                return false;
            }
        }
        return true;
    }

    /**
     * 真正扣料：按 {@link #matches} 同一套顺序，从这些槽里把原料拿走。
     *
     * <p>调用前必须已经确认 {@code matches} 通过，否则可能扣不够。
     */
    public void consume(List<ItemStack> slots) {
        for (AssemblerIngredient spec : this.ingredients) {
            int remaining = spec.count();
            for (ItemStack stack : slots) {
                if (remaining <= 0) {
                    break;
                }
                if (!stack.isEmpty() && spec.ingredient().test(stack)) {
                    int taken = Math.min(remaining, stack.getCount());
                    stack.shrink(taken);
                    remaining -= taken;
                }
            }
        }
    }

    /** 锻压机专用：工具槽里的模具对不对。没有模具要求的配方永远算「对」。 */
    public boolean moldMatches(ItemStack moldStack) {
        return this.mold.map(ingredient -> ingredient.test(moldStack)).orElse(true);
    }

    @Override
    public ItemStack assemble(MachineRecipeInput input, HolderLookup.Provider registries) {
        return this.result.copy();
    }

    @Override
    public ItemStack getResultItem(HolderLookup.Provider registries) {
        return this.result.copy();
    }

    /** 机器配方不在工作台里摆，这里恒为 true。 */
    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return true;
    }

    /** 不是工作台配方，配方书里不显示。 */
    @Override
    public boolean isSpecial() {
        return true;
    }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        NonNullList<Ingredient> list = NonNullList.create();
        this.mold.ifPresent(list::add);
        for (AssemblerIngredient spec : this.ingredients) {
            list.add(spec.ingredient());
        }
        return list;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return this.serializer;
    }

    @Override
    public RecipeType<?> getType() {
        return this.serializer.type();
    }

    /** 全部原料（每种一种 + 要几个）。 */
    public List<AssemblerIngredient> ingredients() {
        return this.ingredients;
    }

    /** 第一种原料，方便单原料机器/JEI 取用。 */
    public Ingredient ingredient() {
        return this.ingredients.get(0).ingredient();
    }

    /** 第一种原料要几个。 */
    public int ingredientCount() {
        return this.ingredients.get(0).count();
    }

    public ItemStack result() {
        return this.result;
    }

    /** 副产物（磨削机掉的废粉）；没有副产物时是空栈。 */
    public ItemStack byproduct() {
        return this.byproduct;
    }

    /** 一次加工吐出来的全部东西：主产物 + 副产物（空的自动跳过）。 */
    public List<ItemStack> results() {
        if (this.byproduct.isEmpty()) {
            return List.of(this.result);
        }
        return List.of(this.result, this.byproduct);
    }

    /** 加工时长，单位 tick。 */
    public int duration() {
        return this.duration;
    }

    public Optional<Ingredient> mold() {
        return this.mold;
    }
}
