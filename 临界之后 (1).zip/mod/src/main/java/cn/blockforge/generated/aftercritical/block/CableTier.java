package cn.blockforge.generated.aftercritical.block;

/**
 * 线缆等级。
 *
 * <p>两个数字决定一根线缆的本事：
 * <ul>
 *   <li>{@code maxTransfer}：每 tick 最多能过多少 FE（对外收发都卡这个数）；</li>
 *   <li>{@code capacity}：线缆自己的小缓存，够撑几 tick 的流量，免得发电机一停电就断供。</li>
 * </ul>
 *
 * <p>线缆本身不耗电：进来多少、出去多少，自己不扣一分。
 */
public enum CableTier {

    /** LV 线缆：80 FE/t。 */
    LV(80, 400, "LV"),

    /** MV 线缆：320 FE/t。 */
    MV(320, 1_600, "MV"),

    /** HV 线缆：2,560 FE/t，阶段 1 才做得出来（装配机 T2）。 */
    HV(2_560, 12_800, "HV");

    private final int maxTransfer;
    private final int capacity;
    private final String label;

    CableTier(int maxTransfer, int capacity, String label) {
        this.maxTransfer = maxTransfer;
        this.capacity = capacity;
        this.label = label;
    }

    /** 每 tick 最多过多少 FE。 */
    public int maxTransfer() {
        return this.maxTransfer;
    }

    /** 线缆内部缓存上限。 */
    public int capacity() {
        return this.capacity;
    }

    /** 界面/提示里显示的等级文字。 */
    public String label() {
        return this.label;
    }
}
