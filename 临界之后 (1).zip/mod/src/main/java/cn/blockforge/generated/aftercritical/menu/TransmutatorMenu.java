package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.TransmutatorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 物质嬗变器的界面：左边一格锕系元素、右边一格短寿命同位素，
 * 底下一串读数（结构、能量、无线端口、进度、状态）。
 */
public class TransmutatorMenu extends AbstractMachineMenu {

    /** 底部读数行数。 */
    public static final int STAT_LINES = 5;

    private static final int DATA_STATUS = 0;
    private static final int DATA_FORMED = 1;
    private static final int DATA_CASING = 2;
    private static final int DATA_COILS = 3;
    private static final int DATA_PORTS = 4;
    private static final int DATA_INPUT = 5;
    private static final int DATA_PROGRESS = 6;
    private static final int DATA_COUNT = 7;

    @Nullable
    private final TransmutatorControllerBlockEntity controller;

    private final int[] values = new int[DATA_COUNT];

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return index >= 0 && index < DATA_COUNT ? values[index] : 0;
        }

        @Override
        public void set(int index, int value) {
            if (index >= 0 && index < DATA_COUNT) {
                values[index] = value;
            }
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    /** 服务端用。 */
    public TransmutatorMenu(int containerId, Inventory playerInventory,
                            TransmutatorControllerBlockEntity controller) {
        this(containerId, playerInventory, (BlockEntity) controller);
    }

    /** 客户端用。 */
    public TransmutatorMenu(int containerId, Inventory playerInventory, @Nullable BlockEntity blockEntity) {
        super(ModMenus.TRANSMUTATOR_CONTROLLER.get(), containerId, playerInventory, 2,
                blockEntity instanceof TransmutatorControllerBlockEntity be ? be : null, 0);
        this.controller = blockEntity instanceof TransmutatorControllerBlockEntity be ? be : null;
        setTextLines(STAT_LINES);

        Container container = container(blockEntity);
        this.addSlot(new ActinidesSlot(container, TransmutatorControllerBlockEntity.SLOT_INPUT,
                MachineLayout.ITEM_X, MachineLayout.ITEM_Y));
        this.addSlot(new OutputSlot(container, TransmutatorControllerBlockEntity.SLOT_OUTPUT,
                MachineLayout.ITEM_X + 72, MachineLayout.ITEM_Y));

        this.addPlayerInventory(playerInventory);
        this.addDataSlots(this.data);
    }

    private static Container container(@Nullable BlockEntity blockEntity) {
        return blockEntity instanceof TransmutatorControllerBlockEntity be
                ? be
                : new SimpleContainer(2);
    }

    public static TransmutatorMenu fromNetwork(int containerId, Inventory playerInventory,
                                               RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        return new TransmutatorMenu(containerId, playerInventory,
                playerInventory.player.level().getBlockEntity(pos));
    }

    @Override
    public void broadcastChanges() {
        if (this.controller != null) {
            this.values[DATA_STATUS] = this.controller.statusCode();
            this.values[DATA_FORMED] = this.controller.isFormed() ? 1 : 0;
            this.values[DATA_CASING] = this.controller.casingCount();
            this.values[DATA_COILS] = this.controller.coilCount();
            this.values[DATA_PORTS] = this.controller.portCount();
            this.values[DATA_INPUT] = this.controller.inputCount();
            this.values[DATA_PROGRESS] = this.controller.progressPercent();
        }
        super.broadcastChanges();
    }

    public int status() {
        return this.values[DATA_STATUS];
    }

    public boolean isFormed() {
        return this.values[DATA_FORMED] != 0;
    }

    public int casing() {
        return this.values[DATA_CASING];
    }

    public int coils() {
        return this.values[DATA_COILS];
    }

    public int ports() {
        return this.values[DATA_PORTS];
    }

    public int input() {
        return this.values[DATA_INPUT];
    }

    public int progressPercent() {
        return this.values[DATA_PROGRESS];
    }

    @Override
    public int textY() {
        return MachineLayout.textY(0);
    }

    @Override
    public int inventoryLabelY() {
        return textY() + STAT_LINES * MachineLayout.TEXT_STEP + 3;
    }

    @Override
    public int inventoryY() {
        return inventoryLabelY() + 10;
    }

    @Override
    public int guiHeight() {
        return inventoryY() + 58 + 18 + 6;
    }

    /** 输入格：只收锕系元素。 */
    public static class ActinidesSlot extends Slot {

        public ActinidesSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.is(cn.blockforge.generated.aftercritical.registry.ModItems.ACTINIDES.get());
        }
    }
}
