package cn.blockforge.generated.aftercritical.registry;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.effect.RadiationEffect;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.effect.MobEffect;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** 自定义状态效果。 */
public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(BuiltInRegistries.MOB_EFFECT, AfterCritical.MOD_ID);

    /** 辐射沾染：每秒掉半颗心、挖掘变慢，最低扣到 1 点血。 */
    public static final DeferredHolder<MobEffect, RadiationEffect> RADIATION_CONTAMINATION =
            EFFECTS.register("radiation_contamination", RadiationEffect::new);

    private ModEffects() {}
}
