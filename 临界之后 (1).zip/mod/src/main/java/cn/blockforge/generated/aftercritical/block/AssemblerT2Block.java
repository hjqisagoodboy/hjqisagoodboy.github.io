package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.AssemblerT2BlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/** 装配机 T2 方块：MV，100 FE/t，装配机 T1 的升级版。 */
public class AssemblerT2Block extends TickingMachineBlock {

    public AssemblerT2Block(Properties properties) {
        super(properties, "MV", "tooltip.aftercritical.energy_per_tick",
                AssemblerT2BlockEntity.ENERGY_PER_TICK, "block.aftercritical.assembler_t2.desc");
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(AssemblerT2Block::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AssemblerT2BlockEntity(pos, state);
    }
}
