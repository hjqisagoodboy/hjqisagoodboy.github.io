package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.AssemblerT1BlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 装配机 T1 的 GUI 菜单：6 个输入槽（两行三列）+ 1 个化学品槽 + 1 个输出槽 + 玩家背包。
 *
 * <p>坐标全部来自 {@link MachineLayout}：中间两行原料、左下角一格放装着化学品的通用罐、
 * 右边箭头指着的就是产物槽。
 */
public class AssemblerT1Menu extends AbstractMachineMenu {

    /** 输入槽第一格、以及格与格之间的距离。 */
    public static final int INPUT_X = 30;
    public static final int INPUT_Y = 24;
    public static final int INPUT_STEP = 18;

    public static final int OUTPUT_X = 126;
    public static final int OUTPUT_Y = 24;

    /** 化学品槽：放装着硫酸这类液体的通用流体罐（配方里写的还是那一个罐子物品）。 */
    public static final int FLUID_X = 30;
    public static final int FLUID_Y = 60;

    /** 原料 → 产物那段箭头。 */
    public static final MachineLayout.Arrow ARROW = new MachineLayout.Arrow(90, 32, 30);

    /** 服务端用：直接拿方块实体当容器（T1 的菜单类型）。 */
    public AssemblerT1Menu(int containerId, Inventory playerInventory, AssemblerT1BlockEntity machine) {
        this(ModMenus.ASSEMBLER_T1.get(), containerId, playerInventory, machine, machine);
    }

    /** 指定菜单类型的版本：装配机 T2 借这一条把菜单类型换成自己的。 */
    public AssemblerT1Menu(MenuType<?> type, int containerId, Inventory playerInventory,
                           AssemblerT1BlockEntity machine) {
        this(type, containerId, playerInventory, machine, machine);
    }

    /** 客户端用：拿不到方块实体时，容器可以是个空壳，内容由同步包填。 */
    public AssemblerT1Menu(MenuType<?> type, int containerId, Inventory playerInventory, Container container,
                           @Nullable EnergyMachineHost machine) {
        super(type, containerId, playerInventory,
                AssemblerT1BlockEntity.SLOT_COUNT, machine);
        for (int i = 0; i < AssemblerT1BlockEntity.INPUT_SLOT_COUNT; i++) {
            int column = i % 3;
            int row = i / 3;
            this.addSlot(new InputSlot(container, AssemblerT1BlockEntity.SLOT_INPUT_FIRST + i,
                    INPUT_X + column * INPUT_STEP, INPUT_Y + row * INPUT_STEP));
        }
        this.addSlot(new OutputSlot(container, AssemblerT1BlockEntity.SLOT_OUTPUT, OUTPUT_X, OUTPUT_Y));
        this.addSlot(new FluidSlot(container, AssemblerT1BlockEntity.SLOT_FLUID, FLUID_X, FLUID_Y));
        this.addPlayerInventory(playerInventory);
    }

    @Override
    public MachineLayout.Arrow arrowGeometry() {
        return ARROW;
    }

    /** 客户端收到「打开菜单」的包后调用：从包里的坐标找回方块实体。 */
    public static AssemblerT1Menu fromNetwork(int containerId, Inventory playerInventory,
                                              RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof AssemblerT1BlockEntity assembler) {
            return new AssemblerT1Menu(ModMenus.ASSEMBLER_T1.get(), containerId, playerInventory, assembler);
        }
        return new AssemblerT1Menu(ModMenus.ASSEMBLER_T1.get(), containerId, playerInventory,
                new SimpleContainer(AssemblerT1BlockEntity.SLOT_COUNT), null);
    }

    /** 化学品槽：只认通用流体罐（空罐也行，装好的更好），配方里写的也是它。 */
    public static class FluidSlot extends Slot {

        public FluidSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.getItem() instanceof UniversalTankItem;
        }
    }
}
