package cn.blockforge.generated.aftercritical.blockentity;

import net.minecraft.world.Container;

/**
 * 界面读流体数据的接口。
 *
 * <p>界面每 tick 通过它问方块实体：第几号罐里有哪种流体、多少 mB。
 * 罐号是「先输入罐、后输出罐」顺着排的，具体哪个是输入、哪个是输出由
 * {@link FluidMachineKind} 决定。
 */
public interface FluidTankHost extends Container {

    /** 这台机器一共几个罐（输入 + 输出）。 */
    int getTankCount();

    /** 第 {@code index} 号罐里现在有多少 mB。 */
    int getTankAmount(int index);

    /** 第 {@code index} 号罐里流体的注册表编号；空罐返回 -1。 */
    int getTankFluidId(int index);

    /** 每个罐的容量（所有罐一样大）。 */
    int getTankCapacity();
}
