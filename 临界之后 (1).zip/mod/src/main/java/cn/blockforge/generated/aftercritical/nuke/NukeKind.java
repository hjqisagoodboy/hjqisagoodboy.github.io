package cn.blockforge.generated.aftercritical.nuke;

import java.util.List;

/**
 * 六颗核弹的「档案」：现实当量换算过来的爆炸半径、坑深、辐射时长，
 * 以及每颗弹自己的<b>装配图</b>——要哪几个组件、每个组件插在界面的什么位置。
 *
 * <p>这里只是数据，方块、物品、模型、成就都按 {@link #id} 自己去找。
 * 加一颗新核弹只要：这里加一行、{@code ModBlocks}/{@code ModItems} 各注册一个、
 * 再画个模型，别的代码不用动。
 *
 * <h2>为什么半径和坑深要分开给</h2>
 * 原来临界反应堆熔毁是「半径 120、坑深 42」，坑深按半径的 35% 走。
 * 核弹的当量差着三个数量级，威力越大不光要炸得宽，坑也得明显更深——
 * 沙皇的坑 155 格深，站在边上才能看出「这颗和那颗不是一个级别」。
 *
 * <h2>槽位坐标为什么要在这写</h2>
 * 每颗弹的界面按它现实里的内部结构摆：枪式的小男孩是一根长管子，五个组件从左到右
 * 顺着弹体排（引信→引发器→铀靶环→炮管→装药）；内爆的胖子、邱小姐是一个球，
 * 核心在正中间、炸药透镜和惰层围在两侧；两颗氢弹是「初级 + 次级」两节，
 * 上面还挂着一顶减速伞。坐标是 176×262 面板里的像素位置（槽的左上角）。
 */
public enum NukeKind {

    /** 小男孩：1.5 万吨，1945 年广岛。枪式结构。 */
    LITTLE_BOY("little_boy", 140, 56, 90, 100, Shape.GUN, List.of(
            new NukeSlot(NukeComponent.FUZE, 26, 46),
            new NukeSlot(NukeComponent.INITIATOR, 50, 46),
            new NukeSlot(NukeComponent.URANIUM_TARGET, 74, 46),
            new NukeSlot(NukeComponent.GUN_BARREL, 98, 46),
            new NukeSlot(NukeComponent.BOOSTER, 122, 46),
            new NukeSlot(NukeComponent.COBALT_SHELL, 74, 76))),
    /** 胖子：2.1 万吨，1945 年长崎。内爆式钚弹。 */
    FAT_MAN("fat_man", 155, 63, 100, 100, Shape.IMPLOSION, List.of(
            new NukeSlot(NukeComponent.FUZE, 80, 20),
            new NukeSlot(NukeComponent.COBALT_SHELL, 44, 48),
            new NukeSlot(NukeComponent.EXPLOSIVE_LENS, 62, 48),
            new NukeSlot(NukeComponent.PLUTONIUM_PIT, 80, 48),
            new NukeSlot(NukeComponent.TAMPER, 98, 48),
            new NukeSlot(NukeComponent.INITIATOR, 80, 76))),
    /** 邱小姐（596）：2.2 万吨，1964 年中国第一颗原子弹。内爆式铀弹。 */
    QIU("qiu", 160, 66, 105, 100, Shape.IMPLOSION, List.of(
            new NukeSlot(NukeComponent.FUZE, 80, 20),
            new NukeSlot(NukeComponent.EXPLOSIVE_LENS, 62, 48),
            new NukeSlot(NukeComponent.URANIUM_PIT, 80, 48),
            new NukeSlot(NukeComponent.REFLECTOR, 98, 48),
            new NukeSlot(NukeComponent.INITIATOR, 80, 76),
            new NukeSlot(NukeComponent.COBALT_SHELL, 98, 76))),
    /** 639-23：330 万吨，1967 年中国第一颗氢弹（工程代号 639）。两级结构。 */
    N639("639", 220, 100, 150, 120, Shape.TWO_STAGE, List.of(
            new NukeSlot(NukeComponent.INITIATOR, 26, 30),
            new NukeSlot(NukeComponent.FUZE, 62, 30),
            new NukeSlot(NukeComponent.BOOSTER, 110, 30),
            new NukeSlot(NukeComponent.PRIMARY, 26, 56),
            new NukeSlot(NukeComponent.DEUTERIUM_LITHIUM, 62, 56),
            new NukeSlot(NukeComponent.TAMPER, 86, 56),
            new NukeSlot(NukeComponent.COBALT_SHELL, 110, 78))),
    /** 常青藤（Ivy Mike）：1040 万吨，1952 年美国第一颗氢弹，液态氘低温装置。 */
    IVY_MIKE("ivy_mike", 260, 125, 180, 140, Shape.TWO_STAGE, List.of(
            new NukeSlot(NukeComponent.INITIATOR, 26, 30),
            new NukeSlot(NukeComponent.FUZE, 62, 30),
            new NukeSlot(NukeComponent.TAMPER, 110, 30),
            new NukeSlot(NukeComponent.PRIMARY, 26, 56),
            new NukeSlot(NukeComponent.CRYOSTAT, 62, 56),
            new NukeSlot(NukeComponent.DEUTERIUM_LITHIUM, 86, 56),
            new NukeSlot(NukeComponent.COBALT_SHELL, 110, 78))),
    /** 沙皇氢弹：5000 万吨，人类造过最大的一颗，带减速伞空投。 */
    TSAR("tsar", 300, 155, 240, 160, Shape.TWO_STAGE, List.of(
            new NukeSlot(NukeComponent.INITIATOR, 26, 30),
            new NukeSlot(NukeComponent.FUZE, 62, 30),
            new NukeSlot(NukeComponent.PARACHUTE, 110, 30),
            new NukeSlot(NukeComponent.PRIMARY, 26, 56),
            new NukeSlot(NukeComponent.DEUTERIUM_LITHIUM, 62, 56),
            new NukeSlot(NukeComponent.TAMPER, 86, 56),
            new NukeSlot(NukeComponent.COBALT_SHELL, 110, 78)));

    /** 界面上要画的「这颗弹长什么样」。 */
    public enum Shape {
        /** 枪式：一根长管，组件一溜排开。 */
        GUN,
        /** 内爆式：一个球，核心居中。 */
        IMPLOSION,
        /** 两级氢弹：初级 + 次级两节。 */
        TWO_STAGE
    }

    /**
     * 一个装配槽：装哪个组件、在界面里的哪个位置。
     *
     * @param component 这个槽只收这一种组件
     * @param x         槽的左上角 x（176 宽的面板坐标）
     * @param y         槽的左上角 y
     */
    public record NukeSlot(NukeComponent component, int x, int y) {
    }

    /** 注册名后缀：方块叫 {@code nuke_<id>}，物品也一样。 */
    public final String id;
    /** 破坏半径（格），也是蘑菇云的缩放基准（120 = 熔毁那一朵）。 */
    public final int radius;
    /** 坑深（格）：从爆心那格往下挖多少。 */
    public final int depth;
    /** 爆炸瞬间的辐射沾染持续多少秒（钴壳会再翻倍）。 */
    public final int radiationSeconds;
    /** 基础引信时长（tick，20 tick = 1 秒）；减速伞会翻倍。 */
    public final int fuseTicks;
    /** 界面里怎么画这颗弹。 */
    public final Shape shape;
    private final List<NukeSlot> slots;

    NukeKind(String id, int radius, int depth, int radiationSeconds, int fuseTicks, Shape shape,
             List<NukeSlot> slots) {
        this.id = id;
        this.radius = radius;
        this.depth = depth;
        this.radiationSeconds = radiationSeconds;
        this.fuseTicks = fuseTicks;
        this.shape = shape;
        this.slots = List.copyOf(slots);
    }

    /** 这颗弹的装配图：几个槽、每个槽收哪个组件、摆在哪。 */
    public List<NukeSlot> slots() {
        return this.slots;
    }

    /** 槽数（也是「满配」要装几个）。 */
    public int componentCount() {
        return this.slots.size();
    }

    /** 方块 / 物品的注册名，例如 {@code nuke_little_boy}。 */
    public String itemId() {
        return "nuke_" + this.id;
    }

    /** 按 id 找回来（方块注册名去掉 {@code nuke_} 后缀之后就是它）。 */
    public static NukeKind byId(String id) {
        for (NukeKind kind : values()) {
            if (kind.id.equals(id)) {
                return kind;
            }
        }
        return LITTLE_BOY;
    }

    /** 方块名字的语言键。 */
    public String langKey() {
        return "block.aftercritical.nuke_" + this.id;
    }

    /** 「现实当量」那一行提示的语言键。 */
    public String yieldKey() {
        return "tooltip.aftercritical.nuke_" + this.id + ".yield";
    }
}
