package cn.blockforge.generated.aftercritical.advancement;

import cn.blockforge.generated.aftercritical.block.MoltenOreBlock;
import cn.blockforge.generated.aftercritical.registry.ModBlocks;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.event.level.BlockEvent;

/**
 * 隐藏结局「轮回」的判定：玩家亲手挖到<b>核弹炸出来的</b>核熔钻石矿和核熔绿宝石矿。
 *
 * <p>为什么不能像别的成就那样用「背包里出现某物品」来判：核熔矿有两种来路——
 * 玩家起爆的核弹，和堆芯熔毁。熔毁走的也是同一套核爆流程（见
 * {@code ReactorControllerBlockEntity#meltDown}），坑底照样会结出核熔矿，
 * 光看背包根本分不出手里这块是哪种。所以标记打在方块状态上
 * （{@link MoltenOreBlock#FROM_NUKE}），这里只在挖掉「带标记的那一块」时才喊话。
 *
 * <p>几件顺带保证的事：
 * <ul>
 *   <li>熔毁废墟里的核熔矿标记是 {@code false}，挖了不算；</li>
 *   <li>挖下来再摆回去的方块会变回 {@code false}（物品不带状态），所以「自己摆一块再挖」骗不到成就；</li>
 *   <li>工具不对（徒手、木镐砸）拿不到矿，也就不算「挖到」——这两样都要铁镐才掉东西。</li>
 * </ul>
 */
public final class MoltenOreHarvest {

    /** 挂在游戏总线上：玩家破坏方块之前先看一眼，是核熔矿就记一笔。 */
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        BlockState state = event.getState();
        // 不是核熔矿、或者是熔毁 / 玩家自己摆的那种，直接走人
        if (!(state.getBlock() instanceof MoltenOreBlock) || !state.getValue(MoltenOreBlock.FROM_NUKE)) {
            return;
        }
        Player player = event.getPlayer();
        // 创造模式手里没工具也能挖下来，就当挖到了
        if (!player.isCreative() && !player.hasCorrectToolForDrops(state)) {
            return;
        }
        if (state.is(ModBlocks.NUCLEAR_MOLTEN_DIAMOND_ORE.get())) {
            ModAdvancementTriggers.fire(player, ModAdvancementTriggers.MOLTEN_DIAMOND_MINED);
        } else if (state.is(ModBlocks.NUCLEAR_MOLTEN_EMERALD_ORE.get())) {
            ModAdvancementTriggers.fire(player, ModAdvancementTriggers.MOLTEN_EMERALD_MINED);
        }
    }

    private MoltenOreHarvest() {}
}
