package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.BatteryLvMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** 电池 LV 的界面：只有一条大能量条 + 电量数字，没有物品槽和箭头。 */
public class BatteryLvScreen extends AbstractMachineScreen<BatteryLvMenu> {

    public BatteryLvScreen(BatteryLvMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }
}
