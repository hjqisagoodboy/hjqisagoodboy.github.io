package cn.blockforge.generated.aftercritical.registry;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.item.FluidIdentifierItem;
import cn.blockforge.generated.aftercritical.item.HammerItem;
import cn.blockforge.generated.aftercritical.item.DetonatorItem;
import cn.blockforge.generated.aftercritical.item.MoldItem;
import cn.blockforge.generated.aftercritical.item.NukeComponentItem;
import cn.blockforge.generated.aftercritical.item.RadiationSuitItem;
import cn.blockforge.generated.aftercritical.item.TooltipItem;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import cn.blockforge.generated.aftercritical.nuke.NukeComponent;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.material.Fluids;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 模组里所有物品都在这里登记。
 *
 * <p>方块物品（矿石、机器）只是方块的「手上的版本」，真正的方块在 {@code ModBlocks}。
 * 下面那些「中间件」是阶段 0 的原料和零件，由工作台、熔炉和机器加工出来，
 * 再拿去合成更高一级的东西。
 */
public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(AfterCritical.MOD_ID);

    public static final DeferredItem<BlockItem> URANIUM_ORE = ITEMS.registerSimpleBlockItem(ModBlocks.URANIUM_ORE);
    public static final DeferredItem<BlockItem> LEAD_ORE = ITEMS.registerSimpleBlockItem(ModBlocks.LEAD_ORE);
    public static final DeferredItem<BlockItem> SPODUMENE_ORE = ITEMS.registerSimpleBlockItem(ModBlocks.SPODUMENE_ORE);
    public static final DeferredItem<BlockItem> BORAX_ORE = ITEMS.registerSimpleBlockItem(ModBlocks.BORAX_ORE);
    public static final DeferredItem<BlockItem> BERYL_ORE = ITEMS.registerSimpleBlockItem(ModBlocks.BERYL_ORE);
    public static final DeferredItem<BlockItem> ZIRCON_ORE = ITEMS.registerSimpleBlockItem(ModBlocks.ZIRCON_ORE);

    /** 破碎机方块物品。 */
    public static final DeferredItem<BlockItem> CRUSHER = ITEMS.registerSimpleBlockItem(ModBlocks.CRUSHER);

    /** 球磨机方块物品。 */
    public static final DeferredItem<BlockItem> BALL_MILL = ITEMS.registerSimpleBlockItem(ModBlocks.BALL_MILL);

    /** 锻压机方块物品。 */
    public static final DeferredItem<BlockItem> FORGING_PRESS = ITEMS.registerSimpleBlockItem(ModBlocks.FORGING_PRESS);

    /** 压块机方块物品。 */
    public static final DeferredItem<BlockItem> COMPACTOR = ITEMS.registerSimpleBlockItem(ModBlocks.COMPACTOR);

    /** 板材模具：锻压机的工具槽物品。 */
    public static final DeferredItem<MoldItem> PLATE_MOLD = ITEMS.registerItem("plate_mold", MoldItem::new);

    /** 线材模具：锻压机的工具槽物品。 */
    public static final DeferredItem<MoldItem> WIRE_MOLD = ITEMS.registerItem("wire_mold", MoldItem::new);

    /** 锤子：工作台上做两个模具用的工具，会磨损耐久但不会被吃掉。 */
    public static final DeferredItem<HammerItem> HAMMER = ITEMS.registerItem(
            "hammer", HammerItem::new, new Item.Properties().durability(HammerItem.DURABILITY));

    // ------------------------------------------------------------------
    // 中间件：板材（由锻压机压出来）
    // ------------------------------------------------------------------

    /** 铁板。 */
    public static final DeferredItem<Item> IRON_PLATE = ITEMS.registerSimpleItem("iron_plate");

    /** 钢板。 */
    public static final DeferredItem<Item> STEEL_PLATE = ITEMS.registerSimpleItem("steel_plate");

    /** 铅板。 */
    public static final DeferredItem<Item> LEAD_PLATE = ITEMS.registerSimpleItem("lead_plate");

    /** 铜板。 */
    public static final DeferredItem<Item> COPPER_PLATE = ITEMS.registerSimpleItem("copper_plate");

    /** 金板。 */
    public static final DeferredItem<Item> GOLD_PLATE = ITEMS.registerSimpleItem("gold_plate");

    /** 齿轮。 */
    public static final DeferredItem<Item> GEAR = ITEMS.registerSimpleItem("gear");

    // ------------------------------------------------------------------
    // 中间件：锭
    // ------------------------------------------------------------------

    /** 钢锭：高碳铁在熔炉里用煤炭烧 10 秒得到。 */
    public static final DeferredItem<TooltipItem> STEEL_INGOT = ITEMS.registerItem(
            "steel_ingot", properties -> new TooltipItem(properties, "tooltip.aftercritical.steel_ingot"));

    /** 铅锭。 */
    public static final DeferredItem<Item> LEAD_INGOT = ITEMS.registerSimpleItem("lead_ingot");

    /** 锆锭。 */
    public static final DeferredItem<Item> ZIRCON_INGOT = ITEMS.registerSimpleItem("zircon_ingot");

    /** 高碳铁：铁锭在熔炉里用煤炭烧 10 秒得到，再烧一次就是钢锭。 */
    public static final DeferredItem<TooltipItem> HIGH_CARBON_IRON = ITEMS.registerItem(
            "high_carbon_iron", properties -> new TooltipItem(properties, "tooltip.aftercritical.high_carbon_iron"));

    // ------------------------------------------------------------------
    // 中间件：零件
    // ------------------------------------------------------------------

    /** 铜线：线材模具压出来的细铜丝。 */
    public static final DeferredItem<Item> COPPER_WIRE = ITEMS.registerSimpleItem("copper_wire");

    /** 铜线圈：一圈缠好的铜线，电机的绕组。 */
    public static final DeferredItem<Item> COPPER_COIL = ITEMS.registerSimpleItem("copper_coil");

    /** 铜管。 */
    public static final DeferredItem<Item> COPPER_PIPE = ITEMS.registerSimpleItem("copper_pipe");

    /** 阀门：管路上开关流体的零件。 */
    public static final DeferredItem<Item> VALVE = ITEMS.registerSimpleItem("valve");

    /** 电路板 T1：第一代电路板，装配机以前的所有机器都靠它。 */
    public static final DeferredItem<Item> CIRCUIT_BOARD_T1 = ITEMS.registerSimpleItem("circuit_board_t1");

    /** 电路板 T2：第二代电路板，只能由装配机 T1 生产。 */
    public static final DeferredItem<Item> CIRCUIT_BOARD_T2 = ITEMS.registerSimpleItem("circuit_board_t2");

    /** 电机 LV：低压电机，运行耗电 8 FE/t。 */
    public static final DeferredItem<TooltipItem> MOTOR_LV = ITEMS.registerItem(
            "motor_lv", properties -> new TooltipItem(properties, "tooltip.aftercritical.motor_lv"));

    /** 机械臂 LV：低压机械臂，运行耗电 8 FE/t。 */
    public static final DeferredItem<TooltipItem> ROBOT_ARM_LV = ITEMS.registerItem(
            "robot_arm_lv", properties -> new TooltipItem(properties, "tooltip.aftercritical.robot_arm_lv"));

    /** 泵 LV：低压泵，运行耗电 8 FE/t。 */
    public static final DeferredItem<TooltipItem> PUMP_LV = ITEMS.registerItem(
            "pump_lv", properties -> new TooltipItem(properties, "tooltip.aftercritical.pump_lv"));

    /** 电机 MV：中压电机，装配机做出来的更劲的电机。 */
    public static final DeferredItem<TooltipItem> MOTOR_MV = ITEMS.registerItem(
            "motor_mv", properties -> new TooltipItem(properties, "tooltip.aftercritical.motor_mv"));

    /** 泵 MV：中压泵，运行耗电 16 FE/t。 */
    public static final DeferredItem<TooltipItem> PUMP_MV = ITEMS.registerItem(
            "pump_mv", properties -> new TooltipItem(properties, "tooltip.aftercritical.pump_mv"));

    /**
     * 机械臂 MV：中压机械臂，运行耗电 16 FE/t。
     *
     * <p>阶段 1 的中间件：机器要做「自动把物品从 A 搬到 B」就得装它。
     */
    public static final DeferredItem<TooltipItem> ROBOT_ARM_MV = ITEMS.registerItem(
            "robot_arm_mv", properties -> new TooltipItem(properties, "tooltip.aftercritical.robot_arm_mv"));

    /**
     * 加热器 LV：低压加热器，只是中间件，自己不耗电。
     *
     * <p>干燥炉、烧结这类要「加热」的机器都要装它。
     */
    public static final DeferredItem<TooltipItem> HEATER_LV = ITEMS.registerItem(
            "heater_lv", properties -> new TooltipItem(properties, "tooltip.aftercritical.heater_lv"));

    /** 加热器 HV：高压加热器，同样是中间件，不耗电。 */
    public static final DeferredItem<TooltipItem> HEATER_HV = ITEMS.registerItem(
            "heater_hv", properties -> new TooltipItem(properties, "tooltip.aftercritical.heater_hv"));

    /** 煤燃料棒：燃料棒发电机烧的燃料，一根 5 分钟。 */
    public static final DeferredItem<TooltipItem> COAL_FUEL_ROD = ITEMS.registerItem(
            "coal_fuel_rod", properties -> new TooltipItem(properties, "tooltip.aftercritical.coal_fuel_rod"));


    // ------------------------------------------------------------------
    // 流体容器：通用流体罐 + 流体识别码
    // ------------------------------------------------------------------

    /**
     * 通用流体罐：全模组唯一的罐子物品，能装 1000 mB 任意流体。
     *
     * <p>空的是它、装了硫酸的也是它——区别只在数据组件里写了什么。
     * 贴图会按里面的流体染色，名字会变成「硫酸流体罐」，同类同量的罐子能叠 64 个。
     */
    public static final DeferredItem<UniversalTankItem> UNIVERSAL_FLUID_TANK =
            ITEMS.registerItem("universal_fluid_tank", UniversalTankItem::new);

    /**
     * 流体识别码：给智能流体管道盖章用的小工具。
     *
     * <p>右键装着流体的罐子绑定流体，再右键管道盖章；本身不消耗。
     */
    public static final DeferredItem<FluidIdentifierItem> FLUID_IDENTIFIER =
            ITEMS.registerItem("fluid_identifier", FluidIdentifierItem::new);

    // ------------------------------------------------------------------
    // 阶段 1 的中间产物（黄饼 → 六氟化铀这条线）
    // ------------------------------------------------------------------

    /** 铀矿渣：浸出槽把铀泡出来之后剩的渣子。 */
    public static final DeferredItem<Item> URANIUM_SLAG = ITEMS.registerSimpleItem("uranium_slag");

    /** 黄饼：沉淀槽析出来的粗铀化合物。 */
    public static final DeferredItem<Item> YELLOWCAKE = ITEMS.registerSimpleItem("yellowcake");

    /** 干燥黄饼：烤掉水分的黄饼，化工厂拿它配硝酸。 */
    public static final DeferredItem<Item> DRIED_YELLOWCAKE = ITEMS.registerSimpleItem("dried_yellowcake");

    /** 二氧化铀粉（UO₂）：转化炉里把硝酸铀酰还原出来的产物。 */
    public static final DeferredItem<Item> UO2_POWDER = ITEMS.registerSimpleItem("uo2_powder");

    /** 四氟化铀（UF₄）：绿色粉末，氟化反应器的原料。 */
    public static final DeferredItem<Item> UF4 = ITEMS.registerSimpleItem("uf4");

    /** 天然铀：天然丰度的金属铀，阶段 2 的燃料线从这里开始。 */
    public static final DeferredItem<Item> NATURAL_URANIUM = ITEMS.registerSimpleItem("natural_uranium");

    // ------------------------------------------------------------------
    // 阶段 2 的中间件（气体离心机、燃料制造链要用）
    // ------------------------------------------------------------------

    /**
     * 传感器：工作台上用电路板 T1 + 红石 + 玻璃做的小零件。
     *
     * <p>级联控制器要用 4 个——它得「看得见」周围的离心机。
     */
    public static final DeferredItem<TooltipItem> SENSOR = ITEMS.registerItem(
            "sensor", properties -> new TooltipItem(properties, "tooltip.aftercritical.sensor"));

    /** 电路板 T3：第三代电路板，只有装配机 T2 做得出来。 */
    public static final DeferredItem<Item> CIRCUIT_BOARD_T3 = ITEMS.registerSimpleItem("circuit_board_t3");

    /** 电路板 T4：第四代电路板，装配机 T3 才做得出来，压水堆控制器要靠它。 */
    public static final DeferredItem<Item> CIRCUIT_BOARD_T4 = ITEMS.registerSimpleItem("circuit_board_t4");

    /** 锆合金管：核燃料棒的包壳管，装配机 T1 用锆锭拉出来。 */
    public static final DeferredItem<Item> ZIRCONIUM_ALLOY_PIPE = ITEMS.registerSimpleItem("zirconium_alloy_pipe");

    /** 锆合金框架：燃料组件的骨架，组装机 T2 用锆合金管焊出来。 */
    public static final DeferredItem<Item> ZIRCONIUM_ALLOY_FRAME =
            ITEMS.registerSimpleItem("zirconium_alloy_frame");

    /** 端塞：把燃料棒两头封死的小盖子，1 个锆锭做 2 个。 */
    public static final DeferredItem<Item> END_PLUG = ITEMS.registerSimpleItem("end_plug");

    // ------------------------------------------------------------------
    // 新一轮机器的方块物品
    // ------------------------------------------------------------------

    /** 装配机 T1 方块物品。 */
    public static final DeferredItem<BlockItem> ASSEMBLER_T1 = ITEMS.registerSimpleBlockItem(ModBlocks.ASSEMBLER_T1);

    /** 燃烧发电机方块物品。 */
    public static final DeferredItem<BlockItem> COMBUSTION_GENERATOR =
            ITEMS.registerSimpleBlockItem(ModBlocks.COMBUSTION_GENERATOR);

    /** 燃料棒发电机方块物品。 */
    public static final DeferredItem<BlockItem> FUEL_ROD_GENERATOR =
            ITEMS.registerSimpleBlockItem(ModBlocks.FUEL_ROD_GENERATOR);

    /** 电池 LV 方块物品。 */
    public static final DeferredItem<BlockItem> BATTERY_LV = ITEMS.registerSimpleBlockItem(ModBlocks.BATTERY_LV);

    /** 电解槽方块物品。 */
    public static final DeferredItem<BlockItem> ELECTROLYZER = ITEMS.registerSimpleBlockItem(ModBlocks.ELECTROLYZER);

    /** 化工厂方块物品。 */
    public static final DeferredItem<BlockItem> CHEMICAL_PLANT = ITEMS.registerSimpleBlockItem(ModBlocks.CHEMICAL_PLANT);

    /** 空气分离器方块物品。 */
    public static final DeferredItem<BlockItem> AIR_SEPARATOR = ITEMS.registerSimpleBlockItem(ModBlocks.AIR_SEPARATOR);

    /** 地下水开采机方块物品。 */
    public static final DeferredItem<BlockItem> GROUNDWATER_PUMP =
            ITEMS.registerSimpleBlockItem(ModBlocks.GROUNDWATER_PUMP);

    // ------------------------------------------------------------------
    // 阶段 1 的五台流体机器与高压电网
    // ------------------------------------------------------------------

    /** 浸出槽方块物品。 */
    public static final DeferredItem<BlockItem> LEACHING_TANK =
            ITEMS.registerSimpleBlockItem(ModBlocks.LEACHING_TANK);

    /** 沉淀槽方块物品。 */
    public static final DeferredItem<BlockItem> PRECIPITATION_TANK =
            ITEMS.registerSimpleBlockItem(ModBlocks.PRECIPITATION_TANK);

    /** 干燥炉方块物品。 */
    public static final DeferredItem<BlockItem> DRYING_OVEN =
            ITEMS.registerSimpleBlockItem(ModBlocks.DRYING_OVEN);

    /** 转化炉方块物品。 */
    public static final DeferredItem<BlockItem> CONVERTER =
            ITEMS.registerSimpleBlockItem(ModBlocks.CONVERTER);

    /** 氟化反应器方块物品。 */
    public static final DeferredItem<BlockItem> FLUORINATION_REACTOR =
            ITEMS.registerSimpleBlockItem(ModBlocks.FLUORINATION_REACTOR);

    /** 装配机 T2 方块物品。 */
    public static final DeferredItem<BlockItem> ASSEMBLER_T2 =
            ITEMS.registerSimpleBlockItem(ModBlocks.ASSEMBLER_T2);

    /** HV 线缆方块物品。 */
    public static final DeferredItem<BlockItem> HV_CABLE = ITEMS.registerSimpleBlockItem(ModBlocks.HV_CABLE);

    /** 变压器 MV→HV 方块物品。 */
    public static final DeferredItem<BlockItem> TRANSFORMER_MV_HV =
            ITEMS.registerSimpleBlockItem(ModBlocks.TRANSFORMER_MV_HV);

    /** 铅块方块物品。 */
    public static final DeferredItem<BlockItem> LEAD_BLOCK = ITEMS.registerSimpleBlockItem(ModBlocks.LEAD_BLOCK);

    /** 储罐多方块控制器方块物品。 */
    public static final DeferredItem<BlockItem> TANK_CONTROLLER =
            ITEMS.registerSimpleBlockItem(ModBlocks.TANK_CONTROLLER);

    /** 储罐流体输入口方块物品。 */
    public static final DeferredItem<BlockItem> TANK_INPUT_PORT =
            ITEMS.registerSimpleBlockItem(ModBlocks.TANK_INPUT_PORT);

    /** 储罐流体输出口方块物品。 */
    public static final DeferredItem<BlockItem> TANK_OUTPUT_PORT =
            ITEMS.registerSimpleBlockItem(ModBlocks.TANK_OUTPUT_PORT);

    /** LV 线缆方块物品。 */
    public static final DeferredItem<BlockItem> LV_CABLE = ITEMS.registerSimpleBlockItem(ModBlocks.LV_CABLE);

    /** MV 线缆方块物品。 */
    public static final DeferredItem<BlockItem> MV_CABLE = ITEMS.registerSimpleBlockItem(ModBlocks.MV_CABLE);

    /** 变压器 LV→MV 方块物品。 */
    public static final DeferredItem<BlockItem> TRANSFORMER_LV_MV =
            ITEMS.registerSimpleBlockItem(ModBlocks.TRANSFORMER_LV_MV);

    /** 物品管道方块物品。 */
    public static final DeferredItem<BlockItem> ITEM_PIPE = ITEMS.registerSimpleBlockItem(ModBlocks.ITEM_PIPE);

    /** 智能流体管道方块物品。 */
    public static final DeferredItem<BlockItem> SMART_FLUID_DUCT =
            ITEMS.registerSimpleBlockItem(ModBlocks.SMART_FLUID_DUCT);

    // ------------------------------------------------------------------
    // 阶段 2 的三台新机器
    // ------------------------------------------------------------------

    /** 气体离心机方块物品：把六氟化铀分成低浓缩铀和贫铀。 */
    public static final DeferredItem<BlockItem> GAS_CENTRIFUGE =
            ITEMS.registerSimpleBlockItem(ModBlocks.GAS_CENTRIFUGE);

    /** 水解反应器方块物品：低浓缩六氟化铀加水 → 二氧化铀粉 + 氢氟酸。 */
    public static final DeferredItem<BlockItem> HYDROLYSIS_REACTOR =
            ITEMS.registerSimpleBlockItem(ModBlocks.HYDROLYSIS_REACTOR);

    /** 级联控制器方块物品：统一给一堆离心机喂料、收成品。 */
    public static final DeferredItem<BlockItem> CASCADE_CONTROLLER =
            ITEMS.registerSimpleBlockItem(ModBlocks.CASCADE_CONTROLLER);

    // ------------------------------------------------------------------
    // 阶段 2 燃料制造链的机器
    // ------------------------------------------------------------------

    /** 烧结炉方块物品：把芯块坯烧硬。 */
    public static final DeferredItem<BlockItem> SINTERING_FURNACE =
            ITEMS.registerSimpleBlockItem(ModBlocks.SINTERING_FURNACE);

    /** 磨削机方块物品：把烧结芯块磨到尺寸。 */
    public static final DeferredItem<BlockItem> GRINDING_MACHINE =
            ITEMS.registerSimpleBlockItem(ModBlocks.GRINDING_MACHINE);

    /** 焊接机方块物品：给燃料棒焊端塞。 */
    public static final DeferredItem<BlockItem> WELDING_MACHINE =
            ITEMS.registerSimpleBlockItem(ModBlocks.WELDING_MACHINE);

    /** 物流控制器方块物品：把管道的货朝六个方向轮流分出去。 */
    public static final DeferredItem<BlockItem> LOGISTICS_CONTROLLER =
            ITEMS.registerSimpleBlockItem(ModBlocks.LOGISTICS_CONTROLLER);

    // ------------------------------------------------------------------
    // 阶段 2 燃料制造链的物品（离心 → 水解 → 压块 → 烧结 → 磨削 → 焊接 → 组装）
    // ------------------------------------------------------------------

    /** 粘合剂：压块机把二氧化铀粉压成芯块坯时加的胶。 */
    public static final DeferredItem<TooltipItem> BINDER = ITEMS.registerItem(
            "binder", properties -> new TooltipItem(properties, "tooltip.aftercritical.binder"));

    /** 低浓缩二氧化铀粉：低浓缩六氟化铀水解出来的粉末。 */
    public static final DeferredItem<Item> LEU_UO2_POWDER = ITEMS.registerSimpleItem("leu_uo2_powder");

    /** 燃料芯块坯：压块机压出来、还没烧的「生坯」。 */
    public static final DeferredItem<Item> FUEL_PELLET_BLANK = ITEMS.registerSimpleItem("fuel_pellet_blank");

    /** 烧结芯块：烧结炉里烧硬的芯块。 */
    public static final DeferredItem<Item> SINTERED_PELLET = ITEMS.registerSimpleItem("sintered_pellet");

    /** 精磨芯块：磨到精确尺寸、可以直接装棒的芯块。 */
    public static final DeferredItem<Item> GROUND_PELLET = ITEMS.registerSimpleItem("ground_pellet");

    /** 废粉：磨削时掉下来的碎屑，目前没用途，先留着以后做回收。 */
    public static final DeferredItem<TooltipItem> SCRAP_DUST = ITEMS.registerItem(
            "scrap_dust", properties -> new TooltipItem(properties, "tooltip.aftercritical.scrap_dust"));

    /** 燃料棒：装满芯块的锆合金管，还没封口。 */
    public static final DeferredItem<TooltipItem> FUEL_ROD = ITEMS.registerItem(
            "fuel_rod", properties -> new TooltipItem(properties, "tooltip.aftercritical.fuel_rod"));

    /** 密封燃料棒：两头焊上端塞的成品燃料棒。 */
    public static final DeferredItem<TooltipItem> SEALED_FUEL_ROD = ITEMS.registerItem(
            "sealed_fuel_rod", properties -> new TooltipItem(properties, "tooltip.aftercritical.sealed_fuel_rod"));

    /** LEU 燃料组件：一捆密封燃料棒装进锆合金框架里。 */
    public static final DeferredItem<TooltipItem> LEU_FUEL_ASSEMBLY = ITEMS.registerItem(
            "leu_fuel_assembly", properties -> new TooltipItem(properties,
                    "tooltip.aftercritical.leu_fuel_assembly"));

    /** 天然铀棒：天然铀做的燃料棒，不浓缩也能用。 */
    public static final DeferredItem<Item> NATURAL_URANIUM_ROD = ITEMS.registerSimpleItem("natural_uranium_rod");

    /** 天然铀棒束：一捆天然铀棒。 */
    public static final DeferredItem<Item> NATURAL_URANIUM_ROD_BUNDLE =
            ITEMS.registerSimpleItem("natural_uranium_rod_bundle");

    /** 贫铀：贫化六氟化铀还原出来的金属铀，密度高、很重。 */
    public static final DeferredItem<TooltipItem> DEPLETED_URANIUM = ITEMS.registerItem(
            "depleted_uranium", properties -> new TooltipItem(properties, "tooltip.aftercritical.depleted_uranium"));

    // ------------------------------------------------------------------
    // 线缆材料
    // ------------------------------------------------------------------

    /** 绝缘布：羊毛加粘液球压出来的线缆外皮。 */
    public static final DeferredItem<TooltipItem> INSULATION_CLOTH = ITEMS.registerItem(
            "insulation_cloth", properties -> new TooltipItem(properties, "tooltip.aftercritical.insulation_cloth"));

    /**
     * MV 线缆芯：8 根铜线加 1 个钢锭扭成的一束粗芯。
     *
     * <p>之所以拆成「线缆芯 → 包绝缘皮」两步：工作台只有 9 个格子，
     * 铜线×8 + 钢锭×1 + 绝缘布×2 一共 11 个物品，一锅炒不下。
     * 两步合起来的材料比例和设计稿完全一致。
     */
    public static final DeferredItem<TooltipItem> MV_CABLE_CORE = ITEMS.registerItem(
            "mv_cable_core", properties -> new TooltipItem(properties, "tooltip.aftercritical.mv_cable_core"));

    // ------------------------------------------------------------------
    // 矿粉：石磨、破碎机磨出来的粉末
    // ------------------------------------------------------------------

    /** 铀矿粉。 */
    public static final DeferredItem<Item> URANIUM_DUST = ITEMS.registerSimpleItem("uranium_dust");

    /** 细铀矿粉。 */
    public static final DeferredItem<Item> FINE_URANIUM_DUST = ITEMS.registerSimpleItem("fine_uranium_dust");

    /** 铅矿粉。 */
    public static final DeferredItem<Item> LEAD_DUST = ITEMS.registerSimpleItem("lead_dust");

    /** 锆石粉。 */
    public static final DeferredItem<Item> ZIRCON_DUST = ITEMS.registerSimpleItem("zircon_dust");

    /** 硼粉。 */
    public static final DeferredItem<Item> BORON_DUST = ITEMS.registerSimpleItem("boron_dust");

    /** 铍粉。 */
    public static final DeferredItem<Item> BERYLLIUM_DUST = ITEMS.registerSimpleItem("beryllium_dust");

    /** 锂粉。 */
    public static final DeferredItem<Item> LITHIUM_DUST = ITEMS.registerSimpleItem("lithium_dust");

    // ------------------------------------------------------------------
    // 阶段 3：中子物理与临界实验
    // ------------------------------------------------------------------

    /** 硼板：硼粉加钢板压出来，控制棒和中子探测器的吸收体。 */
    public static final DeferredItem<Item> BORON_PLATE = ITEMS.registerSimpleItem("boron_plate");

    /** 铍板：铍粉加钢板压出来，反射层块和中子源的原料。 */
    public static final DeferredItem<Item> BERYLLIUM_PLATE = ITEMS.registerSimpleItem("beryllium_plate");

    /** 镭源：铀矿渣加硝酸浸出来的镭盐，中子源的「点火器」。 */
    public static final DeferredItem<TooltipItem> RADIUM_SOURCE = ITEMS.registerItem(
            "radium_source", properties -> new TooltipItem(properties, "tooltip.aftercritical.radium_source"));

    /** 中子源：往反应堆里扔第一颗中子的东西，次临界增殖装置必须放一个。 */
    public static final DeferredItem<TooltipItem> NEUTRON_SOURCE = ITEMS.registerItem(
            "neutron_source", properties -> new TooltipItem(properties, "tooltip.aftercritical.neutron_source"));

    /** 控制棒组件：插进临界实验堆，用硼吸收中子来压 k_eff。 */
    public static final DeferredItem<TooltipItem> CONTROL_ROD = ITEMS.registerItem(
            "control_rod", properties -> new TooltipItem(properties, "tooltip.aftercritical.control_rod"));

    /** 熔毁的燃料棒：超临界太久、堆芯烧穿之后剩下的那一坨。 */
    public static final DeferredItem<TooltipItem> MELTED_FUEL_ROD = ITEMS.registerItem(
            "melted_fuel_rod", properties -> new TooltipItem(properties, "tooltip.aftercritical.melted_fuel_rod"));

    // ------------------------------------------------------------------
    // 阶段 3 的方块物品
    // ------------------------------------------------------------------

    /** 石墨块方块物品。 */
    public static final DeferredItem<BlockItem> GRAPHITE_BLOCK = ITEMS.registerSimpleBlockItem(ModBlocks.GRAPHITE_BLOCK);

    /** 钢块方块物品。 */
    public static final DeferredItem<BlockItem> STEEL_BLOCK = ITEMS.registerSimpleBlockItem(ModBlocks.STEEL_BLOCK);

    /** 石墨慢化剂块方块物品。 */
    public static final DeferredItem<BlockItem> GRAPHITE_MODERATOR =
            ITEMS.registerSimpleBlockItem(ModBlocks.GRAPHITE_MODERATOR);

    /** 反射层块方块物品。 */
    public static final DeferredItem<BlockItem> BERYLLIUM_REFLECTOR =
            ITEMS.registerSimpleBlockItem(ModBlocks.BERYLLIUM_REFLECTOR);

    /** 辐射屏蔽块方块物品。 */
    public static final DeferredItem<BlockItem> RADIATION_SHIELD =
            ITEMS.registerSimpleBlockItem(ModBlocks.RADIATION_SHIELD);

    /** 中子探测器方块物品。 */
    public static final DeferredItem<BlockItem> NEUTRON_DETECTOR =
            ITEMS.registerSimpleBlockItem(ModBlocks.NEUTRON_DETECTOR);

    /** 临界报警器方块物品。 */
    public static final DeferredItem<BlockItem> CRITICAL_ALARM =
            ITEMS.registerSimpleBlockItem(ModBlocks.CRITICAL_ALARM);

    /** 中子通量记录仪方块物品。 */
    public static final DeferredItem<BlockItem> NEUTRON_FLUX_RECORDER =
            ITEMS.registerSimpleBlockItem(ModBlocks.NEUTRON_FLUX_RECORDER);

    /** 次临界增殖装置控制器方块物品。 */
    public static final DeferredItem<BlockItem> SUBCRITICAL_CONTROLLER =
            ITEMS.registerSimpleBlockItem(ModBlocks.SUBCRITICAL_CONTROLLER);

    /** 临界实验堆控制器方块物品。 */
    public static final DeferredItem<BlockItem> CRITICAL_REACTOR_CONTROLLER =
            ITEMS.registerSimpleBlockItem(ModBlocks.CRITICAL_REACTOR_CONTROLLER);

    /** 通用储罐方块物品（32,000 mB，什么流体都能装）。 */
    public static final DeferredItem<BlockItem> UNIVERSAL_TANK =
            ITEMS.registerSimpleBlockItem(ModBlocks.UNIVERSAL_TANK);

    /** 堆芯残骸方块物品：熔毁之后的烂摊子，只能拆掉重造。 */
    public static final DeferredItem<BlockItem> CORE_REMNANT =
            ITEMS.registerSimpleBlockItem(ModBlocks.CORE_REMNANT);

    /** 污染土方块物品：踩上去会持续沾染辐射，永久存在。 */
    public static final DeferredItem<BlockItem> CONTAMINATED_SOIL =
            ITEMS.registerSimpleBlockItem(ModBlocks.CONTAMINATED_SOIL);

    /** 烧结砂方块物品：核爆后在沙地上结成的硬壳。 */
    public static final DeferredItem<BlockItem> SCORCHED_SAND =
            ITEMS.registerSimpleBlockItem(ModBlocks.SCORCHED_SAND);

    /** 焦木方块物品：烧成炭的树干，可以当柴烧。 */
    public static final DeferredItem<BlockItem> CHARRED_LOG =
            ITEMS.registerSimpleBlockItem(ModBlocks.CHARRED_LOG);

    /** 焦土方块物品：爆心 100 格以内那种烧透的黑壳。 */
    public static final DeferredItem<BlockItem> SCORCHED_EARTH =
            ITEMS.registerSimpleBlockItem(ModBlocks.SCORCHED_EARTH);

    /** 辐射焦土方块物品：比焦土更黑的焦壳，裂里透着一点绿。 */
    public static final DeferredItem<BlockItem> RADIOACTIVE_SCORCHED_EARTH =
            ITEMS.registerSimpleBlockItem(ModBlocks.RADIOACTIVE_SCORCHED_EARTH);

    /** 辐射尘方块物品：薄得像雪的一层灰，装在背包里也会慢慢吃辐射。 */
    public static final DeferredItem<BlockItem> RADIOACTIVE_DUST =
            ITEMS.registerSimpleBlockItem(ModBlocks.RADIOACTIVE_DUST);

    /**
     * 核熔的钻石矿方块物品。
     *
     * <p>注意：挖这种矿掉的就是<b>它自己</b>，不会掉原版钻石——原矿在爆炸里已经烧熔了。
     * 以后要提炼的话，得把它当原料送进机器，而不是当钻石用。
     */
    public static final DeferredItem<BlockItem> NUCLEAR_MOLTEN_DIAMOND_ORE =
            ITEMS.registerSimpleBlockItem(ModBlocks.NUCLEAR_MOLTEN_DIAMOND_ORE);

    /** 核熔的绿宝石矿方块物品：同样只掉自己，不掉原版绿宝石。 */
    public static final DeferredItem<BlockItem> NUCLEAR_MOLTEN_EMERALD_ORE =
            ITEMS.registerSimpleBlockItem(ModBlocks.NUCLEAR_MOLTEN_EMERALD_ORE);

    // ------------------------------------------------------------------
    // 辐射防护服四件套
    // ------------------------------------------------------------------

    /** 防护服头盔：带铅玻璃面罩，看外面颜色发暗。 */
    public static final DeferredItem<RadiationSuitItem> RADIATION_SUIT_HELMET = armor(
            "radiation_suit_helmet", ArmorItem.Type.HELMET);

    /** 防护服胸甲：整套防护的核心，铅板夹着隔热布。 */
    public static final DeferredItem<RadiationSuitItem> RADIATION_SUIT_CHESTPLATE = armor(
            "radiation_suit_chestplate", ArmorItem.Type.CHESTPLATE);

    /** 防护服护腿。 */
    public static final DeferredItem<RadiationSuitItem> RADIATION_SUIT_LEGGINGS = armor(
            "radiation_suit_leggings", ArmorItem.Type.LEGGINGS);

    /** 防护服靴子。 */
    public static final DeferredItem<RadiationSuitItem> RADIATION_SUIT_BOOTS = armor(
            "radiation_suit_boots", ArmorItem.Type.BOOTS);

    /** 四件套的统一登记方式。 */
    private static DeferredItem<RadiationSuitItem> armor(String name, ArmorItem.Type type) {
        return ITEMS.registerItem(name,
                properties -> new RadiationSuitItem(ModArmorMaterials.RADIATION_SUIT, type,
                        properties.stacksTo(1)));
    }

    // ------------------------------------------------------------------
    // 阶段 4：研究堆与同位素
    // ------------------------------------------------------------------

    /** 电机HV：装配机 T2 造出来的第一样 HV 级中间件，所有 HV 机器都要用。 */
    public static final DeferredItem<TooltipItem> MOTOR_HV = ITEMS.registerItem(
            "motor_hv", properties -> new TooltipItem(properties, "tooltip.aftercritical.motor_hv"));

    /** 机械臂HV：装配机 T3 和热室机械臂的核心。 */
    public static final DeferredItem<TooltipItem> ROBOT_ARM_HV = ITEMS.registerItem(
            "robot_arm_hv", properties -> new TooltipItem(properties, "tooltip.aftercritical.robot_arm_hv"));

    /** 泵HV：冷却池和高压流体线用的大泵。 */
    public static final DeferredItem<TooltipItem> PUMP_HV = ITEMS.registerItem(
            "pump_hv", properties -> new TooltipItem(properties, "tooltip.aftercritical.pump_hv"));

    // ---- 靶材：装配机 T2 用基础材料造出来的「还没进堆的靶」 ----

    /** 钴59靶：铁锭加铜线压的靶片，进堆照 10 分钟就是钴60。 */
    public static final DeferredItem<TooltipItem> COBALT59_TARGET = target("cobalt59_target");

    /** 锂6靶：锂6 加锆合金管装的靶，照 15 分钟出氚。 */
    public static final DeferredItem<TooltipItem> LITHIUM6_TARGET = target("lithium6_target");

    /** 铀238靶：贫铀压的靶，照 20 分钟增殖成钚239。 */
    public static final DeferredItem<TooltipItem> URANIUM238_TARGET = target("uranium238_target");

    /** 铯133靶：铅锭加玻璃封的靶，照 15 分钟出铯137。 */
    public static final DeferredItem<TooltipItem> CESIUM133_TARGET = target("cesium133_target");

    /** 锶88靶：硼粉加钢板压的靶，照 15 分钟出锶90。 */
    public static final DeferredItem<TooltipItem> STRONTIUM88_TARGET = target("strontium88_target");

    /** 钚239靶：钚239 装的靶，照 20 分钟出锕系元素。 */
    public static final DeferredItem<TooltipItem> PLUTONIUM239_TARGET = target("plutonium239_target");

    /** 硅30靶：石英加钢板压的靶，照 10 分钟出磷32。 */
    public static final DeferredItem<TooltipItem> SILICON30_TARGET = target("silicon30_target");

    // ---- 辐照靶：刚从研究堆里拔出来、还烫手的靶，必须泡水冷却 ----

    /** 辐照过的钴59靶。 */
    public static final DeferredItem<TooltipItem> IRRADIATED_COBALT59 = irradiated("irradiated_cobalt59");

    /** 辐照过的锂6靶。 */
    public static final DeferredItem<TooltipItem> IRRADIATED_LITHIUM6 = irradiated("irradiated_lithium6");

    /** 辐照过的铀238靶。 */
    public static final DeferredItem<TooltipItem> IRRADIATED_URANIUM238 = irradiated("irradiated_uranium238");

    /** 辐照过的铯133靶。 */
    public static final DeferredItem<TooltipItem> IRRADIATED_CESIUM133 = irradiated("irradiated_cesium133");

    /** 辐照过的锶88靶。 */
    public static final DeferredItem<TooltipItem> IRRADIATED_STRONTIUM88 = irradiated("irradiated_strontium88");

    /** 辐照过的钚239靶。 */
    public static final DeferredItem<TooltipItem> IRRADIATED_PLUTONIUM239 =
            irradiated("irradiated_plutonium239");

    /** 辐照过的硅30靶。 */
    public static final DeferredItem<TooltipItem> IRRADIATED_SILICON30 = irradiated("irradiated_silicon30");

    // ---- 同位素：冷却池泡完水出来的成品 ----

    /** 钴60源：最强的人工伽马源，伽马辐照器里当「灯」。 */
    public static final DeferredItem<TooltipItem> COBALT60_SOURCE = ITEMS.registerItem(
            "cobalt60_source", properties -> new TooltipItem(properties, "tooltip.aftercritical.cobalt60_source"));

    /** 氚：锂6 靶照出来的氢同位素，装在小钢瓶里。 */
    public static final DeferredItem<TooltipItem> TRITIUM = ITEMS.registerItem(
            "tritium", properties -> new TooltipItem(properties, "tooltip.aftercritical.tritium"));

    /** 钚239：铀238 靶增殖出来的裂变材料。 */
    public static final DeferredItem<TooltipItem> PLUTONIUM239 = ITEMS.registerItem(
            "plutonium239", properties -> new TooltipItem(properties, "tooltip.aftercritical.plutonium239"));

    /** 铯137：伽马辐照器的主要原料。 */
    public static final DeferredItem<TooltipItem> CESIUM137 = ITEMS.registerItem(
            "cesium137", properties -> new TooltipItem(properties, "tooltip.aftercritical.cesium137"));

    /** 锶90：β 源，做同位素电池用的。 */
    public static final DeferredItem<TooltipItem> STRONTIUM90 = ITEMS.registerItem(
            "strontium90", properties -> new TooltipItem(properties, "tooltip.aftercritical.strontium90"));

    /** 锕系元素：钚靶照完剩下的一锅超铀元素。 */
    public static final DeferredItem<TooltipItem> ACTINIDES = ITEMS.registerItem(
            "actinides", properties -> new TooltipItem(properties, "tooltip.aftercritical.actinides"));

    /** 磷32：硅30 靶照出来的示踪同位素。 */
    public static final DeferredItem<TooltipItem> PHOSPHORUS32 = ITEMS.registerItem(
            "phosphorus32", properties -> new TooltipItem(properties, "tooltip.aftercritical.phosphorus32"));

    /** 锂6：锂粉里挑出来的轻同位素，装锂6 靶要用。 */
    public static final DeferredItem<TooltipItem> LITHIUM6 = ITEMS.registerItem(
            "lithium6", properties -> new TooltipItem(properties, "tooltip.aftercritical.lithium6"));

    // ------------------------------------------------------------------
    // 阶段 4 的方块物品
    // ------------------------------------------------------------------

    /** 装配机 T3 方块物品。 */
    public static final DeferredItem<BlockItem> ASSEMBLER_T3 =
            ITEMS.registerSimpleBlockItem(ModBlocks.ASSEMBLER_T3);

    /** 伽马辐照器方块物品。 */
    public static final DeferredItem<BlockItem> GAMMA_IRRADIATOR =
            ITEMS.registerSimpleBlockItem(ModBlocks.GAMMA_IRRADIATOR);

    /** 辐照靶冷却池方块物品。 */
    public static final DeferredItem<BlockItem> IRRADIATION_POOL =
            ITEMS.registerSimpleBlockItem(ModBlocks.IRRADIATION_POOL);

    /** 研究堆控制器方块物品。 */
    public static final DeferredItem<BlockItem> RESEARCH_REACTOR_CONTROLLER =
            ITEMS.registerSimpleBlockItem(ModBlocks.RESEARCH_REACTOR_CONTROLLER);

    /** 辐照孔道方块物品。 */
    public static final DeferredItem<BlockItem> IRRADIATION_CHANNEL =
            ITEMS.registerSimpleBlockItem(ModBlocks.IRRADIATION_CHANNEL);

    /** 热室机械臂方块物品。 */
    public static final DeferredItem<BlockItem> HOT_CELL_ARM =
            ITEMS.registerSimpleBlockItem(ModBlocks.HOT_CELL_ARM);

    // ------------------------------------------------------------------
    // 冷却的靶材：冷却池泡完水之后的样子，只能拿热室机械臂拆
    // ------------------------------------------------------------------

    /** 冷却的钴59靶。 */
    public static final DeferredItem<TooltipItem> COOLED_COBALT59 = cooled("cooled_cobalt59");

    /** 冷却的锂6靶。 */
    public static final DeferredItem<TooltipItem> COOLED_LITHIUM6 = cooled("cooled_lithium6");

    /** 冷却的铀238靶。 */
    public static final DeferredItem<TooltipItem> COOLED_URANIUM238 = cooled("cooled_uranium238");

    /** 冷却的铯133靶。 */
    public static final DeferredItem<TooltipItem> COOLED_CESIUM133 = cooled("cooled_cesium133");

    /** 冷却的锶88靶。 */
    public static final DeferredItem<TooltipItem> COOLED_STRONTIUM88 = cooled("cooled_strontium88");

    /** 冷却的钚239靶。 */
    public static final DeferredItem<TooltipItem> COOLED_PLUTONIUM239 = cooled("cooled_plutonium239");

    /** 冷却的硅30靶。 */
    public static final DeferredItem<TooltipItem> COOLED_SILICON30 = cooled("cooled_silicon30");

    // ------------------------------------------------------------------
    // 阶段 5：压水堆与蒸汽发电
    // ------------------------------------------------------------------

    /** 蒸汽涡轮：汽轮发电机的中间件，两个涡轮加线圈才拼得出一台发电机。 */
    public static final DeferredItem<TooltipItem> STEAM_TURBINE = ITEMS.registerItem(
            "steam_turbine", properties -> new TooltipItem(properties, "tooltip.aftercritical.steam_turbine"));

    /** 反应堆压力壳方块物品。 */
    public static final DeferredItem<BlockItem> REACTOR_PRESSURE_VESSEL =
            ITEMS.registerSimpleBlockItem(ModBlocks.REACTOR_PRESSURE_VESSEL);

    /** 控制棒端口方块物品。 */
    public static final DeferredItem<BlockItem> CONTROL_ROD_PORT =
            ITEMS.registerSimpleBlockItem(ModBlocks.CONTROL_ROD_PORT);

    /** 燃料端口方块物品。 */
    public static final DeferredItem<BlockItem> FUEL_PORT =
            ITEMS.registerSimpleBlockItem(ModBlocks.FUEL_PORT);

    /** 冷却剂端口方块物品。 */
    public static final DeferredItem<BlockItem> COOLANT_PORT =
            ITEMS.registerSimpleBlockItem(ModBlocks.COOLANT_PORT);

    /** 压水堆控制器方块物品。 */
    public static final DeferredItem<BlockItem> PWR_CONTROLLER =
            ITEMS.registerSimpleBlockItem(ModBlocks.PWR_CONTROLLER);

    /** 汽轮发电机方块物品。 */
    public static final DeferredItem<BlockItem> STEAM_GENERATOR =
            ITEMS.registerSimpleBlockItem(ModBlocks.STEAM_GENERATOR);

    /** 冷凝器方块物品。 */
    public static final DeferredItem<BlockItem> CONDENSER =
            ITEMS.registerSimpleBlockItem(ModBlocks.CONDENSER);

    /** 冷却塔方块物品。 */
    public static final DeferredItem<BlockItem> COOLING_TOWER =
            ITEMS.registerSimpleBlockItem(ModBlocks.COOLING_TOWER);

    // ------------------------------------------------------------------
    // 阶段 6：乏燃料后处理、MOX 燃料与钠冷快堆
    // ------------------------------------------------------------------

    /** 钠泵HV：快堆的初级冷却剂泵，钠冷快堆控制器要 2 台。 */
    public static final DeferredItem<TooltipItem> SODIUM_PUMP_HV = ITEMS.registerItem(
            "sodium_pump_hv", properties -> new TooltipItem(properties, "tooltip.aftercritical.sodium_pump_hv"));

    /** 控制棒驱动器：把控制棒推上拉下的机构，钠冷快堆控制器要 2 台。 */
    public static final DeferredItem<TooltipItem> CONTROL_ROD_DRIVER = ITEMS.registerItem(
            "control_rod_driver", properties -> new TooltipItem(properties,
                    "tooltip.aftercritical.control_rod_driver"));

    /** 乏燃料组件：压水堆烧完的 LEU 燃料组件，后处理线的起点。 */
    public static final DeferredItem<TooltipItem> SPENT_FUEL_ASSEMBLY = ITEMS.registerItem(
            "spent_fuel_assembly", properties -> new TooltipItem(properties,
                    "tooltip.aftercritical.spent_fuel_assembly"));

    /** 冷却的乏燃料组件：在乏燃料冷却池里泡满 10 分钟水之后的样子。 */
    public static final DeferredItem<TooltipItem> COOLED_SPENT_FUEL_ASSEMBLY = ITEMS.registerItem(
            "cooled_spent_fuel_assembly", properties -> new TooltipItem(properties,
                    "tooltip.aftercritical.cooled_spent_fuel_assembly"));

    /** 乏燃料碎块：剪切机剪开的乏燃料芯块，等着用硝酸泡。 */
    public static final DeferredItem<Item> SPENT_FUEL_FRAGMENT = ITEMS.registerSimpleItem("spent_fuel_fragment");

    /** 空框架：剪切机上剥下来的锆合金框架，可以回收再装燃料。 */
    public static final DeferredItem<Item> EMPTY_FUEL_FRAME = ITEMS.registerSimpleItem("empty_fuel_frame");

    /** 壳渣：溶解槽里没泡开的包壳残渣。 */
    public static final DeferredItem<TooltipItem> SHELL_SLAG = ITEMS.registerItem(
            "shell_slag", properties -> new TooltipItem(properties, "tooltip.aftercritical.shell_slag"));

    /** 回收铀：从乏燃料里萃取回来的铀，可以再做燃料。 */
    public static final DeferredItem<TooltipItem> RECOVERED_URANIUM = ITEMS.registerItem(
            "recovered_uranium", properties -> new TooltipItem(properties,
                    "tooltip.aftercritical.recovered_uranium"));

    /** 固化玻璃：高放废液被封进玻璃里，最安全的结局。 */
    public static final DeferredItem<TooltipItem> SOLIDIFIED_GLASS = ITEMS.registerItem(
            "solidified_glass", properties -> new TooltipItem(properties,
                    "tooltip.aftercritical.solidified_glass"));

    /** MOX 芯块坯：钚239 + 贫铀压出来的生坯。 */
    public static final DeferredItem<Item> MOX_PELLET_BLANK = ITEMS.registerSimpleItem("mox_pellet_blank");

    /** 烧结MOX芯块：烧结炉烧硬的 MOX 芯块。 */
    public static final DeferredItem<Item> SINTERED_MOX_PELLET = ITEMS.registerSimpleItem("sintered_mox_pellet");

    /** MOX燃料棒：MOX 芯块装进锆合金管。 */
    public static final DeferredItem<Item> MOX_FUEL_ROD = ITEMS.registerSimpleItem("mox_fuel_rod");

    /** MOX燃料组件：8 根 MOX 棒装进锆合金框架，快堆的燃料。 */
    public static final DeferredItem<TooltipItem> MOX_FUEL_ASSEMBLY = ITEMS.registerItem(
            "mox_fuel_assembly", properties -> new TooltipItem(properties,
                    "tooltip.aftercritical.mox_fuel_assembly"));

    /** 乏燃料组件（快堆）：MOX 在快堆里烧完之后剩下的，里面钚更多。 */
    public static final DeferredItem<TooltipItem> FAST_SPENT_ASSEMBLY = ITEMS.registerItem(
            "fast_spent_assembly", properties -> new TooltipItem(properties,
                    "tooltip.aftercritical.fast_spent_assembly"));

    /** 冷却的乏燃料组件（快堆）：泡过水、可以进剪切机的快堆乏燃料。 */
    public static final DeferredItem<TooltipItem> COOLED_FAST_SPENT_ASSEMBLY = ITEMS.registerItem(
            "cooled_fast_spent_assembly", properties -> new TooltipItem(properties,
                    "tooltip.aftercritical.cooled_fast_spent_assembly"));

    // ---- 阶段 6 的方块物品 ----

    /** 乏燃料冷却池方块物品。 */
    public static final DeferredItem<BlockItem> SPENT_FUEL_POOL =
            ITEMS.registerSimpleBlockItem(ModBlocks.SPENT_FUEL_POOL);

    /** 剪切机方块物品。 */
    public static final DeferredItem<BlockItem> SHEARING_MACHINE =
            ITEMS.registerSimpleBlockItem(ModBlocks.SHEARING_MACHINE);

    /** 溶解槽方块物品。 */
    public static final DeferredItem<BlockItem> DISSOLUTION_TANK =
            ITEMS.registerSimpleBlockItem(ModBlocks.DISSOLUTION_TANK);

    /** 萃取柱方块物品。 */
    public static final DeferredItem<BlockItem> EXTRACTION_COLUMN =
            ITEMS.registerSimpleBlockItem(ModBlocks.EXTRACTION_COLUMN);

    /** 离心萃取器方块物品。 */
    public static final DeferredItem<BlockItem> CENTRIFUGAL_EXTRACTOR =
            ITEMS.registerSimpleBlockItem(ModBlocks.CENTRIFUGAL_EXTRACTOR);

    /** 玻璃固化炉方块物品。 */
    public static final DeferredItem<BlockItem> VITRIFICATION_FURNACE =
            ITEMS.registerSimpleBlockItem(ModBlocks.VITRIFICATION_FURNACE);

    /** 钠冷快堆控制器方块物品。 */
    public static final DeferredItem<BlockItem> FAST_REACTOR_CONTROLLER =
            ITEMS.registerSimpleBlockItem(ModBlocks.FAST_REACTOR_CONTROLLER);

    /** 快中子探测器方块物品。 */
    public static final DeferredItem<BlockItem> FAST_NEUTRON_DETECTOR =
            ITEMS.registerSimpleBlockItem(ModBlocks.FAST_NEUTRON_DETECTOR);

    /** 钠-水蒸汽发生器方块物品。 */
    public static final DeferredItem<BlockItem> SODIUM_STEAM_GENERATOR =
            ITEMS.registerSimpleBlockItem(ModBlocks.SODIUM_STEAM_GENERATOR);

    // ------------------------------------------------------------------
    // 阶段 7：聚变与嬗变
    // ------------------------------------------------------------------

    /** 燃料单元：空的燃料壳子，灌氘、装氚都从它开始（工作台 2 钢板 + 2 玻璃 + 2 铜线做 4 个）。 */
    public static final DeferredItem<TooltipItem> FUSION_FUEL_CELL = ITEMS.registerItem(
            "fusion_fuel_cell", properties -> new TooltipItem(properties,
                    "tooltip.aftercritical.fusion_fuel_cell"));

    /** 氘单元：燃料单元 + 20 mB 氘，在化工厂里灌装。 */
    public static final DeferredItem<TooltipItem> DEUTERIUM_CELL = ITEMS.registerItem(
            "deuterium_cell", properties -> new TooltipItem(properties, "tooltip.aftercritical.deuterium_cell"));

    /** 氚单元：燃料单元 + 1 个氚，装配机 T2 拼出来。 */
    public static final DeferredItem<TooltipItem> TRITIUM_CELL = ITEMS.registerItem(
            "tritium_cell", properties -> new TooltipItem(properties, "tooltip.aftercritical.tritium_cell"));

    /** 氘氚燃料单元：托卡马克点火的燃料，10 秒烧 1 个。 */
    public static final DeferredItem<TooltipItem> DT_FUEL_CELL = ITEMS.registerItem(
            "dt_fuel_cell", properties -> new TooltipItem(properties, "tooltip.aftercritical.dt_fuel_cell"));

    /** 锂7：气体离心机分离锂粉时「重的那一半」，目前是聚变燃料链的副产物。 */
    public static final DeferredItem<TooltipItem> LITHIUM7 = ITEMS.registerItem(
            "lithium7", properties -> new TooltipItem(properties, "tooltip.aftercritical.lithium7"));

    /** 短寿命同位素：物质嬗变器把锕系元素「捏」出来的产物，终局配方的原料。 */
    public static final DeferredItem<TooltipItem> SHORT_LIVED_ISOTOPE = ITEMS.registerItem(
            "short_lived_isotope", properties -> new TooltipItem(properties,
                    "tooltip.aftercritical.short_lived_isotope"));

    /** 铂族金属：离心萃取器回收短寿命同位素得到的贵金属。 */
    public static final DeferredItem<TooltipItem> PLATINUM_GROUP_METAL = ITEMS.registerItem(
            "platinum_group_metal", properties -> new TooltipItem(properties,
                    "tooltip.aftercritical.platinum_group_metal"));

    /** 稀有同位素：回收路线的第二个产物，稀有到没有配方再用它，纯收藏 / 成就。 */
    public static final DeferredItem<TooltipItem> RARE_ISOTOPE = ITEMS.registerItem(
            "rare_isotope", properties -> new TooltipItem(properties, "tooltip.aftercritical.rare_isotope"));

    // ---- 阶段 7 的方块物品 ----

    /** 聚变环外壳方块物品。 */
    public static final DeferredItem<BlockItem> FUSION_RING_CASING =
            ITEMS.registerSimpleBlockItem(ModBlocks.FUSION_RING_CASING);

    /** 超导线圈方块物品。 */
    public static final DeferredItem<BlockItem> SUPERCONDUCTING_COIL =
            ITEMS.registerSimpleBlockItem(ModBlocks.SUPERCONDUCTING_COIL);

    /** 增殖包层模块方块物品。 */
    public static final DeferredItem<BlockItem> BREEDING_BLANKET =
            ITEMS.registerSimpleBlockItem(ModBlocks.BREEDING_BLANKET);

    /** 燃料注入端口方块物品。 */
    public static final DeferredItem<BlockItem> FUEL_INJECTOR_PORT =
            ITEMS.registerSimpleBlockItem(ModBlocks.FUEL_INJECTOR_PORT);

    /** 等离子体诊断器方块物品。 */
    public static final DeferredItem<BlockItem> PLASMA_DIAGNOSTIC =
            ITEMS.registerSimpleBlockItem(ModBlocks.PLASMA_DIAGNOSTIC);

    /** 低温冷却器方块物品。 */
    public static final DeferredItem<BlockItem> CRYOGENIC_COOLER =
            ITEMS.registerSimpleBlockItem(ModBlocks.CRYOGENIC_COOLER);

    /** 聚变控制逻辑方块物品。 */
    public static final DeferredItem<BlockItem> FUSION_CONTROL_LOGIC =
            ITEMS.registerSimpleBlockItem(ModBlocks.FUSION_CONTROL_LOGIC);

    /** 托卡马克控制器方块物品。 */
    public static final DeferredItem<BlockItem> TOKAMAK_CONTROLLER =
            ITEMS.registerSimpleBlockItem(ModBlocks.TOKAMAK_CONTROLLER);

    /** 嬗变器外壳方块物品。 */
    public static final DeferredItem<BlockItem> TRANSMUTATOR_CASING =
            ITEMS.registerSimpleBlockItem(ModBlocks.TRANSMUTATOR_CASING);

    /** 能量端口方块物品。 */
    public static final DeferredItem<BlockItem> ENERGY_PORT =
            ITEMS.registerSimpleBlockItem(ModBlocks.ENERGY_PORT);

    /** 物质嬗变器控制器方块物品。 */
    public static final DeferredItem<BlockItem> TRANSMUTATOR_CONTROLLER =
            ITEMS.registerSimpleBlockItem(ModBlocks.TRANSMUTATOR_CONTROLLER);

    /** 电池 MV 方块物品。 */
    public static final DeferredItem<BlockItem> BATTERY_MV = ITEMS.registerSimpleBlockItem(ModBlocks.BATTERY_MV);

    /** 巨型储能库方块物品。 */
    public static final DeferredItem<BlockItem> GIANT_BATTERY =
            ITEMS.registerSimpleBlockItem(ModBlocks.GIANT_BATTERY);

    /** 地质处置库方块物品。 */
    public static final DeferredItem<BlockItem> GEOLOGIC_REPOSITORY =
            ITEMS.registerSimpleBlockItem(ModBlocks.GEOLOGIC_REPOSITORY);

    // ------------------------------------------------------------------
    // 钯链条与空气分离机部件
    // ------------------------------------------------------------------

    /** 钯矿石方块物品：全世界 -32~32 层生成，矿脉很小，属于稀有矿。 */
    public static final DeferredItem<BlockItem> PALLADIUM_ORE =
            ITEMS.registerSimpleBlockItem(ModBlocks.PALLADIUM_ORE);

    /** 钯精矿粉：钯矿石破碎后的精矿，送去酸浸。 */
    public static final DeferredItem<Item> PALLADIUM_CONCENTRATE =
            ITEMS.registerSimpleItem("palladium_concentrate");

    /** 钯粉：酸浸出来的海绵钯粉，烧一下就是钯锭。 */
    public static final DeferredItem<Item> PALLADIUM_DUST = ITEMS.registerSimpleItem("palladium_dust");

    /** 钯锭：钯粉烧出来的金属锭。 */
    public static final DeferredItem<Item> PALLADIUM_INGOT = ITEMS.registerSimpleItem("palladium_ingot");

    /** 钯金合金锭：钯和金的合金，比纯钯硬、能压成箔，是钯合金膜的原料。 */
    public static final DeferredItem<TooltipItem> PALLADIUM_GOLD_ALLOY_INGOT = ITEMS.registerItem(
            "palladium_gold_alloy_ingot",
            properties -> new TooltipItem(properties, "tooltip.aftercritical.palladium_gold_alloy_ingot"));

    /** 钯金合金板：合金锭压出来的板，下一步装配成膜。 */
    public static final DeferredItem<Item> PALLADIUM_GOLD_ALLOY_PLATE =
            ITEMS.registerSimpleItem("palladium_gold_alloy_plate");

    /**
     * 钯合金膜：空气分离机的核心部件，只让氧气钻过去。
     *
     * <p>装进空气分离机的输入槽后会一直留在里面，不随生产被吃掉。
     */
    public static final DeferredItem<TooltipItem> PALLADIUM_ALLOY_MEMBRANE = ITEMS.registerItem(
            "palladium_alloy_membrane",
            properties -> new TooltipItem(properties, "tooltip.aftercritical.palladium_alloy_membrane"));

    /**
     * 碳分子筛：空气分离机里「筛」住氮气的那一层。
     *
     * <p>和钯合金膜一样是常驻部件，装进去就不消耗。
     */
    public static final DeferredItem<TooltipItem> CARBON_MOLECULAR_SIEVE = ITEMS.registerItem(
            "carbon_molecular_sieve",
            properties -> new TooltipItem(properties, "tooltip.aftercritical.carbon_molecular_sieve"));

    // ------------------------------------------------------------------
    // 钴 / 铯 / 锶：三种靶材金属，从矿石到靶材的一条完整链
    // ------------------------------------------------------------------

    /** 钴矿石方块物品：0~64 层生成，矿脉中等，是钴59靶的起点。 */
    public static final DeferredItem<BlockItem> COBALT_ORE =
            ITEMS.registerSimpleBlockItem(ModBlocks.COBALT_ORE);

    /** 铯矿石方块物品：0~48 层生成，矿脉小、比较少见。 */
    public static final DeferredItem<BlockItem> CESIUM_ORE =
            ITEMS.registerSimpleBlockItem(ModBlocks.CESIUM_ORE);

    /** 锶矿石方块物品：0~80 层生成，矿脉偏大。 */
    public static final DeferredItem<BlockItem> STRONTIUM_ORE =
            ITEMS.registerSimpleBlockItem(ModBlocks.STRONTIUM_ORE);

    /** 钴矿粉：钴矿石破碎出来的精矿，烧成钴锭。 */
    public static final DeferredItem<Item> COBALT_DUST = ITEMS.registerSimpleItem("cobalt_dust");

    /** 铯矿粉：铯矿石破碎出来的精矿，烧成铯锭。 */
    public static final DeferredItem<Item> CESIUM_DUST = ITEMS.registerSimpleItem("cesium_dust");

    /** 锶矿粉：锶矿石破碎出来的精矿，烧成锶锭。 */
    public static final DeferredItem<Item> STRONTIUM_DUST = ITEMS.registerSimpleItem("strontium_dust");

    /** 钴锭：钴59靶的金属基体。 */
    public static final DeferredItem<Item> COBALT_INGOT = ITEMS.registerSimpleItem("cobalt_ingot");

    /** 铯锭：铯133靶的金属基体。 */
    public static final DeferredItem<Item> CESIUM_INGOT = ITEMS.registerSimpleItem("cesium_ingot");

    /** 锶锭：锶88靶的金属基体。 */
    public static final DeferredItem<Item> STRONTIUM_INGOT = ITEMS.registerSimpleItem("strontium_ingot");

    /** 靶材的统一登记方式：一样的东西只有名字不同。 */
    private static DeferredItem<TooltipItem> target(String name) {
        return ITEMS.registerItem(name,
                properties -> new TooltipItem(properties, "tooltip.aftercritical.target"));
    }

    /** 辐照靶的统一登记方式。 */
    private static DeferredItem<TooltipItem> irradiated(String name) {
        return ITEMS.registerItem(name,
                properties -> new TooltipItem(properties, "tooltip.aftercritical.irradiated"));
    }

    /** 冷却的靶材的统一登记方式。 */
    private static DeferredItem<TooltipItem> cooled(String name) {
        return ITEMS.registerItem(name,
                properties -> new TooltipItem(properties, "tooltip.aftercritical.cooled_target"));
    }

    // ------------------------------------------------------------------
    // 武器：六颗核弹、模块化组件、起爆器
    // ------------------------------------------------------------------

    /** 小男孩：1.5 万吨。 */
    public static final DeferredItem<BlockItem> NUKE_LITTLE_BOY =
            ITEMS.registerSimpleBlockItem(ModBlocks.NUKE_LITTLE_BOY);

    /** 胖子：2.1 万吨。 */
    public static final DeferredItem<BlockItem> NUKE_FAT_MAN =
            ITEMS.registerSimpleBlockItem(ModBlocks.NUKE_FAT_MAN);

    /** 邱小姐（596）：2.2 万吨。 */
    public static final DeferredItem<BlockItem> NUKE_QIU =
            ITEMS.registerSimpleBlockItem(ModBlocks.NUKE_QIU);

    /** 639-23：330 万吨。 */
    public static final DeferredItem<BlockItem> NUKE_639 =
            ITEMS.registerSimpleBlockItem(ModBlocks.NUKE_639);

    /** 常青藤（Ivy Mike）：1040 万吨。 */
    public static final DeferredItem<BlockItem> NUKE_IVY_MIKE =
            ITEMS.registerSimpleBlockItem(ModBlocks.NUKE_IVY_MIKE);

    /** 沙皇氢弹：5000 万吨。 */
    public static final DeferredItem<BlockItem> NUKE_TSAR =
            ITEMS.registerSimpleBlockItem(ModBlocks.NUKE_TSAR);

    /** 裂变扳机：氢弹的初级。 */
    public static final DeferredItem<NukeComponentItem> NUKE_PRIMARY = ITEMS.registerItem(
            "nuke_primary", properties -> new NukeComponentItem(properties, NukeComponent.PRIMARY));

    /** 增强装药。 */
    public static final DeferredItem<NukeComponentItem> NUKE_BOOSTER = ITEMS.registerItem(
            "nuke_booster", properties -> new NukeComponentItem(properties, NukeComponent.BOOSTER));

    /** 中子反射层。 */
    public static final DeferredItem<NukeComponentItem> NUKE_REFLECTOR = ITEMS.registerItem(
            "nuke_reflector", properties -> new NukeComponentItem(properties, NukeComponent.REFLECTOR));

    /** 贫铀惰层。 */
    public static final DeferredItem<NukeComponentItem> NUKE_TAMPER = ITEMS.registerItem(
            "nuke_tamper", properties -> new NukeComponentItem(properties, NukeComponent.TAMPER));

    /** 钴-60 外壳。 */
    public static final DeferredItem<NukeComponentItem> NUKE_COBALT_SHELL = ITEMS.registerItem(
            "nuke_cobalt_shell", properties -> new NukeComponentItem(properties, NukeComponent.COBALT_SHELL));

    // ------------------------------------------------------------------
    // 武器：模块化组件的其余几种（每颗弹要的不一样）
    // ------------------------------------------------------------------

    /** 弹头引信：枪式打火、内爆点火，六颗弹全都要。 */
    public static final DeferredItem<NukeComponentItem> NUKE_FUZE = ITEMS.registerItem(
            "nuke_fuze", properties -> new NukeComponentItem(properties, NukeComponent.FUZE));

    /** 中子引发器：起爆瞬间撒中子的那颗小东西。 */
    public static final DeferredItem<NukeComponentItem> NUKE_INITIATOR = ITEMS.registerItem(
            "nuke_initiator", properties -> new NukeComponentItem(properties, NukeComponent.INITIATOR));

    /** 炮管：小男孩枪式结构里加速铀靶环的那一截。 */
    public static final DeferredItem<NukeComponentItem> NUKE_GUN_BARREL = ITEMS.registerItem(
            "nuke_gun_barrel", properties -> new NukeComponentItem(properties, NukeComponent.GUN_BARREL));

    /** 铀靶环：小男孩被炮弹打中的那摞环。 */
    public static final DeferredItem<NukeComponentItem> NUKE_URANIUM_TARGET = ITEMS.registerItem(
            "nuke_uranium_target", properties -> new NukeComponentItem(properties, NukeComponent.URANIUM_TARGET));

    /** 钚核心：胖子的钚-239 球。 */
    public static final DeferredItem<NukeComponentItem> NUKE_PLUTONIUM_PIT = ITEMS.registerItem(
            "nuke_plutonium_pit", properties -> new NukeComponentItem(properties, NukeComponent.PLUTONIUM_PIT));

    /** 铀-235 核心：邱小姐的铀球。 */
    public static final DeferredItem<NukeComponentItem> NUKE_URANIUM_PIT = ITEMS.registerItem(
            "nuke_uranium_pit", properties -> new NukeComponentItem(properties, NukeComponent.URANIUM_PIT));

    /** 炸药透镜：把冲击波压成球面内爆的那一圈。 */
    public static final DeferredItem<NukeComponentItem> NUKE_EXPLOSIVE_LENS = ITEMS.registerItem(
            "nuke_explosive_lens", properties -> new NukeComponentItem(properties, NukeComponent.EXPLOSIVE_LENS));

    /** 氘化锂-6：氢弹的燃料。 */
    public static final DeferredItem<NukeComponentItem> NUKE_DEUTERIUM_LITHIUM = ITEMS.registerItem(
            "nuke_deuterium_lithium",
            properties -> new NukeComponentItem(properties, NukeComponent.DEUTERIUM_LITHIUM));

    /** 低温杜瓦：常青藤装液态氘的保温瓶。 */
    public static final DeferredItem<NukeComponentItem> NUKE_CRYOSTAT = ITEMS.registerItem(
            "nuke_cryostat", properties -> new NukeComponentItem(properties, NukeComponent.CRYOSTAT));

    /** 减速伞：让空投的弹落得慢一点，你有更多时间跑。 */
    public static final DeferredItem<NukeComponentItem> NUKE_PARACHUTE = ITEMS.registerItem(
            "nuke_parachute", properties -> new NukeComponentItem(properties, NukeComponent.PARACHUTE));

    // ------------------------------------------------------------------
    // 武器：造核弹用的原料
    // ------------------------------------------------------------------

    /** 空弹体：六颗弹共用的外壳；不往界面里装组件，它就是个铁皮筒。 */
    public static final DeferredItem<TooltipItem> NUKE_CASING = ITEMS.registerItem(
            "nuke_casing", properties -> new TooltipItem(properties, "tooltip.aftercritical.nuke_casing"));

    /** 高能炸药：压进弹体里的那一圈。 */
    public static final DeferredItem<Item> HIGH_EXPLOSIVE = ITEMS.registerSimpleItem("high_explosive");

    /** 武器级铀：富集到能直接当核装料的铀。 */
    public static final DeferredItem<TooltipItem> WEAPON_GRADE_URANIUM = ITEMS.registerItem(
            "weapon_grade_uranium",
            properties -> new TooltipItem(properties, "tooltip.aftercritical.weapon_grade_uranium"));

    /** 核熔金刚石晶体：核熔钻石矿磨出来的，硬、纯，能当反射层。 */
    public static final DeferredItem<TooltipItem> NUCLEAR_DIAMOND_CRYSTAL = ITEMS.registerItem(
            "nuclear_diamond_crystal",
            properties -> new TooltipItem(properties, "tooltip.aftercritical.nuclear_diamond_crystal"));

    /** 核熔绿宝石晶体：核熔绿宝石矿磨出来的，切炸药透镜就用它。 */
    public static final DeferredItem<TooltipItem> NUCLEAR_EMERALD_CRYSTAL = ITEMS.registerItem(
            "nuclear_emerald_crystal",
            properties -> new TooltipItem(properties, "tooltip.aftercritical.nuclear_emerald_crystal"));

    /** 核装置总装台：专门造核弹和它们的组件。 */
    public static final DeferredItem<BlockItem> WARHEAD_ASSEMBLER =
            ITEMS.registerSimpleBlockItem(ModBlocks.WARHEAD_ASSEMBLER);

    /** 起爆器：潜行右键核弹绑定，再右键空气引爆。 */
    public static final DeferredItem<DetonatorItem> DETONATOR = ITEMS.registerItem(
            "detonator", DetonatorItem::new, new Item.Properties().stacksTo(1));

    private ModItems() {}
}
