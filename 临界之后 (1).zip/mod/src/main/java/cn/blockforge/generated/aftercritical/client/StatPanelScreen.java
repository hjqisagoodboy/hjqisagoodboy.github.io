package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.AbstractMachineMenu;
import cn.blockforge.generated.aftercritical.menu.FluidBarHost;
import cn.blockforge.generated.aftercritical.menu.MachineLayout;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.List;

/**
 * 「读数面板」类的界面骨架：面板还是 {@link AbstractMachineScreen} 那一套（代码画的统一面板、
 * 左边能量槽、右边流体条），但底下的文字不写「状态 / 能量 / 提示」这三行，
 * 而是由子类自己给一串读数（反应堆给 k_eff、通量、温度……记录仪给连接情况和堆型）。
 *
 * <p>这样两个新界面不用各抄一份画字代码，也不会出现「一台机器字在第三行、另一台在第五行」。
 */
public abstract class StatPanelScreen<T extends AbstractMachineMenu> extends AbstractMachineScreen<T> {

    /** 一行读数：字 + 颜色。 */
    protected record Line(Component text, int color) {
    }

    protected StatPanelScreen(T menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    /** 这个界面要显示哪几行，从面板底部第一行开始往下排。 */
    protected abstract List<Line> statLines();

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        // 和机器界面一样：浅灰面板上一律不画投影，避免字看着有重影
        guiGraphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, TEXT_DARK, false);
        guiGraphics.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY,
                TEXT_DARK, false);

        int y = this.menu.textY();
        for (Line line : statLines()) {
            if (line != null && line.text() != null) {
                guiGraphics.drawString(this.font, line.text(), MachineLayout.TEXT_X, y, line.color(), false);
            }
            y += MachineLayout.TEXT_STEP;
        }

        // 右边流体长条旁边的 mB 数字（反应堆那根硼酸条）
        if (this.menu instanceof FluidBarHost host) {
            for (int i = 0; i < host.barCount(); i++) {
                guiGraphics.drawString(this.font, String.valueOf(host.barAmount(i)),
                        host.barX(i) + host.barWidth(i) + 4,
                        host.barY(i) + (host.barHeight(i) - 8) / 2, TEXT_DARK, false);
            }
        }
    }
}
