package cn.blockforge.generated.aftercritical.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

/**
 * 核熔矿（核熔的钻石矿 / 核熔的绿宝石矿）。
 *
 * <p>它比普通方块多一个方块的「出身」标记 {@link #FROM_NUKE}：
 * <ul>
 *   <li>{@code true} —— 核弹（玩家自己起爆的那六种）炸出来的，坑底结的那一批；</li>
 *   <li>{@code false} —— 堆芯熔毁掀出来的废墟里那种，或者玩家自己拿在手上重新摆下来的。</li>
 * </ul>
 *
 * <p>为什么要分这个：成就「轮回」只认核弹炸出来的那一种。熔毁同样会走一遍核爆流程
 * （见 {@code ReactorControllerBlockEntity#meltDown}），坑底照样会结出核熔矿，
 * 不打个记号的话，玩家把反应堆烧毁一次就能白拿成就，跟「拿核弹换更大的核弹」这个轮回
 * 完全不是一回事。
 *
 * <p>标记只写在方块状态里，看不见、也不影响外观：两种矿石长得一模一样，
 * 挖下来掉的也还是它自己。
 */
public class MoltenOreBlock extends Block {

    /** 这块矿是不是核弹炸出来的（{@code true}）/ 熔毁或玩家摆放的（{@code false}）。 */
    public static final BooleanProperty FROM_NUKE = BooleanProperty.create("from_nuke");

    public MoltenOreBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(FROM_NUKE, false));
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return simpleCodec(MoltenOreBlock::new);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FROM_NUKE);
    }
}
