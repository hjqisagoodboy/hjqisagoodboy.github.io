package cn.blockforge.generated.aftercritical.registry;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.fluid.TankContent;
import com.mojang.serialization.Codec;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 模组自己加的数据组件（data component）。
 *
 * <p>1.21 起，物品带着的附加数据（以前叫 NBT）统一叫「组件」：一个物品堆上可以挂若干
 * 「组件类型 → 值」的键值对。原版有火焰附魔、自定义名字这些，我们这里加一个自己的：
 * 「这一格东西里装的是哪种流体、多少 mB」。
 *
 * <p>有了这个组件，通用流体单元不需要为每种流体各做一个物品——<b>同一个物品</b>，
 * 组件里写着「1000 mB 氢」，它就是氢单元；组件没了，它就是空单元。
 * 物品栏、合成、管道都靠组件区分，不会把「水单元」和「岩浆单元」混在一起。
 */
public final class ModDataComponents {

    public static final DeferredRegister<DataComponentType<?>> DATA_COMPONENTS =
            DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, AfterCritical.MOD_ID);

    /**
     * 物品里装的流体（种类 + mB）。
     *
     * <p>值是 {@link TankContent} 而不是 {@code FluidStack}：数据组件要求值类型自己实现
     * {@code equals} / {@code hashCode}，{@code FluidStack} 没有实现，直接放进去会在
     * 创造栏、配方匹配、联机同步处抛错。
     */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<TankContent>> FLUID =
            DATA_COMPONENTS.register("fluid", () -> DataComponentType.<TankContent>builder()
                    .persistent(TankContent.CODEC)
                    .networkSynchronized(TankContent.STREAM_CODEC)
                    .build());

    /**
     * 「预设流体」：空罐子上盖的一个章。
     *
     * <p>用流体识别码给空罐预设一种流体之后，这个罐子只能装那种流体——
     * 放进机器罐子槽时不会把别的液体灌进来，专管专用。
     * 和 {@link #FLUID} 分开存，是因为一个罐子可以「空着但预设了氢」。
     */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<TankContent>> PRESET_FLUID =
            DATA_COMPONENTS.register("preset_fluid", () -> DataComponentType.<TankContent>builder()
                    .persistent(TankContent.CODEC)
                    .networkSynchronized(TankContent.STREAM_CODEC)
                    .build());

    /**
     * 电池物品里存了多少 FE。
     *
     * <p>挖掉电池时把方块里的电量抄到掉落物上，放下时再抄回去，
     * 这样生存模式把巨型储能库换个位置不会把 1.2 亿 FE 丢光。
     * 只挂这一种组件，不用给每种电池各做一个「带电版」物品。
     */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> ENERGY =
            DATA_COMPONENTS.register("energy", () -> DataComponentType.<Integer>builder()
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT)
                    .build());

    /**
     * 起爆器绑定的那颗核弹：在哪个维度、哪个坐标。
     *
     * <p>用原版现成的 {@link GlobalPos}，自带坐标编解码器和网络同步，
     * 换成维度、退出游戏、把起爆器放进箱子都不会把绑定弄丢。
     */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<GlobalPos>> DETONATOR_TARGET =
            DATA_COMPONENTS.register("detonator_target", () -> DataComponentType.<GlobalPos>builder()
                    .persistent(GlobalPos.CODEC)
                    .networkSynchronized(GlobalPos.STREAM_CODEC)
                    .build());

    private ModDataComponents() {}
}
