package cn.blockforge.generated.aftercritical.registry;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.recipe.AssemblerRecipe;
import cn.blockforge.generated.aftercritical.recipe.AssemblerRecipeSerializer;
import cn.blockforge.generated.aftercritical.recipe.FluidProcessRecipe;
import cn.blockforge.generated.aftercritical.recipe.FluidProcessRecipeSerializer;
import cn.blockforge.generated.aftercritical.recipe.MachineRecipe;
import cn.blockforge.generated.aftercritical.recipe.MachineRecipeSerializer;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 机器配方类型和读写器的注册表。
 *
 * <p>「配方类型」决定「这是哪台机器看的配方」：破碎机只找 {@code aftercritical:crusher}，
 * 球磨机只找 {@code aftercritical:ball_mill}，锻压机只找 {@code aftercritical:forging_press}。
 *
 * <p>破碎、球磨、锻压三个类型共用同一个读写器 {@link MachineRecipeSerializer}，所以三台矿机的配方 JSON 格式一致。
 * 电解槽、化工厂、空气分离器共用 {@link FluidProcessRecipeSerializer}，格式也一致。
 */
public final class ModRecipes {

    public static final DeferredRegister<RecipeType<?>> RECIPE_TYPES =
            DeferredRegister.create(Registries.RECIPE_TYPE, AfterCritical.MOD_ID);

    public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS =
            DeferredRegister.create(Registries.RECIPE_SERIALIZER, AfterCritical.MOD_ID);

    /** 破碎机配方类型。 */
    public static final RecipeType<MachineRecipe> CRUSHING = recipeType("crusher");

    /** 球磨机配方类型。 */
    public static final RecipeType<MachineRecipe> BALL_MILLING = recipeType("ball_mill");

    /** 锻压机配方类型。 */
    public static final RecipeType<MachineRecipe> FORGING = recipeType("forging_press");

    /** 压块机配方类型：把散装原料压成块（煤燃料棒）。 */
    public static final RecipeType<MachineRecipe> COMPACTING = recipeType("compactor");

    /** 装配机配方类型：一次吃好几种原料，所以用另一套配方格式 {@link AssemblerRecipe}。 */
    public static final RecipeType<AssemblerRecipe> ASSEMBLER =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "assembler"));

    /** 电解槽配方类型：水或海带水溶液在电解槽里分解。 */
    public static final RecipeType<FluidProcessRecipe> ELECTROLYSIS =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "electrolysis"));

    /** 化工厂配方类型：流体和物品在压力和电的作用下反应。 */
    public static final RecipeType<FluidProcessRecipe> CHEMICAL_PLANT =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "chemical_plant"));

    /** 空气分离器配方类型：从空气里分馏出氮和氧。 */
    public static final RecipeType<FluidProcessRecipe> AIR_SEPARATION =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "air_separation"));

    /** 地下水开采机配方类型：不要原料，光靠电把地下水提上来。 */
    public static final RecipeType<FluidProcessRecipe> GROUNDWATER =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "groundwater"));

    /** 浸出槽配方类型：矿粉 + 硫酸 → 铀酰溶液。 */
    public static final RecipeType<FluidProcessRecipe> LEACHING =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "leaching"));

    /** 沉淀槽配方类型：铀酰溶液 + 沉淀剂 → 黄饼。 */
    public static final RecipeType<FluidProcessRecipe> PRECIPITATION =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "precipitation"));

    /** 干燥炉配方类型：湿的东西 → 干的东西（不吃流体）。 */
    public static final RecipeType<FluidProcessRecipe> DRYING =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "drying"));

    /** 转化炉配方类型：铀氧化物 + 氢氟酸/氟气 → 六氟化铀。 */
    public static final RecipeType<FluidProcessRecipe> CONVERSION =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "conversion"));

    /** 氟化反应器配方类型：氟化物 + 氟气 → 氟化产物。 */
    public static final RecipeType<FluidProcessRecipe> FLUORINATION =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "fluorination"));

    /** 气体离心机配方类型：六氟化铀 → 低浓缩铀 + 贫铀。 */
    public static final RecipeType<FluidProcessRecipe> CENTRIFUGE =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "centrifuge"));

    /** 水解反应器配方类型：低浓缩六氟化铀 + 水 → 二氧化铀粉 + 氢氟酸。 */
    public static final RecipeType<FluidProcessRecipe> HYDROLYSIS =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "hydrolysis"));

    /** 烧结炉配方类型：芯块坯 → 烧结芯块。 */
    public static final RecipeType<MachineRecipe> SINTERING = recipeType("sintering");

    /** 磨削机配方类型：烧结芯块 → 精磨芯块 + 废粉。 */
    public static final RecipeType<MachineRecipe> GRINDING = recipeType("grinding");

    /** 焊接机配方类型：燃料棒 + 端塞 → 密封燃料棒。 */
    public static final RecipeType<MachineRecipe> WELDING = recipeType("welding");

    /** 伽马辐照器配方类型：要照的东西 + 钴60源 → 照完的东西。 */
    public static final RecipeType<MachineRecipe> GAMMA = recipeType("gamma_irradiation");

    /** 研究堆辐照配方类型：靶材 → 辐照靶（10~20 分钟一炉）。 */
    public static final RecipeType<MachineRecipe> IRRADIATION = recipeType("irradiation");

    /** 冷却池配方类型：辐照靶 + 水 → 冷却的靶材（5 分钟）。 */
    public static final RecipeType<FluidProcessRecipe> COOLING =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "cooling"));

    /** 热室机械臂配方类型：冷却的靶材 → 同位素（走一遍机械臂）。 */
    public static final RecipeType<MachineRecipe> HOT_CELL = recipeType("hot_cell");

    /** 冷凝器配方类型：乏蒸汽 → 水（每 tick 一次，闭式循环）。 */
    public static final RecipeType<FluidProcessRecipe> CONDENSATION =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "condensation"));

    // ------------------------------------------------------------------
    // 阶段 6：乏燃料后处理与 MOX 燃料
    // ------------------------------------------------------------------

    /** 乏燃料冷却池配方类型：乏燃料组件 + 水 → 冷却的乏燃料组件（10 分钟）。 */
    public static final RecipeType<FluidProcessRecipe> SPENT_FUEL_COOLING =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "spent_fuel_cooling"));

    /** 剪切机配方类型：冷却的乏燃料组件 → 乏燃料碎块 + 空框架。 */
    public static final RecipeType<MachineRecipe> SHEARING = recipeType("shearing");

    /** 溶解槽配方类型：乏燃料碎块 + 硝酸 → 乏燃料溶解液 + 壳渣。 */
    public static final RecipeType<FluidProcessRecipe> DISSOLUTION =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "dissolution"));

    /** 萃取柱配方类型：溶解液 + TBP → 铀钚萃取液 + 裂变产物废液。 */
    public static final RecipeType<FluidProcessRecipe> EXTRACTION =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "extraction"));

    /** 离心萃取器配方类型：萃取液 → 钚239 + 回收铀；废液 → 锶 / 铯 / 锕系。 */
    public static final RecipeType<FluidProcessRecipe> FISSION_SEPARATION =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "fission_separation"));

    /**
     * 核装置总装台配方类型：武器线的总装机器。
     *
     * <p>六颗核弹（空弹体 + 高能炸药 + 核装料 + 结构件）和全部模块化组件都走这一页，
     * 一台机器一套配方，玩家不用记「这个组件在哪台机器做」。
     */
    public static final RecipeType<MachineRecipe> WARHEAD_ASSEMBLY = recipeType("warhead_assembly");

    /** 玻璃固化炉配方类型：废液 + 玻璃 + 铅板 → 固化玻璃。 */
    public static final RecipeType<FluidProcessRecipe> VITRIFICATION =
            RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "vitrification"));

    public static final MachineRecipeSerializer CRUSHING_SERIALIZER = new MachineRecipeSerializer(CRUSHING);
    public static final MachineRecipeSerializer BALL_MILLING_SERIALIZER = new MachineRecipeSerializer(BALL_MILLING);
    public static final MachineRecipeSerializer FORGING_SERIALIZER = new MachineRecipeSerializer(FORGING);
    public static final MachineRecipeSerializer COMPACTING_SERIALIZER = new MachineRecipeSerializer(COMPACTING);
    public static final MachineRecipeSerializer SINTERING_SERIALIZER = new MachineRecipeSerializer(SINTERING);
    public static final MachineRecipeSerializer GRINDING_SERIALIZER = new MachineRecipeSerializer(GRINDING);
    public static final MachineRecipeSerializer WELDING_SERIALIZER = new MachineRecipeSerializer(WELDING);
    public static final MachineRecipeSerializer GAMMA_SERIALIZER = new MachineRecipeSerializer(GAMMA);
    public static final MachineRecipeSerializer IRRADIATION_SERIALIZER = new MachineRecipeSerializer(IRRADIATION);
    public static final FluidProcessRecipeSerializer COOLING_SERIALIZER = new FluidProcessRecipeSerializer(COOLING);
    public static final MachineRecipeSerializer HOT_CELL_SERIALIZER = new MachineRecipeSerializer(HOT_CELL);
    public static final FluidProcessRecipeSerializer CONDENSATION_SERIALIZER =
            new FluidProcessRecipeSerializer(CONDENSATION);
    public static final FluidProcessRecipeSerializer SPENT_FUEL_COOLING_SERIALIZER =
            new FluidProcessRecipeSerializer(SPENT_FUEL_COOLING);
    public static final MachineRecipeSerializer SHEARING_SERIALIZER = new MachineRecipeSerializer(SHEARING);
    public static final FluidProcessRecipeSerializer DISSOLUTION_SERIALIZER =
            new FluidProcessRecipeSerializer(DISSOLUTION);
    public static final FluidProcessRecipeSerializer EXTRACTION_SERIALIZER =
            new FluidProcessRecipeSerializer(EXTRACTION);
    public static final FluidProcessRecipeSerializer FISSION_SEPARATION_SERIALIZER =
            new FluidProcessRecipeSerializer(FISSION_SEPARATION);
    public static final FluidProcessRecipeSerializer VITRIFICATION_SERIALIZER =
            new FluidProcessRecipeSerializer(VITRIFICATION);
    public static final MachineRecipeSerializer WARHEAD_ASSEMBLY_SERIALIZER =
            new MachineRecipeSerializer(WARHEAD_ASSEMBLY);
    public static final AssemblerRecipeSerializer ASSEMBLER_SERIALIZER = new AssemblerRecipeSerializer(ASSEMBLER);
    public static final FluidProcessRecipeSerializer ELECTROLYSIS_SERIALIZER =
            new FluidProcessRecipeSerializer(ELECTROLYSIS);
    public static final FluidProcessRecipeSerializer CHEMICAL_PLANT_SERIALIZER =
            new FluidProcessRecipeSerializer(CHEMICAL_PLANT);
    public static final FluidProcessRecipeSerializer AIR_SEPARATION_SERIALIZER =
            new FluidProcessRecipeSerializer(AIR_SEPARATION);
    public static final FluidProcessRecipeSerializer GROUNDWATER_SERIALIZER =
            new FluidProcessRecipeSerializer(GROUNDWATER);
    public static final FluidProcessRecipeSerializer LEACHING_SERIALIZER =
            new FluidProcessRecipeSerializer(LEACHING);
    public static final FluidProcessRecipeSerializer PRECIPITATION_SERIALIZER =
            new FluidProcessRecipeSerializer(PRECIPITATION);
    public static final FluidProcessRecipeSerializer DRYING_SERIALIZER =
            new FluidProcessRecipeSerializer(DRYING);
    public static final FluidProcessRecipeSerializer CONVERSION_SERIALIZER =
            new FluidProcessRecipeSerializer(CONVERSION);
    public static final FluidProcessRecipeSerializer FLUORINATION_SERIALIZER =
            new FluidProcessRecipeSerializer(FLUORINATION);
    public static final FluidProcessRecipeSerializer CENTRIFUGE_SERIALIZER =
            new FluidProcessRecipeSerializer(CENTRIFUGE);
    public static final FluidProcessRecipeSerializer HYDROLYSIS_SERIALIZER =
            new FluidProcessRecipeSerializer(HYDROLYSIS);

    static {
        RECIPE_TYPES.register("crusher", () -> CRUSHING);
        RECIPE_TYPES.register("ball_mill", () -> BALL_MILLING);
        RECIPE_TYPES.register("forging_press", () -> FORGING);
        RECIPE_TYPES.register("compactor", () -> COMPACTING);
        RECIPE_TYPES.register("assembler", () -> ASSEMBLER);
        RECIPE_TYPES.register("electrolysis", () -> ELECTROLYSIS);
        RECIPE_TYPES.register("chemical_plant", () -> CHEMICAL_PLANT);
        RECIPE_TYPES.register("air_separation", () -> AIR_SEPARATION);
        RECIPE_TYPES.register("groundwater", () -> GROUNDWATER);
        RECIPE_TYPES.register("leaching", () -> LEACHING);
        RECIPE_TYPES.register("precipitation", () -> PRECIPITATION);
        RECIPE_TYPES.register("drying", () -> DRYING);
        RECIPE_TYPES.register("conversion", () -> CONVERSION);
        RECIPE_TYPES.register("fluorination", () -> FLUORINATION);
        RECIPE_TYPES.register("centrifuge", () -> CENTRIFUGE);
        RECIPE_TYPES.register("hydrolysis", () -> HYDROLYSIS);
        RECIPE_TYPES.register("sintering", () -> SINTERING);
        RECIPE_TYPES.register("grinding", () -> GRINDING);
        RECIPE_TYPES.register("welding", () -> WELDING);
        RECIPE_TYPES.register("gamma_irradiation", () -> GAMMA);
        RECIPE_TYPES.register("irradiation", () -> IRRADIATION);
        RECIPE_TYPES.register("cooling", () -> COOLING);
        RECIPE_TYPES.register("hot_cell", () -> HOT_CELL);
        RECIPE_TYPES.register("condensation", () -> CONDENSATION);
        RECIPE_TYPES.register("spent_fuel_cooling", () -> SPENT_FUEL_COOLING);
        RECIPE_TYPES.register("shearing", () -> SHEARING);
        RECIPE_TYPES.register("dissolution", () -> DISSOLUTION);
        RECIPE_TYPES.register("extraction", () -> EXTRACTION);
        RECIPE_TYPES.register("fission_separation", () -> FISSION_SEPARATION);
        RECIPE_TYPES.register("vitrification", () -> VITRIFICATION);
        RECIPE_TYPES.register("warhead_assembly", () -> WARHEAD_ASSEMBLY);

        RECIPE_SERIALIZERS.register("crusher", () -> CRUSHING_SERIALIZER);
        RECIPE_SERIALIZERS.register("ball_mill", () -> BALL_MILLING_SERIALIZER);
        RECIPE_SERIALIZERS.register("forging_press", () -> FORGING_SERIALIZER);
        RECIPE_SERIALIZERS.register("compactor", () -> COMPACTING_SERIALIZER);
        RECIPE_SERIALIZERS.register("assembler", () -> ASSEMBLER_SERIALIZER);
        RECIPE_SERIALIZERS.register("electrolysis", () -> ELECTROLYSIS_SERIALIZER);
        RECIPE_SERIALIZERS.register("chemical_plant", () -> CHEMICAL_PLANT_SERIALIZER);
        RECIPE_SERIALIZERS.register("air_separation", () -> AIR_SEPARATION_SERIALIZER);
        RECIPE_SERIALIZERS.register("groundwater", () -> GROUNDWATER_SERIALIZER);
        RECIPE_SERIALIZERS.register("leaching", () -> LEACHING_SERIALIZER);
        RECIPE_SERIALIZERS.register("precipitation", () -> PRECIPITATION_SERIALIZER);
        RECIPE_SERIALIZERS.register("drying", () -> DRYING_SERIALIZER);
        RECIPE_SERIALIZERS.register("conversion", () -> CONVERSION_SERIALIZER);
        RECIPE_SERIALIZERS.register("fluorination", () -> FLUORINATION_SERIALIZER);
        RECIPE_SERIALIZERS.register("centrifuge", () -> CENTRIFUGE_SERIALIZER);
        RECIPE_SERIALIZERS.register("hydrolysis", () -> HYDROLYSIS_SERIALIZER);
        RECIPE_SERIALIZERS.register("sintering", () -> SINTERING_SERIALIZER);
        RECIPE_SERIALIZERS.register("grinding", () -> GRINDING_SERIALIZER);
        RECIPE_SERIALIZERS.register("welding", () -> WELDING_SERIALIZER);
        RECIPE_SERIALIZERS.register("gamma_irradiation", () -> GAMMA_SERIALIZER);
        RECIPE_SERIALIZERS.register("irradiation", () -> IRRADIATION_SERIALIZER);
        RECIPE_SERIALIZERS.register("cooling", () -> COOLING_SERIALIZER);
        RECIPE_SERIALIZERS.register("hot_cell", () -> HOT_CELL_SERIALIZER);
        RECIPE_SERIALIZERS.register("condensation", () -> CONDENSATION_SERIALIZER);
        RECIPE_SERIALIZERS.register("spent_fuel_cooling", () -> SPENT_FUEL_COOLING_SERIALIZER);
        RECIPE_SERIALIZERS.register("shearing", () -> SHEARING_SERIALIZER);
        RECIPE_SERIALIZERS.register("dissolution", () -> DISSOLUTION_SERIALIZER);
        RECIPE_SERIALIZERS.register("extraction", () -> EXTRACTION_SERIALIZER);
        RECIPE_SERIALIZERS.register("fission_separation", () -> FISSION_SEPARATION_SERIALIZER);
        RECIPE_SERIALIZERS.register("vitrification", () -> VITRIFICATION_SERIALIZER);
        RECIPE_SERIALIZERS.register("warhead_assembly", () -> WARHEAD_ASSEMBLY_SERIALIZER);
    }

    private static RecipeType<MachineRecipe> recipeType(String path) {
        return RecipeType.simple(ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, path));
    }

    private ModRecipes() {}
}
