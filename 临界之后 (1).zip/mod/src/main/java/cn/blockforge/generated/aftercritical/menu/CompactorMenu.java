package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.CompactorBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 压块机 GUI 的菜单：左边 6 个输入槽（3 列 × 2 行），右边 6 个输出槽（3 列 × 2 行），下面是玩家背包。
 *
 * <p>坐标全部来自 {@link MachineLayout}，两边用一根粗箭头连起来。
 */
public class CompactorMenu extends AbstractMachineMenu {

    /** 输入槽第一格的左上角（16x16 物品区，不含凹槽边框）。 */
    public static final int INPUT_X = 30;
    public static final int INPUT_Y = 24;
    /** 输出槽第一格的左上角。 */
    public static final int OUTPUT_X = 126;
    public static final int OUTPUT_Y = 24;

    /** 输入格 → 输出格那段箭头。 */
    public static final MachineLayout.Arrow ARROW = new MachineLayout.Arrow(90, 32, 30);

    /** 每种槽的列数、行数，以及格子间距。 */
    public static final int COLUMNS = 3;
    public static final int ROWS = 2;
    public static final int STEP = 18;

    /** 服务端用：直接拿方块实体当容器。 */
    public CompactorMenu(int containerId, Inventory playerInventory, CompactorBlockEntity machine) {
        this(containerId, playerInventory, machine, machine);
    }

    /** 客户端用：拿不到方块实体时，容器可以是个空壳，内容由同步包填。 */
    public CompactorMenu(int containerId, Inventory playerInventory, Container container,
                         @Nullable EnergyMachineHost machine) {
        super(ModMenus.COMPACTOR.get(), containerId, playerInventory, CompactorBlockEntity.SLOT_COUNT, machine);
        for (int slot = 0; slot < CompactorBlockEntity.INPUT_SLOTS; slot++) {
            this.addSlot(new InputSlot(container, CompactorBlockEntity.FIRST_INPUT_SLOT + slot,
                    slotX(INPUT_X, slot), slotY(INPUT_Y, slot)));
        }
        for (int slot = 0; slot < CompactorBlockEntity.OUTPUT_SLOTS; slot++) {
            this.addSlot(new OutputSlot(container, CompactorBlockEntity.FIRST_OUTPUT_SLOT + slot,
                    slotX(OUTPUT_X, slot), slotY(OUTPUT_Y, slot)));
        }
        this.addPlayerInventory(playerInventory);
    }

    @Override
    public MachineLayout.Arrow arrowGeometry() {
        return ARROW;
    }

    /** 第 index 格在网格里占第几列（0、1、2、0、1、2……）。 */
    public static int column(int index) {
        return index % COLUMNS;
    }

    /** 第 index 格在网格里占第几行（0、0、0、1、1、1……）。 */
    public static int row(int index) {
        return index / COLUMNS;
    }

    public static int slotX(int originX, int index) {
        return originX + column(index) * STEP;
    }

    public static int slotY(int originY, int index) {
        return originY + row(index) * STEP;
    }

    /** 客户端收到「打开菜单」的包后调用：从包里的坐标找回方块实体。 */
    public static CompactorMenu fromNetwork(int containerId, Inventory playerInventory, RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof CompactorBlockEntity compactor) {
            return new CompactorMenu(containerId, playerInventory, compactor);
        }
        return new CompactorMenu(containerId, playerInventory,
                new SimpleContainer(CompactorBlockEntity.SLOT_COUNT), null);
    }
}
