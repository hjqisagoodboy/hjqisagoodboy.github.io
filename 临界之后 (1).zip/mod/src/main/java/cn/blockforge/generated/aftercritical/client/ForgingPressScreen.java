package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.ForgingPressMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** 锻压机的界面：模具 → 原料 → 箭头 → 成品。 */
public class ForgingPressScreen extends AbstractMachineScreen<ForgingPressMenu> {

    public ForgingPressScreen(ForgingPressMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    /** 第三行提示：模具要放最左边那格。 */
    @Override
    protected Component hintLine() {
        return Component.translatable("gui.aftercritical.forging.mold_hint");
    }
}
