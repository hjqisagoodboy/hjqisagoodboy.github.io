package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.ItemMachineMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * 烧结炉 / 磨削机 / 焊接机共用的界面。
 *
 * <p>面板、能量条、箭头、底部文字全部继承自 {@link AbstractMachineScreen}，
 * 这里只把「这台机器该怎么用」的那句话换掉。
 */
public class ItemMachineScreen extends AbstractMachineScreen<ItemMachineMenu> {

    public ItemMachineScreen(ItemMachineMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected Component hintLine() {
        return Component.translatable(this.menu.kind().hintKey());
    }
}
