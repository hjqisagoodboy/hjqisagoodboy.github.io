package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.block.TankPortBlock;
import cn.blockforge.generated.aftercritical.block.TankPortKind;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;

import javax.annotation.Nullable;

/**
 * 储罐的「口」：不存东西，只把自己这一面接到控制器的大罐子上。
 *
 * <p>输入口只允许灌，输出口只允许抽；没接上（外壳不完整、控制器被拆掉）时两个口都不干活，
 * 管道会以为这里没有接口，继续去别处找。
 */
public class TankPortBlockEntity extends BlockEntity {

    /** 自己接在哪个控制器上；还没接上就是 {@code null}。 */
    @Nullable
    private BlockPos controllerPos;

    public TankPortBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.TANK_PORT.get(), pos, state);
    }

    /** 这是输入口还是输出口。 */
    public TankPortKind kind() {
        return getBlockState().getBlock() instanceof TankPortBlock port ? port.kind() : TankPortKind.INPUT;
    }

    /** 控制器把「我接在这一口上」告诉这个口。 */
    public void bind(BlockPos pos) {
        if (!pos.equals(this.controllerPos)) {
            this.controllerPos = pos;
            setChanged();
        }
    }

    /** 外壳散了、控制器没了：断开。 */
    public void unbind() {
        if (this.controllerPos != null) {
            this.controllerPos = null;
            setChanged();
        }
    }

    /** 现在接着的控制器；没接上、或者结构已经散了的返回 {@code null}。 */
    @Nullable
    public TankControllerBlockEntity controller() {
        if (this.level == null || this.controllerPos == null) {
            return null;
        }
        if (!(this.level.getBlockEntity(this.controllerPos) instanceof TankControllerBlockEntity controller)) {
            return null;
        }
        if (!controller.isFormed() || !controller.containsPort(this.worldPosition)) {
            return null;
        }
        return controller;
    }

    /**
     * 在附近找一次控制器并接上。
     *
     * <p>区块加载的顺序不保证控制器先到，所以口自己也会找一遍；
     * 只有「控制器说这一格是它的口」才算数，不会接错罐子。
     */
    public void refreshController() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        for (BlockPos pos : BlockPos.betweenClosed(this.worldPosition.offset(-2, -2, -2),
                this.worldPosition.offset(2, 2, 2))) {
            if (this.level.getBlockEntity(pos) instanceof TankControllerBlockEntity controller
                    && controller.isFormed() && controller.containsPort(this.worldPosition)) {
                bind(pos.immutable());
                return;
            }
        }
    }

    @Override
    public void onLoad() {
        super.onLoad();
        refreshController();
    }

    public IFluidHandler getFluidHandler() {
        return this.fluidHandler;
    }

    private final IFluidHandler fluidHandler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return 1;
        }

        @Override
        public FluidStack getFluidInTank(int tank) {
            TankControllerBlockEntity controller = controller();
            return controller == null ? FluidStack.EMPTY : controller.tank().getFluid();
        }

        @Override
        public int getTankCapacity(int tank) {
            return TankControllerBlockEntity.CAPACITY;
        }

        @Override
        public boolean isFluidValid(int tank, FluidStack stack) {
            return kind() == TankPortKind.INPUT && controller() != null;
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            if (kind() != TankPortKind.INPUT) {
                return 0;
            }
            TankControllerBlockEntity controller = controller();
            if (controller == null) {
                return 0;
            }
            return controller.getFluidHandler().fill(resource, action);
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            if (kind() != TankPortKind.OUTPUT) {
                return FluidStack.EMPTY;
            }
            TankControllerBlockEntity controller = controller();
            if (controller == null) {
                return FluidStack.EMPTY;
            }
            return controller.getFluidHandler().drain(resource, action);
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            if (kind() != TankPortKind.OUTPUT) {
                return FluidStack.EMPTY;
            }
            TankControllerBlockEntity controller = controller();
            if (controller == null) {
                return FluidStack.EMPTY;
            }
            return controller.getFluidHandler().drain(maxDrain, action);
        }
    };

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (this.controllerPos != null) {
            tag.putLong("Controller", this.controllerPos.asLong());
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.controllerPos = tag.contains("Controller") ? BlockPos.of(tag.getLong("Controller")) : null;
    }
}
