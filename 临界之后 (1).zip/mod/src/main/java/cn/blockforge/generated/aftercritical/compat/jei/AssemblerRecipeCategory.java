package cn.blockforge.generated.aftercritical.compat.jei;

import cn.blockforge.generated.aftercritical.recipe.AssemblerIngredient;
import cn.blockforge.generated.aftercritical.recipe.AssemblerRecipe;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.builder.ITooltipBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.widgets.IRecipeExtrasBuilder;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.ItemLike;

import java.util.List;

/**
 * 装配机 T1 在 JEI 里的样子：左边摆好几种原料（带数量），右边是产物。
 *
 * <p>原料一多就排成 3 + 2 两列，最多同时显示 5 种，按配方里写的顺序摆。
 */
public class AssemblerRecipeCategory implements IRecipeCategory<AssemblerRecipe> {

    private static final int WIDTH = 132;
    private static final int HEIGHT = 82;

    private static final int MAX_SHOWN = 5;
    private static final int SLOT_STEP = 22;
    private static final int ARROW_X = 78;
    private static final int ARROW_Y = 18;
    private static final int OUTPUT_X = 104;

    private final RecipeType<AssemblerRecipe> recipeType;
    private final Component title;
    private final IDrawable icon;

    public AssemblerRecipeCategory(IGuiHelper guiHelper, RecipeType<AssemblerRecipe> recipeType,
                                   Component title, ItemLike machine) {
        this.recipeType = recipeType;
        this.title = title;
        this.icon = guiHelper.createDrawableItemLike(machine);
    }

    @Override
    public RecipeType<AssemblerRecipe> getRecipeType() {
        return this.recipeType;
    }

    @Override
    public Component getTitle() {
        return this.title;
    }

    @Override
    public IDrawable getIcon() {
        return this.icon;
    }


    @Override
    public int getWidth() {
        return WIDTH;
    }

    @Override
    public int getHeight() {
        return HEIGHT;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, AssemblerRecipe recipe, IFocusGroup focuses) {
        List<AssemblerIngredient> ingredients = recipe.ingredients();
        int shown = Math.min(MAX_SHOWN, ingredients.size());
        for (int i = 0; i < shown; i++) {
            AssemblerIngredient ingredient = ingredients.get(i);
            int x = 6 + (i % 3) * SLOT_STEP;
            int y = 6 + (i / 3) * SLOT_STEP;
            int count = ingredient.count();
            builder.addSlot(RecipeIngredientRole.INPUT, x, y)
                    .setStandardSlotBackground()
                    .addIngredients(ingredient.ingredient())
                    .addRichTooltipCallback((slot, tooltip) -> addCountTooltip(tooltip, count));
        }
        builder.addSlot(RecipeIngredientRole.OUTPUT, OUTPUT_X, 6)
                .setOutputSlotBackground()
                .addItemStack(recipe.result());
    }

    @Override
    public void createRecipeExtras(IRecipeExtrasBuilder builder, AssemblerRecipe recipe, IFocusGroup focuses) {
        builder.addRecipeArrow().setPosition(ARROW_X, ARROW_Y);
        builder.addText(Component.translatable("jei.aftercritical.recipe_info",
                String.format("%.1f", recipe.duration() / 20.0F), recipe.energyPerTick()), 6, 58);
        // 一级 / 二级配方现在已经分到两个分页里了，页面标题就是机器名，
        // 这里不用再补一行「需要：装配机 T2」，免得两句话重复。
    }

    private static void addCountTooltip(ITooltipBuilder tooltip, int count) {
        if (count > 1) {
            tooltip.add(Component.translatable("jei.aftercritical.count", count));
        }
    }
}
