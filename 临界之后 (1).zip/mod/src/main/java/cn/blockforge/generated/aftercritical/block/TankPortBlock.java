package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.TankPortBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 储罐多方块的「口」：流体输入口 / 流体输出口。
 *
 * <p>本身不存东西，只是把自己这一面接到控制器的大罐子上：
 * 输入口只让流体进，输出口只让流体出。
 *
 * <p>右键没有界面——它就是一个接口，接上智能流体管道就能用了。
 * 想拿通用流体罐手动灌/舀也行（方块身上的流体接口对罐子是开放的）。
 */
public class TankPortBlock extends BaseEntityBlock {

    private final TankPortKind kind;

    public TankPortBlock(Properties properties, TankPortKind kind) {
        super(properties);
        this.kind = kind;
    }

    /** 这是输入口还是输出口。 */
    public TankPortKind kind() {
        return this.kind;
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(properties -> new TankPortBlock(properties, this.kind));
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new TankPortBlockEntity(pos, state);
    }

    /** 邻居变了（比如旁边放上了控制器）就重新找一次控制器。 */
    @Override
    protected void neighborChanged(BlockState state, Level level, BlockPos pos, net.minecraft.world.level.block.Block neighbor,
                                   BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighbor, neighborPos, movedByPiston);
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof TankPortBlockEntity port) {
            port.refreshController();
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable(this.kind.descriptionKey()).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.tank_port.hint").withStyle(ChatFormatting.DARK_GRAY));
    }

    /** 口本身不挡光，方便看外壳。 */
    @Override
    protected boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
        return false;
    }
}
