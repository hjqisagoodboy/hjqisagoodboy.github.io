package cn.blockforge.generated.aftercritical.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * 锤子：工作台上敲模具用的工具。
 *
 * <p>它不是一次性消耗品：在合成台里每做一次模具，锤子只磨损 1 点耐久，
 * 做完还留在合成格里（耐久掉光才会消失）。
 * 这个「合成后留下的东西」由 {@link #getCraftingRemainingItem(ItemStack)} 决定，
 * 原版合成台的产物槽会按它把锤子放回去。
 */
public class HammerItem extends Item {

    /**
     * 满耐久时能敲多少下。
     *
     * <p>锤子是开局工具，不是长期替代锻压机的手段：一下铁块出 3 块板、
     * 一下铜块出 16 根线，够撑到发电机通电就够了。真要量产，交给锻压机。
     */
    public static final int DURABILITY = 64;

    public HammerItem(Properties properties) {
        super(properties);
    }

    /** 告诉合成台：这个东西合成后要留一份下来。 */
    @Override
    public boolean hasCraftingRemainingItem(ItemStack stack) {
        return true;
    }

    /** 留下的那一份：耐久 +1，掉光就返回空（锤子报废）。 */
    @Override
    public ItemStack getCraftingRemainingItem(ItemStack stack) {
        ItemStack worn = stack.copyWithCount(1);
        int nextDamage = worn.getDamageValue() + 1;
        if (nextDamage >= worn.getMaxDamage()) {
            return ItemStack.EMPTY;
        }
        worn.setDamageValue(nextDamage);
        return worn;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.hammer")
                .withStyle(ChatFormatting.GRAY));
    }
}
