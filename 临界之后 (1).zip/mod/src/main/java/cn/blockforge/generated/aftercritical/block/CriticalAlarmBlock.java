package cn.blockforge.generated.aftercritical.block;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

import java.util.List;

/**
 * 临界报警器：k_eff > 1.0 的时候响，并往外发满格红石信号（15）。
 *
 * <p>和探测器一样，判断和响铃都是控制器干的：控制器每 tick 看 k 有没有超过 1，
 * 超了就把周围这一圈报警器点亮（{@code powered} 属性变 true），并且每 20 tick 响一声。
 * 所以报警器必须砌在反应堆结构里才会被控制器管到。
 */
public class CriticalAlarmBlock extends Block {

    /** 现在是不是在报警（true 时换「亮」的贴图，并且输出 15 格红石）。 */
    public static final BooleanProperty POWERED = BlockStateProperties.POWERED;

    public CriticalAlarmBlock(Properties properties) {
        super(properties);
        registerDefaultState(defaultBlockState().setValue(POWERED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(POWERED);
    }

    @Override
    protected boolean isSignalSource(BlockState state) {
        return true;
    }

    @Override
    protected int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return state.getValue(POWERED) ? 15 : 0;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.critical_alarm.trigger")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.critical_alarm.place")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
