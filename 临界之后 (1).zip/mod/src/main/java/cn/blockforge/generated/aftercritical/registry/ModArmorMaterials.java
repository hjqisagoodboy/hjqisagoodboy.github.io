package cn.blockforge.generated.aftercritical.registry;

import cn.blockforge.generated.aftercritical.AfterCritical;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * 护甲材质：辐射防护服一套（对应 {@link ModItems} 里的四件套）。
 *
 * <p>1.21.1 的护甲不是「一个物品一张图」就完事的：要登记一条 {@link ArmorMaterial}
 * （防御值、耐久倍率、修理材料、外观贴图），再拿它去造四件 {@code ArmorItem}。
 * 外观贴图走 {@link ArmorMaterial.Layer}，两张图分别对应：
 * <ul>
 *   <li>{@code textures/models/armor/radiation_suit_layer_1.png} —— 头盔 / 胸甲 / 靴子；</li>
 *   <li>{@code textures/models/armor/radiation_suit_layer_2.png} —— 护腿。</li>
 * </ul>
 *
 * <p>防御值比铁（头盔 2 / 胸甲 6 / 护腿 5 / 靴子 2，共 15）高一档，共 20，
 * 刚好和钻石套持平；耐久倍率 25、附魔性 12，是「穿得久、能附魔，但不是终极护甲」的定位。
 * 真正值钱的是穿齐四件的防辐射效果，见 {@code RadiationProtection}。
 */
public final class ModArmorMaterials {

    public static final DeferredRegister<ArmorMaterial> ARMOR_MATERIALS =
            DeferredRegister.create(Registries.ARMOR_MATERIAL, AfterCritical.MOD_ID);

    /** 辐射防护服：铅板 + 隔热布，一整套穿齐才挡得住辐射。 */
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> RADIATION_SUIT =
            ARMOR_MATERIALS.register("radiation_suit", () -> new ArmorMaterial(
                    defense(),
                    12,
                    SoundEvents.ARMOR_EQUIP_LEATHER,
                    () -> Ingredient.of(ModItems.LEAD_PLATE.get()),
                    List.of(new ArmorMaterial.Layer(
                            ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "radiation_suit"))),
                    1.0F,
                    0.0F));

    private ModArmorMaterials() {}

    /** 四件的防御值：头 3 / 胸 8 / 腿 6 / 靴 3，合计 20。 */
    private static Map<ArmorItem.Type, Integer> defense() {
        Map<ArmorItem.Type, Integer> defense = new EnumMap<>(ArmorItem.Type.class);
        defense.put(ArmorItem.Type.HELMET, 3);
        defense.put(ArmorItem.Type.CHESTPLATE, 8);
        defense.put(ArmorItem.Type.LEGGINGS, 6);
        defense.put(ArmorItem.Type.BOOTS, 3);
        return defense;
    }
}
