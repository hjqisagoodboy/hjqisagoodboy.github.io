package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.FuelRodGeneratorBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/** 燃料棒发电机方块：MV，烧煤燃料棒，输出 320 FE/t。 */
public class FuelRodGeneratorBlock extends TickingMachineBlock {

    public FuelRodGeneratorBlock(Properties properties) {
        super(properties, "MV", "tooltip.aftercritical.output_per_tick",
                FuelRodGeneratorBlockEntity.OUTPUT_PER_TICK, "block.aftercritical.fuel_rod_generator.desc");
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(FuelRodGeneratorBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new FuelRodGeneratorBlockEntity(pos, state);
    }
}
