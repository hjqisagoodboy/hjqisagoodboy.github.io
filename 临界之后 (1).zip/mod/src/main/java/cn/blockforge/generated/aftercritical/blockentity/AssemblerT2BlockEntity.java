package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.menu.AssemblerT2Menu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 装配机 T2：MV 机器，额定 100 FE/t。
 *
 * <p>加工流程和 T1 一模一样（同一套装配配方、同样 6+1 个输入槽），
 * 区别只有三点：额定功率翻倍到 100 FE/t、属于 MV 级电网、界面叫「装配机 T2」。
 * 所以这里只覆盖 T1 的那几个参数，不重写任何加工代码。
 */
public class AssemblerT2BlockEntity extends AssemblerT1BlockEntity {

    /** 额定运行功率：100 FE/t（最终定稿 v4）。 */
    public static final int ENERGY_PER_TICK = 100;

    public AssemblerT2BlockEntity(BlockPos pos, BlockState state) {
        this(ModBlockEntities.ASSEMBLER_T2.get(), pos, state);
    }

    /** 给子类（装配机 T3）用的构造器：方块实体类型由子类自己指定。 */
    protected AssemblerT2BlockEntity(net.minecraft.world.level.block.entity.BlockEntityType<?> type,
                                     BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    @Override
    protected int baseEnergyPerTick() {
        return ENERGY_PER_TICK;
    }

    /** 装配机 T2 能做 1、2 两级配方（T1 的配方它也照做，方便升级后不用再摆一台 T1）。 */
    @Override
    protected int machineTier() {
        return 2;
    }

    @Override
    protected MenuType<?> menuType() {
        return ModMenus.ASSEMBLER_T2.get();
    }

    @Override
    protected String titleKey() {
        return "container.aftercritical.assembler_t2";
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new AssemblerT2Menu(containerId, playerInventory, this);
    }
}
