package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.HotCellArmBlockEntity;
import cn.blockforge.generated.aftercritical.effect.RadiationProtection;
import cn.blockforge.generated.aftercritical.registry.ModEffects;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 热室机械臂：隔着屏蔽墙把冷却好的靶材拆成同位素。
 *
 * <p>它有界面（1 格进、1 格出），只能处理【冷却的靶材】，每 tick 吃 32 FE。
 * 坏处是里面的东西都带强辐射：<b>直接用手拆方块</b>，或者<b>想用漏斗/管道从里面抽</b>，
 * 物品会掉一地，同时 3×3×3 范围内的活物都会吃一发辐射。
 * 所以正确做法是老老实实打开界面操作。
 */
public class HotCellArmBlock extends TickingMachineBlock {

    public static final String DESCRIPTION = "block.aftercritical.hot_cell_arm.desc";

    /** 吸入辐射的范围：以方块为中心 3×3×3。 */
    public static final double HAZARD_RADIUS = 1.5D;

    public HotCellArmBlock(Properties properties) {
        super(properties, "HV", "tooltip.aftercritical.energy_per_tick",
                HotCellArmBlockEntity.ENERGY_PER_TICK, DESCRIPTION);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(HotCellArmBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new HotCellArmBlockEntity(pos, state);
    }

    /** 拆方块时里面的东西照常掉出来，但是会带上辐射伤害。 */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        super.onRemove(state, level, pos, newState, movedByPiston);
        if (!level.isClientSide) {
            radiate(level, pos);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.aftercritical.hot_cell_arm.hazard")
                .withStyle(ChatFormatting.RED));
    }

    /**
     * 给 3×3×3 范围内的活物上辐射沾染，顺手扣 1 颗心。
     *
     * <p>方块实体（漏斗抽取）和方块的 {@code onRemove} 都调这里。
     */
    public static void radiate(Level level, BlockPos pos) {
        AABB box = new AABB(pos).inflate(HAZARD_RADIUS);
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, box)) {
            // 穿齐防护服的人不受这圈辐射影响
            if (RadiationProtection.isFullSuit(entity)) {
                continue;
            }
            entity.addEffect(new MobEffectInstance(ModEffects.RADIATION_CONTAMINATION, 30 * 20, 0));
            entity.hurt(entity.damageSources().magic(), 2.0F);
        }
        if (level instanceof net.minecraft.server.level.ServerLevel server) {
            server.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,
                    pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5,
                    12, 0.6, 0.6, 0.6, 0.02);
        }
    }
}
