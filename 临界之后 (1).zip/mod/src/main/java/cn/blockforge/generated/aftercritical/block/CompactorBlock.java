package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.CompactorBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/** 压块机方块：MV，100 FE/t，把散装原料压成结实的块（燃料棒）。 */
public class CompactorBlock extends MachineBlock {

    public CompactorBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(CompactorBlock::new);
    }

    @Override
    protected int energyPerTick() {
        return CompactorBlockEntity.ENERGY_PER_TICK;
    }

    /** 压块机是 MV 档，物品提示里要写 MV 而不是默认的 LV。 */
    @Override
    protected String tier() {
        return "MV";
    }

    @Override
    protected String recipeHintKey() {
        return "tooltip.aftercritical.compactor.recipes";
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CompactorBlockEntity(pos, state);
    }
}
