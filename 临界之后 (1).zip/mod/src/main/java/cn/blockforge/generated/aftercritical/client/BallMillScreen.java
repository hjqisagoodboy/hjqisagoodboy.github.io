package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.BallMillMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** 球磨机的界面：和破碎机长得一模一样，只是标题和配方不同。 */
public class BallMillScreen extends AbstractMachineScreen<BallMillMenu> {

    public BallMillScreen(BallMillMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }
}
