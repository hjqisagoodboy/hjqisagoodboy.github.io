package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.blockentity.GiantBatteryBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 巨型储能库的界面：和电池 LV / MV 一样，没有机器槽，只有一条能量条 + 电量数字。
 *
 * <p>差别只在数字大：这里是 1.2 亿 FE，界面第二行会直接写出来
 * （「能量：12,000,000 / 120,000,000 FE」），不用玩家自己数零。
 */
public class GiantBatteryMenu extends AbstractMachineMenu {

    public GiantBatteryMenu(int containerId, Inventory playerInventory, GiantBatteryBlockEntity battery) {
        this(containerId, playerInventory, battery, battery);
    }

    public GiantBatteryMenu(int containerId, Inventory playerInventory, Container container,
                            @Nullable EnergyMachineHost machine) {
        super(ModMenus.GIANT_BATTERY.get(), containerId, playerInventory, 0, machine);
        this.addPlayerInventory(playerInventory);
    }

    public static GiantBatteryMenu fromNetwork(int containerId, Inventory playerInventory,
                                               RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof GiantBatteryBlockEntity battery) {
            return new GiantBatteryMenu(containerId, playerInventory, battery);
        }
        return new GiantBatteryMenu(containerId, playerInventory, new SimpleContainer(0), null);
    }
}
