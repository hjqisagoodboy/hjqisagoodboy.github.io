package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.CableBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;

import javax.annotation.Nullable;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * LV / MV 线缆方块。
 *
 * <p>一根线缆就是六个方向上的「插头」：哪边挨着线缆、发电机、机器或者变压器，
 * 那一面就显示成接头，其它面缩在中间。连接状态用六个布尔属性记录：
 * {@code connected_north}、{@code connected_south}、{@code connected_east}、
 * {@code connected_west}、{@code connected_up}、{@code connected_down}，
 * 方块状态文件（blockstates/lv_cable.json）用 multipart 按这六个属性拼模型。
 *
 * <p>「挨着能通电的东西」= 那一面的邻居身上有 FE 接口（{@code Capabilities.EnergyStorage.BLOCK}），
 * 所以线缆跟线缆、发电机、电池、机器、变压器都会自动连上，不用玩家手动配。
 */
public class CableBlock extends BaseEntityBlock {

    public static final BooleanProperty CONNECTED_NORTH = BooleanProperty.create("connected_north");
    public static final BooleanProperty CONNECTED_EAST = BooleanProperty.create("connected_east");
    public static final BooleanProperty CONNECTED_SOUTH = BooleanProperty.create("connected_south");
    public static final BooleanProperty CONNECTED_WEST = BooleanProperty.create("connected_west");
    public static final BooleanProperty CONNECTED_UP = BooleanProperty.create("connected_up");
    public static final BooleanProperty CONNECTED_DOWN = BooleanProperty.create("connected_down");

    /** 「方向 → 对应的方块状态属性」，省得写六个 switch。 */
    public static final Map<Direction, BooleanProperty> CONNECTIONS = buildConnectionMap();

    /** 线缆的碰撞箱：中间那一小段，玩家可以踩过去也能穿过去。 */
    private static final VoxelShape CORE_SHAPE = Block.box(5.0D, 5.0D, 5.0D, 11.0D, 11.0D, 11.0D);

    private final CableTier tier;

    public CableBlock(Properties properties, CableTier tier) {
        super(properties);
        this.tier = tier;
        BlockState state = this.stateDefinition.any();
        for (BooleanProperty property : CONNECTIONS.values()) {
            state = state.setValue(property, Boolean.FALSE);
        }
        this.registerDefaultState(state);
    }

    public CableTier tier() {
        return this.tier;
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(properties -> new CableBlock(properties, this.tier));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(CONNECTED_NORTH, CONNECTED_EAST, CONNECTED_SOUTH, CONNECTED_WEST, CONNECTED_UP, CONNECTED_DOWN);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return CORE_SHAPE;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CableBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                  BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return (tickLevel, pos, tickState, blockEntity) -> {
            if (blockEntity instanceof CableBlockEntity cable) {
                cable.serverTick();
            }
        };
    }

    // ------------------------------------------------------------------
    // 连接状态
    // ------------------------------------------------------------------

    /** 放下时先算一遍六个方向。 */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return refreshConnections(context.getLevel(), context.getClickedPos(), defaultBlockState());
    }

    /**
     * 邻居变了（放下机器、拆掉线缆……）就重算这一面的接头。
     *
     * <p>{@code direction} 是从本方块指向邻居的方向；邻居朝向我们的那面是它的反方向。
     */
    @Override
    protected BlockState updateShape(BlockState state, Direction direction, BlockState neighbourState,
                                     LevelAccessor level, BlockPos pos, BlockPos neighbourPos) {
        return state.setValue(CONNECTIONS.get(direction),
                connectsTo(level, neighbourPos, direction.getOpposite()));
    }

    /** 把六个方向重新算一遍，返回新的方块状态（不改世界，调用方自己决定要不要 setBlock）。 */
    public BlockState refreshConnections(LevelAccessor level, BlockPos pos, BlockState state) {
        BlockState result = state;
        for (Direction direction : Direction.values()) {
            result = result.setValue(CONNECTIONS.get(direction),
                    connectsTo(level, pos.relative(direction), direction.getOpposite()));
        }
        return result;
    }

    /** 邻居身上有 FE 接口就算接上了。 */
    private static boolean connectsTo(LevelAccessor level, BlockPos neighbourPos, Direction faceOfNeighbour) {
        if (level instanceof Level realLevel) {
            IEnergyStorage storage = realLevel.getCapability(
                    Capabilities.EnergyStorage.BLOCK, neighbourPos, faceOfNeighbour);
            return storage != null;
        }
        // 世界生成阶段拿不到能力系统，退一步只认线缆自己
        return level.getBlockState(neighbourPos).getBlock() instanceof CableBlock;
    }

    /** 物品栏提示：等级、传输上限、会自动连谁。 */
    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.tier", this.tier.label())
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.cable.transfer", this.tier.maxTransfer())
                .withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.cable.auto_connect")
                .withStyle(ChatFormatting.GRAY));
    }

    private static Map<Direction, BooleanProperty> buildConnectionMap() {
        Map<Direction, BooleanProperty> map = new EnumMap<>(Direction.class);
        map.put(Direction.NORTH, CONNECTED_NORTH);
        map.put(Direction.EAST, CONNECTED_EAST);
        map.put(Direction.SOUTH, CONNECTED_SOUTH);
        map.put(Direction.WEST, CONNECTED_WEST);
        map.put(Direction.UP, CONNECTED_UP);
        map.put(Direction.DOWN, CONNECTED_DOWN);
        return map;
    }
}
