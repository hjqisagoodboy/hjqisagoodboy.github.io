package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.menu.FluidIdentifierMenu;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.material.Fluid;

import java.util.List;

/**
 * 流体识别码的界面：8×4 的流体格子 + 一个罐子槽。
 *
 * <p>每个格子里画一块那种流体的颜色（我方块的贴图本身是格子凹槽，颜色是代码填上去的），
 * 鼠标指上去会显示「中文名 + 英文 ID」。左键点一格 → 识别码绑定这种流体；
 * 罐子槽里放了空罐的话，顺手把这个罐子也预设成这种流体。
 */
public class FluidIdentifierScreen extends AbstractContainerScreen<FluidIdentifierMenu> {

    private static final ResourceLocation BACKGROUND = ResourceLocation.fromNamespaceAndPath(
            AfterCritical.MOD_ID, "textures/gui/fluid_identifier.png");

    private static final int TEXT_DARK = 0x404040;
    private static final int TEXT_GRAY = 0x707070;
    private static final int CELL_EDGE = 0xFF2A2A2A;
    private static final int SELECTED_EDGE = 0xFFFFFFFF;

    public FluidIdentifierScreen(FluidIdentifierMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
        this.imageWidth = FluidIdentifierMenu.IMAGE_WIDTH;
        this.imageHeight = FluidIdentifierMenu.IMAGE_HEIGHT;
        this.inventoryLabelY = FluidIdentifierMenu.INVENTORY_LABEL_Y;
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        guiGraphics.blit(BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight);
        drawCells(guiGraphics);
    }

    /** 往每个格子里填一块流体颜色。 */
    private void drawCells(GuiGraphics guiGraphics) {
        List<Fluid> fluids = FluidIdentifierMenu.registeredFluids();
        int boundId = fluidId(this.menu.boundFluid());
        for (int index = 0; index < FluidIdentifierMenu.GRID_COUNT; index++) {
            int x = this.leftPos + FluidIdentifierMenu.GRID_X + (index % FluidIdentifierMenu.COLUMNS)
                    * FluidIdentifierMenu.CELL;
            int y = this.topPos + FluidIdentifierMenu.GRID_Y + (index / FluidIdentifierMenu.COLUMNS)
                    * FluidIdentifierMenu.CELL;
            if (index >= fluids.size()) {
                continue;
            }
            Fluid fluid = fluids.get(index);
            int color = ModFluids.colorOf(fluid);
            guiGraphics.fill(x - 1, y - 1, x + 17, y + 17, CELL_EDGE);
            guiGraphics.fill(x, y, x + 16, y + 16, 0xFF000000 | (color & 0xFFFFFF));
            if (fluidId(fluid) == boundId) {
                // 当前绑定的那种，外面套一圈白框
                guiGraphics.fill(x - 2, y - 2, x + 18, y - 1, SELECTED_EDGE);
                guiGraphics.fill(x - 2, y + 17, x + 18, y + 18, SELECTED_EDGE);
                guiGraphics.fill(x - 2, y - 1, x - 1, y + 17, SELECTED_EDGE);
                guiGraphics.fill(x + 17, y - 1, x + 18, y + 17, SELECTED_EDGE);
            }
        }
    }

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        guiGraphics.drawString(this.font, this.title, 8, 6, TEXT_DARK, false);
        guiGraphics.drawString(this.font, this.playerInventoryTitle, 8, this.inventoryLabelY, TEXT_DARK, false);

        Fluid bound = this.menu.boundFluid();
        if (bound == null) {
            guiGraphics.drawString(this.font,
                    Component.translatable("gui.aftercritical.fluid_identifier.none"), 8, 94, TEXT_GRAY, false);
        } else {
            guiGraphics.drawString(this.font,
                    Component.translatable("gui.aftercritical.fluid_identifier.selected", fluidName(bound)),
                    8, 94, TEXT_DARK, false);
            guiGraphics.drawString(this.font, registryName(bound), 8, 103, TEXT_GRAY, false);
        }

        guiGraphics.drawString(this.font, Component.translatable("gui.aftercritical.fluid_identifier.jar"),
                28, 116, TEXT_GRAY, false);
    }

    /** 鼠标指在哪个格子上；指不到 -1。 */
    private int cellAt(int mouseX, int mouseY) {
        int gridX = this.leftPos + FluidIdentifierMenu.GRID_X;
        int gridY = this.topPos + FluidIdentifierMenu.GRID_Y;
        int width = FluidIdentifierMenu.COLUMNS * FluidIdentifierMenu.CELL;
        int height = FluidIdentifierMenu.ROWS * FluidIdentifierMenu.CELL;
        if (mouseX < gridX || mouseX >= gridX + width || mouseY < gridY || mouseY >= gridY + height) {
            return -1;
        }
        int column = (mouseX - gridX) / FluidIdentifierMenu.CELL;
        int row = (mouseY - gridY) / FluidIdentifierMenu.CELL;
        int index = row * FluidIdentifierMenu.COLUMNS + column;
        return index < FluidIdentifierMenu.registeredFluids().size() ? index : -1;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int cell = cellAt((int) mouseX, (int) mouseY);
        if (cell >= 0 && button == 0 && this.minecraft != null && this.minecraft.gameMode != null) {
            Fluid fluid = FluidIdentifierMenu.registeredFluids().get(cell);
            this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, fluidId(fluid));
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        int cell = cellAt(mouseX, mouseY);
        if (cell >= 0) {
            Fluid fluid = FluidIdentifierMenu.registeredFluids().get(cell);
            guiGraphics.renderComponentTooltip(this.font,
                    List.of(Component.literal(fluidName(fluid)),
                            Component.literal(registryName(fluid))
                                    .withStyle(net.minecraft.ChatFormatting.DARK_GRAY)),
                    mouseX, mouseY);
        }
    }

    private static int fluidId(Fluid fluid) {
        return fluid == null ? -1 : BuiltInRegistries.FLUID.getId(fluid);
    }

    private static String fluidName(Fluid fluid) {
        return ModFluids.displayName(fluidId(fluid)).getString();
    }

    private static String registryName(Fluid fluid) {
        ResourceLocation id = BuiltInRegistries.FLUID.getKey(fluid);
        return id == null ? "" : id.toString();
    }
}
