package cn.blockforge.generated.aftercritical.advancement;

import cn.blockforge.generated.aftercritical.AfterCritical;
import net.minecraft.advancements.CriterionTrigger;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 成就系统的「电线」：注册自定义触发条件，并提供两行代码就能用的喊话方法。
 *
 * <p>事件名用常量写死，机器那边和 JSON 里必须一字不差，所以只认这里的常量。
 */
public final class ModAdvancementTriggers {

    public static final DeferredRegister<CriterionTrigger<?>> TRIGGERS =
            DeferredRegister.create(Registries.TRIGGER_TYPE, AfterCritical.MOD_ID);

    /** 通用的「机器事件」触发器。 */
    public static final DeferredHolder<CriterionTrigger<?>, MachineEventTrigger> MACHINE_EVENT =
            TRIGGERS.register("machine_event", MachineEventTrigger::new);

    // ------------------------------------------------------------------
    // 事件名（JSON 里 conditions.event 写的就是这些字符串）
    // ------------------------------------------------------------------

    /** 任意一台发电机第一次真的发出了电。 */
    public static final String FIRST_POWER = "first_power";
    /** 次临界增殖装置的中子通量起来了。 */
    public static final String SUBCRITICAL_FLUX = "subcritical_flux";
    /** 临界实验堆 k_eff 第一次冲上 1.0。 */
    public static final String FISSION_CRITICAL = "fission_critical";
    /** 堆芯熔毁。 */
    public static final String FISSION_MELTDOWN = "fission_meltdown";
    /** 手上拿着一片辐射尘（成就「这是雪吗？」）。 */
    public static final String HOLD_RADIOACTIVE_DUST = "hold_radioactive_dust";
    /** 研究堆开始照靶材。 */
    public static final String RESEARCH_IRRADIATION = "research_irradiation";
    /** 压水堆开始出蒸汽。 */
    public static final String PWR_STEAM = "pwr_steam";
    /** 汽轮发电机并网发电。 */
    public static final String PWR_POWER = "pwr_power";
    /** 钠冷快堆开始出热。 */
    public static final String FAST_REACTOR = "fast_reactor";
    /** 托卡马克点火成功。 */
    public static final String TOKAMAK_IGNITE = "tokamak_ignite";
    /** 托卡马克稳态满功率跑满一分钟。 */
    public static final String TOKAMAK_STEADY = "tokamak_steady";
    /** 物质嬗变完成一次。 */
    public static final String TRANSMUTATION = "transmutation";
    /** 往地质处置库封存了固化玻璃。 */
    public static final String BURIAL = "burial";
    /** 玻璃固化炉走「同位素路线」烧出一块固化玻璃（成就「结局·深埋」的条件之一）。 */
    public static final String VITRIFY_ISOTOPE = "vitrify_isotope";
    /** 玻璃固化炉走「废液路线」烧出一块固化玻璃（成就「结局·深埋」的另一个条件）。 */
    public static final String VITRIFY_WASTE = "vitrify_waste";
    /** 用钴60源把生鸡肉照成熟鸡肉（成就「一源两用」的第一半）。 */
    public static final String GAMMA_COOKED_CHICKEN = "gamma_cooked_chicken";
    /** 用钴60源把腐肉照成皮革（成就「一源两用」的第二半）。 */
    public static final String GAMMA_LEATHER = "gamma_leather";
    /** 挖到一块「核弹炸出来的」核熔的钻石矿（隐藏结局「轮回」的一半）。 */
    public static final String MOLTEN_DIAMOND_MINED = "molten_diamond_mined";
    /** 挖到一块「核弹炸出来的」核熔的绿宝石矿（隐藏结局「轮回」的另一半）。 */
    public static final String MOLTEN_EMERALD_MINED = "molten_emerald_mined";

    // ------------------------------------------------------------------
    // 武器（核弹）
    // ------------------------------------------------------------------

    /** 往核弹里装进第一个模块化组件。 */
    public static final String NUKE_COMPONENT = "nuke_component";
    /** 六个组件槽全部插满之后再起爆。 */
    public static final String NUKE_FULL_LOADOUT = "nuke_full_loadout";
    /** 用钴-60 外壳起爆一次（「钴弹」成就）。 */
    public static final String NUKE_COBALT = "nuke_cobalt";

    /** 某颗核弹起爆的事件名：{@code detonate_little_boy} 这种。 */
    public static String detonateEvent(String nukeId) {
        return "detonate_" + nukeId;
    }

    private ModAdvancementTriggers() {}

    /** 给指定玩家记一次事件（客户端 / 非玩家实体直接忽略）。 */
    public static void fire(Player player, String event) {
        if (player instanceof ServerPlayer serverPlayer) {
            MACHINE_EVENT.get().fire(serverPlayer, event);
        }
    }

    /**
     * 给机器附近所有玩家记一次事件。
     *
     * <p>机器不知道「是谁在玩」，所以按距离找人：站在堆边看着它点火的都算。
     * 只在状态发生跳变的那一 tick 调用，不能每 tick 都来一遍（找实体不便宜）。
     */
    public static void fireNearby(Level level, BlockPos pos, double radius, String event) {
        if (!(level instanceof ServerLevel server)) {
            return;
        }
        for (ServerPlayer player : server.getEntitiesOfClass(ServerPlayer.class, new AABB(pos).inflate(radius))) {
            fire(player, event);
        }
    }
}
