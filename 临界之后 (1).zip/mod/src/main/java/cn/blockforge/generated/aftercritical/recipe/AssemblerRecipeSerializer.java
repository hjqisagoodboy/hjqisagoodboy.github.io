package cn.blockforge.generated.aftercritical.recipe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link AssemblerRecipe} 的读写器：JSON ↔ 配方对象，网络包 ↔ 配方对象。
 */
public final class AssemblerRecipeSerializer implements RecipeSerializer<AssemblerRecipe> {

    private static final Codec<AssemblerIngredient> INGREDIENT_CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Ingredient.CODEC_NONEMPTY.fieldOf("ingredient").forGetter(AssemblerIngredient::ingredient),
            Codec.INT.optionalFieldOf("count", 1).forGetter(AssemblerIngredient::count)
    ).apply(instance, AssemblerIngredient::new));

    private final RecipeType<AssemblerRecipe> type;
    private final MapCodec<AssemblerRecipe> codec;
    private final StreamCodec<RegistryFriendlyByteBuf, AssemblerRecipe> streamCodec;

    public AssemblerRecipeSerializer(RecipeType<AssemblerRecipe> type) {
        this.type = type;
        this.codec = RecordCodecBuilder.mapCodec(instance -> instance.group(
                INGREDIENT_CODEC.listOf().fieldOf("ingredients").forGetter(AssemblerRecipe::ingredients),
                ItemStack.CODEC.fieldOf("result").forGetter(AssemblerRecipe::result),
                Codec.INT.optionalFieldOf("time", 200).forGetter(AssemblerRecipe::duration),
                Codec.INT.optionalFieldOf("energy", 50).forGetter(AssemblerRecipe::energyPerTick),
                Codec.INT.optionalFieldOf("tier", 1).forGetter(AssemblerRecipe::tier)
        ).apply(instance, (ingredients, result, time, energy, tier) ->
                new AssemblerRecipe(ingredients, result, time, energy, tier, this)));

        this.streamCodec = StreamCodec.of(
                (RegistryFriendlyByteBuf buf, AssemblerRecipe recipe) -> {
                    buf.writeVarInt(recipe.ingredients().size());
                    for (AssemblerIngredient spec : recipe.ingredients()) {
                        Ingredient.CONTENTS_STREAM_CODEC.encode(buf, spec.ingredient());
                        buf.writeVarInt(spec.count());
                    }
                    ItemStack.STREAM_CODEC.encode(buf, recipe.result());
                    buf.writeVarInt(recipe.duration());
                    buf.writeVarInt(recipe.energyPerTick());
                    buf.writeVarInt(recipe.tier());
                },
                (RegistryFriendlyByteBuf buf) -> {
                    int size = buf.readVarInt();
                    List<AssemblerIngredient> ingredients = new ArrayList<>(size);
                    for (int i = 0; i < size; i++) {
                        Ingredient ingredient = Ingredient.CONTENTS_STREAM_CODEC.decode(buf);
                        ingredients.add(new AssemblerIngredient(ingredient, buf.readVarInt()));
                    }
                    ItemStack result = ItemStack.STREAM_CODEC.decode(buf);
                    int time = buf.readVarInt();
                    int energy = buf.readVarInt();
                    int tier = buf.readVarInt();
                    return new AssemblerRecipe(ingredients, result, time, energy, tier, this);
                });
    }

    @Override
    public MapCodec<AssemblerRecipe> codec() {
        return this.codec;
    }

    @Override
    public StreamCodec<RegistryFriendlyByteBuf, AssemblerRecipe> streamCodec() {
        return this.streamCodec;
    }

    public RecipeType<AssemblerRecipe> type() {
        return this.type;
    }
}
