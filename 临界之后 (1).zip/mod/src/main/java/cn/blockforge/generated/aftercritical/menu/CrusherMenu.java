package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.CrusherBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 破碎机 GUI 的菜单：机器槽 2 个（输入、输出）+ 玩家背包。
 *
 * <p>坐标全部来自 {@link MachineLayout}：左边能量条、中间「输入 → 输出」+ 箭头、右边留空。
 */
public class CrusherMenu extends AbstractMachineMenu {

    public static final int INPUT_X = 30;
    public static final int INPUT_Y = 30;
    public static final int OUTPUT_X = 118;
    public static final int OUTPUT_Y = 30;

    /** 输入 → 输出那段箭头。 */
    public static final MachineLayout.Arrow ARROW = new MachineLayout.Arrow(52, 38, 62);

    /** 服务端用：直接拿方块实体当容器。 */
    public CrusherMenu(int containerId, Inventory playerInventory, CrusherBlockEntity machine) {
        this(containerId, playerInventory, machine, machine);
    }

    /** 客户端用：拿不到方块实体时，容器可以是个空壳，内容由同步包填。 */
    public CrusherMenu(int containerId, Inventory playerInventory, Container container,
                       @Nullable EnergyMachineHost machine) {
        super(ModMenus.CRUSHER.get(), containerId, playerInventory, CrusherBlockEntity.SLOT_COUNT, machine);
        this.addSlot(new InputSlot(container, CrusherBlockEntity.SLOT_INPUT, INPUT_X, INPUT_Y));
        this.addSlot(new OutputSlot(container, CrusherBlockEntity.SLOT_OUTPUT, OUTPUT_X, OUTPUT_Y));
        this.addPlayerInventory(playerInventory);
    }

    @Override
    public MachineLayout.Arrow arrowGeometry() {
        return ARROW;
    }

    /** 客户端收到「打开菜单」的包后调用：从包里的坐标找回方块实体。 */
    public static CrusherMenu fromNetwork(int containerId, Inventory playerInventory, RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof CrusherBlockEntity crusher) {
            return new CrusherMenu(containerId, playerInventory, crusher);
        }
        return new CrusherMenu(containerId, playerInventory,
                new SimpleContainer(CrusherBlockEntity.SLOT_COUNT), null);
    }
}
