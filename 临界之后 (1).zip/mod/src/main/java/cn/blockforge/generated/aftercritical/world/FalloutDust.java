package cn.blockforge.generated.aftercritical.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 核爆之后飘 5 分钟的粉尘。
 *
 * <p>爆心 120 格以内一直灰蒙蒙的一片：站在里面的人周围随时能看到灰在飘，
 * 站在外面看，爆心上空也还是脏的。5 分钟（6000 tick）之后散干净。
 *
 * <p>为什么按玩家发、而不是按坐标发：粒子包只送到 32 格内的玩家，按坐标发的话
 * 远处的人什么都看不见。这里对每个玩家单独算——近处的人周围撒一把，远处的人
 * 在爆心上空补几缕，谁都能看出「那边炸过」，每个人的开销又都很小。
 */
public final class FalloutDust {

    /** 粉尘飘多久（5 分钟）。 */
    public static final int DURATION = 5 * 60 * 20;
    /** 最远还给发粒子的玩家距离（格）。 */
    private static final double VIEW_RADIUS = 600.0;
    /** 站在爆心附近的人，自己周围撒灰的范围。 */
    private static final double LOCAL_RADIUS = 20.0;

    private static final List<Task> TASKS = new ArrayList<>();

    private FalloutDust() {}

    /** 起一片粉尘（跟着核爆一起开始）。 */
    public static void start(ServerLevel level, BlockPos core, int blastRadius) {
        TASKS.add(new Task(level, core.immutable(), blastRadius));
    }

    /** 服务端每 tick 推进一次。 */
    public static void tick(MinecraftServer server) {
        if (TASKS.isEmpty()) {
            return;
        }
        Iterator<Task> iterator = TASKS.iterator();
        while (iterator.hasNext()) {
            Task task = iterator.next();
            if (task.level.getServer() != server) {
                continue;
            }
            if (task.tick()) {
                iterator.remove();
            }
        }
    }

    private static final class Task {
        private final ServerLevel level;
        private final BlockPos core;
        private final int blastRadius;
        private int age;

        private Task(ServerLevel level, BlockPos core, int blastRadius) {
            this.level = level;
            this.core = core;
            this.blastRadius = blastRadius;
        }

        private boolean tick() {
            if (++this.age >= DURATION) {
                // 5 分钟了，顺手再清一遍掉落物：扫尾阶段烤掉的树可能还在掉树苗
                NuclearBlast.cleanDrops(this.level, this.core, NuclearBlast.CLEANUP_RADIUS);
                return true;
            }
            // 每 2 tick 发一次就够密了，不必每 tick 都发
            if (this.age % 2 != 0) {
                return false;
            }

            Vec3 center = Vec3.atCenterOf(this.core);
            RandomSource random = this.level.random;
            for (ServerPlayer player : this.level.players()) {
                double distance = player.position().distanceTo(center);
                if (distance > VIEW_RADIUS) {
                    continue;
                }
                if (distance <= this.blastRadius + LOCAL_RADIUS) {
                    localHaze(player, random);
                } else {
                    distantHaze(player, random, center);
                }
            }
            return false;
        }

        /** 站在废墟里的人：脚边撒一层灰，头顶再飘几团。 */
        private void localHaze(ServerPlayer player, RandomSource random) {
            this.level.sendParticles(player, ParticleTypes.ASH, true,
                    player.getX(), player.getY() + 0.6, player.getZ(),
                    4, 16.0, 1.2, 16.0, 0.0);

            ParticleOptions air = switch (random.nextInt(3)) {
                case 0 -> ParticleTypes.WHITE_ASH;
                case 1 -> ParticleTypes.CLOUD;
                default -> ParticleTypes.LARGE_SMOKE;
            };
            this.level.sendParticles(player, air, true,
                    player.getX(), player.getY() + 7.0, player.getZ(),
                    3, 20.0, 7.0, 20.0, 0.005);
        }

        /** 站在外面看的人：在爆心上空补几缕，让人看得出那边还灰着。 */
        private void distantHaze(ServerPlayer player, RandomSource random, Vec3 center) {
            ParticleOptions type = random.nextBoolean() ? ParticleTypes.WHITE_ASH : ParticleTypes.ASH;
            this.level.sendParticles(player, type, true,
                    center.x + (random.nextDouble() - 0.5) * 160.0,
                    center.y + 18.0 + random.nextDouble() * 60.0,
                    center.z + (random.nextDouble() - 0.5) * 160.0,
                    2, 26.0, 10.0, 26.0, 0.0);
        }
    }
}
