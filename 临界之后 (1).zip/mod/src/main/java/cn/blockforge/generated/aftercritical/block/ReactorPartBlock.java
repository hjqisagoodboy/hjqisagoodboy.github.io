package cn.blockforge.generated.aftercritical.block;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.Block;

import java.util.List;

/**
 * 压水堆的「结构方块」：压力壳、冷却塔这种只是砌墙用的。
 *
 * <p>没有界面、不耗电、也不存东西，唯一多做的一件事是物品栏里写一句它是干什么的，
 * 免得新手拿着一堆方块不知道往哪摆。
 */
public class ReactorPartBlock extends Block {

    private final String descriptionKey;

    public ReactorPartBlock(Properties properties, String descriptionKey) {
        super(properties);
        this.descriptionKey = descriptionKey;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        tooltip.add(Component.translatable(this.descriptionKey).withStyle(ChatFormatting.GRAY));
    }
}
