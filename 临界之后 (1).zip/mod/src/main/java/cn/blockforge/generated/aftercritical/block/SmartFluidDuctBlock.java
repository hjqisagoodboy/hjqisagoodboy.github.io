package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.SmartFluidDuctBlockEntity;
import cn.blockforge.generated.aftercritical.item.FluidIdentifierItem;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.phys.BlockHitResult;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 智能流体管道（参考 HBM 的智能流体管道）：盖了章才干活、只搬盖的那种流体。
 *
 * <p>三句话说完用法：
 * <ol>
 *   <li>放下时是<b>空白</b>的，不搬任何东西；</li>
 *   <li>拿流体识别码右键它 → 盖章，从此只搬识别码上那一种流体；</li>
 *   <li>只有盖了<b>同一种章</b>的管道和它接得上，空白管道谁都不接。</li>
 * </ol>
 *
 * <p>每 tick 从相邻的「装着自己这种流体」的输出口抽 100 mB，顺着同一张网送进最近的输入口。
 * 管道不耗电。盖的章用颜色显示：整根管子会染成那种流体的颜色，空白的保持金属灰。
 */
public class SmartFluidDuctBlock extends AbstractPipeBlock {

    /**
     * 这根管道盖的是几号流体（编号见 {@code ModFluids#ductIndexOf}）。
     *
     * <p>这个属性不参与传输逻辑，纯粹是为了「盖章之后方块状态变了、客户端重新烘一遍模型」：
     * 方块颜色是在烘焙模型时算进网格的，只改方块实体数据的话客户端不会重画，
     * 玩家就会看到「章盖了但管子还是灰的」。
     */
    public static final IntegerProperty FLUID_INDEX =
            IntegerProperty.create("fluid_index", ModFluids.DUCT_INDEX_NONE, ModFluids.DUCT_INDEX_MAX);

    public SmartFluidDuctBlock(Properties properties) {
        super(properties);
    }

    /** 六个方向的接头 + 自己盖的章，一共七个方块状态属性。 */
    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(FLUID_INDEX);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(SmartFluidDuctBlock::new);
    }

    /**
     * 这一面算不算接上。
     *
     * <p>邻居是管道：两边都盖了章、而且是同一种流体才算接上（空白管道不跟任何人接）；
     * 邻居是机器/罐子：只要有流体接口就接上，方便玩家一眼看出管子通向哪儿。
     */
    @Override
    protected boolean canConnectTo(LevelAccessor level, BlockPos selfPos, BlockPos neighbourPos,
                                   Direction faceOfNeighbour) {
        BlockEntity neighbour = level.getBlockEntity(neighbourPos);
        if (neighbour instanceof SmartFluidDuctBlockEntity other) {
            return level.getBlockEntity(selfPos) instanceof SmartFluidDuctBlockEntity self
                    && self.isSameMarkerAs(other);
        }
        if (level instanceof Level realLevel) {
            return realLevel.getCapability(Capabilities.FluidHandler.BLOCK, neighbourPos, faceOfNeighbour) != null;
        }
        return false;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new SmartFluidDuctBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                  BlockEntityType<T> type) {
        if (level.isClientSide) {
            return null;
        }
        return (tickLevel, pos, tickState, blockEntity) -> {
            if (blockEntity instanceof SmartFluidDuctBlockEntity duct) {
                duct.serverTick();
            }
        };
    }

    // ------------------------------------------------------------------
    // 盖章
    // ------------------------------------------------------------------

    /**
     * 拿流体识别码右键 → 给这根管子盖章。
     *
     * <p>识别码没绑定流体时不做任何改动，只给玩家一句提示；
     * 手里拿的不是识别码就返回「交给方块自己处理」，不影响正常放方块。
     */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!(stack.getItem() instanceof FluidIdentifierItem)) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        Fluid fluid = FluidIdentifierItem.boundFluid(stack);
        if (fluid == null) {
            if (!level.isClientSide) {
                player.displayClientMessage(
                        Component.translatable("message.aftercritical.fluid_identifier.unbound"), true);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof SmartFluidDuctBlockEntity duct) {
            duct.setMarker(fluid);
            player.displayClientMessage(Component.translatable(
                    "message.aftercritical.smart_fluid_duct.marked",
                    new FluidStack(fluid, 1).getHoverName()), true);
            level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 0.8F, 1.2F);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** 物品栏提示：这管子怎么用。 */
    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.smart_fluid_duct.desc")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.smart_fluid_duct.howto")
                .withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.pipe.no_power")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
