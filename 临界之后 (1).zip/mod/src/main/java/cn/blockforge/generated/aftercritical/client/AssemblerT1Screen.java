package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.AssemblerT1Menu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * 装配机 T1 的界面。
 *
 * <p>装配机能做什么，直接看 JEI 里的「装配机 T1」分类，机器界面保持干净：
 * 中间两行原料、左下角一格放装着液体的通用罐、右边箭头指着产物。
 */
public class AssemblerT1Screen extends AbstractMachineScreen<AssemblerT1Menu> {

    public AssemblerT1Screen(AssemblerT1Menu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected Component hintLine() {
        return Component.translatable("gui.aftercritical.assembler.hint");
    }
}
