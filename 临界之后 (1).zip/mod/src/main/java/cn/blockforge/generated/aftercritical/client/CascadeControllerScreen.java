package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.CascadeControllerMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * 级联控制器的界面：三根长条（进料 / 产物一 / 产物二）+ 每根右边一对罐子槽。
 *
 * <p>底下第一行多写一句「已连接离心机 n / 32」——离心机是扫出来的，
 * 所以挪动离心机之后这个数字 1 秒内会自己变。
 */
public class CascadeControllerScreen extends AbstractMachineScreen<CascadeControllerMenu> {

    public CascadeControllerScreen(CascadeControllerMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected Component statusLine() {
        Component base = super.statusLine();
        return Component.literal(base.getString() + "  ·  "
                + Component.translatable("gui.aftercritical.cascade.connected",
                this.menu.getConnected(), this.menu.getMaxCentrifuges()).getString());
    }

    @Override
    protected Component hintLine() {
        return Component.translatable("gui.aftercritical.fluid.jar_hint");
    }
}
