package cn.blockforge.generated.aftercritical.block;

/**
 * 储罐多方块的两个「口」。
 *
 * <p>一个口只干一件事，所以玩家一眼就能看出管路该怎么接：
 * <ul>
 *   <li>{@link #INPUT} 流体输入口：只能往里灌（智能流体管道的送货端、机器的出液口都接这一面）；</li>
 *   <li>{@link #OUTPUT} 流体输出口：只能往外抽（智能流体管道的抽取端接这一面）。</li>
 * </ul>
 *
 * <p>两个口都是同一个方块类，只是方块里存着不同的 {@code kind}。
 */
public enum TankPortKind {

    /** 输入口：收液。 */
    INPUT("tooltip.aftercritical.tank_port.input"),

    /** 输出口：放液。 */
    OUTPUT("tooltip.aftercritical.tank_port.output");

    private final String descriptionKey;

    TankPortKind(String descriptionKey) {
        this.descriptionKey = descriptionKey;
    }

    /** 物品提示里那句说明的语言键。 */
    public String descriptionKey() {
        return this.descriptionKey;
    }
}
