package cn.blockforge.generated.aftercritical.recipe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;

import java.util.ArrayList;
import java.util.List;

/**
 * {@link FluidProcessRecipe} 的读写器：JSON ↔ 配方对象，网络包 ↔ 配方对象。
 *
 * <p>和矿机那边一样，三个配方类型（电解、化工、空气分离）共用一个读写器，
 * 差别只在构造时传进来的 {@code type}。
 */
public final class FluidProcessRecipeSerializer implements RecipeSerializer<FluidProcessRecipe> {

    private static final Codec<AssemblerIngredient> ITEM_INPUT_CODEC = RecordCodecBuilder.create(instance ->
            instance.group(
                    Ingredient.CODEC_NONEMPTY.fieldOf("ingredient").forGetter(AssemblerIngredient::ingredient),
                    Codec.INT.optionalFieldOf("count", 1).forGetter(AssemblerIngredient::count)
            ).apply(instance, AssemblerIngredient::new));

    private static final Codec<FluidAmount> FLUID_CODEC = RecordCodecBuilder.create(instance ->
            instance.group(
                    ResourceLocation.CODEC.fieldOf("fluid").forGetter(FluidAmount::fluid),
                    Codec.INT.fieldOf("amount").forGetter(FluidAmount::amount)
            ).apply(instance, FluidAmount::new));

    private final RecipeType<FluidProcessRecipe> type;
    private final MapCodec<FluidProcessRecipe> codec;
    private final StreamCodec<RegistryFriendlyByteBuf, FluidProcessRecipe> streamCodec;

    public FluidProcessRecipeSerializer(RecipeType<FluidProcessRecipe> type) {
        this.type = type;

        this.codec = RecordCodecBuilder.mapCodec(instance -> instance.group(
                ITEM_INPUT_CODEC.listOf().optionalFieldOf("item_inputs", List.of())
                        .forGetter(FluidProcessRecipe::itemInputs),
                FLUID_CODEC.listOf().optionalFieldOf("fluid_inputs", List.of())
                        .forGetter(FluidProcessRecipe::fluidInputs),
                ItemStack.CODEC.listOf().optionalFieldOf("item_outputs", List.of())
                        .forGetter(FluidProcessRecipe::itemOutputs),
                FLUID_CODEC.listOf().optionalFieldOf("fluid_outputs", List.of())
                        .forGetter(FluidProcessRecipe::fluidOutputs),
                // 催化剂（可选，不消耗）：电解槽靠它把「水 → 氘」和「水 → 氢 + 氧」分成两条配方
                ITEM_INPUT_CODEC.optionalFieldOf("catalyst").forGetter(FluidProcessRecipe::catalyst),
                Codec.INT.optionalFieldOf("time", 200).forGetter(FluidProcessRecipe::duration),
                Codec.INT.optionalFieldOf("energy", 40).forGetter(FluidProcessRecipe::energyPerTick)
        ).apply(instance, (itemInputs, fluidInputs, itemOutputs, fluidOutputs, catalyst, time, energy) ->
                new FluidProcessRecipe(itemInputs, fluidInputs, itemOutputs, fluidOutputs, catalyst,
                        time, energy, this)));

        this.streamCodec = StreamCodec.of(
                (RegistryFriendlyByteBuf buf, FluidProcessRecipe recipe) -> {
                    buf.writeVarInt(recipe.itemInputs().size());
                    for (AssemblerIngredient spec : recipe.itemInputs()) {
                        Ingredient.CONTENTS_STREAM_CODEC.encode(buf, spec.ingredient());
                        buf.writeVarInt(spec.count());
                    }
                    buf.writeVarInt(recipe.fluidInputs().size());
                    for (FluidAmount spec : recipe.fluidInputs()) {
                        writeFluid(buf, spec);
                    }
                    buf.writeVarInt(recipe.itemOutputs().size());
                    for (ItemStack stack : recipe.itemOutputs()) {
                        ItemStack.STREAM_CODEC.encode(buf, stack);
                    }
                    buf.writeVarInt(recipe.fluidOutputs().size());
                    for (FluidAmount spec : recipe.fluidOutputs()) {
                        writeFluid(buf, spec);
                    }
                    buf.writeBoolean(recipe.catalyst().isPresent());
                    recipe.catalyst().ifPresent(catalyst -> {
                        Ingredient.CONTENTS_STREAM_CODEC.encode(buf, catalyst.ingredient());
                        buf.writeVarInt(catalyst.count());
                    });
                    buf.writeVarInt(recipe.duration());
                    buf.writeVarInt(recipe.energyPerTick());
                },
                (RegistryFriendlyByteBuf buf) -> {
                    List<AssemblerIngredient> itemInputs = new ArrayList<>();
                    for (int i = 0, size = buf.readVarInt(); i < size; i++) {
                        Ingredient ingredient = Ingredient.CONTENTS_STREAM_CODEC.decode(buf);
                        itemInputs.add(new AssemblerIngredient(ingredient, buf.readVarInt()));
                    }
                    List<FluidAmount> fluidInputs = new ArrayList<>();
                    for (int i = 0, size = buf.readVarInt(); i < size; i++) {
                        fluidInputs.add(readFluid(buf));
                    }
                    List<ItemStack> itemOutputs = new ArrayList<>();
                    for (int i = 0, size = buf.readVarInt(); i < size; i++) {
                        itemOutputs.add(ItemStack.STREAM_CODEC.decode(buf));
                    }
                    List<FluidAmount> fluidOutputs = new ArrayList<>();
                    for (int i = 0, size = buf.readVarInt(); i < size; i++) {
                        fluidOutputs.add(readFluid(buf));
                    }
                    java.util.Optional<AssemblerIngredient> catalyst = java.util.Optional.empty();
                    if (buf.readBoolean()) {
                        Ingredient ingredient = Ingredient.CONTENTS_STREAM_CODEC.decode(buf);
                        catalyst = java.util.Optional.of(new AssemblerIngredient(ingredient, buf.readVarInt()));
                    }
                    int time = buf.readVarInt();
                    int energy = buf.readVarInt();
                    return new FluidProcessRecipe(itemInputs, fluidInputs, itemOutputs, fluidOutputs,
                            catalyst, time, energy, FluidProcessRecipeSerializer.this);
                });
    }

    private static void writeFluid(RegistryFriendlyByteBuf buf, FluidAmount spec) {
        buf.writeResourceLocation(spec.fluid());
        buf.writeVarInt(spec.amount());
    }

    private static FluidAmount readFluid(RegistryFriendlyByteBuf buf) {
        return new FluidAmount(buf.readResourceLocation(), buf.readVarInt());
    }

    @Override
    public MapCodec<FluidProcessRecipe> codec() {
        return this.codec;
    }

    @Override
    public StreamCodec<RegistryFriendlyByteBuf, FluidProcessRecipe> streamCodec() {
        return this.streamCodec;
    }

    public RecipeType<FluidProcessRecipe> type() {
        return this.type;
    }
}
