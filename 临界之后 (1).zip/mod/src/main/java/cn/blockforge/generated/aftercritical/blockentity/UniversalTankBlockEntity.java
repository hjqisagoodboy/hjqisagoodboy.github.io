package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.fluid.TankContent;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModDataComponents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

import javax.annotation.Nullable;

/**
 * 通用储罐的方块实体：一个 32,000 mB 的罐子，先用流体识别码「盖章」，之后只收那一种流体。
 *
 * <p>和原来那个「硼酸储罐」的区别：
 * <ul>
 *   <li><b>什么都能装</b>：水、岩浆、硫酸、核废水、别的模组的流体都行，容量 32 桶（32,000 mB）；</li>
 *   <li><b>绑定</b>：拿绑好的流体识别码右键它，以后就只认这一种（防止管道把别的东西灌进来）；</li>
 *   <li><b>没绑也能用</b>：空罐子第一次被灌进什么，就自动绑定那种流体——
 *       懒得盖章时直接把管道接上也能跑，不会把两种液体混在一个罐子里；</li>
 *   <li><b>拆除保留内容</b>：挖掉时里面的流体和绑定都会跟着方块物品走，重新放下还在；
 *       想清空就用空手潜行右键解绑（罐子必须是空的）。</li>
 * </ul>
 *
 * <p>对外就是一个标准的流体接口（六面），智能流体管道、通用流体罐、别的模组的管道都能直接接。
 */
public class UniversalTankBlockEntity extends BlockEntity implements TickableBlockEntity {

    /** 容量：32 桶。 */
    public static final int CAPACITY = 32_000;

    /** 绑定的流体；{@code null} 表示还没绑定（什么都能装）。 */
    @Nullable
    private Fluid bound;

    private final FluidTank tank = new FluidTank(CAPACITY) {
        @Override
        public boolean isFluidValid(FluidStack stack) {
            return UniversalTankBlockEntity.this.accepts(stack.getFluid());
        }
    };

    private final IFluidHandler fluidHandler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return 1;
        }

        @Override
        public FluidStack getFluidInTank(int index) {
            return UniversalTankBlockEntity.this.tank.getFluid();
        }

        @Override
        public int getTankCapacity(int index) {
            return CAPACITY;
        }

        @Override
        public boolean isFluidValid(int index, FluidStack stack) {
            return UniversalTankBlockEntity.this.accepts(stack.getFluid());
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            if (!UniversalTankBlockEntity.this.accepts(resource.getFluid())) {
                return 0;
            }
            int filled = UniversalTankBlockEntity.this.tank.fill(resource, action);
            if (filled > 0 && action.execute()) {
                // 没盖章的罐子：第一次进什么就绑什么，之后只认这一种
                if (UniversalTankBlockEntity.this.bound == null) {
                    UniversalTankBlockEntity.this.bound = resource.getFluid();
                }
                setChanged();
            }
            return filled;
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            FluidStack drained = UniversalTankBlockEntity.this.tank.drain(resource, action);
            if (!drained.isEmpty() && action.execute()) {
                setChanged();
            }
            return drained;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            FluidStack drained = UniversalTankBlockEntity.this.tank.drain(maxDrain, action);
            if (!drained.isEmpty() && action.execute()) {
                setChanged();
            }
            return drained;
        }
    };

    public UniversalTankBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.UNIVERSAL_TANK.get(), pos, state);
    }

    public IFluidHandler getFluidHandler() {
        return this.fluidHandler;
    }

    public FluidTank tank() {
        return this.tank;
    }

    public int amount() {
        return this.tank.getFluidAmount();
    }

    public FluidStack stored() {
        return this.tank.getFluid();
    }

    @Nullable
    public Fluid boundFluid() {
        return this.bound;
    }

    /** 这个罐子收不收 {@code fluid}：没绑定时什么都能装；绑定了就只认那一种。 */
    public boolean accepts(Fluid fluid) {
        if (this.bound != null) {
            return this.bound.isSame(fluid);
        }
        FluidStack stored = this.tank.getFluid();
        return stored.isEmpty() || stored.getFluid().isSame(fluid);
    }

    /**
     * 绑定一种流体（传 {@code null} 是解绑）。
     *
     * @return 成功返回 true；罐子里已经有别的流体、或者解绑时罐子还没倒空，返回 false
     */
    public boolean bind(@Nullable Fluid fluid) {
        if (fluid == null) {
            if (!this.tank.isEmpty()) {
                return false;
            }
            this.bound = null;
            setChanged();
            return true;
        }
        if (!this.tank.isEmpty() && !this.tank.getFluid().getFluid().isSame(fluid)) {
            return false;
        }
        this.bound = fluid;
        setChanged();
        return true;
    }

    /**
     * 方块从物品变回世界时，把挖掉时带走的流体 / 绑定装回来。
     *
     * <p>方块物品上的数据组件有两种：
     * {@code FLUID}（罐子里有东西）和 {@code PRESET_FLUID}（罐子是空的，但绑了一种流体）。
     */
    public void loadFromItem(ItemStack stack) {
        TankContent content = stack.get(ModDataComponents.FLUID.get());
        if (content != null && content.amount() > 0) {
            FluidStack stored = content.toStack();
            this.bound = stored.getFluid();
            this.tank.fill(stored.copyWithAmount(Math.min(stored.getAmount(), CAPACITY)),
                    IFluidHandler.FluidAction.EXECUTE);
        } else {
            TankContent preset = stack.get(ModDataComponents.PRESET_FLUID.get());
            if (preset != null) {
                this.bound = preset.fluidValue();
            }
        }
        setChanged();
    }

    /** 这个罐子没有每 tick 的活，接口留着是为了跟别的方块一样的写法。 */
    @Override
    public void serverTick() {
        // 进出全靠外部的管道和罐子
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Tank", this.tank.writeToNBT(registries, new CompoundTag()));
        if (this.bound != null) {
            tag.putString("Bound", BuiltInRegistries.FLUID.getKey(this.bound).toString());
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.tank.readFromNBT(registries, tag.getCompound("Tank"));
        this.bound = null;
        if (tag.contains("Bound")) {
            ResourceLocation id = ResourceLocation.tryParse(tag.getString("Bound"));
            if (id != null) {
                Fluid fluid = BuiltInRegistries.FLUID.get(id);
                if (fluid != null) {
                    this.bound = fluid;
                }
            }
        }
    }
}
