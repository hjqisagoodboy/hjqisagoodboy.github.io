package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.CoolantPortBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 冷却剂端口：压水堆的进出水口。
 *
 * <p>一个端口身上有两个罐子：<b>进水罐</b>只收水，<b>出汽罐</b>只放蒸汽。
 * 智能流体管道、通用流体罐、原版桶都能直接接上——往进水罐灌水，
 * 从出汽罐抽走蒸汽送去汽轮发电机。一个堆至少要 2 个端口（1 进 1 出）。
 */
public class CoolantPortBlock extends TickablePartBlock {

    public static final String DESCRIPTION = "block.aftercritical.coolant_port.desc";

    public CoolantPortBlock(Properties properties) {
        super(properties, DESCRIPTION);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(CoolantPortBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CoolantPortBlockEntity(pos, state);
    }
}
