package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.BatteryLvBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/** 电池 LV 的 GUI 菜单：没有机器槽，只有电量和玩家背包。 */
public class BatteryLvMenu extends AbstractMachineMenu {

    public BatteryLvMenu(int containerId, Inventory playerInventory, BatteryLvBlockEntity battery) {
        this(containerId, playerInventory, battery, battery);
    }

    public BatteryLvMenu(int containerId, Inventory playerInventory, Container container,
                         @Nullable EnergyMachineHost machine) {
        super(ModMenus.BATTERY_LV.get(), containerId, playerInventory, 0, machine);
        this.addPlayerInventory(playerInventory);
    }

    public static BatteryLvMenu fromNetwork(int containerId, Inventory playerInventory,
                                            RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof BatteryLvBlockEntity battery) {
            return new BatteryLvMenu(containerId, playerInventory, battery);
        }
        return new BatteryLvMenu(containerId, playerInventory, new SimpleContainer(0), null);
    }
}
