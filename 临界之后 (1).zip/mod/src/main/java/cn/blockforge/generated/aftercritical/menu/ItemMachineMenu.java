package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.blockentity.ItemMachineBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.ItemMachineKind;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 烧结炉 / 磨削机 / 焊接机共用的菜单。
 *
 * <p>版式还是那把统一的尺子：左边能量条，中间一排「输入 → 输出」，
 * 输入槽从左往右排，输出槽从 {@value #OUTPUT_X} 开始排，中间一根箭头串起来。
 * 焊接机是 2 进 1 出、磨削机是 1 进 2 出，槽数由 {@link ItemMachineKind} 决定，
 * 所以同一个界面类能同时给三台机器用。
 */
public class ItemMachineMenu extends AbstractMachineMenu {

    /** 第一个输入槽的左上角。 */
    public static final int INPUT_X = 30;
    public static final int INPUT_Y = 30;
    /** 第一个输出槽的左上角。 */
    public static final int OUTPUT_X = 128;
    /** 格子间距（16 像素格子 + 2 像素缝）。 */
    public static final int STEP = 18;

    private final ItemMachineKind kind;

    public ItemMachineMenu(MenuType<?> type, int containerId, Inventory playerInventory, Container container,
                           @Nullable EnergyMachineHost machine, ItemMachineKind kind) {
        super(type, containerId, playerInventory, kind.slotCount(), machine);
        this.kind = kind;

        for (int i = 0; i < kind.itemInputs(); i++) {
            this.addSlot(new InputSlot(container, kind.inputSlot(i), INPUT_X + i * STEP, INPUT_Y));
        }
        for (int j = 0; j < kind.itemOutputs(); j++) {
            this.addSlot(new OutputSlot(container, kind.outputSlot(j), OUTPUT_X + j * STEP, INPUT_Y));
        }
        this.addPlayerInventory(playerInventory);
    }

    /** 这台界面是哪台机器（界面拿它查提示文字）。 */
    public ItemMachineKind kind() {
        return this.kind;
    }

    /** 输入方阵和输出方阵之间那根箭头，长度跟着槽数自动伸缩。 */
    @Override
    public MachineLayout.Arrow arrowGeometry() {
        int start = INPUT_X + this.kind.itemInputs() * STEP + 2;
        int end = OUTPUT_X - 6;
        return new MachineLayout.Arrow(start, INPUT_Y + 8, Math.max(18, end - start));
    }

    /** 客户端收到「打开菜单」的包后调用。 */
    public static ItemMachineMenu fromNetwork(MenuType<?> type, int containerId, Inventory playerInventory,
                                              RegistryFriendlyByteBuf buffer, ItemMachineKind kind) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof ItemMachineBlockEntity machine) {
            return new ItemMachineMenu(type, containerId, playerInventory, machine, machine, kind);
        }
        return new ItemMachineMenu(type, containerId, playerInventory,
                new SimpleContainer(kind.slotCount()), null, kind);
    }
}
