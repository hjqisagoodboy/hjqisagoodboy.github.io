package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.blockentity.PwrControllerBlockEntity;
import cn.blockforge.generated.aftercritical.menu.PwrControllerMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;

/**
 * 压水堆控制器的界面。
 *
 * <p>版式和阶段 3 的反应堆类似：上面一条控制棒插入深度滑块（左边「−」右边「+」，
 * 中间可以直接点），右边两根流体长条（水 / 蒸汽），底下七行热工读数。
 *
 * <p>玩法就一句话：把燃料插够、控制棒插深一点，让温度别超过 1,200 °C，
 * 同时保证水一直供得上——水一断，温度会一路往上飙。
 */
public class PwrControllerScreen extends StatPanelScreen<PwrControllerMenu> {

    // 滑块布局（面板坐标）
    private static final int SLIDER_X = 30;
    private static final int SLIDER_Y = 52;
    private static final int SLIDER_W = 78;
    private static final int SLIDER_H = 8;
    private static final int BUTTON_MINUS_X = 13;
    private static final int BUTTON_PLUS_X = 111;
    private static final int BUTTON_Y = 50;
    private static final int BUTTON_W = 15;
    private static final int BUTTON_H = 12;

    public PwrControllerScreen(PwrControllerMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected List<Line> statLines() {
        List<Line> lines = new ArrayList<>(PwrControllerMenu.STAT_LINES);

        boolean formed = this.menu.isFormed();
        lines.add(new Line(Component.translatable(formed
                ? "gui.aftercritical.reactor.structure_ok"
                : "gui.aftercritical.reactor.structure_missing"), formed ? TEXT_OK : TEXT_BAD));

        lines.add(new Line(Component.translatable("gui.aftercritical.pwr.mat",
                this.menu.shell(), PwrControllerBlockEntity.MIN_SHELL,
                this.menu.lead(), PwrControllerBlockEntity.MIN_LEAD), TEXT_GRAY));

        lines.add(new Line(Component.translatable("gui.aftercritical.pwr.mat2",
                this.menu.concrete(), PwrControllerBlockEntity.MIN_CONCRETE,
                this.menu.glass(), PwrControllerBlockEntity.MIN_GLASS), TEXT_GRAY));

        lines.add(new Line(Component.translatable("gui.aftercritical.pwr.ports",
                this.menu.fuelPorts(), this.menu.rodPorts(), this.menu.coolantPorts()), TEXT_GRAY));

        lines.add(new Line(Component.translatable("gui.aftercritical.pwr.fuel",
                this.menu.fuel(), PwrControllerBlockEntity.MIN_FUEL, PwrControllerBlockEntity.MAX_FUEL,
                this.menu.rods(), PwrControllerBlockEntity.MIN_RODS), TEXT_DARK));

        lines.add(new Line(Component.translatable("gui.aftercritical.pwr.thermal",
                this.menu.temperature(), this.menu.thermalPower(), this.menu.steamPerTick()),
                this.menu.temperature() >= PwrControllerBlockEntity.TEMP_DAMAGE ? TEXT_BAD : TEXT_DARK));

        if (this.menu.melted() > 0) {
            lines.add(new Line(Component.translatable("gui.aftercritical.pwr.melted", this.menu.melted()),
                    TEXT_BAD));
        } else {
            lines.add(new Line(Component.translatable("gui.aftercritical.pwr.status." + this.menu.status()),
                    statusColorOf(this.menu.status())));
        }
        return lines;
    }

    private static int statusColorOf(int status) {
        return switch (status) {
            case PwrControllerBlockEntity.STATUS_RUNNING -> TEXT_OK;
            case PwrControllerBlockEntity.STATUS_OVERHEAT -> TEXT_BAD;
            case PwrControllerBlockEntity.STATUS_NO_WATER, PwrControllerBlockEntity.STATUS_NO_SPACE,
                 PwrControllerBlockEntity.STATUS_SCRAM -> TEXT_WARN;
            default -> TEXT_GRAY;
        };
    }

    // ------------------------------------------------------------------
    // 背景：控制棒滑块
    // ------------------------------------------------------------------

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        super.renderBg(guiGraphics, partialTick, mouseX, mouseY);

        int x = this.leftPos + SLIDER_X;
        int y = this.topPos + SLIDER_Y;

        guiGraphics.fill(x - 1, y - 1, x + SLIDER_W + 1, y + SLIDER_H + 1, PANEL_DARK);
        guiGraphics.fill(x, y, x + SLIDER_W, y + SLIDER_H, ENERGY_TRACK);
        int filled = Math.round(SLIDER_W * this.menu.rodDepth() / 100.0F);
        if (filled > 0) {
            guiGraphics.fill(x, y, x + filled, y + SLIDER_H, 0xFF4A9BD8);
            guiGraphics.fill(x, y, x + filled, y + 1, 0xFF8FD0FF);
        }

        drawButton(guiGraphics, this.leftPos + BUTTON_MINUS_X, this.topPos + BUTTON_Y, "-");
        drawButton(guiGraphics, this.leftPos + BUTTON_PLUS_X, this.topPos + BUTTON_Y, "+");

        guiGraphics.drawString(this.font,
                Component.translatable("gui.aftercritical.pwr.depth", this.menu.rodDepth()),
                this.leftPos + SLIDER_X, this.topPos + SLIDER_Y + 12, TEXT_DARK, false);
        guiGraphics.drawString(this.font,
                Component.translatable("gui.aftercritical.pwr.water",
                        this.menu.barAmount(0), this.menu.barAmount(1), this.menu.barCapacity()),
                this.leftPos + SLIDER_X, this.topPos + SLIDER_Y + 24, TEXT_DARK, false);
    }

    private void drawButton(GuiGraphics guiGraphics, int x, int y, String text) {
        guiGraphics.fill(x, y, x + BUTTON_W, y + BUTTON_H, PANEL_BG);
        guiGraphics.fill(x, y, x + BUTTON_W, y + 1, PANEL_LIGHT);
        guiGraphics.fill(x, y + BUTTON_H - 1, x + BUTTON_W, y + BUTTON_H, PANEL_DARK);
        guiGraphics.fill(x, y, x + 1, y + BUTTON_H, PANEL_LIGHT);
        guiGraphics.fill(x + BUTTON_W - 1, y, x + BUTTON_W, y + BUTTON_H, PANEL_DARK);
        int textWidth = this.font.width(text);
        guiGraphics.drawString(this.font, text,
                x + (BUTTON_W - textWidth) / 2, y + (BUTTON_H - 8) / 2 + 1, TEXT_DARK, false);
    }

    // ------------------------------------------------------------------
    // 点按钮 / 点滑块
    // ------------------------------------------------------------------

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && this.minecraft != null && this.minecraft.gameMode != null) {
            int x = (int) mouseX - this.leftPos;
            int y = (int) mouseY - this.topPos;
            if (inside(x, y, BUTTON_MINUS_X, BUTTON_Y, BUTTON_W, BUTTON_H)) {
                send(PwrControllerMenu.BUTTON_ROD_LESS);
                return true;
            }
            if (inside(x, y, BUTTON_PLUS_X, BUTTON_Y, BUTTON_W, BUTTON_H)) {
                send(PwrControllerMenu.BUTTON_ROD_MORE);
                return true;
            }
            if (inside(x, y, SLIDER_X, SLIDER_Y, SLIDER_W, SLIDER_H)) {
                int percent = Math.round((x - SLIDER_X) * 100.0F / SLIDER_W);
                send(PwrControllerMenu.BUTTON_ROD_ABSOLUTE + Math.max(0, Math.min(100, percent)));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void send(int buttonId) {
        if (this.minecraft != null && this.minecraft.gameMode != null) {
            this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, buttonId);
        }
    }

    private static boolean inside(int x, int y, int left, int top, int width, int height) {
        return x >= left && x < left + width && y >= top && y < top + height;
    }
}
