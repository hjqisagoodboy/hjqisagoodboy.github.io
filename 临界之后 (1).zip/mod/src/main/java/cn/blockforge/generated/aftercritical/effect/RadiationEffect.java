package cn.blockforge.generated.aftercritical.effect;

import cn.blockforge.generated.aftercritical.AfterCritical;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

/**
 * 辐射沾染（radiation_contamination）。
 *
 * <ul>
 *   <li>每秒扣 1 点血（半颗心），血量见底到 1 点时不再继续扣，不会直接致死。</li>
 *   <li>挖掘速度降低 30%。</li>
 * </ul>
 */
public class RadiationEffect extends MobEffect {
    private static final ResourceLocation MINING_SLOWDOWN_ID =
            ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "radiation_mining_slowdown");

    /** 每秒（20 tick）结算一次。 */
    private static final int TICKS_PER_SECOND = 20;
    /** 每次扣 1 点血 = 半颗心。 */
    private static final float DAMAGE_PER_SECOND = 1.0F;
    /** 扣血的下限：血量为 1 点时停手。 */
    private static final float MIN_HEALTH = 1.0F;

    public RadiationEffect() {
        super(MobEffectCategory.HARMFUL, 0x6FA84B);
        this.addAttributeModifier(
                Attributes.BLOCK_BREAK_SPEED,
                MINING_SLOWDOWN_ID,
                -0.3D,
                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
    }

    @Override
    public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
        return duration % TICKS_PER_SECOND == 0;
    }

    @Override
    public boolean applyEffectTick(LivingEntity entity, int amplifier) {
        // 防护服按件数削伤害：每件少 25%，四件齐了就是 0（而且根本不会挂上这个效果）
        float damage = (float) (DAMAGE_PER_SECOND * RadiationProtection.radiationMultiplier(entity));
        if (!entity.level().isClientSide && damage > 0.0F && entity.getHealth() - damage >= MIN_HEALTH) {
            entity.hurt(entity.damageSources().magic(), damage);
        }
        return true;
    }
}
