package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.block.TransmutatorControllerBlock;
import cn.blockforge.generated.aftercritical.energy.BufferedEnergyStorage;
import cn.blockforge.generated.aftercritical.itemhandler.ContainerItemHandler;
import cn.blockforge.generated.aftercritical.menu.TransmutatorMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModBlocks;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.items.IItemHandler;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 物质嬗变器控制器：7×7×7 多方块的心脏，模组的终点机器。
 *
 * <p>它自己不发一度电：结构里的【能量端口】接收 256 格内托卡马克的无线供电，
 * 控制器每 tick 从端口里抽最多 20,000 FE 存进自己的 1,000,000 FE 缓冲。
 *
 * <p>一次嬗变：1 个【锕系元素】+ <b>1,000,000 FE</b> → 1 个【短寿命同位素】，耗时 60 秒。
 * 电没攒够就停在「缺电」，产量和距离都摆在界面里，玩家一看就知道是不是离太远了。
 */
public class TransmutatorControllerBlockEntity extends BlockEntity
        implements Container, net.minecraft.world.MenuProvider, TickableBlockEntity, EnergyMachineHost {

    // ------------------------------------------------------------------
    // 结构
    // ------------------------------------------------------------------

    /** 7×7×7 的正方体。 */
    public static final int SIZE = 7;
    /** 外壳至少多少块。 */
    public static final int MIN_CASING = 48;
    /** 超导线圈正好 8 块（磁约束把锕系元素「捏」在中间）。 */
    public static final int MIN_COILS = 8;
    /** 能量端口至少 1 个。 */
    public static final int MIN_PORTS = 1;

    /** 结构每 2 秒重查一次。 */
    public static final int VALIDATE_INTERVAL = 40;

    // ------------------------------------------------------------------
    // 数值（定稿 v4）
    // ------------------------------------------------------------------

    /** 一次嬗变消耗的能量。 */
    public static final int COST = 1_000_000;
    /** 一次嬗变耗时：60 秒。 */
    public static final int DURATION = 1_200;
    /** 内部缓冲容量：正好装下一次嬗变。 */
    public static final int ENERGY_CAPACITY = 1_000_000;
    /** 每 tick 从能量端口抽多少电。 */
    public static final int PULL_PER_TICK = 20_000;
    /** 无线供电半径（和托卡马克对齐）。 */
    public static final int WIRELESS_RANGE = 256;

    /** 输入槽：锕系元素。 */
    public static final int SLOT_INPUT = 0;
    /** 输出槽：短寿命同位素。 */
    public static final int SLOT_OUTPUT = 1;

    // ------------------------------------------------------------------
    // 界面状态码
    // ------------------------------------------------------------------

    public static final int STATUS_UNFORMED = 0;
    public static final int STATUS_NO_PARTS = 1;
    public static final int STATUS_NO_ENERGY = 2;
    public static final int STATUS_NO_INPUT = 3;
    public static final int STATUS_OUTPUT_FULL = 4;
    public static final int STATUS_RUNNING = 5;
    public static final int STATUS_IDLE = 6;

    // ------------------------------------------------------------------
    // 状态
    // ------------------------------------------------------------------

    private final NonNullList<ItemStack> items = NonNullList.withSize(2, ItemStack.EMPTY);
    private final IItemHandler itemHandler = new ContainerItemHandler(this,
            slot -> slot == SLOT_INPUT,
            slot -> slot == SLOT_OUTPUT);
    private final BufferedEnergyStorage energy =
            new BufferedEnergyStorage(ENERGY_CAPACITY, PULL_PER_TICK, 0, this::setChanged);

    private boolean formed;
    private int casingCount;
    private int coilCount;
    private int portCount;
    private int validateTimer;
    private List<BlockPos> ports = List.of();

    private boolean working;
    private int progress;
    private int status = STATUS_UNFORMED;
    private int inputCount;

    public TransmutatorControllerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.TRANSMUTATOR_CONTROLLER.get(), pos, state);
    }

    public IItemHandler getItemHandler() {
        return this.itemHandler;
    }

    public IEnergyStorage getEnergyStorage() {
        return this.energy;
    }

    public void validateSoon() {
        this.validateTimer = 1;
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        if (--this.validateTimer <= 0) {
            this.validateTimer = VALIDATE_INTERVAL;
            validateStructure();
        }

        pullFromPorts();
        this.inputCount = countInput();

        if (!this.formed) {
            this.working = false;
            this.progress = 0;
        }

        if (this.working) {
            if (this.level instanceof ServerLevel server && this.progress % 20 == 0) {
                server.sendParticles(ParticleTypes.ENCHANT,
                        this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 1.2,
                        this.worldPosition.getZ() + 0.5, 4, 0.5, 0.4, 0.5, 0.05);
            }
            this.progress++;
            if (this.progress >= DURATION) {
                finishTransmutation();
            }
        } else if (canStart()) {
            startTransmutation();
        }

        int newStatus = computeStatus();
        if (this.status != newStatus) {
            this.status = newStatus;
            setChanged();
        }
        setChanged();
    }

    /** 从结构里的能量端口抽电。 */
    private void pullFromPorts() {
        if (this.level == null || this.ports.isEmpty()) {
            return;
        }
        int budget = Math.min(this.energy.getFreeSpace(), PULL_PER_TICK);
        for (BlockPos pos : this.ports) {
            if (budget <= 0) {
                break;
            }
            if (this.level.getBlockEntity(pos) instanceof EnergyPortBlockEntity port) {
                int taken = port.takeEnergy(budget);
                if (taken > 0) {
                    this.energy.grow(taken);
                    budget -= taken;
                }
            }
        }
    }

    private boolean canStart() {
        if (!this.formed || this.inputCount <= 0) {
            return false;
        }
        if (this.energy.getEnergyStored() < COST) {
            return false;
        }
        return hasOutputRoom();
    }

    private void startTransmutation() {
        if (!this.energy.consume(COST)) {
            return;
        }
        consumeOneInput();
        this.working = true;
        this.progress = 0;
        if (this.level instanceof ServerLevel server) {
            server.playSound(null, this.worldPosition, SoundEvents.BEACON_AMBIENT, SoundSource.BLOCKS, 0.6F, 0.6F);
        }
        setChanged();
    }

    private void finishTransmutation() {
        this.working = false;
        this.progress = 0;
        ItemStack out = this.items.get(SLOT_OUTPUT);
        if (out.isEmpty()) {
            this.items.set(SLOT_OUTPUT, new ItemStack(ModItems.SHORT_LIVED_ISOTOPE.get()));
        } else if (out.is(ModItems.SHORT_LIVED_ISOTOPE.get()) && out.getCount() < out.getMaxStackSize()) {
            out.grow(1);
        }
        if (this.level instanceof ServerLevel server) {
            server.playSound(null, this.worldPosition, SoundEvents.BEACON_POWER_SELECT, SoundSource.BLOCKS, 0.7F, 1.4F);
        }
        // 成就「物质嬗变」：第一次真的把锕系元素变成短寿命同位素
        ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 48.0,
                ModAdvancementTriggers.TRANSMUTATION);
        setChanged();
    }

    private boolean hasOutputRoom() {
        ItemStack out = this.items.get(SLOT_OUTPUT);
        if (out.isEmpty()) {
            return true;
        }
        return out.is(ModItems.SHORT_LIVED_ISOTOPE.get()) && out.getCount() < out.getMaxStackSize();
    }

    private int countInput() {
        ItemStack stack = this.items.get(SLOT_INPUT);
        return stack.is(ModItems.ACTINIDES.get()) ? stack.getCount() : 0;
    }

    private void consumeOneInput() {
        ItemStack stack = this.items.get(SLOT_INPUT);
        stack.shrink(1);
        if (stack.isEmpty()) {
            this.items.set(SLOT_INPUT, ItemStack.EMPTY);
        }
    }

    private int computeStatus() {
        if (!this.formed) {
            return this.casingCount >= MIN_CASING && this.coilCount >= MIN_COILS && this.portCount >= MIN_PORTS
                    ? STATUS_UNFORMED
                    : STATUS_NO_PARTS;
        }
        if (this.working) {
            return STATUS_RUNNING;
        }
        if (this.inputCount <= 0) {
            return STATUS_NO_INPUT;
        }
        if (!hasOutputRoom()) {
            return STATUS_OUTPUT_FULL;
        }
        if (this.energy.getEnergyStored() < COST) {
            return STATUS_NO_ENERGY;
        }
        return STATUS_IDLE;
    }

    // ------------------------------------------------------------------
    // 结构检测
    // ------------------------------------------------------------------

    public void validateStructure() {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        Direction facing = facing();
        int px = facing.getStepZ();
        int pz = -facing.getStepX();
        int radius = (SIZE - 1) / 2;

        int casing = 0;
        int coils = 0;
        List<BlockPos> foundPorts = new ArrayList<>();
        boolean complete = true;

        for (int depth = 0; depth < SIZE && complete; depth++) {
            for (int side = -radius; side <= radius && complete; side++) {
                for (int up = 0; up < SIZE && complete; up++) {
                    BlockPos pos = this.worldPosition.offset(
                            facing.getStepX() * depth + px * side, up, facing.getStepZ() * depth + pz * side);
                    if (!server.isLoaded(pos)) {
                        complete = false;
                        break;
                    }
                    if (pos.equals(this.worldPosition)) {
                        continue;
                    }
                    Block block = server.getBlockState(pos).getBlock();
                    if (block == ModBlocks.TRANSMUTATOR_CASING.get()) {
                        casing++;
                    } else if (block == ModBlocks.SUPERCONDUCTING_COIL.get()) {
                        coils++;
                    } else if (block == ModBlocks.ENERGY_PORT.get()) {
                        foundPorts.add(pos);
                    }
                }
            }
        }

        this.formed = complete && casing >= MIN_CASING && coils >= MIN_COILS
                && foundPorts.size() >= MIN_PORTS;
        this.casingCount = casing;
        this.coilCount = coils;
        this.portCount = foundPorts.size();
        this.ports = List.copyOf(foundPorts);
        setChanged();
    }

    private Direction facing() {
        BlockState state = getBlockState();
        if (state.hasProperty(TransmutatorControllerBlock.FACING)) {
            return state.getValue(TransmutatorControllerBlock.FACING);
        }
        return Direction.NORTH;
    }

    // ------------------------------------------------------------------
    // 给界面看的数
    // ------------------------------------------------------------------

    public boolean isFormed() {
        return this.formed;
    }

    public int casingCount() {
        return this.casingCount;
    }

    public int coilCount() {
        return this.coilCount;
    }

    public int portCount() {
        return this.portCount;
    }

    public int inputCount() {
        return this.inputCount;
    }

    public int progressPercent() {
        return Math.round(100.0F * this.progress / DURATION);
    }

    public int statusCode() {
        return this.status;
    }

    public boolean isWorking() {
        return this.working;
    }

    // ------------------------------------------------------------------
    // EnergyMachineHost
    // ------------------------------------------------------------------

    @Override
    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    @Override
    public int getEnergyCapacity() {
        return ENERGY_CAPACITY;
    }

    @Override
    public int getStatus() {
        return this.status;
    }

    @Override
    public int getProgress() {
        return this.progress;
    }

    @Override
    public int getMaxProgress() {
        return DURATION;
    }

    // ------------------------------------------------------------------
    // 菜单 / 物品槽
    // ------------------------------------------------------------------

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.transmutator_controller");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new TransmutatorMenu(containerId, playerInventory, this);
    }

    @Override
    public int getContainerSize() {
        return this.items.size();
    }

    @Override
    public boolean isEmpty() {
        return this.items.get(SLOT_INPUT).isEmpty() && this.items.get(SLOT_OUTPUT).isEmpty();
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        stack.limitSize(getMaxStackSize(stack));
        setChanged();
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot == SLOT_INPUT && stack.is(ModItems.ACTINIDES.get());
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
        tag.putBoolean("Working", this.working);
        tag.putInt("Progress", this.progress);
        ContainerHelper.saveAllItems(tag, this.items, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
        this.working = tag.getBoolean("Working");
        this.progress = tag.getInt("Progress");
        ContainerHelper.loadAllItems(tag, this.items, registries);
    }
}
