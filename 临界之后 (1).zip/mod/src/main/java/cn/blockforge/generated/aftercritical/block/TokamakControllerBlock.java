package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.TokamakControllerBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 托卡马克控制器：9×9×9 多方块的心脏。
 *
 * <p>和快堆一样：控制器贴在正面墙、贴地那排正中间，方块朝哪堆就往哪长，右键开界面。
 * 界面里放氘氚燃料单元、按「点火」；点着之后 IP 就变成一个 20,000 FE/t 的发电机，
 * 同时还往 256 格内的能量端口无线送电。
 */
public class TokamakControllerBlock extends TickablePartBlock {

    public static final String DESCRIPTION = "block.aftercritical.tokamak_controller.desc";

    /** 方块朝哪 = 结构往哪长。只有水平四个方向。 */
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    public TokamakControllerBlock(Properties properties) {
        super(properties, DESCRIPTION);
        registerDefaultState(defaultBlockState().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(TokamakControllerBlock::new);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection());
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new TokamakControllerBlockEntity(pos, state);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MenuProvider provider) {
            player.openMenu(provider, pos);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MenuProvider provider) {
            player.openMenu(provider, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** 旁边多一块少一块就立刻重查结构。 */
    @Override
    protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighbor,
                                   BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighbor, neighborPos, movedByPiston);
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof TokamakControllerBlockEntity controller) {
            controller.validateSoon();
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.aftercritical.tokamak.size",
                TokamakControllerBlockEntity.SIZE, TokamakControllerBlockEntity.SIZE,
                TokamakControllerBlockEntity.SIZE).withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.tokamak.materials",
                TokamakControllerBlockEntity.MIN_CASING,
                TokamakControllerBlockEntity.MIN_COILS,
                TokamakControllerBlockEntity.MIN_BLANKETS).withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.tokamak.parts",
                TokamakControllerBlockEntity.MIN_INJECTORS,
                TokamakControllerBlockEntity.MIN_DIAGNOSTICS,
                TokamakControllerBlockEntity.MIN_COOLERS,
                TokamakControllerBlockEntity.MIN_LOGIC).withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.tokamak.run",
                TokamakControllerBlockEntity.STARTUP_FE,
                TokamakControllerBlockEntity.OUTPUT_FE).withStyle(ChatFormatting.GRAY));
    }
}
