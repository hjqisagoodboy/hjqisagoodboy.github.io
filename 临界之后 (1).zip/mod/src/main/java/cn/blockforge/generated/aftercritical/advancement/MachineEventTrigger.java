package cn.blockforge.generated.aftercritical.advancement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.advancements.critereon.ContextAwarePredicate;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger;
import net.minecraft.server.level.ServerPlayer;

import java.util.Optional;

/**
 * 自定义触发条件：「某台机器发生了某件事」。
 *
 * <p>原版的触发条件只会看物品栏、看方块、看状态效果，机器真正转起来这件事它看不见。
 * 所以这里做一个通用触发器：条件里写一个事件名，机器那边喊一声同一个事件名，成就就亮。
 *
 * <p>JSON 长这样：
 * <pre>
 *   "criteria": {
 *     "event": {
 *       "trigger": "aftercritical:machine_event",
 *       "conditions": { "event": "fission_critical" }
 *     }
 *   }
 * </pre>
 */
public class MachineEventTrigger extends SimpleCriterionTrigger<MachineEventTrigger.TriggerInstance> {

    /** 条件里只有两样东西：可选的玩家谓词，和必须写的事件名。 */
    public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            ContextAwarePredicate.CODEC.optionalFieldOf("player").forGetter(TriggerInstance::player),
            Codec.STRING.fieldOf("event").forGetter(TriggerInstance::event)
    ).apply(instance, TriggerInstance::new));

    @Override
    public Codec<TriggerInstance> codec() {
        return CODEC;
    }

    /** 机器那边喊一声：把这个事件派给这个玩家。 */
    public void fire(ServerPlayer player, String event) {
        this.trigger(player, instance -> instance.matches(event));
    }

    public record TriggerInstance(Optional<ContextAwarePredicate> player, String event)
            implements SimpleCriterionTrigger.SimpleInstance {

        /** 事件名对上就算数。 */
        public boolean matches(String fired) {
            return this.event.equals(fired);
        }
    }
}
