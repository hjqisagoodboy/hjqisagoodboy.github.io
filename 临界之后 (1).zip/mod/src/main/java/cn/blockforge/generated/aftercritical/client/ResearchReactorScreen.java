package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.blockentity.ResearchReactorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.menu.ResearchReactorMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;

/**
 * 研究堆控制器的界面。
 *
 * <p>不看 k_eff（研究堆是低功率稳定运行，没有临界问题），只看三件事：
 * 结构搭全了没有、燃料和控制棒插够了没有、这一炉靶照到哪儿了。
 */
public class ResearchReactorScreen extends StatPanelScreen<ResearchReactorMenu> {

    public ResearchReactorScreen(ResearchReactorMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected List<Line> statLines() {
        List<Line> lines = new ArrayList<>(ResearchReactorMenu.STAT_LINES);

        int status = this.menu.getStatus();
        lines.add(new Line(Component.literal(statusTextOf(status) + "    "
                + this.menu.getEnergyStored() + " / " + this.menu.getEnergyCapacity() + " FE"),
                status == 2 ? TEXT_OK : TEXT_DARK));

        boolean formed = this.menu.isFormed();
        lines.add(new Line(Component.translatable(formed
                ? "gui.aftercritical.reactor.structure_ok"
                : "gui.aftercritical.reactor.structure_missing"),
                formed ? TEXT_OK : TEXT_BAD));

        lines.add(new Line(Component.translatable("gui.aftercritical.research.mat_a",
                this.menu.graphite(), ResearchReactorControllerBlockEntity.MIN_GRAPHITE,
                this.menu.reflector(), ResearchReactorControllerBlockEntity.MIN_REFLECTOR,
                this.menu.shield(), ResearchReactorControllerBlockEntity.MIN_SHIELD), TEXT_GRAY));

        lines.add(new Line(Component.translatable("gui.aftercritical.research.mat_b",
                this.menu.channels(), ResearchReactorControllerBlockEntity.MIN_CHANNELS,
                this.menu.detectors(), ResearchReactorControllerBlockEntity.MIN_DETECTORS,
                this.menu.water(), ResearchReactorControllerBlockEntity.MIN_WATER), TEXT_GRAY));

        boolean ready = this.menu.fuel() >= ResearchReactorControllerBlockEntity.MIN_FUEL
                && this.menu.rods() >= ResearchReactorControllerBlockEntity.MIN_RODS;
        lines.add(new Line(Component.translatable("gui.aftercritical.research.core",
                this.menu.fuel(), ResearchReactorControllerBlockEntity.MIN_FUEL,
                this.menu.rods(), ResearchReactorControllerBlockEntity.MIN_RODS),
                ready ? TEXT_OK : TEXT_WARN));

        int max = this.menu.getMaxProgress();
        if (max > 0) {
            int percent = Math.round(100.0F * Math.max(0, Math.min(this.menu.getProgress(), max)) / max);
            int seconds = Math.max(0, (max - this.menu.getProgress()) / 20);
            lines.add(new Line(Component.translatable("gui.aftercritical.research.progress", percent, seconds),
                    TEXT_DARK));
        } else {
            lines.add(new Line(Component.translatable("gui.aftercritical.research.idle"), TEXT_DARK));
        }
        return lines;
    }

    /** 状态码 → 一行中文（和别的机器界面口径一致）。 */
    private static String statusTextOf(int status) {
        return switch (status) {
            case 1 -> Component.translatable("gui.aftercritical.status.running").getString();
            case 2 -> Component.translatable("gui.aftercritical.status.no_energy").getString();
            case 3 -> Component.translatable("gui.aftercritical.status.output_blocked").getString();
            default -> Component.translatable("gui.aftercritical.status.idle").getString();
        };
    }
}
