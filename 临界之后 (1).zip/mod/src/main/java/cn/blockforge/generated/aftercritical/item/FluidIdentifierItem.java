package cn.blockforge.generated.aftercritical.item;

import cn.blockforge.generated.aftercritical.menu.FluidIdentifierMenu;
import cn.blockforge.generated.aftercritical.fluid.TankContent;
import cn.blockforge.generated.aftercritical.registry.ModDataComponents;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.Fluid;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 流体识别码（参考 HBM 的流体识别器）：给智能流体管道「盖章」、给通用流体罐「预设」用的小工具。
 *
 * <p>用法三步：
 * <ol>
 *   <li><b>右键空气</b> → 打开识别码界面，里面一格格列着游戏里所有流体（颜色方块 + 中文名 + 英文 ID），
 *       点一个就绑定它；界面里还能放一个空罐子，点流体时顺手把罐子预设成那种流体；</li>
 *   <li>拿着绑好的识别码<b>右键智能流体管道</b> → 管道被盖上这个章，从此只搬这一种流体；</li>
 *   <li>拿着绑好的识别码<b>右键装着流体的机器 / 罐子</b> → 直接绑定那种流体（不用开界面也行）。</li>
 * </ol>
 *
 * <p>识别码<b>不会被消耗</b>，绑定一次可以给一根根管道反复盖章；刚合成出来是「未绑定」，
 * 这时右键管道不会发生任何事，物品提示里会写清楚。
 */
public class FluidIdentifierItem extends Item {

    public FluidIdentifierItem(Properties properties) {
        super(properties);
    }

    /** 这个识别码绑定的流体；还没绑定时返回 {@code null}。 */
    @Nullable
    public static Fluid boundFluid(ItemStack stack) {
        TankContent stored = stack.get(ModDataComponents.FLUID.get());
        return stored == null ? null : stored.fluidValue();
    }

    /** 把识别码绑定到 {@code fluid}（传 {@code null} 就是解绑）。 */
    public static void bind(ItemStack stack, @Nullable Fluid fluid) {
        if (fluid == null) {
            stack.remove(ModDataComponents.FLUID.get());
        } else {
            // 只借这个组件记「是哪种流体」，数量给 1 mB 占个位，不参与任何运算
            stack.set(ModDataComponents.FLUID.get(), new TankContent(fluid.builtInRegistryHolder(), 1));
        }
    }

    // ------------------------------------------------------------------
    // 右键空气：开界面选流体
    // ------------------------------------------------------------------

    /**
     * 右键空气 → 打开识别码界面。
     *
     * <p>界面里列着所有流体；选中之后服务端会把识别码的数据组件改掉。
     * 界面的菜单类型不需要额外参数，所以这里用最简单的 {@code openMenu}。
     */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            player.openMenu(new MenuProvider() {
                @Override
                public Component getDisplayName() {
                    return Component.translatable("container.aftercritical.fluid_identifier");
                }

                @Override
                public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player owner) {
                    return new FluidIdentifierMenu(containerId, inventory);
                }
            });
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    // ------------------------------------------------------------------
    // 右键方块：直接绑定方块里那种流体
    // ------------------------------------------------------------------

    /**
     * 右键「装着流体的东西」＝ 绑定这种流体。
     *
     * <p>只读取、不抽走：对着机器或罐子右键不会把里面的液体弄没。
     * 点到的方块没流体接口、或者里面的罐子全是空的 → 什么都不做，右键交给方块自己（比如开机器界面）。
     */
    @Override
    public InteractionResult onItemUseFirst(ItemStack stack, UseOnContext context) {
        Level level = context.getLevel();
        Player player = context.getPlayer();
        if (player == null) {
            return InteractionResult.PASS;
        }
        BlockPos pos = context.getClickedPos();
        IFluidHandler handler = level.getCapability(Capabilities.FluidHandler.BLOCK, pos, context.getClickedFace());
        Fluid fluid = handler == null ? null : firstFluidIn(handler);
        if (fluid == null) {
            return InteractionResult.PASS;
        }
        if (!level.isClientSide) {
            bind(stack, fluid);
            Component name = new FluidStack(fluid, 1).getHoverName();
            player.displayClientMessage(
                    Component.translatable("message.aftercritical.fluid_identifier.bound", name), true);
            level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.7F, 1.4F);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /**
     * 找「这个方块真正能往外抽的那一种流体」。
     *
     * <p>以前的写法是「从上往下找第一个装着的流体」，结果在汽轮发电机上翻车：
     * 那台机器有两个罐子，0 号是进汽罐（只进不出）、1 号是乏蒸汽罐（能抽），
     * 进汽罐里只要有蒸汽，识别码就被绑成蒸汽，管道拿蒸汽去抽乏蒸汽罐当然一滴也抽不出来。
     *
     * <p>现在按「能不能抽」来挑：挨个罐子试着 drain 1 mB（只是模拟，不动真东西），
     * 第一个抽得出来的就是它。一个都抽不动（比如全是进料罐）才退回第一种装着的流体。
     */
    @Nullable
    private static Fluid firstFluidIn(IFluidHandler handler) {
        Fluid fallback = null;
        for (int i = 0; i < handler.getTanks(); i++) {
            FluidStack stack = handler.getFluidInTank(i);
            if (stack.isEmpty()) {
                continue;
            }
            if (fallback == null) {
                fallback = stack.getFluid();
            }
            FluidStack probe = handler.drain(stack.copyWithAmount(1), IFluidHandler.FluidAction.SIMULATE);
            if (!probe.isEmpty()) {
                return stack.getFluid();
            }
        }
        return fallback;
    }

    // ------------------------------------------------------------------
    // 提示与外观
    // ------------------------------------------------------------------

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context,
                                List<Component> tooltip, TooltipFlag flag) {
        Fluid fluid = boundFluid(stack);
        if (fluid == null) {
            tooltip.add(Component.translatable("tooltip.aftercritical.fluid_identifier.unbound")
                    .withStyle(ChatFormatting.GRAY));
            tooltip.add(Component.translatable("tooltip.aftercritical.fluid_identifier.bind_hint")
                    .withStyle(ChatFormatting.DARK_GRAY));
        } else {
            tooltip.add(Component.translatable("tooltip.aftercritical.fluid_identifier.bound",
                            new FluidStack(fluid, 1).getHoverName().getString())
                    .withStyle(ChatFormatting.GRAY));
            tooltip.add(Component.translatable("tooltip.aftercritical.fluid_identifier.use_hint")
                    .withStyle(ChatFormatting.DARK_GRAY));
        }
        tooltip.add(Component.translatable("tooltip.aftercritical.fluid_identifier.noconsume")
                .withStyle(ChatFormatting.DARK_GRAY));
    }

    /** 客户端用：绑定了就染成那种流体的颜色，没绑定保持原色。 */
    @Nullable
    public static Integer tintOf(ItemStack stack) {
        Fluid fluid = boundFluid(stack);
        return fluid == null ? null : ModFluids.colorOf(fluid);
    }
}
