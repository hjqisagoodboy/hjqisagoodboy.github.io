package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.blockentity.ResearchReactorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 研究堆控制器的界面：左边三排槽（燃料 4 / 控制棒 4 / 辐照孔道 4），右边一排产物槽，
 * 底下一串结构读数。
 *
 * <p>版式和别的机器一样用 {@link MachineLayout} 那把尺子，只是槽位摆成四行四列。
 */
public class ResearchReactorMenu extends AbstractMachineMenu {

    /** 第一列槽的 x，以及列间距。 */
    public static final int COL_X = 30;
    public static final int COL_STEP = 18;
    /** 三排输入槽的 y。 */
    public static final int FUEL_Y = 26;
    public static final int ROD_Y = 44;
    public static final int CHANNEL_Y = 62;
    /** 产物槽那一排。 */
    public static final int OUTPUT_X = 126;
    public static final int OUTPUT_Y = 44;

    /** 底部读数一共几行。 */
    public static final int STAT_LINES = 6;

    private static final int DATA_FORMED = 0;
    private static final int DATA_GRAPHITE = 1;
    private static final int DATA_REFLECTOR = 2;
    private static final int DATA_SHIELD = 3;
    private static final int DATA_CHANNELS = 4;
    private static final int DATA_DETECTORS = 5;
    private static final int DATA_WATER = 6;
    private static final int DATA_FUEL = 7;
    private static final int DATA_RODS = 8;
    private static final int DATA_COUNT = 9;

    @Nullable
    private final ResearchReactorControllerBlockEntity reactor;

    private boolean formed;
    private int graphite;
    private int reflector;
    private int shield;
    private int channels;
    private int detectors;
    private int water;
    private int fuel;
    private int rods;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case DATA_FORMED -> formed ? 1 : 0;
                case DATA_GRAPHITE -> graphite;
                case DATA_REFLECTOR -> reflector;
                case DATA_SHIELD -> shield;
                case DATA_CHANNELS -> channels;
                case DATA_DETECTORS -> detectors;
                case DATA_WATER -> water;
                case DATA_FUEL -> fuel;
                case DATA_RODS -> rods;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case DATA_FORMED -> formed = value != 0;
                case DATA_GRAPHITE -> graphite = value;
                case DATA_REFLECTOR -> reflector = value;
                case DATA_SHIELD -> shield = value;
                case DATA_CHANNELS -> channels = value;
                case DATA_DETECTORS -> detectors = value;
                case DATA_WATER -> water = value;
                case DATA_FUEL -> fuel = value;
                case DATA_RODS -> rods = value;
                default -> {
                }
            }
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    /** 服务端用。 */
    public ResearchReactorMenu(int containerId, Inventory playerInventory,
                               ResearchReactorControllerBlockEntity reactor) {
        this(containerId, playerInventory, reactor, reactor);
    }

    /** 客户端用：容器可以是个空壳，内容由同步包填。 */
    public ResearchReactorMenu(int containerId, Inventory playerInventory, Container container,
                               @Nullable EnergyMachineHost machine) {
        super(ModMenus.RESEARCH_REACTOR.get(), containerId, playerInventory,
                ResearchReactorControllerBlockEntity.SLOT_COUNT, machine);
        this.reactor = machine instanceof ResearchReactorControllerBlockEntity be ? be : null;

        for (int i = 0; i < ResearchReactorControllerBlockEntity.FUEL_SLOTS; i++) {
            this.addSlot(new FuelSlot(container, ResearchReactorControllerBlockEntity.SLOT_FUEL_FIRST + i,
                    COL_X + i * COL_STEP, FUEL_Y));
        }
        for (int i = 0; i < ResearchReactorControllerBlockEntity.ROD_SLOTS; i++) {
            this.addSlot(new RodSlot(container, ResearchReactorControllerBlockEntity.SLOT_ROD_FIRST + i,
                    COL_X + i * COL_STEP, ROD_Y));
        }
        for (int i = 0; i < ResearchReactorControllerBlockEntity.CHANNEL_SLOTS; i++) {
            this.addSlot(new ChannelSlot(container, ResearchReactorControllerBlockEntity.SLOT_CHANNEL_FIRST + i,
                    COL_X + i * COL_STEP, CHANNEL_Y));
        }
        for (int i = 0; i < ResearchReactorControllerBlockEntity.OUTPUT_SLOTS; i++) {
            this.addSlot(new OutputSlot(container, ResearchReactorControllerBlockEntity.SLOT_OUTPUT_FIRST + i,
                    OUTPUT_X + i * COL_STEP, OUTPUT_Y));
        }
        this.addPlayerInventory(playerInventory);
        this.addDataSlots(this.data);
    }

    /** 客户端收到「打开菜单」的包后调用。 */
    public static ResearchReactorMenu fromNetwork(int containerId, Inventory playerInventory,
                                                  RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof ResearchReactorControllerBlockEntity reactor) {
            return new ResearchReactorMenu(containerId, playerInventory, reactor);
        }
        return new ResearchReactorMenu(containerId, playerInventory,
                new SimpleContainer(ResearchReactorControllerBlockEntity.SLOT_COUNT), null);
    }

    @Override
    public void broadcastChanges() {
        if (this.reactor != null) {
            this.formed = this.reactor.isFormed();
            this.graphite = this.reactor.graphiteCount();
            this.reflector = this.reactor.reflectorCount();
            this.shield = this.reactor.shieldCount();
            this.channels = this.reactor.channelBlockCount();
            this.detectors = this.reactor.detectorCount();
            this.water = this.reactor.waterCount();
            this.fuel = this.reactor.fuelCount();
            this.rods = this.reactor.rodCount();
        }
        super.broadcastChanges();
    }

    /** 输入槽 → 产物槽那根箭头（箭头里灌的是辐照进度）。 */
    @Override
    public MachineLayout.Arrow arrowGeometry() {
        return new MachineLayout.Arrow(COL_X + 4 * COL_STEP + 2, OUTPUT_Y + 8, 28);
    }

    public boolean isFormed() {
        return this.formed;
    }

    public int graphite() {
        return this.graphite;
    }

    public int reflector() {
        return this.reflector;
    }

    public int shield() {
        return this.shield;
    }

    public int channels() {
        return this.channels;
    }

    public int detectors() {
        return this.detectors;
    }

    public int water() {
        return this.water;
    }

    public int fuel() {
        return this.fuel;
    }

    public int rods() {
        return this.rods;
    }

    @Override
    public boolean stillValid(net.minecraft.world.entity.player.Player player) {
        return this.reactor == null || this.reactor.stillValid(player);
    }

    // ------------------------------------------------------------------
    // 版式：底部读数比别的机器多两行
    // ------------------------------------------------------------------

    @Override
    public int textY() {
        return MachineLayout.textY(0);
    }

    @Override
    public int inventoryLabelY() {
        return textY() + STAT_LINES * MachineLayout.TEXT_STEP + 3;
    }

    @Override
    public int inventoryY() {
        return inventoryLabelY() + 10;
    }

    @Override
    public int guiHeight() {
        return inventoryY() + 58 + 18 + 6;
    }

    // ------------------------------------------------------------------
    // 槽位：每排只认自己那类东西
    // ------------------------------------------------------------------

    /** 燃料槽：只收低浓缩铀燃料组件。 */
    public static class FuelSlot extends Slot {

        public FuelSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.is(cn.blockforge.generated.aftercritical.registry.ModItems.LEU_FUEL_ASSEMBLY.get());
        }
    }

    /** 控制棒槽：只收控制棒组件。 */
    public static class RodSlot extends Slot {

        public RodSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.is(cn.blockforge.generated.aftercritical.registry.ModItems.CONTROL_ROD.get());
        }
    }

    /** 辐照孔道槽：只收 7 种靶材。 */
    public static class ChannelSlot extends Slot {

        public ChannelSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return ResearchReactorControllerBlockEntity.TARGETS.contains(stack.getItem());
        }
    }

    /** 待机状态下提示「还差什么」：结构不完整。 */
    public boolean isMissingStructure() {
        return !this.formed;
    }

    /** 结构齐全但燃料或控制棒不够。 */
    public boolean isMissingFuelOrRods() {
        return this.formed
                && (this.fuel < ResearchReactorControllerBlockEntity.MIN_FUEL
                || this.rods < ResearchReactorControllerBlockEntity.MIN_RODS);
    }
}
