package cn.blockforge.generated.aftercritical.registry;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.blockentity.AssemblerT1BlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.AssemblerT2BlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.AssemblerT3BlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.BallMillBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.BatteryLvBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.BatteryMvBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.BoricAcidTankBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.CascadeControllerBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.UniversalTankBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.CableBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.CombustionGeneratorBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.CompactorBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.ControlRodPortBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.CoolantPortBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.CoreRemnantBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.CrusherBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.EnergyPortBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.FastReactorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.FluidMachineBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.ForgingPressBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.FuelPortBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.FuelRodGeneratorBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.GeologicRepositoryBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.GiantBatteryBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.HotCellArmBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.ItemMachineBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.ItemPipeBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.LogisticsControllerBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.NeutronFluxRecorderBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.NukeBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.PwrControllerBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.ReactorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.ResearchReactorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.SmartFluidDuctBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.SodiumSteamGeneratorBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.SteamGeneratorBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.TankControllerBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.TankPortBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.TokamakControllerBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.TransformerBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.TransmutatorControllerBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 机器方块实体的注册表。
 *
 * <p>每种机器一个类型：方块实体类型要「绑定」到方块上，游戏才知道放下这个方块该生成哪个方块实体。
 */
public final class ModBlockEntities {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, AfterCritical.MOD_ID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CrusherBlockEntity>> CRUSHER =
            BLOCK_ENTITIES.register("crusher", () -> BlockEntityType.Builder
                    .of(CrusherBlockEntity::new, ModBlocks.CRUSHER.get())
                    .build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<BallMillBlockEntity>> BALL_MILL =
            BLOCK_ENTITIES.register("ball_mill", () -> BlockEntityType.Builder
                    .of(BallMillBlockEntity::new, ModBlocks.BALL_MILL.get())
                    .build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ForgingPressBlockEntity>> FORGING_PRESS =
            BLOCK_ENTITIES.register("forging_press", () -> BlockEntityType.Builder
                    .of(ForgingPressBlockEntity::new, ModBlocks.FORGING_PRESS.get())
                    .build(null));

    /** 压块机的方块实体。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CompactorBlockEntity>> COMPACTOR =
            BLOCK_ENTITIES.register("compactor", () -> BlockEntityType.Builder
                    .of(CompactorBlockEntity::new, ModBlocks.COMPACTOR.get())
                    .build(null));

    /** 装配机 T1 的方块实体。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AssemblerT1BlockEntity>> ASSEMBLER_T1 =
            BLOCK_ENTITIES.register("assembler_t1", () -> BlockEntityType.Builder
                    .of(AssemblerT1BlockEntity::new, ModBlocks.ASSEMBLER_T1.get())
                    .build(null));

    /** 装配机 T2 的方块实体（和 T1 共用加工代码，只是额定功率不同）。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AssemblerT2BlockEntity>> ASSEMBLER_T2 =
            BLOCK_ENTITIES.register("assembler_t2", () -> BlockEntityType.Builder
                    .of(AssemblerT2BlockEntity::new, ModBlocks.ASSEMBLER_T2.get())
                    .build(null));

    /** 装配机 T3 的方块实体（三级配方，300 FE/t）。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AssemblerT3BlockEntity>> ASSEMBLER_T3 =
            BLOCK_ENTITIES.register("assembler_t3", () -> BlockEntityType.Builder
                    .of(AssemblerT3BlockEntity::new, ModBlocks.ASSEMBLER_T3.get())
                    .build(null));

    /** 燃烧发电机的方块实体。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CombustionGeneratorBlockEntity>>
            COMBUSTION_GENERATOR = BLOCK_ENTITIES.register("combustion_generator", () -> BlockEntityType.Builder
            .of(CombustionGeneratorBlockEntity::new, ModBlocks.COMBUSTION_GENERATOR.get())
            .build(null));

    /** 燃料棒发电机的方块实体。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<FuelRodGeneratorBlockEntity>>
            FUEL_ROD_GENERATOR = BLOCK_ENTITIES.register("fuel_rod_generator", () -> BlockEntityType.Builder
            .of(FuelRodGeneratorBlockEntity::new, ModBlocks.FUEL_ROD_GENERATOR.get())
            .build(null));

    /** 电池 LV 的方块实体。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<BatteryLvBlockEntity>> BATTERY_LV =
            BLOCK_ENTITIES.register("battery_lv", () -> BlockEntityType.Builder
                    .of(BatteryLvBlockEntity::new, ModBlocks.BATTERY_LV.get())
                    .build(null));

    /** 十台流体机器共用一个方块实体类型（具体是哪台看方块，见 {@code FluidMachineKind}）。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<FluidMachineBlockEntity>> FLUID_MACHINE =
            BLOCK_ENTITIES.register("fluid_machine", () -> BlockEntityType.Builder
                    .of(FluidMachineBlockEntity::new, ModBlocks.ELECTROLYZER.get(), ModBlocks.CHEMICAL_PLANT.get(),
                            ModBlocks.AIR_SEPARATOR.get(), ModBlocks.GROUNDWATER_PUMP.get(),
                            ModBlocks.LEACHING_TANK.get(),
                            ModBlocks.PRECIPITATION_TANK.get(), ModBlocks.DRYING_OVEN.get(),
                            ModBlocks.CONVERTER.get(), ModBlocks.FLUORINATION_REACTOR.get(),
                            ModBlocks.GAS_CENTRIFUGE.get(), ModBlocks.HYDROLYSIS_REACTOR.get(),
                            ModBlocks.IRRADIATION_POOL.get(), ModBlocks.CONDENSER.get(),
                            ModBlocks.SPENT_FUEL_POOL.get(), ModBlocks.DISSOLUTION_TANK.get(),
                            ModBlocks.EXTRACTION_COLUMN.get(), ModBlocks.CENTRIFUGAL_EXTRACTOR.get(),
                            ModBlocks.VITRIFICATION_FURNACE.get())
                    .build(null));

    /**
     * 三种线缆共用一个方块实体类型：LV / MV / HV 直接从方块上问（{@code CableBlock#tier()}），
     * 所以不需要为每一级再抄一份方块实体。
     */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CableBlockEntity>> CABLE =
            BLOCK_ENTITIES.register("cable", () -> BlockEntityType.Builder
                    .of(CableBlockEntity::new, ModBlocks.LV_CABLE.get(), ModBlocks.MV_CABLE.get(),
                            ModBlocks.HV_CABLE.get())
                    .build(null));

    /** 两种变压器共用一个方块实体类型：收多少送多少从方块上问（{@code TransformerBlock#tier()}）。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TransformerBlockEntity>> TRANSFORMER =
            BLOCK_ENTITIES.register("transformer_lv_mv", () -> BlockEntityType.Builder
                    .of(TransformerBlockEntity::new, ModBlocks.TRANSFORMER_LV_MV.get(),
                            ModBlocks.TRANSFORMER_MV_HV.get())
                    .build(null));

    /** 物品管道的方块实体。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ItemPipeBlockEntity>> ITEM_PIPE =
            BLOCK_ENTITIES.register("item_pipe", () -> BlockEntityType.Builder
                    .of(ItemPipeBlockEntity::new, ModBlocks.ITEM_PIPE.get())
                    .build(null));

    /**
     * 烧结炉、磨削机、焊接机共用一个方块实体类型。
     *
     * <p>具体是哪台从方块上问（{@code ItemMachineBlock#kind()}），
     * 槽数和功率都在型号表 {@code ItemMachineKind} 里，所以不用抄三份。
     */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ItemMachineBlockEntity>> ITEM_MACHINE =
            BLOCK_ENTITIES.register("item_machine", () -> BlockEntityType.Builder
                    .of(ItemMachineBlockEntity::new, ModBlocks.SINTERING_FURNACE.get(),
                            ModBlocks.GRINDING_MACHINE.get(), ModBlocks.WELDING_MACHINE.get(),
                            ModBlocks.GAMMA_IRRADIATOR.get(), ModBlocks.SHEARING_MACHINE.get(),
                            ModBlocks.WARHEAD_ASSEMBLER.get())
                    .build(null));

    /** 物流控制器：九格缓冲 + 六方向轮流分发。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<LogisticsControllerBlockEntity>>
            LOGISTICS_CONTROLLER = BLOCK_ENTITIES.register("logistics_controller", () -> BlockEntityType.Builder
            .of(LogisticsControllerBlockEntity::new, ModBlocks.LOGISTICS_CONTROLLER.get())
            .build(null));

    /** 智能流体管道的方块实体：记着自己被盖的章，并负责一 tick 100 mB 的搬运。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SmartFluidDuctBlockEntity>>
            SMART_FLUID_DUCT = BLOCK_ENTITIES.register("smart_fluid_duct", () -> BlockEntityType.Builder
            .of(SmartFluidDuctBlockEntity::new, ModBlocks.SMART_FLUID_DUCT.get())
            .build(null));

    /** 储罐多方块控制器：64,000 mB 的大罐子 + 外壳检查。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TankControllerBlockEntity>>
            TANK_CONTROLLER = BLOCK_ENTITIES.register("tank_controller", () -> BlockEntityType.Builder
            .of(TankControllerBlockEntity::new, ModBlocks.TANK_CONTROLLER.get())
            .build(null));

    /** 级联控制器的方块实体：扫描周围的离心机、统一分配进料和收成品。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CascadeControllerBlockEntity>>
            CASCADE_CONTROLLER = BLOCK_ENTITIES.register("cascade_controller", () -> BlockEntityType.Builder
            .of(CascadeControllerBlockEntity::new, ModBlocks.CASCADE_CONTROLLER.get())
            .build(null));

    /** 两个储罐口共用一个方块实体类型：进 / 出从方块上问。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TankPortBlockEntity>> TANK_PORT =
            BLOCK_ENTITIES.register("tank_port", () -> BlockEntityType.Builder
                    .of(TankPortBlockEntity::new, ModBlocks.TANK_INPUT_PORT.get(), ModBlocks.TANK_OUTPUT_PORT.get())
                    .build(null));

    // ------------------------------------------------------------------
    // 阶段 3：中子物理与临界实验
    // ------------------------------------------------------------------

    /** 两种反应堆控制器共用一个方块实体类型：具体是哪种从方块上问（{@code ReactorControllerBlock#kind()}）。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ReactorControllerBlockEntity>>
            REACTOR_CONTROLLER = BLOCK_ENTITIES.register("reactor_controller", () -> BlockEntityType.Builder
            .of(ReactorControllerBlockEntity::new, ModBlocks.SUBCRITICAL_CONTROLLER.get(),
                    ModBlocks.CRITICAL_REACTOR_CONTROLLER.get())
            .build(null));

    /** 中子通量记录仪：自己找最近的反应堆控制器抄读数。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<NeutronFluxRecorderBlockEntity>>
            NEUTRON_FLUX_RECORDER = BLOCK_ENTITIES.register("neutron_flux_recorder", () -> BlockEntityType.Builder
            .of(NeutronFluxRecorderBlockEntity::new, ModBlocks.NEUTRON_FLUX_RECORDER.get())
            .build(null));

    /** 通用储罐：32,000 mB，什么流体都能装，靠流体识别码绑定。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<UniversalTankBlockEntity>>
            UNIVERSAL_TANK = BLOCK_ENTITIES.register("universal_tank", () -> BlockEntityType.Builder
            .of(UniversalTankBlockEntity::new, ModBlocks.UNIVERSAL_TANK.get())
            .build(null));

    /** 旧版硼酸储罐的方块实体：只为老存档保留，已经没有物品了。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<BoricAcidTankBlockEntity>>
            BORIC_ACID_TANK = BLOCK_ENTITIES.register("boric_acid_tank", () -> BlockEntityType.Builder
            .of(BoricAcidTankBlockEntity::new, ModBlocks.BORIC_ACID_TANK.get())
            .build(null));

    /** 堆芯残骸：熔毁后接着冒 10 秒蘑菇云，顺带散辐射。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CoreRemnantBlockEntity>>
            CORE_REMNANT = BLOCK_ENTITIES.register("core_remnant", () -> BlockEntityType.Builder
            .of(CoreRemnantBlockEntity::new, ModBlocks.CORE_REMNANT.get())
            .build(null));

    // ------------------------------------------------------------------
    // 阶段 4：研究堆
    // ------------------------------------------------------------------

    /** 研究堆控制器：7×8×7 多方块，辐照靶材。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ResearchReactorControllerBlockEntity>>
            RESEARCH_REACTOR = BLOCK_ENTITIES.register("research_reactor",
            () -> BlockEntityType.Builder
                    .of(ResearchReactorControllerBlockEntity::new, ModBlocks.RESEARCH_REACTOR_CONTROLLER.get())
                    .build(null));

    /** 热室机械臂：带界面的靶材拆解机器。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<HotCellArmBlockEntity>>
            HOT_CELL_ARM = BLOCK_ENTITIES.register("hot_cell_arm", () -> BlockEntityType.Builder
            .of(HotCellArmBlockEntity::new, ModBlocks.HOT_CELL_ARM.get())
            .build(null));

    // ------------------------------------------------------------------
    // 阶段 5：压水堆与蒸汽发电
    // ------------------------------------------------------------------

    /** 压水堆控制器：7×7×8 多方块，产蒸汽。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PwrControllerBlockEntity>>
            PWR_CONTROLLER = BLOCK_ENTITIES.register("pwr_controller", () -> BlockEntityType.Builder
            .of(PwrControllerBlockEntity::new, ModBlocks.PWR_CONTROLLER.get())
            .build(null));

    /** 燃料端口：最多 8 支 LEU 燃料组件。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<FuelPortBlockEntity>>
            FUEL_PORT = BLOCK_ENTITIES.register("fuel_port", () -> BlockEntityType.Builder
            .of(FuelPortBlockEntity::new, ModBlocks.FUEL_PORT.get())
            .build(null));

    /** 控制棒端口：一根控制棒组件。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ControlRodPortBlockEntity>>
            CONTROL_ROD_PORT = BLOCK_ENTITIES.register("control_rod_port", () -> BlockEntityType.Builder
            .of(ControlRodPortBlockEntity::new, ModBlocks.CONTROL_ROD_PORT.get())
            .build(null));

    /** 冷却剂端口：进水罐 + 出汽罐。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CoolantPortBlockEntity>>
            COOLANT_PORT = BLOCK_ENTITIES.register("coolant_port", () -> BlockEntityType.Builder
            .of(CoolantPortBlockEntity::new, ModBlocks.COOLANT_PORT.get())
            .build(null));

    /** 汽轮发电机：蒸汽 → 电 + 乏蒸汽。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SteamGeneratorBlockEntity>>
            STEAM_GENERATOR = BLOCK_ENTITIES.register("steam_generator", () -> BlockEntityType.Builder
            .of(SteamGeneratorBlockEntity::new, ModBlocks.STEAM_GENERATOR.get())
            .build(null));

    // ------------------------------------------------------------------
    // 阶段 6：钠冷快堆
    // ------------------------------------------------------------------

    /** 钠冷快堆控制器：7×7×7 多方块，烧 MOX、喝液态钠。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<FastReactorControllerBlockEntity>>
            FAST_REACTOR_CONTROLLER = BLOCK_ENTITIES.register("fast_reactor_controller",
            () -> BlockEntityType.Builder
                    .of(FastReactorControllerBlockEntity::new, ModBlocks.FAST_REACTOR_CONTROLLER.get())
                    .build(null));

    /** 钠-水蒸汽发生器：快堆二回路，水进、乏蒸汽出、电往外送。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SodiumSteamGeneratorBlockEntity>>
            SODIUM_STEAM_GENERATOR = BLOCK_ENTITIES.register("sodium_steam_generator",
            () -> BlockEntityType.Builder
                    .of(SodiumSteamGeneratorBlockEntity::new, ModBlocks.SODIUM_STEAM_GENERATOR.get())
                    .build(null));

    // ------------------------------------------------------------------
    // 阶段 7：聚变与嬗变
    // ------------------------------------------------------------------

    /** 托卡马克控制器：9×9×9 多方块，点火后 20,000 FE/t。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TokamakControllerBlockEntity>>
            TOKAMAK_CONTROLLER = BLOCK_ENTITIES.register("tokamak_controller",
            () -> BlockEntityType.Builder
                    .of(TokamakControllerBlockEntity::new, ModBlocks.TOKAMAK_CONTROLLER.get())
                    .build(null));

    /** 能量端口：无线接收托卡马克的电，1,000,000 FE 缓冲。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<EnergyPortBlockEntity>>
            ENERGY_PORT = BLOCK_ENTITIES.register("energy_port",
            () -> BlockEntityType.Builder
                    .of(EnergyPortBlockEntity::new, ModBlocks.ENERGY_PORT.get())
                    .build(null));

    /** 物质嬗变器控制器：7×7×7 多方块，1,000,000 FE 换 1 个短寿命同位素。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TransmutatorControllerBlockEntity>>
            TRANSMUTATOR_CONTROLLER = BLOCK_ENTITIES.register("transmutator_controller",
            () -> BlockEntityType.Builder
                    .of(TransmutatorControllerBlockEntity::new, ModBlocks.TRANSMUTATOR_CONTROLLER.get())
                    .build(null));

    /** 电池 MV：160,000 FE 的启动电源。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<BatteryMvBlockEntity>> BATTERY_MV =
            BLOCK_ENTITIES.register("battery_mv", () -> BlockEntityType.Builder
                    .of(BatteryMvBlockEntity::new, ModBlocks.BATTERY_MV.get())
                    .build(null));

    /** 巨型储能库：单方块 1.2 亿 FE 的大电池。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GiantBatteryBlockEntity>>
            GIANT_BATTERY = BLOCK_ENTITIES.register("giant_battery", () -> BlockEntityType.Builder
                    .of(GiantBatteryBlockEntity::new, ModBlocks.GIANT_BATTERY.get())
                    .build(null));

    /** 地质处置库：只记封存了多少块固化玻璃。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GeologicRepositoryBlockEntity>>
            GEOLOGIC_REPOSITORY = BLOCK_ENTITIES.register("geologic_repository",
            () -> BlockEntityType.Builder
                    .of(GeologicRepositoryBlockEntity::new, ModBlocks.GEOLOGIC_REPOSITORY.get())
                    .build(null));

    /** 核弹：六颗弹共用一个方块实体类型（是哪颗由方块的注册名决定）。 */
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<NukeBlockEntity>> NUKE =
            BLOCK_ENTITIES.register("nuke", () -> BlockEntityType.Builder
                    .of(NukeBlockEntity::new,
                            ModBlocks.NUKE_LITTLE_BOY.get(),
                            ModBlocks.NUKE_FAT_MAN.get(),
                            ModBlocks.NUKE_QIU.get(),
                            ModBlocks.NUKE_639.get(),
                            ModBlocks.NUKE_IVY_MIKE.get(),
                            ModBlocks.NUKE_TSAR.get())
                    .build(null));

    private ModBlockEntities() {}
}
