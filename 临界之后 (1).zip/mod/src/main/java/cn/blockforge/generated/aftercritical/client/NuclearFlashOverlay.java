package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.network.BlastFxState;
import net.minecraft.client.gui.GuiGraphics;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderGuiEvent;

/**
 * 核爆的全屏视觉：爆闪、火球余晖、暖色滤镜、暗角，全部盖在 HUD 之上。
 *
 * <p>只在客户端加载（{@code value = Dist.CLIENT}）。服务器只负责发「离爆心多近」，
 * 这里拿着那个数去问 {@link BlastFxState} 要「现在这一帧该画什么」，所以多少格外的玩家
 * 看到的都是一整屏幕的白，而不是原版 {@code FLASH} 粒子在远处变成的白方块。
 *
 * <h2>画的顺序（从下往上）</h2>
 * <ol>
 *   <li><b>橙色火球余晖</b>：白幕退掉的过程中从底下透出来的就是它；</li>
 *   <li><b>纯白爆闪</b>：0–0.32 秒盖满，之后按平方退掉；</li>
 *   <li><b>暖色滤镜</b>：白闪没了以后接管，把整个画面压成橙红色，跟着爆炸声一起退；</li>
 *   <li><b>暗角</b>：四周压黑，把视线往中间挤，冲击感更像「被闪到睁不开眼」。</li>
 * </ol>
 *
 * <p>爆闪和滤镜全程只用半透明的 {@code fill} 盖色，不读写屏幕像素，
 * 所以对帧率几乎没有影响，也不会和光影 mod 抢帧缓冲。
 */
@EventBusSubscriber(modid = AfterCritical.MOD_ID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class NuclearFlashOverlay {

    /** 纯白：爆闪本体。 */
    private static final int COLOR_WHITE = 0xFFFFFF;
    /** 火球余晖的颜色：偏黄的亮橙。 */
    private static final int COLOR_EMBER = 0xFFA24C;
    /** 滤镜的颜色：橙红，像隔着一层灼热的空气看世界。 */
    private static final int COLOR_FILTER = 0xE06A20;

    /** 低于这个透明度就不画了，省得每帧白跑一次填充。 */
    private static final float EPSILON = 0.004F;

    /** 暗角左右两侧分几层做渐变（上下两端用的是真正的渐变填充）。 */
    private static final int SIDE_STEPS = 8;

    private NuclearFlashOverlay() {}

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        if (!BlastFxState.active()) {
            return;
        }
        GuiGraphics graphics = event.getGuiGraphics();
        int width = graphics.guiWidth();
        int height = graphics.guiHeight();

        float white = BlastFxState.whiteAlpha();
        float ember = BlastFxState.emberAlpha();
        float filter = BlastFxState.filterAlpha();
        float vignette = BlastFxState.vignetteAlpha();

        if (white <= EPSILON && ember <= EPSILON && filter <= EPSILON) {
            return;
        }

        // 1. 火球余晖垫在最底下：白幕一退，露出来的就是它
        if (ember > EPSILON) {
            graphics.fill(0, 0, width, height, argb(ember, COLOR_EMBER));
        }

        // 2. 纯白爆闪盖在上层
        if (white > EPSILON) {
            graphics.fill(0, 0, width, height, argb(white, COLOR_WHITE));
        }

        // 3. 暖色滤镜
        if (filter > EPSILON) {
            graphics.fill(0, 0, width, height, argb(filter, COLOR_FILTER));
        }

        // 4. 暗角：白闪期间不压，不然「全屏纯白」就白不起来了
        float corner = vignette * (1.0F - Math.min(1.0F, white));
        if (corner > EPSILON) {
            drawVignette(graphics, width, height, corner);
        }
    }

    /**
     * 四周压黑的暗角。
     *
     * <p>上下两端用 {@code fillGradient} 做真正的渐变；左右两侧没有横向渐变可用，
     * 就等分成几道竖条、每道依次变淡——层数够多的时候眼睛看不出台阶。
     */
    private static void drawVignette(GuiGraphics graphics, int width, int height, float alpha) {
        int topBand = Math.max(24, height / 4);
        int edge = argb(alpha, 0x000000);
        int clear = 0;

        graphics.fillGradient(0, 0, width, topBand, edge, clear);
        graphics.fillGradient(0, height - topBand, width, height, clear, edge);

        int sideBand = Math.max(20, width / 6);
        int stepWidth = Math.max(1, sideBand / SIDE_STEPS);
        for (int i = 0; i < SIDE_STEPS; i++) {
            float left = 1.0F - i / (float) SIDE_STEPS;
            int color = argb(alpha * left * left, 0x000000);
            if (color == 0) {
                continue;
            }
            int x0 = i * stepWidth;
            graphics.fill(x0, 0, x0 + stepWidth, height, color);
            int x1 = width - (i + 1) * stepWidth;
            graphics.fill(x1, 0, x1 + stepWidth, height, color);
        }
    }

    /** 把 0~1 的透明度和 RGB 拼成一个 ARGB 颜色。 */
    private static int argb(float alpha, int rgb) {
        int a = Math.round(Math.max(0.0F, Math.min(1.0F, alpha)) * 255.0F);
        return a <= 0 ? 0 : (a << 24) | rgb;
    }
}
