package cn.blockforge.generated.aftercritical.network;

import cn.blockforge.generated.aftercritical.AfterCritical;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * 「这里有一朵蘑菇云」的包：服务器只报位置、大小和已经过了多久，长什么样由客户端
 * 用自己的模型画（{@code assets/aftercritical/mushroom_cloud.json}）。
 *
 * <p>以前蘑菇云是几千颗粒子，靠 {@code ClientboundLevelParticlesPacket} 一颗颗发；
 * 现在换成一整个带骨骼动画的模型，一朵云只发这一条消息。已经过了多久也带上，
 * 是为了后进服务器 / 后来才走进视野的玩家也能接上同一朵云，而不是从头再长一遍。
 *
 * @param id       这朵云的编号（同一个编号的包，客户端只认最新的那条）
 * @param x        爆心 x（方块中心）
 * @param y        模型脚底贴地的高度
 * @param z        爆心 z
 * @param scale    模型放大多少倍（模型自己高约 64 格，乘完才是这颗弹该有的大小）
 * @param duration 这朵云一共活多少 tick
 * @param age      发这条包的时候，云已经活了多久
 */
public record MushroomCloudPayload(int id, double x, double y, double z,
                                   float scale, int duration, int age)
        implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<MushroomCloudPayload> TYPE =
            new CustomPacketPayload.Type<>(
                    ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "mushroom_cloud"));

    public static final StreamCodec<FriendlyByteBuf, MushroomCloudPayload> STREAM_CODEC =
            StreamCodec.of(
                    (buf, payload) -> {
                        buf.writeVarInt(payload.id());
                        buf.writeDouble(payload.x());
                        buf.writeDouble(payload.y());
                        buf.writeDouble(payload.z());
                        buf.writeFloat(payload.scale());
                        buf.writeVarInt(payload.duration());
                        buf.writeVarInt(payload.age());
                    },
                    buf -> new MushroomCloudPayload(
                            buf.readVarInt(),
                            buf.readDouble(),
                            buf.readDouble(),
                            buf.readDouble(),
                            buf.readFloat(),
                            buf.readVarInt(),
                            buf.readVarInt()));

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
