package cn.blockforge.generated.aftercritical.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * 带一行灰色说明文字的普通物品。
 *
 * <p>机械臂、泵这类「零件」本身不做任何事，玩家光看名字不知道它是干什么的、
 * 也不知道它运行起来要耗多少电，所以注册时给它挂一句说明。
 * 说明文字的语言文件键由构造时传进来的 {@code tooltipKey} 决定。
 */
public class TooltipItem extends Item {

    private final String tooltipKey;

    public TooltipItem(Properties properties, String tooltipKey) {
        super(properties);
        this.tooltipKey = tooltipKey;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable(this.tooltipKey).withStyle(ChatFormatting.GRAY));
    }
}
