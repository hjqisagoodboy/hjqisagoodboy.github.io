package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.effect.RadiationProtection;
import cn.blockforge.generated.aftercritical.registry.ModEffects;
import net.minecraft.core.BlockPos;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * 铀矿石方块。
 *
 * <p>玩家用任意工具（包括空手）挖掉它时，会获得 10 秒“辐射沾染”。
 */
public class UraniumOreBlock extends Block {
    /** 辐射沾染持续 10 秒 = 200 tick。 */
    private static final int EFFECT_DURATION_TICKS = 200;

    public UraniumOreBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void playerDestroy(
            Level level,
            Player player,
            BlockPos pos,
            BlockState state,
            BlockEntity blockEntity,
            ItemStack tool) {
        super.playerDestroy(level, player, pos, state, blockEntity, tool);
        // 穿齐辐射防护服就一点不沾：挖矿的粉尘也挡得住
        if (!level.isClientSide && !RadiationProtection.isFullSuit(player)) {
            player.addEffect(new MobEffectInstance(ModEffects.RADIATION_CONTAMINATION, EFFECT_DURATION_TICKS, 0));
        }
    }
}
