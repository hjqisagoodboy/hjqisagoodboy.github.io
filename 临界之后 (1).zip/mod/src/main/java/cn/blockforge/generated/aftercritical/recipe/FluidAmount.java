package cn.blockforge.generated.aftercritical.recipe;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.material.Fluid;
import net.neoforged.neoforge.fluids.FluidStack;

/**
 * 配方里写的「哪种流体、多少 mB」。
 *
 * <p>JSON 里写成 {@code {"fluid": "minecraft:water", "amount": 1000}}。
 * 用 {@link ResourceLocation} 而不是直接存 {@link Fluid} 对象，是因为读 JSON 的时候
 * 注册表可能还没完全建好；真正用到的时候再由 {@link #stack()} 去查。
 */
public record FluidAmount(ResourceLocation fluid, int amount) {

    public FluidAmount {
        amount = Math.max(1, amount);
    }

    /** 查到这个流体；查不到返回 {@code null}（比如别的模组被删了）。 */
    public Fluid resolve() {
        return BuiltInRegistries.FLUID.get(this.fluid);
    }

    /** 转成一份流体栈，方便塞进储罐。 */
    public FluidStack stack() {
        Fluid fluid = resolve();
        return fluid == null ? FluidStack.EMPTY : new FluidStack(fluid, this.amount);
    }

    /** 罐子里这一份东西够不够这条配方要的量。 */
    public boolean test(FluidStack tank) {
        if (tank.isEmpty() || tank.getAmount() < this.amount) {
            return false;
        }
        Fluid fluid = resolve();
        return fluid != null && tank.getFluid() == fluid;
    }
}
