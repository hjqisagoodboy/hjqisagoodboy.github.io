package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.effect.RadiationAura;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FlowingFluid;

/**
 * 核废水方块：灰黑色、半透明的脏水，核爆把原来的水「照脏」之后就变成它。
 *
 * <p>它和水一样能流、能游（水流属性在 {@code ModFluids} 里登记），唯一的额外逻辑是
 * <b>泡在里面就一直吃辐射</b>——和污染土、辐射尘用的是同一套
 * {@link RadiationAura}，所以穿齐四件辐射防护服照样完全免疫。
 *
 * <p>为什么写在方块里而不是写在流体里：{@code Block#entityInside} 会在实体和方块
 * 重叠的时候自动被调用（每 tick 都调），不管玩家是游过去、掉进去还是被冲进去都算数，
 * 比在服务端 tick 里挨个玩家查位置省事，也能顺手处理掉进废水里的动物。
 */
public class WastewaterBlock extends LiquidBlock {

    public WastewaterBlock(FlowingFluid fluid, Properties properties) {
        super(fluid, properties);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (!level.isClientSide && entity instanceof LivingEntity living) {
            RadiationAura.apply(living);
        }
        super.entityInside(state, level, pos, entity);
    }
}
