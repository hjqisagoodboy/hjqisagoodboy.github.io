package cn.blockforge.generated.aftercritical.nuke;

import cn.blockforge.generated.aftercritical.item.NukeComponentItem;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * 核弹里的模块化组件。每一颗弹需要哪几种，写在 {@link NukeKind#slots()} 里。
 *
 * <p>这里只放「这个组件本身让爆炸怎么变」：半径倍率、坑深倍率、辐射倍率、引信倍率。
 * 「它该装在弹的哪个位置」是某一颗弹的事，不写在这张公共表里——
 * 同一个「中子引发器」在胖子身上是外圈最后一道保险，在沙皇身上是初级扳机的触发器。
 *
 * <p>数值都是乘算：一颗弹能装的组件固定，全装对就是这颗弹的「满配」。
 * 装错了槽不算数（界面里也不让放），所以不会出现「乱塞一通反而更大」。
 */
public enum NukeComponent {

    // ---- 六颗弹通用 / 多颗弹共用 ----

    /** 引信：让起爆时序更准，炸药能量少跑掉一点。 */
    FUZE("nuke_fuze", 1.04F, 1.00F, 1.00F, 1.00F),
    /** 中子引发器：起爆瞬间撒出一把中子，链式反应起得更早。 */
    INITIATOR("nuke_initiator", 1.06F, 1.00F, 1.00F, 1.00F),
    /** 裂变扳机：氢弹的初级，靠它点着次级。 */
    PRIMARY("nuke_primary", 1.12F, 1.00F, 1.00F, 1.00F),
    /** 增强装药：多一圈高能炸药，压缩得更狠。 */
    BOOSTER("nuke_booster", 1.08F, 1.00F, 1.00F, 1.00F),
    /** 中子反射层：把跑掉的中子反弹回去，同样的核装料多裂变一点。 */
    REFLECTOR("nuke_reflector", 1.06F, 1.04F, 1.00F, 1.00F),
    /** 铀-238 惰层：又重又硬，把爆炸往下压，坑更深。 */
    TAMPER("nuke_tamper", 1.00F, 1.10F, 1.00F, 1.00F),
    /** 钴-60 外壳：炸完留下一大片长久辐射。 */
    COBALT_SHELL("nuke_cobalt_shell", 1.00F, 1.00F, 2.00F, 1.00F),

    // ---- 枪式（小男孩）----

    /** 炮管：铀靶环加速的那截管子，越长末速越高。 */
    GUN_BARREL("nuke_gun_barrel", 1.05F, 1.00F, 1.00F, 1.00F),
    /** 铀靶环：被炮弹打中的那摞环，整颗弹的核装料。 */
    URANIUM_TARGET("nuke_uranium_target", 1.10F, 1.02F, 1.00F, 1.00F),

    // ---- 内爆式（胖子、邱小姐）----

    /** 钚核心：内爆式的心脏，纯钚-239 球。 */
    PLUTONIUM_PIT("nuke_plutonium_pit", 1.15F, 1.05F, 1.00F, 1.00F),
    /** 铀-235 核心：邱小姐的紧凑铀球，比钚芯难压但同样致命。 */
    URANIUM_PIT("nuke_uranium_pit", 1.14F, 1.05F, 1.00F, 1.00F),
    /** 炸药透镜：一圈形状精确的炸药块，把球面冲击波压成完美的内爆。 */
    EXPLOSIVE_LENS("nuke_explosive_lens", 1.10F, 1.00F, 1.00F, 1.00F),

    // ---- 氢弹 ----

    /** 氘化锂-6：氢弹的燃料，中子一照就生出氚。 */
    DEUTERIUM_LITHIUM("nuke_deuterium_lithium", 1.20F, 1.08F, 1.00F, 1.00F),
    /** 低温杜瓦：常青藤那套的液态氘保温瓶，历史上整套装置重达六十多吨。 */
    CRYOSTAT("nuke_cryostat", 1.12F, 1.00F, 1.00F, 1.00F),
    /** 减速伞：从飞机上扔下来先减速，引爆前你有更多时间跑远。 */
    PARACHUTE("nuke_parachute", 1.00F, 1.00F, 1.00F, 2.00F);

    /** 物品名（不带模组前缀）。 */
    public final String itemId;
    /** 半径倍率。 */
    public final float radiusFactor;
    /** 坑深倍率。 */
    public final float depthFactor;
    /** 辐射时长倍率。 */
    public final float radiationFactor;
    /** 引信时长倍率（大于 1 = 倒计时更长，跑得掉）。 */
    public final float fuseFactor;

    NukeComponent(String itemId, float radiusFactor, float depthFactor, float radiationFactor,
                  float fuseFactor) {
        this.itemId = itemId;
        this.radiusFactor = radiusFactor;
        this.depthFactor = depthFactor;
        this.radiationFactor = radiationFactor;
        this.fuseFactor = fuseFactor;
    }

    /** 语言键（物品名）。 */
    public String langKey() {
        return "item.aftercritical." + this.itemId;
    }

    /** 提示里那一行「装上去有什么用」。 */
    public String effectKey() {
        return "tooltip.aftercritical." + this.itemId + ".effect";
    }

    /**
     * 按某一颗弹的槽位表，把槽里装的组件算成一次爆炸的最终参数。
     *
     * <p>槽里放的东西和这个槽要求的组件对不上就不算——正常流程里界面不让放，
     * 但老存档、指令、拆方块都可能塞进别的东西，这里兜一下。
     *
     * @param slots 槽里的内容，顺序和 {@link NukeKind#slots()} 一致
     */
    public static Loadout loadout(NukeKind kind, List<ItemStack> slots) {
        List<NukeKind.NukeSlot> layout = kind.slots();
        float radiusFactor = 1.0F;
        float depthFactor = 1.0F;
        float radiationFactor = 1.0F;
        float fuseFactor = 1.0F;
        int installed = 0;
        boolean cobalt = false;
        for (int index = 0; index < layout.size() && index < slots.size(); index++) {
            ItemStack stack = slots.get(index);
            if (stack.isEmpty()) {
                continue;
            }
            NukeComponent component = NukeComponentItem.componentOf(stack);
            if (component != layout.get(index).component()) {
                continue;
            }
            installed++;
            radiusFactor *= component.radiusFactor;
            depthFactor *= component.depthFactor;
            radiationFactor *= component.radiationFactor;
            fuseFactor *= component.fuseFactor;
            if (component == COBALT_SHELL) {
                cobalt = true;
            }
        }
        int radius = Math.round(kind.radius * radiusFactor);
        int depth = Math.round(kind.depth * depthFactor);
        int radiationTicks = Math.round(kind.radiationSeconds * 20 * radiationFactor);
        int fuseTicks = Math.round(kind.fuseTicks * fuseFactor);
        return new Loadout(radius, depth, radiationTicks, installed, layout.size(), fuseTicks, cobalt);
    }

    /**
     * 一次爆炸的最终参数。
     *
     * @param installed 真的装对了的组件个数
     * @param capacity  这颗弹一共有几个槽（满配成就看它）
     * @param fuseTicks 从点火到爆炸的 tick 数
     */
    public record Loadout(int radius, int depth, int radiationTicks, int installed, int capacity,
                          int fuseTicks, boolean cobalt) {
    }
}
