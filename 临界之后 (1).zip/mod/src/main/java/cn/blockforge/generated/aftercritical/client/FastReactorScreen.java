package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.blockentity.FastReactorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.menu.FastReactorMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;

/**
 * 钠冷快堆控制器的界面：两行 MOX 燃料格 + 一格产物，燃料格下面一条控制棒滑块，
 * 右边一根钠长条，底下六行读数。
 *
 * <p>和压水堆的界面长得像，但读数换成了快堆关心的东西：外壳、探测器、发生器、钠、
 * 热量百分比、当前发电量，还有「这一支 MOX 烧到多少」。
 */
public class FastReactorScreen extends StatPanelScreen<FastReactorMenu> {

    private static final int SLIDER_X = 30;
    private static final int SLIDER_Y = 64;
    private static final int SLIDER_W = 78;
    private static final int SLIDER_H = 8;
    private static final int BUTTON_MINUS_X = 13;
    private static final int BUTTON_PLUS_X = 111;
    private static final int BUTTON_Y = 62;
    private static final int BUTTON_W = 15;
    private static final int BUTTON_H = 12;

    public FastReactorScreen(FastReactorMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected List<Line> statLines() {
        List<Line> lines = new ArrayList<>(FastReactorMenu.STAT_LINES);

        boolean formed = this.menu.isFormed();
        lines.add(new Line(Component.translatable(formed
                ? "gui.aftercritical.reactor.structure_ok"
                : "gui.aftercritical.reactor.structure_missing"), formed ? TEXT_OK : TEXT_BAD));

        lines.add(new Line(Component.translatable("gui.aftercritical.fast.mat",
                this.menu.shell(), FastReactorControllerBlockEntity.MIN_SHELL), TEXT_GRAY));

        lines.add(new Line(Component.translatable("gui.aftercritical.fast.parts",
                this.menu.detectors(), FastReactorControllerBlockEntity.MIN_DETECTORS,
                this.menu.generators(), FastReactorControllerBlockEntity.MIN_GENERATORS,
                this.menu.rodPorts(), FastReactorControllerBlockEntity.MIN_ROD_PORTS), TEXT_GRAY));

        lines.add(new Line(Component.translatable("gui.aftercritical.fast.fuel",
                this.menu.fuel(), FastReactorControllerBlockEntity.MIN_FUEL,
                FastReactorControllerBlockEntity.FUEL_SLOTS,
                this.menu.rods(), this.menu.rodPorts()), TEXT_DARK));

        lines.add(new Line(Component.translatable("gui.aftercritical.fast.heat",
                this.menu.heatPercent(), this.menu.outputFePerTick(),
                this.menu.sodiumAmount(), FastReactorControllerBlockEntity.SODIUM_CAPACITY),
                this.menu.status() == FastReactorControllerBlockEntity.STATUS_NO_SODIUM ? TEXT_WARN : TEXT_DARK));

        lines.add(new Line(Component.translatable("gui.aftercritical.fast.status." + this.menu.status()),
                statusColorOf(this.menu.status())));
        return lines;
    }

    private static int statusColorOf(int status) {
        return switch (status) {
            case FastReactorControllerBlockEntity.STATUS_RUNNING -> TEXT_OK;
            case FastReactorControllerBlockEntity.STATUS_NO_SODIUM,
                 FastReactorControllerBlockEntity.STATUS_NO_FUEL,
                 FastReactorControllerBlockEntity.STATUS_NO_RODS,
                 FastReactorControllerBlockEntity.STATUS_OUTPUT_FULL -> TEXT_WARN;
            default -> TEXT_GRAY;
        };
    }

    // ------------------------------------------------------------------
    // 背景：控制棒滑块 + 两支 MOX 燃料进度
    // ------------------------------------------------------------------

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        super.renderBg(guiGraphics, partialTick, mouseX, mouseY);

        int x = this.leftPos + SLIDER_X;
        int y = this.topPos + SLIDER_Y;

        guiGraphics.fill(x - 1, y - 1, x + SLIDER_W + 1, y + SLIDER_H + 1, PANEL_DARK);
        guiGraphics.fill(x, y, x + SLIDER_W, y + SLIDER_H, ENERGY_TRACK);
        int filled = Math.round(SLIDER_W * this.menu.rodDepth() / 100.0F);
        if (filled > 0) {
            guiGraphics.fill(x, y, x + filled, y + SLIDER_H, 0xFF4A9BD8);
            guiGraphics.fill(x, y, x + filled, y + 1, 0xFF8FD0FF);
        }

        drawButton(guiGraphics, this.leftPos + BUTTON_MINUS_X, this.topPos + BUTTON_Y, "-");
        drawButton(guiGraphics, this.leftPos + BUTTON_PLUS_X, this.topPos + BUTTON_Y, "+");

        guiGraphics.drawString(this.font,
                Component.translatable("gui.aftercritical.fast.depth", this.menu.rodDepth()),
                this.leftPos + SLIDER_X, this.topPos + SLIDER_Y + 11, TEXT_DARK, false);
        guiGraphics.drawString(this.font,
                Component.translatable("gui.aftercritical.fast.burn", this.menu.burnPercent()),
                this.leftPos + SLIDER_X + 82, this.topPos + SLIDER_Y + 11, TEXT_DARK, false);
    }

    private void drawButton(GuiGraphics guiGraphics, int x, int y, String text) {
        guiGraphics.fill(x, y, x + BUTTON_W, y + BUTTON_H, PANEL_BG);
        guiGraphics.fill(x, y, x + BUTTON_W, y + 1, PANEL_LIGHT);
        guiGraphics.fill(x, y + BUTTON_H - 1, x + BUTTON_W, y + BUTTON_H, PANEL_DARK);
        guiGraphics.fill(x, y, x + 1, y + BUTTON_H, PANEL_LIGHT);
        guiGraphics.fill(x + BUTTON_W - 1, y, x + BUTTON_W, y + BUTTON_H, PANEL_DARK);
        int textWidth = this.font.width(text);
        guiGraphics.drawString(this.font, text,
                x + (BUTTON_W - textWidth) / 2, y + (BUTTON_H - 8) / 2 + 1, TEXT_DARK, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && this.minecraft != null && this.minecraft.gameMode != null) {
            int x = (int) mouseX - this.leftPos;
            int y = (int) mouseY - this.topPos;
            if (inside(x, y, BUTTON_MINUS_X, BUTTON_Y, BUTTON_W, BUTTON_H)) {
                send(FastReactorMenu.BUTTON_ROD_LESS);
                return true;
            }
            if (inside(x, y, BUTTON_PLUS_X, BUTTON_Y, BUTTON_W, BUTTON_H)) {
                send(FastReactorMenu.BUTTON_ROD_MORE);
                return true;
            }
            if (inside(x, y, SLIDER_X, SLIDER_Y, SLIDER_W, SLIDER_H)) {
                int percent = Math.round((x - SLIDER_X) * 100.0F / SLIDER_W);
                send(FastReactorMenu.BUTTON_ROD_ABSOLUTE + Math.max(0, Math.min(100, percent)));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void send(int buttonId) {
        if (this.minecraft != null && this.minecraft.gameMode != null) {
            this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, buttonId);
        }
    }

    private static boolean inside(int x, int y, int left, int top, int width, int height) {
        return x >= left && x < left + width && y >= top && y < top + height;
    }
}
