package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.SodiumSteamGeneratorBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 钠-水蒸汽发生器的界面：左边能量条，右边两根长条（水 / 乏蒸汽），底下四行读数。
 *
 * <p>没有物品槽——水靠管道或相邻的储罐自动抽进来，乏蒸汽从长条那头被管道抽走。
 */
public class SodiumSteamGeneratorMenu extends AbstractMachineMenu implements FluidBarHost {

    /** 两根长条的位置（面板坐标）。 */
    public static final int BAR_X = 150;
    public static final int BAR_TOP = 28;
    public static final int BAR_STEP = 22;
    public static final int BAR_W = 14;
    public static final int BAR_H = 18;

    /** 底部读数几行。 */
    public static final int STAT_LINES = 4;

    private static final int DATA_WATER = 0;
    private static final int DATA_EXHAUST = 1;
    private static final int DATA_RATE = 2;
    private static final int DATA_OUTPUT = 3;
    private static final int DATA_HEAT = 4;
    private static final int DATA_COUNT = 5;

    @Nullable
    private final SodiumSteamGeneratorBlockEntity generator;
    private final int[] values = new int[DATA_COUNT];

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return index >= 0 && index < DATA_COUNT ? values[index] : 0;
        }

        @Override
        public void set(int index, int value) {
            if (index >= 0 && index < DATA_COUNT) {
                values[index] = value;
            }
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    /** 服务端用。 */
    public SodiumSteamGeneratorMenu(int containerId, Inventory playerInventory,
                                    SodiumSteamGeneratorBlockEntity generator) {
        this(containerId, playerInventory, (BlockEntity) generator);
    }

    /** 客户端用。 */
    public SodiumSteamGeneratorMenu(int containerId, Inventory playerInventory, @Nullable BlockEntity blockEntity) {
        super(ModMenus.SODIUM_STEAM_GENERATOR.get(), containerId, playerInventory, 0,
                blockEntity instanceof SodiumSteamGeneratorBlockEntity be ? be : null, 2);
        this.generator = blockEntity instanceof SodiumSteamGeneratorBlockEntity be ? be : null;
        this.addPlayerInventory(playerInventory);
        this.addDataSlots(this.data);
    }

    public static SodiumSteamGeneratorMenu fromNetwork(int containerId, Inventory playerInventory,
                                                       RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        return new SodiumSteamGeneratorMenu(containerId, playerInventory,
                playerInventory.player.level().getBlockEntity(pos));
    }

    @Override
    public void broadcastChanges() {
        if (this.generator != null) {
            this.values[DATA_WATER] = this.generator.waterAmount();
            this.values[DATA_EXHAUST] = this.generator.exhaustAmount();
            this.values[DATA_RATE] = this.generator.waterPerTick();
            this.values[DATA_OUTPUT] = this.generator.outputFePerTick();
            this.values[DATA_HEAT] = this.generator.heatPermille();
        }
        super.broadcastChanges();
    }

    /** 没有机器槽，Shift 点击不搬东西。 */
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    public int waterPerTick() {
        return this.values[DATA_RATE];
    }

    public int outputFePerTick() {
        return this.values[DATA_OUTPUT];
    }

    public int heatPercent() {
        return Math.round(this.values[DATA_HEAT] / 10.0F);
    }

    public int tankCapacity() {
        return SodiumSteamGeneratorBlockEntity.TANK_CAPACITY;
    }

    // ------------------------------------------------------------------
    // FluidBarHost
    // ------------------------------------------------------------------

    @Override
    public int barCount() {
        return 2;
    }

    @Override
    public int barX(int index) {
        return BAR_X;
    }

    @Override
    public int barY(int index) {
        return BAR_TOP + index * BAR_STEP;
    }

    @Override
    public int barWidth(int index) {
        return BAR_W;
    }

    @Override
    public int barHeight(int index) {
        return BAR_H;
    }

    @Override
    public int barAmount(int index) {
        return index == 0 ? this.values[DATA_WATER] : this.values[DATA_EXHAUST];
    }

    @Override
    public int barFluidId(int index) {
        if (barAmount(index) <= 0) {
            return -1;
        }
        return BuiltInRegistries.FLUID.getId(index == 0
                ? net.minecraft.world.level.material.Fluids.WATER
                : ModFluids.EXHAUST_STEAM.source.get());
    }

    @Override
    public int barCapacity() {
        return SodiumSteamGeneratorBlockEntity.TANK_CAPACITY;
    }

    @Override
    public boolean barIsInput(int index) {
        return index == 0;
    }

    // ------------------------------------------------------------------
    // 版式：底部四行读数
    // ------------------------------------------------------------------

    @Override
    public int textY() {
        return MachineLayout.textY(0);
    }

    @Override
    public int inventoryLabelY() {
        return textY() + STAT_LINES * MachineLayout.TEXT_STEP + 3;
    }

    @Override
    public int inventoryY() {
        return inventoryLabelY() + 10;
    }

    @Override
    public int guiHeight() {
        return inventoryY() + 58 + 18 + 6;
    }

    /** 客户端兜底：拿不到方块实体时也要能建出菜单。 */
    @SuppressWarnings("unused")
    private static Container emptyContainer() {
        return new SimpleContainer(0);
    }
}
