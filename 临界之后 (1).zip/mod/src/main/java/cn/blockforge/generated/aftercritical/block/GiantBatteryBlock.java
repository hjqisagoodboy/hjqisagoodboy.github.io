package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.GiantBatteryBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 巨型储能库的方块：单方块，1.2 亿 FE，充放 20,000 FE/t。
 *
 * <p>它不需要多方块结构，摆一块就是全部容量——玩家不用为了「存一炉电」
 * 去铺一面墙的电池 MV。
 */
public class GiantBatteryBlock extends TickingMachineBlock {

    public GiantBatteryBlock(Properties properties) {
        super(properties, "HV", "tooltip.aftercritical.charge_rate",
                GiantBatteryBlockEntity.MAX_RECEIVE_PER_TICK, "block.aftercritical.giant_battery.desc");
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(GiantBatteryBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new GiantBatteryBlockEntity(pos, state);
    }
}
