package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.blockentity.FuelPortBlockEntity;
import cn.blockforge.generated.aftercritical.menu.FuelPortMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * 燃料端口的界面：一块普通面板，8 个燃料格排成 4×2，下面一条燃烧进度箭头。
 *
 * <p>底下的读数就三行：接没接上压水堆、里面有几支燃料、这一支烧到百分之几。
 * 面板上没有能量条也没有流体长条——这不是机器，只是个插燃料的口。
 */
public class FuelPortScreen extends AbstractMachineScreen<FuelPortMenu> {

    public FuelPortScreen(FuelPortMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    /** 第一行：状态。没接堆、没燃料、正在烧，三种情况一眼分开。 */
    @Override
    protected Component statusLine() {
        if (!this.menu.isLinked()) {
            return Component.translatable("gui.aftercritical.fuel_port.unlinked");
        }
        if (this.menu.fuelCount() <= 0) {
            return Component.translatable("gui.aftercritical.fuel_port.empty");
        }
        int max = this.menu.getMaxProgress();
        int percent = max <= 0 ? 0
                : Math.round(100.0F * Math.max(0, Math.min(this.menu.getProgress(), max)) / max);
        return Component.translatable("gui.aftercritical.fuel_port.burning", percent);
    }

    @Override
    protected int statusColor() {
        if (!this.menu.isLinked()) {
            return TEXT_BAD;
        }
        return this.menu.fuelCount() > 0 ? TEXT_OK : TEXT_WARN;
    }

    /** 第三行：这个格子能放什么、烧完会变成什么。 */
    @Override
    protected Component hintLine() {
        return Component.translatable("gui.aftercritical.fuel_port.hint",
                this.menu.fuelCount(), FuelPortBlockEntity.SLOTS);
    }
}
