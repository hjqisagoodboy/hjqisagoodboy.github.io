package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.recipe.MachineRecipe;
import cn.blockforge.generated.aftercritical.registry.ModRecipes;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.crafting.RecipeType;

/**
 * 阶段 2 燃料制造链上三台「只吃物品、不碰流体」的机器。
 *
 * <p>烧结炉、磨削机、焊接机的加工方式一模一样（放原料、耗电、攒进度、出成品），
 * 差别只有：等级、功率、几个输入槽、几个输出槽、看哪一类配方。把这些数字集中写在这里，
 * 方块、方块实体、界面各读各的，就不用为每台机器抄一份代码。
 *
 * <p>压块机和组装机 T2 在之前几轮已经单独做过，不在这张表里。
 */
public enum ItemMachineKind {

    /**
     * 烧结炉：HV，150 FE/t，1 进 1 出。
     *
     * <p>把压好的芯块坯送进高温炉里烧硬，烧出来的烧结芯块才能上车床磨。
     */
    SINTERING_FURNACE("HV", 150, 1, 1,
            "block.aftercritical.sintering_furnace.desc", "container.aftercritical.sintering_furnace",
            "gui.aftercritical.sintering.hint"),

    /**
     * 磨削机：MV，80 FE/t，1 进 2 出。
     *
     * <p>把烧结芯块磨到精确尺寸，磨下来的粉就是「废粉」——第二个输出槽里的副产物。
     */
    GRINDING_MACHINE("MV", 80, 1, 2,
            "block.aftercritical.grinding_machine.desc", "container.aftercritical.grinding_machine",
            "gui.aftercritical.grinding.hint"),

    /**
     * 焊接机：MV，100 FE/t，2 进 1 出。
     *
     * <p>燃料棒一头塞一个端塞，焊死就是密封燃料棒。
     */
    WELDING_MACHINE("MV", 100, 2, 1,
            "block.aftercritical.welding_machine.desc", "container.aftercritical.welding_machine",
            "gui.aftercritical.welding.hint"),

    /**
     * 伽马辐照器：HV，100 FE/t，2 进 1 出。
     *
     * <p>一格放要照的东西（腐肉、生鸡肉），一格放钴60源当「灯泡」；
     * 钴60源会被消耗掉，一炉换一炉。
     */
    GAMMA_IRRADIATOR("HV", 100, 2, 1,
            "block.aftercritical.gamma_irradiator.desc", "container.aftercritical.gamma_irradiator",
            "gui.aftercritical.gamma.hint"),

    /**
     * 剪切机：HV，200 FE/t，1 进 2 出。
     *
     * <p>后处理线的「开罐刀」：把冷却好的乏燃料组件剪成碎块（主产物），
     * 顺手把外面的空框架剥下来（副产物，可以回收再拿去装配燃料组件）。
     */
    SHEARING_MACHINE("HV", 200, 1, 2,
            "block.aftercritical.shearing_machine.desc", "container.aftercritical.shearing_machine",
            "gui.aftercritical.shearing.hint"),

    /**
     * 核装置总装台：HV，400 FE/t，4 进 1 出。
     *
     * <p>武器线的总装机器。核弹本体（空弹体 + 高能炸药 + 核装料 + 结构件）和
     * 它们的模块化组件（引信、中子引发器、炸药透镜、惰层、锂氘燃料……）都在这台上做，
     * 一台机器包完整条武器线，不用为每种组件再开一台。
     */
    WARHEAD_ASSEMBLY("HV", 400, 4, 1,
            "block.aftercritical.warhead_assembler.desc", "container.aftercritical.warhead_assembler",
            "gui.aftercritical.warhead.hint");

    private final String tier;
    private final int energyPerTick;
    private final int itemInputs;
    private final int itemOutputs;
    private final String descriptionKey;
    private final String titleKey;
    private final String hintKey;

    ItemMachineKind(String tier, int energyPerTick, int itemInputs, int itemOutputs,
                    String descriptionKey, String titleKey, String hintKey) {
        this.tier = tier;
        this.energyPerTick = energyPerTick;
        this.itemInputs = itemInputs;
        this.itemOutputs = itemOutputs;
        this.descriptionKey = descriptionKey;
        this.titleKey = titleKey;
        this.hintKey = hintKey;
    }

    public String tier() {
        return this.tier;
    }

    public int energyPerTick() {
        return this.energyPerTick;
    }

    public int itemInputs() {
        return this.itemInputs;
    }

    public int itemOutputs() {
        return this.itemOutputs;
    }

    /** 机器自己的槽位总数（输入在前、输出在后）。 */
    public int slotCount() {
        return this.itemInputs + this.itemOutputs;
    }

    /** 第 {@code index} 个输入槽的槽号。 */
    public int inputSlot(int index) {
        return index;
    }

    /** 第 {@code index} 个输出槽的槽号：紧跟在输入槽后面。 */
    public int outputSlot(int index) {
        return this.itemInputs + index;
    }

    public String descriptionKey() {
        return this.descriptionKey;
    }

    /** 界面顶上的标题。 */
    public Component displayName() {
        return Component.translatable(this.titleKey);
    }

    public String titleKey() {
        return this.titleKey;
    }

    /** 界面上第三行的操作提示。 */
    public String hintKey() {
        return this.hintKey;
    }

    /** 这台机器去配方管理器里找哪一类配方。 */
    public RecipeType<MachineRecipe> recipeType() {
        return switch (this) {
            case SINTERING_FURNACE -> ModRecipes.SINTERING;
            case GRINDING_MACHINE -> ModRecipes.GRINDING;
            case WELDING_MACHINE -> ModRecipes.WELDING;
            case GAMMA_IRRADIATOR -> ModRecipes.GAMMA;
            case SHEARING_MACHINE -> ModRecipes.SHEARING;
            case WARHEAD_ASSEMBLY -> ModRecipes.WARHEAD_ASSEMBLY;
        };
    }
}
