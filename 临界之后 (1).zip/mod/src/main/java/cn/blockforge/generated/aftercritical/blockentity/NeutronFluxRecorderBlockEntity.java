package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.menu.NeutronFluxRecorderMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 中子通量记录仪的方块实体：盯着「最近的那台反应堆控制器」，把 k_eff 和通量抄过来。
 *
 * <p>为什么是「抄」而不是「控制器推」：记录仪可以摆在反应堆外头看着方便，
 * 让控制器每 tick 找一遍所有记录仪反而更贵。这里只在第一次用的找一次控制器（24 格内最近的），
 * 之后每 tick 只问那一台；那台要是被拆了，过 5 秒再重新找一次。
 */
public class NeutronFluxRecorderBlockEntity extends BlockEntity
        implements MenuProvider, TickableBlockEntity {

    /** 找控制器的半径（格）。 */
    public static final int LINK_RADIUS = 24;
    /** 没连上的时候多久重试一次（tick）。找一次要扫一大片方块，所以别太勤。 */
    private static final int RELINK_INTERVAL = 400;

    @Nullable
    private BlockPos linkedPos;

    private boolean linked;
    private int kScaled;
    private int flux;
    private int status;
    private boolean criticalKind;
    private int retryTimer;

    public NeutronFluxRecorderBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.NEUTRON_FLUX_RECORDER.get(), pos, state);
    }

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        ReactorControllerBlockEntity controller = controller();
        if (controller == null) {
            this.linked = false;
            this.kScaled = 0;
            this.flux = 0;
            this.status = ReactorControllerBlockEntity.STATUS_IDLE;
            if (++this.retryTimer >= RELINK_INTERVAL) {
                this.retryTimer = 0;
                relink();
            }
            return;
        }
        this.linked = true;
        this.kScaled = controller.kEffScaled();
        this.flux = controller.fluxInt();
        this.status = controller.statusCode();
        this.criticalKind = controller.kind() == ReactorKind.CRITICAL;
    }

    /** 立刻找一个最近的反应堆控制器（右键打开界面前会调一次）。 */
    public void relink() {
        if (!(this.level instanceof net.minecraft.server.level.ServerLevel server)) {
            return;
        }
        ReactorControllerBlockEntity best = null;
        double bestDistance = Double.MAX_VALUE;
        BlockPos min = this.worldPosition.offset(-LINK_RADIUS, -LINK_RADIUS / 2, -LINK_RADIUS);
        BlockPos max = this.worldPosition.offset(LINK_RADIUS, LINK_RADIUS / 2, LINK_RADIUS);
        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            if (server.getBlockEntity(pos) instanceof ReactorControllerBlockEntity controller) {
                double distance = pos.distSqr(this.worldPosition);
                if (distance < bestDistance) {
                    bestDistance = distance;
                    best = controller;
                }
            }
        }
        this.linkedPos = best == null ? null : best.getBlockPos().immutable();
        setChanged();
    }

    @Nullable
    private ReactorControllerBlockEntity controller() {
        if (this.level == null || this.linkedPos == null) {
            return null;
        }
        if (this.level.getBlockEntity(this.linkedPos) instanceof ReactorControllerBlockEntity controller) {
            return controller;
        }
        this.linkedPos = null;
        return null;
    }

    public boolean isLinked() {
        return this.linked;
    }

    public int kScaled() {
        return this.kScaled;
    }

    public int flux() {
        return this.flux;
    }

    public int status() {
        return this.status;
    }

    public boolean isCriticalKind() {
        return this.criticalKind;
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new NeutronFluxRecorderMenu(containerId, playerInventory, this);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.neutron_flux_recorder");
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (this.linkedPos != null) {
            tag.putLong("Linked", this.linkedPos.asLong());
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.linkedPos = tag.contains("Linked") ? BlockPos.of(tag.getLong("Linked")) : null;
        this.retryTimer = RELINK_INTERVAL - 1;
    }

    @Override
    public void setLevel(Level level) {
        super.setLevel(level);
        if (!level.isClientSide) {
            this.retryTimer = RELINK_INTERVAL - 1;
        }
    }
}
