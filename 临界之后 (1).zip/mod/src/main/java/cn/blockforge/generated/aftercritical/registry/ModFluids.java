package cn.blockforge.generated.aftercritical.registry;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.fluid.ModFluidType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.neoforged.neoforge.fluids.BaseFlowingFluid;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * 模组自己注册的一批流体。
 *
 * <p>前 7 种是阶段 0 的：氢、氧、氮、氯、钠、氨、硫酸；
 * 后面是阶段 1、2 的化工流体，以及阶段 5 的蒸汽、乏蒸汽、重水。
 *
 * <p>每种流体在游戏里其实是三样东西：
 * <ul>
 *   <li>{@code FluidType}：流体的「性格」——中文名、颜色、密度、粘度，界面和提示靠它显示；</li>
 *   <li>{@code Fluid}：静止 + 流动两份本体，机器、管道、储罐的 {@code IFluidHandler} 读写它；</li>
 *   <li>{@code LiquidBlock}：能放进世界的那一方块流体（用通用流体罐倒出来才看得到）。</li>
 * </ul>
 *
 * <p>水不在这里——原版的 {@code minecraft:water} 直接用，不用重复注册。
 */
public final class ModFluids {

    /** 一桶 / 一个通用流体罐装多少 mB。 */
    public static final int BUCKET_VOLUME = 1000;

    /** 流体类型的注册表。 */
    public static final DeferredRegister<FluidType> FLUID_TYPES =
            DeferredRegister.create(NeoForgeRegistries.Keys.FLUID_TYPES, AfterCritical.MOD_ID);

    /** 流体本体的注册表。 */
    public static final DeferredRegister<Fluid> FLUIDS =
            DeferredRegister.create(Registries.FLUID, AfterCritical.MOD_ID);

    // ------------------------------------------------------------------
    // 阶段 0 的 7 种
    // ------------------------------------------------------------------

    /** 氢：电解水得到，比空气轻。 */
    public static final FluidSet HYDROGEN = new FluidSet("hydrogen", 0x86C7FF, -100, 200,
            () -> ModBlocks.HYDROGEN_FLUID.get());
    /** 氧：电解水、空气分离器都能得到。 */
    public static final FluidSet OXYGEN = new FluidSet("oxygen", 0x9BE8FF, 100, 400,
            () -> ModBlocks.OXYGEN_FLUID.get());
    /** 氮：空气分离器从空气里分离出来。 */
    public static final FluidSet NITROGEN = new FluidSet("nitrogen", 0xB8B8D8, 80, 350,
            () -> ModBlocks.NITROGEN_FLUID.get());
    /** 氯气：电解海带水溶液得到。 */
    public static final FluidSet CHLORINE = new FluidSet("chlorine", 0xC6E04A, 250, 300,
            () -> ModBlocks.CHLORINE_FLUID.get());
    /** 钠：电解海带水溶液得到（按液态金属处理，又稠又重）。 */
    public static final FluidSet SODIUM = new FluidSet("sodium", 0xE0B060, 2500, 2500,
            () -> ModBlocks.SODIUM_FLUID.get());
    /** 氨：氮和氢在化工厂里合成。 */
    public static final FluidSet AMMONIA = new FluidSet("ammonia", 0x7FE0C0, -300, 250,
            () -> ModBlocks.AMMONIA_FLUID.get());
    /** 硫酸：火药和水在化工厂里反应得到，装配机做电池要用。 */
    public static final FluidSet SULFURIC_ACID = new FluidSet("sulfuric_acid", 0xD9A51F, 1800, 1500,
            () -> ModBlocks.SULFURIC_ACID_FLUID.get());

    // ------------------------------------------------------------------
    // 阶段 1 的 9 种（第 1 步先只注册，配方留给第 3 步）
    // ------------------------------------------------------------------

    /** 铀酰溶液：黄绿色，浸出槽里用硫酸泡铀矿粉的产物。 */
    public static final FluidSet URANYL_SOLUTION = new FluidSet("uranyl_solution", 0x9BC24A, 1200, 1200,
            () -> ModBlocks.URANYL_SOLUTION_FLUID.get());
    /** 硝酸铀酰：淡黄色，铀酰溶液加硝酸得到。 */
    public static final FluidSet URANYL_NITRATE = new FluidSet("uranyl_nitrate", 0xE8D98A, 1250, 1100,
            () -> ModBlocks.URANYL_NITRATE_FLUID.get());
    /** 氢氟酸：无色偏淡绿，剧毒（本轮不做伤害）。 */
    public static final FluidSet HYDROFLUORIC_ACID = new FluidSet("hydrofluoric_acid", 0xDFF5E8, 1150, 900,
            () -> ModBlocks.HYDROFLUORIC_ACID_FLUID.get());
    /** 氟气：淡黄绿色气体，比空气重。 */
    public static final FluidSet FLUORINE = new FluidSet("fluorine", 0xD8EE7A, 200, 250,
            () -> ModBlocks.FLUORINE_FLUID.get());
    /** 硼酸：白色，很稠。 */
    public static final FluidSet BORIC_ACID = new FluidSet("boric_acid", 0xF0F0F0, 1300, 1800,
            () -> ModBlocks.BORIC_ACID_FLUID.get());
    /** 粘合剂：淡棕色，又黏又稠。 */
    public static final FluidSet ADHESIVE = new FluidSet("adhesive", 0xC9925A, 1400, 2600,
            () -> ModBlocks.ADHESIVE_FLUID.get());
    /** 过氧化氢：淡蓝色，强氧化剂。 */
    public static final FluidSet HYDROGEN_PEROXIDE = new FluidSet("hydrogen_peroxide", 0xBFE6F5, 1450, 700,
            () -> ModBlocks.HYDROGEN_PEROXIDE_FLUID.get());
    /** 硝酸：淡黄色。 */
    public static final FluidSet NITRIC_ACID = new FluidSet("nitric_acid", 0xE9D96B, 1500, 800,
            () -> ModBlocks.NITRIC_ACID_FLUID.get());
    /** 氮氧化物：棕红色气体（本轮不做伤害效果）。 */
    public static final FluidSet NITROGEN_OXIDE = new FluidSet("nitrogen_oxide", 0x9A3B22, 300, 200,
            () -> ModBlocks.NITROGEN_OXIDE_FLUID.get());

    // ------------------------------------------------------------------
    // 阶段 1 工艺里另外两种流体（黄饼路线要用）
    // ------------------------------------------------------------------

    /** 废液：沉淀槽里析出黄饼之后剩下来的废酸液，目前只能装罐存着。 */
    public static final FluidSet WASTE_LIQUID = new FluidSet("waste_liquid", 0x6B6250, 1400, 1400,
            () -> ModBlocks.WASTE_LIQUID_FLUID.get());

    /** 六氟化铀（UF₆）：氟化反应器产出的气体，阶段 2 的气体离心机要靠它浓缩。 */
    public static final FluidSet URANIUM_HEXAFLUORIDE = new FluidSet("uranium_hexafluoride", 0xE6E2A8, 400, 300,
            () -> ModBlocks.URANIUM_HEXAFLUORIDE_FLUID.get());

    // ------------------------------------------------------------------
    // 阶段 2 离心机分出来的两种六氟化铀
    // ------------------------------------------------------------------

    /**
     * 低浓缩六氟化铀：离心机甩出来的「轻的那一半」，铀-235 比例更高。
     *
     * <p>颜色比天然六氟化铀更偏金黄，水解之后就变成 LEU 二氧化铀粉。
     */
    public static final FluidSet LEU_URANIUM_HEXAFLUORIDE = new FluidSet("leu_uranium_hexafluoride", 0xE8C34A,
            420, 300, () -> ModBlocks.LEU_URANIUM_HEXAFLUORIDE_FLUID.get());

    /**
     * 贫化六氟化铀：离心机留下来的「重的那一半」，铀-235 少得可怜。
     *
     * <p>颜色发灰绿，跟低浓缩的一对比就能分清哪根管子里走的是哪一路。
     */
    public static final FluidSet DEPLETED_URANIUM_HEXAFLUORIDE = new FluidSet(
            "depleted_uranium_hexafluoride", 0x8E9B84, 430, 320,
            () -> ModBlocks.DEPLETED_URANIUM_HEXAFLUORIDE_FLUID.get());

    // ------------------------------------------------------------------
    // 阶段 5：压水堆的一回路 / 二回路（简化：水 → 蒸汽 → 乏蒸汽 → 水）
    // ------------------------------------------------------------------

    /**
     * 蒸汽：压水堆里水被烧开之后出来的白色气体，推着汽轮发电机转。
     *
     * <p>密度比空气小，会往上飘；颜色给得很白，和灰色的乏蒸汽一眼能分开。
     */
    public static final FluidSet STEAM = new FluidSet("steam", 0xF2F6FA, -200, 150,
            () -> ModBlocks.STEAM_FLUID.get());

    /**
     * 乏蒸汽：在汽轮发电机里做完功、温度和压力都掉下来的淡灰色蒸汽。
     *
     * <p>要送进冷凝器换回水，才能再泵回反应堆，闭环就靠它。
     */
    public static final FluidSet EXHAUST_STEAM = new FluidSet("exhaust_steam", 0xC9CED4, -100, 250,
            () -> ModBlocks.EXHAUST_STEAM_FLUID.get());

    /**
     * 重水：压水堆的理想慢化剂和冷却剂，深蓝色。
     *
     * <p>本轮配方里先可以直接用普通水顶替，但流体本身先注册好，
     * 以后要做重水提纯、重水堆随时能接上。
     */
    public static final FluidSet HEAVY_WATER = new FluidSet("heavy_water", 0x1E3F8F, 1100, 1000,
            () -> ModBlocks.HEAVY_WATER_FLUID.get());

    // ------------------------------------------------------------------
    // 阶段 6：乏燃料后处理的四种流体
    // ------------------------------------------------------------------

    /**
     * 乏燃料溶解液：深绿色，剪切机剪碎的乏燃料用硝酸泡开之后的「汤」。
     *
     * <p>里面同时有没烧完的铀、新生成的钚，以及一大堆裂变产物，
     * 后面的萃取柱就是靠 TBP 把铀钚从这锅汤里「捞」出来。
     */
    public static final FluidSet DISSOLVED_FUEL = new FluidSet("dissolved_fuel", 0x1F5C2E, 1600, 1400,
            () -> ModBlocks.DISSOLVED_FUEL_FLUID.get());

    /**
     * 铀钚萃取液：荧光绿，TBP 从溶解液里萃出来的铀 + 钚混合物。
     *
     * <p>进离心萃取器之后就被拆成钚239、回收铀两样固体。
     */
    public static final FluidSet URANIUM_PLUTONIUM_EXTRACT = new FluidSet(
            "uranium_plutonium_extract", 0x9DFF3C, 1500, 1200,
            () -> ModBlocks.URANIUM_PLUTONIUM_EXTRACT_FLUID.get());

    /**
     * 裂变产物废液：深棕色，萃完铀钚之后剩下的那锅「高放废液」。
     *
     * <p>里面是锶、铯、锕系这些裂变产物，最后要送进玻璃固化炉封进玻璃里。
     */
    public static final FluidSet FISSION_PRODUCT_WASTE = new FluidSet(
            "fission_product_waste", 0x3A2313, 1700, 2200,
            () -> ModBlocks.FISSION_PRODUCT_WASTE_FLUID.get());

    /**
     * 有机相（TBP）：淡黄色，萃取柱里「捞」铀钚用的萃取剂。
     *
     * <p>它是循环使用的：萃取柱每走一遍吃掉 500 mB，所以得一直补。
     */
    public static final FluidSet TBP_ORGANIC_PHASE = new FluidSet("tbp_organic_phase", 0xE8D68A, 900, 700,
            () -> ModBlocks.TBP_ORGANIC_PHASE_FLUID.get());

    // ------------------------------------------------------------------
    // 阶段 7：聚变燃料（氘）
    // ------------------------------------------------------------------

    /**
     * 氘：氢的重同位素，电解水时顺带分离出来的一点点「重水里的氢」。
     *
     * <p>1,000 mB 水里只出 20 mB 氘，所以聚变燃料要攒：先拿它灌成【氘单元】，
     * 再和【氚单元】在装配机里拼成氘氚燃料单元，托卡马克才点得着火。
     *
     * <p>颜色给成很淡的蓝白，和氢（浅蓝）、氚（游戏里是物品）一眼能分开。
     */
    public static final FluidSet DEUTERIUM = new FluidSet("deuterium", 0xBFE9FF, -60, 140,
            () -> ModBlocks.DEUTERIUM_FLUID.get());

    // ------------------------------------------------------------------
    // 核爆废土：核废水 / 核熔废水
    // ------------------------------------------------------------------

    /**
     * 核废水：核爆把湖、河、水池里的水「照脏」之后剩下的东西。
     *
     * <p>灰黑色，流动性和水一模一样（能流 4 格、每格掉一层），所以炸完的水面
     * 不会再是干干净净的蓝色。半透明，跟水一样能看见底下的方块。
     *
     * <p>泡在里面就一直吃辐射，穿齐四件辐射防护服则完全免疫。
     */
    public static final FluidSet NUCLEAR_WASTEWATER = new FluidSet("nuclear_wastewater", 0x23282B,
            1000, 1000, () -> ModBlocks.NUCLEAR_WASTEWATER_FLUID.get(), 0xC0, false);

    /**
     * 核熔废水：核爆把岩浆「掺脏」之后剩下的东西——深绿色，比岩浆还稠。
     *
     * <p>流动距离、流速、粘稠度全部照岩浆来（只流 2 格、每格掉两层、30 tick 才走一步），
     * 泡在里面除了被灼烧，还会持续吃辐射。本身发光，坑底能照出一片绿光。
     */
    public static final FluidSet NUCLEAR_MOLTEN_WASTE = new FluidSet("nuclear_molten_waste", 0x1E4A1C,
            3000, 6000, () -> ModBlocks.NUCLEAR_MOLTEN_WASTE_FLUID.get(), 0xFF, true);

    /**
     * 全部流体，方便统一遍历。
     *
     * <p>必须等上面的字段都建好之后再拼成数组（静态初始化是按书写顺序跑的），
     * 所以它写在流体字段的后面、颜色表的前面。
     */
    private static final FluidSet[] ALL_FLUIDS = {HYDROGEN, OXYGEN, NITROGEN, CHLORINE, SODIUM, AMMONIA,
            SULFURIC_ACID, URANYL_SOLUTION, URANYL_NITRATE, HYDROFLUORIC_ACID, FLUORINE, BORIC_ACID, ADHESIVE,
            HYDROGEN_PEROXIDE, NITRIC_ACID, NITROGEN_OXIDE, WASTE_LIQUID, URANIUM_HEXAFLUORIDE,
            LEU_URANIUM_HEXAFLUORIDE, DEPLETED_URANIUM_HEXAFLUORIDE, STEAM, EXHAUST_STEAM, HEAVY_WATER,
            DISSOLVED_FUEL, URANIUM_PLUTONIUM_EXTRACT, FISSION_PRODUCT_WASTE, TBP_ORGANIC_PHASE, DEUTERIUM,
            NUCLEAR_WASTEWATER, NUCLEAR_MOLTEN_WASTE};

    /** 本模组注册的全部流体（创造模式物品栏、界面列举用）。 */
    public static FluidSet[] allFluids() {
        return ALL_FLUIDS.clone();
    }

    /** 界面里画流体的颜色；按注册名（去掉 flowing_ 前缀 / _flowing 后缀）查。 */
    private static final Map<String, Integer> COLORS = new HashMap<>();

    /** 找不到颜色时用的灰。 */
    private static final int DEFAULT_COLOR = 0xFF8A8A8A;

    static {
        COLORS.put("water", 0xFF3F76E4);
        COLORS.put("lava", 0xFFFF8A1F);
        for (FluidSet set : ALL_FLUIDS) {
            COLORS.put(set.name, set.color);
        }
    }

    /**
     * 一种流体登记出来的全套东西。
     *
     * <p>方块和桶用 {@link Supplier} 传进来，是为了避开「流体要用方块，方块又要用流体」
     * 这种静态初始化的死循环——真正去取的时候两边都已经初始化完了。
     */
    public static final class FluidSet {

        /** 注册名（不带命名空间）。 */
        public final String name;
        /** 界面、贴图里用的颜色（ARGB，不透明）。 */
        public final int color;
        /** 流体的「性格」。 */
        public final DeferredHolder<FluidType, FluidType> type;
        /** 静止的那份流体，配方、储罐、单元里用的就是它。 */
        public final DeferredHolder<Fluid, BaseFlowingFluid.Source> source;
        /** 流动的那份流体，只在方块世界里用得着。 */
        public final DeferredHolder<Fluid, BaseFlowingFluid.Flowing> flowing;

        private FluidSet(String name, int rgb, int density, int viscosity,
                         Supplier<LiquidBlock> fluidBlock) {
            this(name, rgb, density, viscosity, fluidBlock, 0xFF, false);
        }

        /**
         * 带透明度和「稠不稠」的构造器。
         *
         * @param alpha 液体在世界里画出来的不透明度（0xFF = 完全不透明，跟其它流体一样；
         *              0xC0 左右就是半透明，跟水一个观感）
         * @param thick {@code true} 表示按岩浆那套来：只流 2 格、每格掉两层、30 tick 走一步
         */
        private FluidSet(String name, int rgb, int density, int viscosity,
                         Supplier<LiquidBlock> fluidBlock, int alpha, boolean thick) {
            this.name = name;
            this.color = 0xFF000000 | (rgb & 0xFFFFFF);
            // 世界里画的时候用带透明度的颜色；界面上的色块仍然用不透明的 color
            int tint = ((alpha & 0xFF) << 24) | (rgb & 0xFFFFFF);

            this.type = FLUID_TYPES.register(name, () -> new ModFluidType(FluidType.Properties.create()
                    .descriptionId("fluid.aftercritical." + name)
                    .density(density)
                    .viscosity(viscosity)
                    .canDrown(false)
                    .canSwim(false)
                    .canPushEntity(false)
                    .canExtinguish(false)
                    .supportsBoating(false), tint));

            BaseFlowingFluid.Properties properties = new BaseFlowingFluid.Properties(
                    this.type::get, this::sourceFluid, this::flowingFluid)
                    .block(fluidBlock)
                    .slopeFindDistance(thick ? 2 : 4)
                    .levelDecreasePerBlock(thick ? 2 : 1)
                    .explosionResistance(100.0F)
                    .tickRate(thick ? 30 : 10);

            this.source = FLUIDS.register(name, () -> new BaseFlowingFluid.Source(properties));
            this.flowing = FLUIDS.register(name + "_flowing", () -> new BaseFlowingFluid.Flowing(properties));
        }

        private Fluid sourceFluid() {
            return this.source.get();
        }

        private Fluid flowingFluid() {
            return this.flowing.get();
        }

        /** 一份这个流体（静止的那份）。 */
        public FluidStack stack(int amount) {
            return new FluidStack(this.source.get(), amount);
        }
    }

    private ModFluids() {}

    /** 界面里画这个流体的颜色（ARGB）。 */
    public static int colorOf(int fluidId) {
        Fluid fluid = BuiltInRegistries.FLUID.byId(fluidId);
        if (fluid == null) {
            return DEFAULT_COLOR;
        }
        ResourceLocation id = BuiltInRegistries.FLUID.getKey(fluid);
        if (id == null) {
            return DEFAULT_COLOR;
        }
        return COLORS.getOrDefault(shortName(id), DEFAULT_COLOR);
    }

    /** 某个流体本身的颜色（ARGB）；不认识的流体返回默认灰。 */
    public static int colorOf(Fluid fluid) {
        return colorOf(BuiltInRegistries.FLUID.getId(fluid));
    }

    /** 把 {@code flowing_water} / {@code hydrogen_flowing} 还原成 {@code water} / {@code hydrogen}。 */
    private static String shortName(ResourceLocation id) {
        String path = id.getPath();
        if (path.startsWith("flowing_")) {
            path = path.substring("flowing_".length());
        }
        if (path.endsWith("_flowing")) {
            path = path.substring(0, path.length() - "_flowing".length());
        }
        return path;
    }

    /**
     * 界面上显示的名字。
     *
     * <p>故意不查 {@code FluidType}：原版水的 FluidType 是在客户端渲染时才准备齐的，
     * 这里只用注册名拼语言键，服务端和客户端都稳。
     */
    public static Component displayName(int fluidId) {
        Fluid fluid = BuiltInRegistries.FLUID.byId(fluidId);
        if (fluid == null) {
            return Component.translatable("gui.aftercritical.fluid.unknown");
        }
        ResourceLocation id = BuiltInRegistries.FLUID.getKey(fluid);
        if (id == null) {
            return Component.translatable("gui.aftercritical.fluid.unknown");
        }
        String name = shortName(id);
        if (id.getNamespace().equals(AfterCritical.MOD_ID)) {
            return Component.translatable("fluid." + id.getNamespace() + "." + name);
        }
        return Component.translatable("block." + id.getNamespace() + "." + name);
    }

    // ------------------------------------------------------------------
    // 智能流体管道用的「流体编号」
    // ------------------------------------------------------------------

    /** 管道没盖章。 */
    public static final int DUCT_INDEX_NONE = 0;
    /** 盖的是水。 */
    public static final int DUCT_INDEX_WATER = ALL_FLUIDS.length + 1;
    /** 盖的是岩浆。 */
    public static final int DUCT_INDEX_LAVA = ALL_FLUIDS.length + 2;
    /** 管道盖的是「别的模组的流体」，颜色得问方块实体。 */
    public static final int DUCT_INDEX_OTHER = 63;
    /**
     * 方块状态里这个属性的上限（0..63）。
     *
     * <p>以前是 31：30 种流体 + 水 + 岩浆 + 「别的流体」正好顶到天花板，
     * 再加两种核废水就整整齐齐地越界了（岩浆的编号会变成 32，写进方块状态直接崩）。
     * 扩到 63 之后还剩三十来个空位，以后再加流体不用再动这里。
     */
    public static final int DUCT_INDEX_MAX = 63;

    /**
     * 这种流体在管道方块状态里是几号。
     *
     * <p>方块状态只能存数字（存不了流体本身），所以这里给每种流体编个号：
     * 0 = 没盖章，1 开始是本模组注册的流体，紧接着是水、岩浆，31 = 别的流体。
     * 编号跟着 {@link #ALL_FLUIDS} 的长度自动排，加新流体不用回来改。
     *
     * <p>编号放进方块状态有个好处：盖章时方块状态变了，客户端就会把这一格重画一遍，
     * 管道颜色立刻跟着变（方块颜色是在烘焙模型时算进去的，不换状态就不重画）。
     */
    public static int ductIndexOf(@Nullable Fluid fluid) {
        if (fluid == null) {
            return DUCT_INDEX_NONE;
        }
        for (int i = 0; i < ALL_FLUIDS.length; i++) {
            if (fluid.isSame(ALL_FLUIDS[i].source.get())) {
                return i + 1;
            }
        }
        if (fluid.isSame(Fluids.WATER)) {
            return DUCT_INDEX_WATER;
        }
        if (fluid.isSame(Fluids.LAVA)) {
            return DUCT_INDEX_LAVA;
        }
        return DUCT_INDEX_OTHER;
    }

    /** 管道编号对应的颜色（ARGB）；没盖章、「别的流体」这两个编号没有固定颜色，返回 -1。 */
    public static int ductIndexColor(int index) {
        if (index >= 1 && index <= ALL_FLUIDS.length) {
            return ALL_FLUIDS[index - 1].color;
        }
        if (index == DUCT_INDEX_WATER) {
            return 0xFF3F76E4;
        }
        if (index == DUCT_INDEX_LAVA) {
            return 0xFFFF8A1F;
        }
        return -1;
    }
}
