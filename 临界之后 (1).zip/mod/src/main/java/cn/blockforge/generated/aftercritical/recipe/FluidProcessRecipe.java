package cn.blockforge.generated.aftercritical.recipe;

import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.fluids.FluidStack;

import java.util.List;

/**
 * 流体机器的配方：物品进、流体进，物品出、流体出。
 *
 * <p>三台机器（电解槽、化工厂、空气分离器）共用这一种格式，配方写在
 * {@code data/aftercritical/recipe/electrolysis|chemical_plant|air_separation/} 下，例如：
 * <pre>{@code
 * {
 *   "type": "aftercritical:electrolysis",
 *   "item_inputs": [{"ingredient": {"item": "minecraft:kelp"}, "count": 8}],
 *   "fluid_inputs": [{"fluid": "minecraft:water", "amount": 1000}],
 *   "fluid_outputs": [
 *     {"fluid": "aftercritical:sodium", "amount": 500},
 *     {"fluid": "aftercritical:chlorine", "amount": 500}
 *   ],
 *   "time": 300,
 *   "energy": 40
 * }
 * }</pre>
 *
 * <p>四种列表都可以留空。{@code time} 是总 tick 数（20 tick = 1 秒），
 * {@code energy} 是每 tick 吃多少 FE。
 *
 * <p>还有一个可选的 {@code catalyst}（催化剂）：
 * <pre>{@code
 * "catalyst": {"ingredient": {"item": "aftercritical:palladium_alloy_membrane"}, "count": 1}
 * }</pre>
 * 它只要求「机器里有这件东西」，加工完不会被扣掉。电解槽靠它把两条水配方分开。
 */
public final class FluidProcessRecipe implements Recipe<FluidProcessInput> {

    private final List<AssemblerIngredient> itemInputs;
    private final List<FluidAmount> fluidInputs;
    private final List<ItemStack> itemOutputs;
    private final List<FluidAmount> fluidOutputs;
    /**
     * 催化剂（可选）：配方成立必须「在槽里」，但加工完<b>不消耗</b>。
     *
     * <p>这是给电解槽分产线用的：水 → 氢 + 氧 和 水 → 氘 + 氢 + 氧 原料完全一样，
     * 光看原料永远只会选中其中一条。现在氘那条要「槽里放着钯合金膜」才算数，
     * 于是「放膜出氘、不放膜只出氢氧」，两条配方彻底分开。
     *
     * <p>数据包写法：{@code "catalyst": {"ingredient": {"item": "..."}, "count": 1}}。
     */
    private final java.util.Optional<AssemblerIngredient> catalyst;
    private final int duration;
    private final int energyPerTick;
    private final FluidProcessRecipeSerializer serializer;

    public FluidProcessRecipe(List<AssemblerIngredient> itemInputs, List<FluidAmount> fluidInputs,
                              List<ItemStack> itemOutputs, List<FluidAmount> fluidOutputs,
                              int duration, int energyPerTick, FluidProcessRecipeSerializer serializer) {
        this(itemInputs, fluidInputs, itemOutputs, fluidOutputs, java.util.Optional.empty(),
                duration, energyPerTick, serializer);
    }

    public FluidProcessRecipe(List<AssemblerIngredient> itemInputs, List<FluidAmount> fluidInputs,
                              List<ItemStack> itemOutputs, List<FluidAmount> fluidOutputs,
                              java.util.Optional<AssemblerIngredient> catalyst,
                              int duration, int energyPerTick, FluidProcessRecipeSerializer serializer) {
        this.itemInputs = List.copyOf(itemInputs);
        this.fluidInputs = List.copyOf(fluidInputs);
        this.itemOutputs = List.copyOf(itemOutputs);
        this.fluidOutputs = List.copyOf(fluidOutputs);
        this.catalyst = catalyst == null ? java.util.Optional.empty() : catalyst;
        this.duration = Math.max(1, duration);
        this.energyPerTick = Math.max(1, energyPerTick);
        this.serializer = serializer;
    }

    /**
     * 机器里的东西能不能凑齐这条配方。
     *
     * <p>物品：一种一种地找槽位，一个槽只能用一次（和装配机同一套算法）。
     * 流体：一种一种地找输入罐，罐里得是同一种流体、量也够。
     * 催化剂：只要某个物品槽里有它就通过，不占「原料槽」。
     */
    @Override
    public boolean matches(FluidProcessInput input, Level level) {
        return matchesItems(input) && matchesCatalyst(input) && matchesFluids(input);
    }

    /** 催化剂在不在这台机器里（没有要求催化剂时永远为 true）。 */
    public boolean matchesCatalyst(FluidProcessInput input) {
        if (this.catalyst.isEmpty()) {
            return true;
        }
        AssemblerIngredient spec = this.catalyst.get();
        for (int i = 0; i < input.size(); i++) {
            if (spec.test(input.getItem(i))) {
                return true;
            }
        }
        return false;
    }

    /** 只看物品够不够（界面用它区分「缺原料」和「缺流体」）。 */
    public boolean matchesItems(FluidProcessInput input) {
        boolean[] used = new boolean[input.size()];
        for (AssemblerIngredient spec : this.itemInputs) {
            boolean found = false;
            for (int i = 0; i < input.size(); i++) {
                if (used[i]) {
                    continue;
                }
                if (spec.test(input.getItem(i))) {
                    used[i] = true;
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return true;
    }

    /** 只看流体够不够。 */
    public boolean matchesFluids(FluidProcessInput input) {
        for (FluidAmount spec : this.fluidInputs) {
            boolean found = false;
            for (FluidStack stack : input.fluids()) {
                if (spec.test(stack)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack assemble(FluidProcessInput input, HolderLookup.Provider registries) {
        return this.itemOutputs.isEmpty() ? ItemStack.EMPTY : this.itemOutputs.get(0).copy();
    }

    @Override
    public ItemStack getResultItem(HolderLookup.Provider registries) {
        return this.itemOutputs.isEmpty() ? ItemStack.EMPTY : this.itemOutputs.get(0).copy();
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return true;
    }

    @Override
    public boolean isSpecial() {
        return true;
    }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        NonNullList<Ingredient> list = NonNullList.create();
        for (AssemblerIngredient spec : this.itemInputs) {
            list.add(spec.ingredient());
        }
        return list;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return this.serializer;
    }

    @Override
    public RecipeType<?> getType() {
        return this.serializer.type();
    }

    /** 要吃的物品（可以一条都没有）。 */
    public List<AssemblerIngredient> itemInputs() {
        return this.itemInputs;
    }

    /** 要吃的流体（可以一条都没有，比如空气分离器）。 */
    public List<FluidAmount> fluidInputs() {
        return this.fluidInputs;
    }

    /** 催化剂（不消耗）；大多数配方没有。 */
    public java.util.Optional<AssemblerIngredient> catalyst() {
        return this.catalyst;
    }

    /** 产出物品（最多一条，多余的会被忽略）。 */
    public List<ItemStack> itemOutputs() {
        return this.itemOutputs;
    }

    /** 产出流体。 */
    public List<FluidAmount> fluidOutputs() {
        return this.fluidOutputs;
    }

    /** 加工时长，单位 tick。 */
    public int duration() {
        return this.duration;
    }

    /** 每 tick 吃多少 FE。 */
    public int energyPerTick() {
        return this.energyPerTick;
    }
}
