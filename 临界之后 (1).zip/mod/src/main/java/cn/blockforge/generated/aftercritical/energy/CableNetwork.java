package cn.blockforge.generated.aftercritical.energy;

import cn.blockforge.generated.aftercritical.blockentity.CableBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 一整张「连在一起的线缆」当成一张电网来结算。
 *
 * <p>以前的线缆是各干各的：每根线缆每 tick 把缓存里的电推给邻居，
 * 再记住「刚从哪一面收的」，推的时候绕开那一面，电就一格一格往下接力。
 * 直着连没问题，但玩家一旦把线缆接成<b>闭环</b>，每根线缆前面永远有下一根，
 * 电就在圈里无限转圈：数字一直乱跳，接在圈上的机器也拿不稳电。
 * 而且一 tick 里能顺着方块更新的先后顺序跑过好几格，走几格全看运气。
 *
 * <p>现在的做法（方案 A：整网结算）：
 * <ol>
 *   <li>从任意一根线缆出发，把<b>六向相连</b>的线缆全找出来，凑成一张网；</li>
 *   <li>一张网一 tick <b>只算一次</b>（第一根轮到的线缆负责算，其它线缆这一 tick 直接跳过）；</li>
 *   <li>整网的缓存先合并成一个池子，从贴着的发电机 / 电池抽电，再推给贴着的机器，
 *       最后把剩下的电按容量比例分回每根线缆；</li>
 *   <li>于是闭环只是「同一批线缆多接了一条边」，环里的电不会再绕圈，
 *       数字稳定，机器该拿多少拿多少。</li>
 * </ol>
 *
 * <p>每 tick 的进出总量还是按线缆等级算：整网每 tick 最多抽 {@code 线缆数 × 每根上限}、
 * 最多送 {@code 线缆数 × 每根上限}，和以前一串线缆的总吞吐一致。
 * 过载烧线缆的判断留在每根线缆的接口里（机器抽得太狠就烧那一根）。
 */
public final class CableNetwork {

    /** 每个维度「这一 tick 已经算过哪些线缆」，避免一张网被算很多遍。 */
    private static final class TickState {
        private long tick = Long.MIN_VALUE;
        private final Set<Long> processed = new HashSet<>();
    }

    private static final Map<ResourceKey<Level>, TickState> STATES = new HashMap<>();

    private CableNetwork() {}

    /**
     * 这根线缆轮到自己更新时调用：如果它所在的网这一 tick 还没算过，就由它来把整网算一遍。
     */
    public static void tick(CableBlockEntity origin) {
        if (!(origin.getLevel() instanceof ServerLevel level)) {
            return;
        }
        long now = level.getGameTime();
        TickState state = STATES.computeIfAbsent(level.dimension(), key -> new TickState());
        if (state.tick != now) {
            state.tick = now;
            state.processed.clear();
        }
        if (!state.processed.add(origin.getBlockPos().asLong())) {
            // 同一张网的另一根线缆这一 tick 已经算过了
            return;
        }
        List<CableBlockEntity> members = collect(origin, level, state);
        if (members.isEmpty()) {
            return;
        }
        solve(level, members);
    }

    /** 从 {@code origin} 出发找出整张网（六向相连的线缆），顺便把它们记成「这一 tick 算过了」。 */
    private static List<CableBlockEntity> collect(CableBlockEntity origin, ServerLevel level, TickState state) {
        List<CableBlockEntity> members = new ArrayList<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        queue.add(origin.getBlockPos());
        while (!queue.isEmpty()) {
            BlockPos pos = queue.poll();
            if (!(level.getBlockEntity(pos) instanceof CableBlockEntity cable) || cable.isBurnt()) {
                continue;
            }
            members.add(cable);
            for (Direction side : Direction.values()) {
                BlockPos next = pos.relative(side);
                if (level.getBlockEntity(next) instanceof CableBlockEntity
                        && state.processed.add(next.asLong())) {
                    queue.add(next);
                }
            }
        }
        return members;
    }

    /** 端口角色：既不收也不放的方块，忽略。 */
    private static final int PORT_NONE = 0;
    /** 端口角色：只能往外送电（发电机）。 */
    private static final int PORT_SOURCE = 1;
    /** 端口角色：只能收电（机器、嬗变器这类）。 */
    private static final int PORT_MACHINE = 2;
    /** 端口角色：既能充又能放（电池、能量端口这类）。 */
    private static final int PORT_BATTERY = 3;

    /**
     * 判断一个 FE 接口在线缆网里扮演什么角色。
     *
     * <p>本模组自己的缓存（{@link BufferedEnergyStorage}）用<b>配置值</b>判断，
     * 不看当前电量：电池充满了 {@code canReceive()} 会变成 false，
     * 只看动态值的话满电池会被当成「纯发电机」继续被线缆抽电，玩家看到的就是电池自己漏电。
     * 别的模组的接口没有配置值可读，才退回动态的 {@code canExtract} / {@code canReceive}。
     */
    private static int classify(IEnergyStorage storage) {
        boolean canOutput;
        boolean canInput;
        if (storage instanceof BufferedEnergyStorage buffered) {
            canOutput = buffered.getMaxExtract() > 0;
            canInput = buffered.getMaxReceive() > 0;
        } else {
            canOutput = storage.canExtract();
            canInput = storage.canReceive();
        }
        if (canOutput && canInput) {
            return PORT_BATTERY;
        }
        if (canOutput) {
            return PORT_SOURCE;
        }
        return canInput ? PORT_MACHINE : PORT_NONE;
    }

    /**
     * 整网结算：合并缓存 → 发电机进池 → 供机器 → 多余的充电池 → 剩下的分回线缆。
     *
     * <p>关键在顺序：<b>机器优先，电池垫后</b>。以前是「谁能收就推给谁」，
     * 电池因为有电也能被抽（{@code canExtract} 为 true），于是既抽又充、永远显示放电；
     * 现在电池只有在机器确实缺电时才放电，机器吃饱后的富余才拿去充电池。
     */
    private static void solve(ServerLevel level, List<CableBlockEntity> members) {
        int capacity = 0;
        int throughput = 0;
        int stored = 0;
        for (CableBlockEntity member : members) {
            capacity += member.tier().capacity();
            throughput += member.tier().maxTransfer();
            stored += member.getStoredEnergy();
        }
        if (capacity <= 0) {
            return;
        }

        // 0) 把贴着的端口找出来按角色分好。每个方块位置只算一次：
        //    一块电池可能同时贴着两根线缆，重复处理会超收 / 超抽。
        List<IEnergyStorage> sources = new ArrayList<>();
        List<IEnergyStorage> machines = new ArrayList<>();
        List<IEnergyStorage> batteries = new ArrayList<>();
        Set<Long> visited = new HashSet<>();
        for (CableBlockEntity member : members) {
            for (Direction side : Direction.values()) {
                BlockPos neighbour = member.getBlockPos().relative(side);
                if (!visited.add(neighbour.asLong())) {
                    continue;
                }
                if (level.getBlockEntity(neighbour) instanceof CableBlockEntity) {
                    continue;
                }
                IEnergyStorage storage = level.getCapability(Capabilities.EnergyStorage.BLOCK,
                        neighbour, side.getOpposite());
                if (storage == null) {
                    continue;
                }
                switch (classify(storage)) {
                    case PORT_SOURCE -> sources.add(storage);
                    case PORT_MACHINE -> machines.add(storage);
                    case PORT_BATTERY -> batteries.add(storage);
                    default -> {
                        // 既不收也不放，不参与
                    }
                }
            }
        }

        int pool = Math.min(stored, capacity);
        // 「搬进池子」和「从池子搬出」各有一份带宽：一 tick 里线缆可以同时收 320、送 320，
        // 共用一个预算的话，发电机一进池就把预算用光，电池那一 tick 就再也充不进去了。
        int inBudget = throughput;
        int outBudget = throughput;
        // 池子还能再装多少：只限制「往池子里搬电」，不限制「从池子里送出去」
        int roomInPool = capacity - pool;

        // 1) 发电机产的电先搬进池子
        for (IEnergyStorage source : sources) {
            int canMove = Math.min(inBudget, roomInPool);
            if (canMove <= 0) {
                break;
            }
            int moved = Math.min(source.extractEnergy(canMove, true), canMove);
            if (moved <= 0) {
                continue;
            }
            moved = source.extractEnergy(moved, false);
            if (moved <= 0) {
                continue;
            }
            pool += moved;
            roomInPool -= moved;
            inBudget -= moved;
        }

        // 2) 先算机器这一 tick 还能吃多少（模拟接收，不落地）
        int[] demand = new int[machines.size()];
        int totalDemand = 0;
        for (int i = 0; i < machines.size(); i++) {
            demand[i] = machines.get(i).receiveEnergy(Integer.MAX_VALUE / 4, true);
            totalDemand += demand[i];
        }

        // 3) 池子不够机器吃，才从电池放电补缺口。
        //    机器吃饱就不动电池，免得电池刚充进来的电又被线缆抽走。
        int gap = totalDemand - Math.min(pool, totalDemand);
        for (IEnergyStorage battery : batteries) {
            int canMove = Math.min(Math.min(gap, inBudget), roomInPool);
            if (canMove <= 0) {
                break;
            }
            int moved = Math.min(battery.extractEnergy(canMove, true), canMove);
            if (moved <= 0) {
                continue;
            }
            moved = battery.extractEnergy(moved, false);
            if (moved <= 0) {
                continue;
            }
            pool += moved;
            roomInPool -= moved;
            inBudget -= moved;
            gap -= moved;
        }

        // 4) 送机器（每个端口这一 tick 只调一次，天然受它自己的每 tick 接收上限约束）
        for (int i = 0; i < machines.size(); i++) {
            if (pool <= 0 || outBudget <= 0) {
                break;
            }
            int want = Math.min(Math.min(pool, demand[i]), outBudget);
            if (want <= 0) {
                continue;
            }
            int accepted = machines.get(i).receiveEnergy(want, false);
            if (accepted <= 0) {
                continue;
            }
            pool -= accepted;
            outBudget -= accepted;
        }

        // 5) 机器吃不完的，充进电池
        for (IEnergyStorage battery : batteries) {
            if (pool <= 0 || outBudget <= 0) {
                break;
            }
            int want = Math.min(pool, outBudget);
            int accepted = battery.receiveEnergy(want, false);
            if (accepted <= 0) {
                continue;
            }
            pool -= accepted;
            outBudget -= accepted;
        }

        // 6) 剩下的电按容量比例分回每根线缆，数字才稳得住
        distribute(members, pool, capacity);
    }

    /** 把 {@code stored} 分回每根线缆：先按容量比例，零头再补给还有空位的。 */
    private static void distribute(List<CableBlockEntity> members, int stored, int capacity) {
        if (capacity <= 0) {
            return;
        }
        int pool = Math.max(0, Math.min(stored, capacity));
        int remainder = pool;
        for (CableBlockEntity member : members) {
            int cap = member.tier().capacity();
            int share = (int) ((long) pool * cap / capacity);
            share = Math.max(0, Math.min(share, cap));
            member.setStoredEnergy(share);
            remainder -= share;
        }
        // 整数除法的零头：一根一根补给还有空位的线缆（每根最多补到自己的上限）
        while (remainder > 0) {
            boolean placed = false;
            for (CableBlockEntity member : members) {
                if (remainder <= 0) {
                    break;
                }
                if (member.getStoredEnergy() < member.tier().capacity()) {
                    member.setStoredEnergy(member.getStoredEnergy() + 1);
                    remainder--;
                    placed = true;
                }
            }
            if (!placed) {
                break;
            }
        }
    }

    /** 服务端关掉时把记账全清掉（换存档、换世界不会带着上一局的名单）。 */
    public static void clearAll() {
        STATES.clear();
    }
}
