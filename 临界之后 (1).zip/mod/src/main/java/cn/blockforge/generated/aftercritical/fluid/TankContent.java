package cn.blockforge.generated.aftercritical.fluid;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.level.material.Fluid;

import javax.annotation.Nullable;

/**
 * 「一个罐子里装着哪种流体、多少 mB」。
 *
 * <p>为什么不直接把 {@link net.neoforged.neoforge.fluids.FluidStack} 塞进数据组件里？
 * 因为 Minecraft 规定：能当数据组件的值，必须自己实现 {@code equals} 和 {@code hashCode}
 * （它要靠这两个方法判断「两格东西一不一样、能不能叠在一起」）。
 * {@code FluidStack} 没有实现，硬放进去会在创造栏、配方、联机同步这些地方直接报错。
 *
 * <p>所以这里用 {@code record} 包一层：record 自带 {@code equals} / {@code hashCode}，
 * 里面只放「哪种流体（用 Holder 表示，注册表里的流体都靠它指）+ 多少 mB」。
 * 需要算流体逻辑时，再用 {@link #toStack()} 转回 {@code FluidStack}。
 *
 * <p>JSON 里的样子：{@code {"id": "aftercritical:sulfuric_acid", "amount": 1000}}。
 */
public record TankContent(Holder<Fluid> fluid, int amount) {

    /** 存档 / 配方用的编解码器；字段名 {@code id} 和 {@code amount} 是写进 json 的名字。 */
    public static final Codec<TankContent> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            BuiltInRegistries.FLUID.holderByNameCodec().fieldOf("id").forGetter(TankContent::fluid),
            ExtraCodecs.POSITIVE_INT.fieldOf("amount").forGetter(TankContent::amount)
    ).apply(instance, TankContent::new));

    /** 网络同步用的编解码器。 */
    public static final StreamCodec<RegistryFriendlyByteBuf, TankContent> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.holderRegistry(Registries.FLUID), TankContent::fluid,
            ByteBufCodecs.VAR_INT, TankContent::amount,
            TankContent::new);

    /** 从 {@code FluidStack} 转过来；空栈返回 {@code null}（空就是不挂组件）。 */
    @Nullable
    public static TankContent of(@Nullable net.neoforged.neoforge.fluids.FluidStack stack) {
        if (stack == null || stack.isEmpty()) {
            return null;
        }
        return new TankContent(stack.getFluidHolder(), stack.getAmount());
    }

    /** 转回 {@code FluidStack}，方便和流体槽、管道打交道。 */
    public net.neoforged.neoforge.fluids.FluidStack toStack() {
        return new net.neoforged.neoforge.fluids.FluidStack(this.fluid, this.amount);
    }

    /** 只要流体种类。 */
    public Fluid fluidValue() {
        return this.fluid.value();
    }
}
