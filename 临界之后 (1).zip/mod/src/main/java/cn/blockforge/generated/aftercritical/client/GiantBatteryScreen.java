package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.blockentity.GiantBatteryBlockEntity;
import cn.blockforge.generated.aftercritical.menu.GiantBatteryMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * 巨型储能库的界面：一条大能量条 + 电量数字，底下写一行容量和充放速度。
 *
 * <p>和电池 MV 的区别只有这个数字：这里是 1.2 亿 FE、20,000 FE/t，
 * 所以单独开一个界面类把提示写清楚，玩家一眼知道「这东西够烧一炉」。
 */
public class GiantBatteryScreen extends AbstractMachineScreen<GiantBatteryMenu> {

    public GiantBatteryScreen(GiantBatteryMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected Component hintLine() {
        return Component.translatable("gui.aftercritical.giant_battery.hint",
                GiantBatteryBlockEntity.MAX_RECEIVE_PER_TICK);
    }
}
