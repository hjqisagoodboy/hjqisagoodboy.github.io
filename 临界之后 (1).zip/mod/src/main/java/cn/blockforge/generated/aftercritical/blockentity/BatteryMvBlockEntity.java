package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.energy.BufferedEnergyStorage;
import cn.blockforge.generated.aftercritical.energy.EnergyTransfer;
import cn.blockforge.generated.aftercritical.menu.BatteryMvMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.IEnergyStorage;

import javax.annotation.Nullable;

/**
 * 电池 MV：容量比电池 LV 大 4 倍，是托卡马克点火的标准「启动电源」。
 *
 * <p>单块存 160,000 FE，8 块并联正好 1,280,000 FE（定稿 v4 里要求的那一组）。
 * 收电 2,048 FE/t，放电 320 FE/t。
 */
public class BatteryMvBlockEntity extends BlockEntity
        implements MenuProvider, EnergyMachineHost, TickableBlockEntity, EnergyStorable {

    /** 储能上限：160,000 FE。 */
    public static final int ENERGY_CAPACITY = 160_000;
    /** 每 tick 最多收进来多少 FE。 */
    public static final int MAX_RECEIVE_PER_TICK = 2_048;
    /** 最大输出：320 FE/t。 */
    public static final int MAX_OUTPUT_PER_TICK = 320;

    private final BatteryStatusTracker statusTracker = new BatteryStatusTracker();
    private final BufferedEnergyStorage energy = new BufferedEnergyStorage(
            ENERGY_CAPACITY, MAX_RECEIVE_PER_TICK, MAX_OUTPUT_PER_TICK, this::onEnergyChanged);
    private int status = STATUS_IDLE;

    public BatteryMvBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.BATTERY_MV.get(), pos, state);
    }

    public IEnergyStorage getEnergyStorage() {
        return this.energy;
    }

    /** 能量一有变动就记一笔：不管是谁改的（直连邻居、线缆网、GUI），状态都跟着变。 */
    private void onEnergyChanged() {
        setChanged();
        long gameTime = this.level == null ? 0L : this.level.getGameTime();
        this.statusTracker.onEnergyChanged(this.energy.getEnergyStored(), gameTime);
    }

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        // 只和直连的方块打交道；线缆里的电交给 CableNetwork 整网调度，先供机器、剩下再充电池
        EnergyTransfer.pullForCharging(this.level, this.worldPosition, this.energy, MAX_RECEIVE_PER_TICK);
        EnergyTransfer.pushToConsumers(this.level, this.worldPosition, this.energy, MAX_OUTPUT_PER_TICK);

        int newStatus = this.statusTracker.status(this.level.getGameTime());
        if (this.status != newStatus) {
            this.status = newStatus;
            setChanged();
        }
    }

    @Override
    public int getStoredEnergy() {
        return this.energy.getEnergyStored();
    }

    @Override
    public void setStoredEnergy(int value) {
        this.energy.setEnergy(value);
        this.statusTracker.reset(this.energy.getEnergyStored());
        setChanged();
    }

    @Override
    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    @Override
    public int getEnergyCapacity() {
        return this.energy.getMaxEnergyStored();
    }

    @Override
    public int getStatus() {
        return this.status;
    }

    @Override
    public int getProgress() {
        return 0;
    }

    @Override
    public int getMaxProgress() {
        return 0;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.battery_mv");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new BatteryMvMenu(containerId, playerInventory, this);
    }

    // ------------------------------------------------------------------
    // 电池没有物品槽，但 GUI 菜单需要一个「容器」，所以这几个方法都空着实现
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return 0;
    }

    @Override
    public boolean isEmpty() {
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        return ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
        tag.putInt("Status", this.status);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
        this.status = tag.getInt("Status");
        this.statusTracker.reset(this.energy.getEnergyStored());
    }
}
