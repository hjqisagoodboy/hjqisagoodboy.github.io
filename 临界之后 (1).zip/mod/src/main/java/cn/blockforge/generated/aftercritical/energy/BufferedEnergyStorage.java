package cn.blockforge.generated.aftercritical.energy;

import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * 既能存电、也能对外送电的 FE 缓存（发电机、电池用）。
 *
 * <p>和只进不出的 {@link MachineEnergyStorage} 的区别：
 * <ul>
 *   <li>{@code maxReceive} 决定外面每 tick 最多能灌进来多少（电池要能充电）；</li>
 *   <li>{@code maxExtract} 决定每 tick 最多能往外送多少（发电机 80 / 320，电池 80）。</li>
 * </ul>
 */
public final class BufferedEnergyStorage implements IEnergyStorage {

    private final int capacity;
    private final int maxReceive;
    private final int maxExtract;
    private final Runnable onChange;
    private int energy;

    public BufferedEnergyStorage(int capacity, int maxReceive, int maxExtract, Runnable onChange) {
        this.capacity = capacity;
        this.maxReceive = maxReceive;
        this.maxExtract = maxExtract;
        this.onChange = onChange;
    }

    @Override
    public int receiveEnergy(int toReceive, boolean simulate) {
        if (toReceive <= 0 || this.maxReceive <= 0) {
            return 0;
        }
        int accepted = Math.min(Math.min(toReceive, this.maxReceive), this.capacity - this.energy);
        if (accepted <= 0) {
            return 0;
        }
        if (!simulate) {
            this.energy += accepted;
            this.onChange.run();
        }
        return accepted;
    }

    @Override
    public int extractEnergy(int toExtract, boolean simulate) {
        if (toExtract <= 0 || this.maxExtract <= 0) {
            return 0;
        }
        int taken = Math.min(Math.min(toExtract, this.maxExtract), this.energy);
        if (taken <= 0) {
            return 0;
        }
        if (!simulate) {
            this.energy -= taken;
            this.onChange.run();
        }
        return taken;
    }

    @Override
    public int getEnergyStored() {
        return this.energy;
    }

    @Override
    public int getMaxEnergyStored() {
        return this.capacity;
    }

    @Override
    public boolean canExtract() {
        return this.maxExtract > 0 && this.energy > 0;
    }

    @Override
    public boolean canReceive() {
        return this.maxReceive > 0 && this.energy < this.capacity;
    }

    /** 机器自己发电时往缓存里塞（不走 {@link #receiveEnergy}，那个有每 tick 上限）。 */
    public int grow(int amount) {
        if (amount <= 0) {
            return 0;
        }
        int accepted = Math.min(amount, this.capacity - this.energy);
        if (accepted <= 0) {
            return 0;
        }
        this.energy += accepted;
        this.onChange.run();
        return accepted;
    }

    public int getFreeSpace() {
        return this.capacity - this.energy;
    }

    /** 配置的每 tick 最大接收量（不随当前电量变化，线缆网靠它判断这个方块是不是「电池」）。 */
    public int getMaxReceive() {
        return this.maxReceive;
    }

    /** 配置的每 tick 最大输出量（不随当前电量变化，线缆网靠它判断这个方块是不是「发电机」）。 */
    public int getMaxExtract() {
        return this.maxExtract;
    }

    /** 机器自己「一口气」扣电（例如点火一次性抽 72,000 FE），不受每 tick 上限限制。 */
    public boolean consume(int amount) {
        if (amount <= 0) {
            return true;
        }
        if (this.energy < amount) {
            return false;
        }
        this.energy -= amount;
        this.onChange.run();
        return true;
    }

    public void setEnergy(int value) {
        this.energy = Math.max(0, Math.min(value, this.capacity));
    }
}
