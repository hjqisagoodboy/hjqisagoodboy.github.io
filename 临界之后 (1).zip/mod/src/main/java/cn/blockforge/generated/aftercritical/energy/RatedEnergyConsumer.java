package cn.blockforge.generated.aftercritical.energy;

/**
 * 「我这台机器每 tick 要吃多少电」的声明。
 *
 * <p>线缆靠它判断自己扛不扛得住：一台额定 120 FE/t 的机器从 80 FE/t 的 LV 线缆上取电，
 * 线缆就会被烧掉。只看机器的额定功率，不看它这一 tick 实际拿了多少，
 * 所以逻辑是固定的、可预期的，不会因为机器偶尔闲着就时烧时不烧。
 */
public interface RatedEnergyConsumer {

    /** 这台机器额定每 tick 消耗多少 FE。 */
    int ratedEnergyPerTick();
}
