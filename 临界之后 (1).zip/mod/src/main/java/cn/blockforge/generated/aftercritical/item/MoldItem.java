package cn.blockforge.generated.aftercritical.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * 模具类物品（板材模具、线材模具）。
 *
 * <p>它本身不做事，只是一个标记：锻压机的工具槽通过 {@code instanceof MoldItem}
 * 判断「这东西能不能塞进工具槽」。模具没有耐久，也不会被消耗。
 *
 * <p>反过来，锻压机的输入槽也不收模具——模具是工具，不是原料。
 */
public class MoldItem extends Item {

    public MoldItem(Properties properties) {
        super(properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.mold_hint")
                .withStyle(ChatFormatting.GRAY));
    }
}
