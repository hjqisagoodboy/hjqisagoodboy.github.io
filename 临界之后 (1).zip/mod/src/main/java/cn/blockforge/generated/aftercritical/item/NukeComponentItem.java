package cn.blockforge.generated.aftercritical.item;

import cn.blockforge.generated.aftercritical.nuke.NukeComponent;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 核弹的模块化组件：拿在手上是普通物品，右键放进核弹界面里才起作用。
 *
 * <p>组件不会被消耗——装上去就一直待在核弹里，跟着核弹一起炸掉。
 */
public class NukeComponentItem extends Item {

    private final NukeComponent component;

    public NukeComponentItem(Properties properties, NukeComponent component) {
        super(properties);
        this.component = component;
    }

    public NukeComponent component() {
        return this.component;
    }

    /** 这个物品堆是不是组件；不是就返回 {@code null}。 */
    @Nullable
    public static NukeComponent componentOf(ItemStack stack) {
        return stack.getItem() instanceof NukeComponentItem item ? item.component : null;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.nuke_component")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable(this.component.effectKey())
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
