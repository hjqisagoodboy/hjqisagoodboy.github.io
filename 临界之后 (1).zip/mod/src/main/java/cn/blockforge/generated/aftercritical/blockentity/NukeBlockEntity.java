package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.block.NukeBlock;
import cn.blockforge.generated.aftercritical.item.NukeComponentItem;
import cn.blockforge.generated.aftercritical.menu.NukeMenu;
import cn.blockforge.generated.aftercritical.nuke.NukeComponent;
import cn.blockforge.generated.aftercritical.nuke.NukeKind;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.world.NuclearBlast;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 核弹方块实体：存六个模块化组件槽 + 一根五秒的引信。
 *
 * <p>起爆流程：起爆器把 {@link #arm(Player)} 叫起来 → 每 tick 减引信，
 * 期间每秒钟在动作条上数秒、冒烟、滴滴响 → 到 0 调 {@link #detonate(ServerPlayer)}，
 * 把自己这一格清掉，然后把半径、坑深、辐射时长交给
 * {@link NuclearBlast}（和临界反应堆熔毁共用同一套挖掘、焦土、蘑菇云）。
 *
 * <p>组件不会被消耗：它们跟着核弹一起消失。拆掉核弹（没起爆）时，
 * {@link NukeBlock#onRemove} 会把槽里的东西吐回地上。
 */
public class NukeBlockEntity extends BlockEntity implements Container, net.minecraft.world.MenuProvider,
        TickableBlockEntity {

    /**
     * 槽位表最多几个槽（沙皇那一颗 7 个）。
     *
     * <p>实际能用几个看这颗弹的装配图 {@link NukeKind#slots()}：小男孩 6 个、沙皇 7 个。
     * 存档一律按 7 格存，换弹种也不会丢数据。
     */
    public static final int MAX_SLOTS = 7;
    /** 引信最长多少 tick（减速伞翻倍之后的上限，防止存档里出现离谱数字）。 */
    public static final int MAX_FUSE_TICKS = 600;
    /** 倒计时的时候多远的人能听到数秒。 */
    private static final double COUNTDOWN_RADIUS = 64.0;
    /** 组件数量变化时，多远的人算「参与了装配」（成就用）。 */
    private static final double ASSEMBLY_RADIUS = 8.0;

    private final NonNullList<ItemStack> items = NonNullList.withSize(MAX_SLOTS, ItemStack.EMPTY);
    private boolean armed;
    private int fuse;
    /** 谁按的起爆器：倒计时结束时按这个把成就发给他。 */
    @Nullable
    private java.util.UUID armedBy;
    /** 上一次 tick 数到的组件数量：一变就说明有人刚装 / 拆了组件。 */
    private int lastInstalled = -1;

    public NukeBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.NUKE.get(), pos, state);
    }

    /** 这颗弹的档案。 */
    public NukeKind kind() {
        return getBlockState().getBlock() instanceof NukeBlock nuke ? nuke.kind() : NukeKind.LITTLE_BOY;
    }

    /** 槽里装的组件算出来的最终爆炸参数（界面里也用这个显示）。 */
    public NukeComponent.Loadout loadout() {
        return NukeComponent.loadout(kind(), this.items);
    }

    /** 已经在倒计时了吗（防止连点起爆器）。 */
    public boolean isArmed() {
        return this.armed;
    }

    // ------------------------------------------------------------------
    // 每 tick：引信 + 装配成就
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        int installed = countInstalled();
        if (installed != this.lastInstalled) {
            this.lastInstalled = installed;
            if (installed > 0) {
                ModAdvancementTriggers.fireNearby(server, this.worldPosition, ASSEMBLY_RADIUS,
                        ModAdvancementTriggers.NUKE_COMPONENT);
            }
        }
        if (!this.armed) {
            return;
        }

        this.fuse--;
        if (this.fuse > 0 && this.fuse % 20 == 0) {
            int seconds = this.fuse / 20;
            for (ServerPlayer player : server.getEntitiesOfClass(ServerPlayer.class,
                    new net.minecraft.world.phys.AABB(this.worldPosition).inflate(COUNTDOWN_RADIUS))) {
                player.displayClientMessage(Component.translatable(
                        "message.aftercritical.nuke.countdown", seconds), true);
            }
            server.playSound(null, this.worldPosition, SoundEvents.NOTE_BLOCK_PLING.value(),
                    SoundSource.BLOCKS, 3.0F, this.fuse % 40 == 0 ? 0.7F : 1.2F);
        }
        if (this.fuse % 5 == 0) {
            server.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                    this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 1.2,
                    this.worldPosition.getZ() + 0.5, 3, 0.3, 0.2, 0.3, 0.01);
        }
        if (this.fuse <= 0) {
            detonate(this.armedBy == null ? null
                    : server.getServer().getPlayerList().getPlayer(this.armedBy));
        }
    }

    /** 已经装对了的组件个数（只数装配图里要求的那种，塞错的槽不算）。 */
    private int countInstalled() {
        return loadout().installed();
    }

    // ------------------------------------------------------------------
    // 起爆
    // ------------------------------------------------------------------

    /**
     * 点火：开始倒计时（基础 5 秒，沙皇 8 秒，装减速伞再翻倍）。
     *
     * @return 已经在倒计时了返回 {@code false}
     */
    public boolean arm(@Nullable Player player) {
        if (this.armed) {
            return false;
        }
        this.armed = true;
        this.fuse = loadout().fuseTicks();
        this.armedBy = player instanceof ServerPlayer serverPlayer ? serverPlayer.getUUID() : null;
        setChanged();
        if (this.level != null) {
            this.level.playSound(null, this.worldPosition, SoundEvents.BEACON_ACTIVATE,
                    SoundSource.BLOCKS, 3.0F, 0.5F);
            if (player != null) {
                player.displayClientMessage(Component.translatable(
                        "message.aftercritical.detonator.armed",
                        Component.translatable(kind().langKey()), this.fuse / 20), false);
            }
        }
        return true;
    }

    /**
     * 真正起爆：清掉自己这一格，然后交给 {@link NuclearBlast}。
     *
     * <p>{@code anchor} 传 {@code null}，所以爆心不会凭空冒出堆芯残骸和熔毁燃料棒——
     * 那些是反应堆熔毁专属的，核弹炸完就是一个干干净净的坑。
     */
    public void detonate(@Nullable ServerPlayer trigger) {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        NukeKind kind = kind();
        NukeComponent.Loadout loadout = loadout();
        BlockPos pos = this.worldPosition.immutable();

        // 先清空组件槽：下面的 setBlock 会触发 onRemove，不清空的话
        // 组件会当成「拆掉核弹」掉一地，等于白送玩家一堆东西
        this.clearContent();
        server.setBlock(pos, Blocks.AIR.defaultBlockState(), net.minecraft.world.level.block.Block.UPDATE_CLIENTS);
        NuclearBlast.start(server, pos, null, loadout.radius(), 0, loadout.depth(), loadout.radiationTicks());

        String event = "detonate_" + kind.id;
        if (trigger != null) {
            ModAdvancementTriggers.fire(trigger, event);
            if (loadout.installed() >= loadout.capacity()) {
                ModAdvancementTriggers.fire(trigger, ModAdvancementTriggers.NUKE_FULL_LOADOUT);
            }
            if (loadout.cobalt()) {
                ModAdvancementTriggers.fire(trigger, ModAdvancementTriggers.NUKE_COBALT);
            }
        }
        // 站在旁边看着的人也算「亲眼见过这一颗」
        ModAdvancementTriggers.fireNearby(server, pos, 64.0, event);
    }

    // ------------------------------------------------------------------
    // 容器（这颗弹装配图上的几个组件槽）
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return kind().componentCount();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack removed = ContainerHelper.removeItem(this.items, slot, amount);
        if (!removed.isEmpty()) {
            setChanged();
        }
        return removed;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        setChanged();
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    /**
     * 每个槽只收装配图上要求的那一种组件。
     *
     * <p>比如小男孩的第 3 格只收「铀靶环」，往里塞引爆器是放不进去的。
     */
    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        List<NukeKind.NukeSlot> layout = kind().slots();
        if (slot < 0 || slot >= layout.size()) {
            return false;
        }
        NukeComponent component = NukeComponentItem.componentOf(stack);
        return component != null && component == layout.get(slot).component();
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    /** 界面标题就是这颗弹的名字。 */
    @Override
    public Component getDisplayName() {
        return Component.translatable(kind().langKey());
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
        return new NukeMenu(containerId, inventory, this);
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    /** 给界面 / 调试用的一份组件列表（不可改）。 */
    public List<ItemStack> componentStacks() {
        return this.items;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        ContainerHelper.saveAllItems(tag, this.items, registries);
        tag.putBoolean("Armed", this.armed);
        tag.putInt("Fuse", this.fuse);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        ContainerHelper.loadAllItems(tag, this.items, registries);
        this.armed = tag.getBoolean("Armed");
        this.fuse = Math.max(0, Math.min(MAX_FUSE_TICKS, tag.getInt("Fuse")));
        if (this.armed && this.fuse == 0) {
            this.fuse = loadout().fuseTicks();
        }
    }
}
