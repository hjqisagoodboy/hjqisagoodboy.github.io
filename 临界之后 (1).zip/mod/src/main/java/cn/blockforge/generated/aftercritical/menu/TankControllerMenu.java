package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.TankControllerBlockEntity;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 储罐控制器的界面：一根大流体长条（64,000 mB）+ 一对罐子槽。
 *
 * <p>长条右边是「操作槽」和「返还槽」：操作槽放满罐就往罐里倒、放空罐就从罐里灌满，
 * 处理完的罐子自动跑到返还槽，玩家只需要动这两个格子。
 *
 * <p>这块方块没有电，所以界面上不会出现能量条；底下两行写的是结构有没有搭好、还剩多少空间。
 */
public class TankControllerMenu extends AbstractMachineMenu implements FluidBarHost {

    /** 大罐子那根长条：比普通长条粗一点、高一点。 */
    public static final int BAR_X = MachineLayout.FLUID_X;
    public static final int BAR_Y = MachineLayout.FLUID_TOP;
    public static final int BAR_W = 12;
    public static final int BAR_H = 56;

    private static final int DATA_AMOUNT = 0;
    private static final int DATA_FLUID = 1;
    private static final int DATA_FORMED = 2;

    @Nullable
    private final TankControllerBlockEntity controller;

    private int amount;
    private int fluidId = -1;
    private boolean formed;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case DATA_AMOUNT -> amount;
                case DATA_FLUID -> fluidId;
                case DATA_FORMED -> formed ? 1 : 0;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case DATA_AMOUNT -> amount = value;
                case DATA_FLUID -> fluidId = value;
                case DATA_FORMED -> formed = value != 0;
                default -> {
                }
            }
        }

        @Override
        public int getCount() {
            return 3;
        }
    };

    /** 服务端用。 */
    public TankControllerMenu(int containerId, Inventory playerInventory, TankControllerBlockEntity controller) {
        this(ModMenus.TANK_CONTROLLER.get(), containerId, playerInventory, controller, controller);
    }

    private TankControllerMenu(MenuType<?> type, int containerId, Inventory playerInventory,
                               Container container, @Nullable TankControllerBlockEntity controller) {
        // 储罐没有能量系统（machine 传 null），右边一行流体长条
        super(type, containerId, playerInventory, TankControllerBlockEntity.SLOT_COUNT, null, 1);
        this.controller = controller;
        this.addSlot(new OperateSlot(container, TankControllerBlockEntity.SLOT_OP_JAR,
                opSlotX(), slotY()));
        this.addSlot(new ReturnSlot(container, TankControllerBlockEntity.SLOT_RETURN_JAR,
                returnSlotX(), slotY()));
        this.addPlayerInventory(playerInventory);
        this.addDataSlots(this.data);
    }

    /** 操作槽、返还槽的位置和其他机器完全一致，表头才对得上。 */
    public static int opSlotX() {
        return BAR_X + MachineLayout.FLUID_OP_DX;
    }

    public static int returnSlotX() {
        return BAR_X + MachineLayout.FLUID_RET_DX;
    }

    public static int slotY() {
        return BAR_Y - 1;
    }

    /** 客户端收到「打开菜单」的包后调用。 */
    public static TankControllerMenu fromNetwork(int containerId, Inventory playerInventory,
                                                 RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof TankControllerBlockEntity tank) {
            return new TankControllerMenu(ModMenus.TANK_CONTROLLER.get(), containerId, playerInventory, tank, tank);
        }
        return new TankControllerMenu(ModMenus.TANK_CONTROLLER.get(), containerId, playerInventory,
                new SimpleContainer(TankControllerBlockEntity.SLOT_COUNT), null);
    }

    @Override
    public void broadcastChanges() {
        if (this.controller != null) {
            this.amount = this.controller.getFluidAmount();
            this.fluidId = this.controller.getFluidId();
            this.formed = this.controller.isFormed();
        }
        super.broadcastChanges();
    }

    public int getAmount() {
        return this.amount;
    }

    public int getFluidId() {
        return this.fluidId;
    }

    public int getCapacity() {
        return TankControllerBlockEntity.CAPACITY;
    }

    public boolean isFormed() {
        return this.formed;
    }

    // ------------------------------------------------------------------
    // FluidBarHost
    // ------------------------------------------------------------------

    @Override
    public int barCount() {
        return 1;
    }

    @Override
    public int barX(int index) {
        return BAR_X;
    }

    @Override
    public int barY(int index) {
        return BAR_Y;
    }

    @Override
    public int barWidth(int index) {
        return BAR_W;
    }

    @Override
    public int barHeight(int index) {
        return BAR_H;
    }

    @Override
    public int barAmount(int index) {
        return this.amount;
    }

    @Override
    public int barFluidId(int index) {
        return this.fluidId;
    }

    @Override
    public int barCapacity() {
        return getCapacity();
    }

    @Override
    public boolean barIsInput(int index) {
        return true;
    }

    @Override
    public boolean stillValid(Player player) {
        return this.controller == null || this.controller.stillValid(player);
    }

    /** Shift + 点击：机器槽和玩家背包互相搬（具体去哪个槽由槽自己的 mayPlace 决定）。 */
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return super.quickMoveStack(player, index);
    }

    /** 操作槽：放通用流体罐（满罐倒进去、空罐灌满），能叠 64 个。 */
    public static class OperateSlot extends Slot {

        public OperateSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.getItem() instanceof UniversalTankItem;
        }
    }

    /** 返还槽：只能拿，不能塞。 */
    public static class ReturnSlot extends Slot {

        public ReturnSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return false;
        }
    }
}
