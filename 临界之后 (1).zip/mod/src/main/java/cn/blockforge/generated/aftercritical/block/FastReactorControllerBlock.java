package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.FastReactorControllerBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 钠冷快堆控制器：7 宽 × 7 深 × 7 高的多方块心脏。
 *
 * <p>和压水堆一样：控制器贴在正面墙、贴地那排正中间，方块朝哪堆就往哪长，右键开界面。
 * 区别是它烧 MOX、喝液态钠，电由结构里的钠-水蒸汽发生器自己发。
 */
public class FastReactorControllerBlock extends TickablePartBlock {

    public static final String DESCRIPTION = "block.aftercritical.fast_reactor_controller.desc";

    /** 方块朝哪 = 结构往哪长。只有水平四个方向。 */
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    public FastReactorControllerBlock(Properties properties) {
        super(properties, DESCRIPTION);
        registerDefaultState(defaultBlockState().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(FastReactorControllerBlock::new);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection());
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new FastReactorControllerBlockEntity(pos, state);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        // 手里拿着装钠的通用流体罐：直接往堆里灌，不弹界面
        if (stack.getItem() instanceof cn.blockforge.generated.aftercritical.item.UniversalTankItem
                && !level.isClientSide
                && level.getBlockEntity(pos) instanceof FastReactorControllerBlockEntity controller
                && controller.fillSodiumFromHand(player, hand)) {
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MenuProvider provider) {
            player.openMenu(provider, pos);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof MenuProvider provider) {
            player.openMenu(provider, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** 旁边多一块少一块就立刻重查结构，不用干等两秒。 */
    @Override
    protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block neighbor,
                                   BlockPos neighborPos, boolean movedByPiston) {
        super.neighborChanged(state, level, pos, neighbor, neighborPos, movedByPiston);
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof FastReactorControllerBlockEntity controller) {
            controller.validateSoon();
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.aftercritical.fast.size",
                FastReactorControllerBlockEntity.SIZE_W, FastReactorControllerBlockEntity.SIZE_H,
                FastReactorControllerBlockEntity.SIZE_D).withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.fast.materials",
                FastReactorControllerBlockEntity.MIN_SHELL).withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.fast.parts",
                FastReactorControllerBlockEntity.MIN_DETECTORS,
                FastReactorControllerBlockEntity.MIN_GENERATORS,
                FastReactorControllerBlockEntity.MIN_ROD_PORTS).withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.fast.run",
                FastReactorControllerBlockEntity.MIN_FUEL,
                FastReactorControllerBlockEntity.FUEL_SLOTS,
                FastReactorControllerBlockEntity.SODIUM_CAPACITY,
                FastReactorControllerBlockEntity.OUTPUT_PER_GENERATOR).withStyle(ChatFormatting.GRAY));
    }
}
