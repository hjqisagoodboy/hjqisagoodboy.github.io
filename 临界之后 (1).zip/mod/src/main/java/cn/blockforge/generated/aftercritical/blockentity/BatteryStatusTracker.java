package cn.blockforge.generated.aftercritical.blockentity;

/**
 * 电池界面状态（充电中 / 放电中 / 待机）的小记账本。
 *
 * <p>为什么不能像以前那样「这一 tick 自己推出去多少就显示放电」：
 * 接线缆之后电池本身不推也不抽（线缆里的电交给
 * {@link cn.blockforge.generated.aftercritical.energy.CableNetwork} 整网调度），
 * 能量是在电池自己 tick 之外被线缆网改的。所以只能盯着能量本身：
 * 谁把能量改多了就是充电，改少了就是放电。
 *
 * <p>连续 2 tick 没人动它，就回到「待机」，免得电池充满了还一直写着「充电中」。
 */
public final class BatteryStatusTracker {

    /** 超过这么多 tick 没有能量变化就回「待机」。 */
    private static final int IDLE_TIMEOUT = 2;

    private int lastEnergy;
    private int status = EnergyMachineHost.STATUS_IDLE;
    private long lastChangeTick = Long.MIN_VALUE;

    /** 能量刚被改过：按增减更新状态。 */
    public void onEnergyChanged(int now, long gameTime) {
        if (now > this.lastEnergy) {
            this.status = EnergyMachineHost.STATUS_CHARGING;
        } else if (now < this.lastEnergy) {
            this.status = EnergyMachineHost.STATUS_DISCHARGING;
        } else {
            return;
        }
        this.lastEnergy = now;
        this.lastChangeTick = gameTime;
    }

    /** 读档 / 从物品还原之后同步基准值，不然第一次改动会被误判。 */
    public void reset(int energy) {
        this.lastEnergy = Math.max(0, energy);
        this.status = EnergyMachineHost.STATUS_IDLE;
        this.lastChangeTick = Long.MIN_VALUE;
    }

    /** 这一 tick 该显示的状态。 */
    public int status(long gameTime) {
        if (this.status == EnergyMachineHost.STATUS_IDLE || this.lastChangeTick == Long.MIN_VALUE) {
            return EnergyMachineHost.STATUS_IDLE;
        }
        return gameTime - this.lastChangeTick > IDLE_TIMEOUT
                ? EnergyMachineHost.STATUS_IDLE
                : this.status;
    }
}
