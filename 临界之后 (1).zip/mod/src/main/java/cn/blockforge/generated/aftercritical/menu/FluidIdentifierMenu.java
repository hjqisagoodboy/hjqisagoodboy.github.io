package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.item.FluidIdentifierItem;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 流体识别码的界面：一格格列出游戏里所有已注册的流体，点一下就绑定。
 *
 * <p>界面里还有<b>一个罐子槽</b>：把空的通用流体罐放进去再点流体，
 * 这个罐子就会被「预设」成那种流体——以后放进机器罐子槽时只收那种液体。
 *
 * <p>识别码本身拿在手上，界面并不改它的位置，只是改它的数据组件；
 * 拿在左手、右手都能开（{@link #handOf} 自己判断是哪只手）。
 */
public class FluidIdentifierMenu extends AbstractContainerMenu {

    public static final int IMAGE_WIDTH = 176;
    public static final int IMAGE_HEIGHT = 222;
    public static final int INVENTORY_LABEL_Y = 132;

    /** 流体格子：8 列 × 4 行 = 32 格，一页正好放下现在所有流体。 */
    public static final int GRID_X = 8;
    public static final int GRID_Y = 18;
    public static final int CELL = 18;
    public static final int COLUMNS = 8;
    public static final int ROWS = 4;
    public static final int GRID_COUNT = COLUMNS * ROWS;

    /** 罐子槽（可选：放空罐用来预设）。 */
    public static final int TANK_SLOT_X = 8;
    public static final int TANK_SLOT_Y = 112;

    /** 玩家背包第一行的 y。 */
    public static final int INVENTORY_Y = 140;

    /** 「所有能装的流体」算一次就缓存起来（界面每帧都要问）。 */
    private static List<Fluid> FLUID_CACHE;

    /** 同步给客户端的两样东西：识别码绑了哪种流体、罐子槽里的罐子预设了哪种。 */
    private static final int DATA_BOUND = 0;
    private static final int DATA_PRESET = 1;

    private final Player owner;
    private final Container tankContainer;
    private final int[] synced = {-1, -1};

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return index >= 0 && index < synced.length ? synced[index] : -1;
        }

        @Override
        public void set(int index, int value) {
            if (index >= 0 && index < synced.length) {
                synced[index] = value;
            }
        }

        @Override
        public int getCount() {
            return synced.length;
        }
    };

    public FluidIdentifierMenu(int containerId, Inventory playerInventory) {
        super(ModMenus.FLUID_IDENTIFIER.get(), containerId);
        this.owner = playerInventory.player;
        this.tankContainer = new SimpleContainer(1);

        this.addSlot(new TankSlot(this.tankContainer, 0, TANK_SLOT_X, TANK_SLOT_Y));
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                this.addSlot(new Slot(playerInventory, column + row * 9 + 9,
                        8 + column * 18, INVENTORY_Y + row * 18));
            }
        }
        for (int column = 0; column < 9; column++) {
            this.addSlot(new Slot(playerInventory, column, 8 + column * 18, INVENTORY_Y + 58));
        }
        this.addDataSlots(this.data);
    }

    /**
     * 游戏里所有「能被装进容器」的流体。
     *
     * <p>过滤掉空气和「流动中」的那份（流动的水、流动的岩浆、我们每种流体的 flowing 版本），
     * 只留下源头那一份，所以列表里不会一个流体出现两遍。
     * 顺序就是注册顺序：原版的水、岩浆在前，然后是本模组的 16 种。
     */
    public static List<Fluid> registeredFluids() {
        // 第一帧里算一次就够了：注册表在游戏启动之后不会再变
        if (FLUID_CACHE == null) {
            List<Fluid> list = new ArrayList<>();
            for (Fluid fluid : BuiltInRegistries.FLUID) {
                if (fluid.isSame(Fluids.EMPTY)) {
                    continue;
                }
                if (!fluid.isSource(fluid.defaultFluidState())) {
                    continue;
                }
                list.add(fluid);
            }
            FLUID_CACHE = List.copyOf(list);
        }
        return FLUID_CACHE;
    }

    /** 第 {@code index} 格是哪种流体；越界返回 {@code null}。 */
    @Nullable
    public static Fluid fluidAt(int index) {
        List<Fluid> list = registeredFluids();
        return index >= 0 && index < list.size() ? list.get(index) : null;
    }

    /** 这个流体的注册表编号（界面同步用的整数）；{@code null} 返回 -1。 */
    public static int fluidIdOf(@Nullable Fluid fluid) {
        return fluid == null ? -1 : BuiltInRegistries.FLUID.getId(fluid);
    }

    /** 编号换回流体。 */
    @Nullable
    public static Fluid fluidOf(int id) {
        if (id < 0) {
            return null;
        }
        Fluid fluid = BuiltInRegistries.FLUID.byId(id);
        return fluid == null || fluid.isSame(Fluids.EMPTY) ? null : fluid;
    }

    /** 识别码拿在哪只手上：优先找主手，主手不是识别码就当副手。 */
    public static net.minecraft.world.InteractionHand handOf(Player player) {
        return player.getMainHandItem().getItem() instanceof FluidIdentifierItem
                ? net.minecraft.world.InteractionHand.MAIN_HAND
                : net.minecraft.world.InteractionHand.OFF_HAND;
    }

    /** 服务端每 tick 把「识别码绑了谁」「罐子预设了谁」同步给客户端。 */
    @Override
    public void broadcastChanges() {
        // 这两个数字得在 super 之前算好，super 会把它们打包发走
        if (this.owner != null) {
            this.synced[DATA_BOUND] = fluidIdOf(FluidIdentifierItem.boundFluid(heldIdentifier(this.owner)));
            this.synced[DATA_PRESET] = fluidIdOf(UniversalTankItem.getPreset(this.tankContainer.getItem(0)));
        }
        super.broadcastChanges();
    }

    /** 玩家手上那个识别码。 */
    private static ItemStack heldIdentifier(Player player) {
        return player.getItemInHand(handOf(player));
    }

    /**
     * 点了一个流体格子。
     *
     * <p>按钮号就是流体的注册表编号。点了之后两件事：
     * 识别码绑定它；罐子槽里如果有空的通用流体罐，就给它盖上同样的预设章。
     */
    @Override
    public boolean clickMenuButton(Player player, int id) {
        Fluid fluid = fluidOf(id);
        if (fluid == null) {
            return false;
        }
        ItemStack identifier = heldIdentifier(player);
        if (!(identifier.getItem() instanceof FluidIdentifierItem)) {
            return false;
        }
        FluidIdentifierItem.bind(identifier, fluid);

        ItemStack tank = this.tankContainer.getItem(0);
        if (tank.getItem() instanceof UniversalTankItem && !UniversalTankItem.isFilled(tank)) {
            UniversalTankItem.setPreset(tank, fluid);
            this.tankContainer.setChanged();
        }
        this.broadcastChanges();
        return true;
    }

    /** 识别码当前绑定的流体（客户端也用这个画界面）。 */
    @Nullable
    public Fluid boundFluid() {
        return fluidOf(this.synced[DATA_BOUND]);
    }

    /** 罐子槽里那个罐子预设的流体。 */
    @Nullable
    public Fluid presetFluid() {
        return fluidOf(this.synced[DATA_PRESET]);
    }

    /** 关界面时把罐子槽里的东西还给玩家，别吞了。 */
    @Override
    public void removed(Player player) {
        super.removed(player);
        // 只在服务端还东西：客户端也执行一次的话会凭空多出一份
        if (player.level().isClientSide) {
            return;
        }
        ItemStack leftover = this.tankContainer.removeItemNoUpdate(0);
        if (!leftover.isEmpty() && !player.getInventory().add(leftover)) {
            player.drop(leftover, false);
        }
    }

    /** 界面里没有可放东西的地方（除了罐子槽），Shift 点击就只做「罐子槽 ↔ 背包」。 */
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack copy = stack.copy();
        if (index == 0) {
            if (!this.moveItemStackTo(stack, 1, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else if (stack.getItem() instanceof UniversalTankItem) {
            if (!this.moveItemStackTo(stack, 0, 1, false)) {
                return ItemStack.EMPTY;
            }
        } else {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return copy;
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    /** 罐子槽：只收通用流体罐，一次一个。 */
    public static class TankSlot extends Slot {

        public TankSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.getItem() instanceof UniversalTankItem;
        }

        @Override
        public int getMaxStackSize() {
            return 1;
        }
    }
}
