package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.EnergyPortBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

/**
 * 能量端口：托卡马克无线供电的「接收天线」，也是物质嬗变器结构里唯一的电源入口。
 *
 * <p>它自己带 1,000,000 FE 的缓冲：256 格内只要有正在运行的托卡马克，
 * 每 tick 就能收进最多 20,000 FE；结构里的嬗变器控制器再从它身上抽电。
 * 空手右键看一眼当前电量和最近有没有收到无线供电。
 */
public class EnergyPortBlock extends TickablePartBlock {

    public static final String DESCRIPTION = "block.aftercritical.energy_port.desc";

    public EnergyPortBlock(Properties properties) {
        super(properties, DESCRIPTION);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(EnergyPortBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new EnergyPortBlockEntity(pos, state);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hitResult) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof EnergyPortBlockEntity port) {
            player.displayClientMessage(Component.translatable("gui.aftercritical.energy_port.status",
                    port.getEnergyStored(), port.capacity(), port.linkActive() ? 1 : 0)
                    .withStyle(port.linkActive() ? ChatFormatting.GREEN : ChatFormatting.GRAY), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
