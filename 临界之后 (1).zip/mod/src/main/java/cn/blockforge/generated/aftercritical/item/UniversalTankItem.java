package cn.blockforge.generated.aftercritical.item;

import cn.blockforge.generated.aftercritical.fluid.TankContent;
import cn.blockforge.generated.aftercritical.registry.ModDataComponents;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 通用流体罐：能装 1000 mB 任意流体的小罐子。
 *
 * <p>整个模组<b>只有这一个</b>罐子物品 id（{@code aftercritical:universal_fluid_tank}）。
 * 装满之后靠数据组件记住「装的是什么流体、多少 mB」，所以「水罐 / 氢罐 / 硫酸罐」
 * 其实是同一件物品：贴图共用一张罐体，液面那一层按流体颜色染色，
 * 物品名自动变成「水流体罐」「硫酸流体罐」。
 *
 * <p>堆叠规则（用的是 1.21 的组件相等判断，不需要自己写）：
 * <ul>
 *   <li>空罐：身上没有任何组件，所以空罐和空罐全是同一件东西 → 叠 64；</li>
 *   <li>装了同一种流体、同样是 1000 mB 的罐子：组件一模一样 → 叠 64；</li>
 *   <li>装的流体不同、或者装得多少不同：组件不一样 → 不会叠在一起。</li>
 * </ul>
 *
 * <p>除了装流体，它还能被<b>预设</b>：用流体识别码在识别码界面里给空罐盖个章，
 * 这个罐子以后只接受那一种流体（专管专用，防止管道把别的东西灌进来）。
 *
 * <p>右键怎么走（都在 {@link #onItemUseFirst} 里判断，比方块自己的右键更早）：
 * <ol>
 *   <li>点到的方块身上有流体接口（我们的机器、别的模组的罐子）：
 *       空罐就从「输出槽」那边装，装多少算多少；装满的罐就往「输入槽」里倒；</li>
 *   <li>点到的是世界里的流体源方块（水、岩浆、我们的 16 种流体）：
 *       空罐舀满，源方块消失（和用桶舀水一样）；</li>
 *   <li>都不是：什么都不做，右键交给方块自己处理（比如打开机器界面）。</li>
 * </ol>
 *
 * <p>机器界面里的「罐子槽」也会自动和机器装/卸；对着界面里的长条右键是快捷操作。
 * 罐子倒空之后变回空罐（不消耗罐子本身），装满同一种流体的罐子可以叠到 64 个。
 */
public class UniversalTankItem extends Item {

    /** 一个罐子装多少 mB。 */
    public static final int CAPACITY = 1000;

    public UniversalTankItem(Properties properties) {
        super(properties);
    }

    // ------------------------------------------------------------------
    // 读、写罐子里的东西
    // ------------------------------------------------------------------

    /** 这个罐子里装的流体；空罐返回 {@link FluidStack#EMPTY}。 */
    public static FluidStack getFluid(ItemStack stack) {
        if (!(stack.getItem() instanceof UniversalTankItem)) {
            return FluidStack.EMPTY;
        }
        TankContent stored = stack.get(ModDataComponents.FLUID.get());
        return stored == null ? FluidStack.EMPTY : stored.toStack();
    }

    /** 罐子是不是装了东西。 */
    public static boolean isFilled(ItemStack stack) {
        return !getFluid(stack).isEmpty();
    }

    /** 这个罐子预设的流体；没预设返回 {@code null}（表示「什么都能装」）。 */
    @Nullable
    public static Fluid getPreset(ItemStack stack) {
        if (!(stack.getItem() instanceof UniversalTankItem)) {
            return null;
        }
        TankContent preset = stack.get(ModDataComponents.PRESET_FLUID.get());
        return preset == null ? null : preset.fluidValue();
    }

    /** 给空罐预设一种流体；传 {@code null} 就是取消预设。 */
    public static void setPreset(ItemStack stack, @Nullable Fluid fluid) {
        if (fluid == null) {
            stack.remove(ModDataComponents.PRESET_FLUID.get());
        } else {
            // 只借这个组件记「是哪种流体」，数量给 1 mB 占个位，不参与任何运算
            stack.set(ModDataComponents.PRESET_FLUID.get(), new TankContent(fluid.builtInRegistryHolder(), 1));
        }
    }

    /**
     * 这个罐子收不收 {@code fluid}。
     *
     * <p>三种情况收：罐子是空的且没预设（万能罐）、预设的就是这种流体、
     * 罐子里装的本来就是这种流体（往里续）。
     */
    public static boolean accepts(ItemStack stack, Fluid fluid) {
        if (!(stack.getItem() instanceof UniversalTankItem)) {
            return false;
        }
        FluidStack stored = getFluid(stack);
        if (!stored.isEmpty()) {
            return stored.getFluid().isSame(fluid);
        }
        Fluid preset = getPreset(stack);
        return preset == null || preset.isSame(fluid);
    }

    /** 这个罐子还能装多少 mB（不是罐子就是 0）。 */
    public static int freeSpace(ItemStack stack) {
        if (!(stack.getItem() instanceof UniversalTankItem)) {
            return 0;
        }
        return CAPACITY - getFluid(stack).getAmount();
    }

    /** 造一个装着 {@code amount} mB {@code fluid} 的罐子。 */
    public static ItemStack create(Fluid fluid, int amount) {
        ItemStack stack = new ItemStack(ModItems.UNIVERSAL_FLUID_TANK.get());
        if (fluid != null && amount > 0) {
            stack.set(ModDataComponents.FLUID.get(),
                    new TankContent(fluid.builtInRegistryHolder(), Math.min(amount, CAPACITY)));
        }
        return stack;
    }

    /**
     * 在 {@code stack} 的基础上改成「装着 amount mB 的 fluid」，返回新的一格。
     *
     * <p>预设章会保留；数量归零就变回空罐。
     */
    public static ItemStack withFluid(ItemStack stack, Fluid fluid, int amount) {
        ItemStack result = stack.copyWithCount(1);
        if (amount <= 0) {
            result.remove(ModDataComponents.FLUID.get());
        } else {
            result.set(ModDataComponents.FLUID.get(),
                    new TankContent(fluid.builtInRegistryHolder(), Math.min(amount, CAPACITY)));
        }
        return result;
    }

    /** 一个空罐。 */
    public static ItemStack empty() {
        return new ItemStack(ModItems.UNIVERSAL_FLUID_TANK.get());
    }

    // ------------------------------------------------------------------
    // 右键空气：和另一只手上的识别码配合，给空罐打预设
    // ------------------------------------------------------------------

    /**
     * 右手拿空罐、左手拿识别码，右键空气 → 罐子被预设成识别码上那种流体。
     *
     * <p>界面里也能做（识别码界面有个罐子槽），这里多给一条「不用开界面」的路子。
     */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack tank = player.getItemInHand(hand);
        InteractionHand other = hand == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
        ItemStack identifier = player.getItemInHand(other);
        if (!(identifier.getItem() instanceof FluidIdentifierItem)) {
            return InteractionResultHolder.pass(tank);
        }
        Fluid bound = FluidIdentifierItem.boundFluid(identifier);
        if (bound == null || isFilled(tank)) {
            return InteractionResultHolder.pass(tank);
        }
        if (!level.isClientSide) {
            setPreset(tank, bound);
            player.displayClientMessage(Component.translatable(
                    "message.aftercritical.universal_tank.preset",
                    new FluidStack(bound, 1).getHoverName()), true);
            level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.PLAYERS, 0.7F, 1.4F);
        }
        return InteractionResultHolder.sidedSuccess(tank, level.isClientSide);
    }

    // ------------------------------------------------------------------
    // 右键
    // ------------------------------------------------------------------

    @Override
    public InteractionResult onItemUseFirst(ItemStack stack, UseOnContext context) {
        Level level = context.getLevel();
        Player player = context.getPlayer();
        if (player == null) {
            return InteractionResult.PASS;
        }
        boolean changed = interact(level, context.getClickedPos(), context.getClickedFace(),
                player, context.getHand(), stack, !level.isClientSide);
        return changed ? InteractionResult.sidedSuccess(level.isClientSide) : InteractionResult.PASS;
    }

    /**
     * 真正干活的地方。
     *
     * @param server 只有服务端才真的改世界、改物品，客户端只做一遍「模拟」让手臂摆动一致
     * @return 做成了就返回 true
     */
    private boolean interact(Level level, BlockPos pos, Direction face, Player player, InteractionHand hand,
                             ItemStack held, boolean server) {
        FluidStack stored = getFluid(held);
        IFluidHandler handler = level.getCapability(Capabilities.FluidHandler.BLOCK, pos, face);
        if (stored.isEmpty()) {
            if (handler != null) {
                return takeFromHandler(level, pos, player, hand, held, handler, server);
            }
            return takeFromWorld(level, pos, player, hand, held, server);
        }
        return handler != null && pourInto(level, pos, player, hand, held, stored, handler, server);
    }

    /**
     * 从方块里装进罐子（机器的话走的就是「出液长条」）。
     *
     * <p>有多少装多少：机器里只剩 300 mB 也能装走，不会硬要 1000。
     */
    private boolean takeFromHandler(Level level, BlockPos pos, Player player, InteractionHand hand,
                                    ItemStack held, IFluidHandler handler, boolean server) {
        FluidStack probe = handler.drain(CAPACITY, IFluidHandler.FluidAction.SIMULATE);
        if (probe.isEmpty()) {
            return false;
        }
        if (!accepts(held, probe.getFluid())) {
            return false;
        }
        if (server) {
            FluidStack drained = handler.drain(CAPACITY, IFluidHandler.FluidAction.EXECUTE);
            if (drained.isEmpty()) {
                return false;
            }
            replaceHeld(player, hand, held, withFluid(held, drained.getFluid(), drained.getAmount()));
            level.playSound(null, pos, SoundEvents.BUCKET_FILL, SoundSource.BLOCKS, 1.0F, 1.0F);
        }
        return true;
    }

    /**
     * 把罐子里的流体倒进方块（机器的进液长条）。
     *
     * <p>倒空的那一格会变回空罐，而不是被吃掉。
     */
    private boolean pourInto(Level level, BlockPos pos, Player player, InteractionHand hand, ItemStack held,
                             FluidStack stored, IFluidHandler handler, boolean server) {
        FluidStack offer = stored.copyWithAmount(Math.min(stored.getAmount(), CAPACITY));
        if (handler.fill(offer.copy(), IFluidHandler.FluidAction.SIMULATE) <= 0) {
            return false;
        }
        if (server) {
            int filled = handler.fill(offer.copy(), IFluidHandler.FluidAction.EXECUTE);
            if (filled <= 0) {
                return false;
            }
            int remaining = stored.getAmount() - filled;
            replaceHeld(player, hand, held, withFluid(held, stored.getFluid(), remaining));
            level.playSound(null, pos, SoundEvents.BUCKET_EMPTY, SoundSource.BLOCKS, 1.0F, 1.0F);
        }
        return true;
    }

    /** 从世界里的流体源方块舀满一格（水、岩浆、模组流体都行）。 */
    private boolean takeFromWorld(Level level, BlockPos pos, Player player, InteractionHand hand,
                                  ItemStack held, boolean server) {
        FluidState state = level.getBlockState(pos).getFluidState();
        if (state.isEmpty() || !state.isSource()) {
            return false;
        }
        Fluid fluid = state.getType();
        if (!accepts(held, fluid)) {
            return false;
        }
        if (server) {
            // 和原版桶一样：舀走源头，四周的流体会自己流回来（只拿一个源头）
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), 11);
            replaceHeld(player, hand, held, withFluid(held, fluid, CAPACITY));
            level.playSound(null, pos, SoundEvents.BUCKET_FILL, SoundSource.BLOCKS, 1.0F, 1.0F);
        }
        return true;
    }

    /**
     * 把手上那一格换成 {@code result}：一叠的少一个、把新的塞回背包（塞不下就丢脚下）。
     *
     * <p>这里必须「一格换一格」。以前创造模式直接 {@code setItemInHand(result)}，
     * 而 {@code result} 永远是 1 个，于是手里拿着 64 个罐子右键机器时，
     * 63 个罐子凭空消失、机器里却只进了 1 个罐子的量——玩家反馈的就是这个。
     * 罐子本来就不该被「吃掉」：倒空 / 装满只是换了个内容物，数量要守恒。
     */
    private static void replaceHeld(Player player, InteractionHand hand, ItemStack held, ItemStack result) {
        if (held.getCount() <= 1) {
            player.setItemInHand(hand, result);
            return;
        }
        held.shrink(1);
        if (!player.getInventory().add(result)) {
            player.drop(result, false);
        }
    }

    // ------------------------------------------------------------------
    // 名字、提示与外观
    // ------------------------------------------------------------------

    /**
     * 装满的罐子直接叫「水流体罐」「硫酸流体罐」；预设过但还空着叫「预设氢罐」。
     *
     * <p>物品 id 还是同一个，只有显示名跟着内容物 / 预设走。
     */
    @Override
    public Component getName(ItemStack stack) {
        FluidStack stored = getFluid(stack);
        if (!stored.isEmpty()) {
            return Component.translatable("item.aftercritical.universal_tank.filled", stored.getHoverName());
        }
        Fluid preset = getPreset(stack);
        if (preset != null) {
            return Component.translatable("item.aftercritical.universal_tank.preset",
                    new FluidStack(preset, 1).getHoverName());
        }
        return super.getName(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context,
                                List<Component> tooltip, TooltipFlag flag) {
        FluidStack stored = getFluid(stack);
        if (stored.isEmpty()) {
            tooltip.add(Component.translatable("tooltip.aftercritical.universal_tank.empty")
                    .withStyle(ChatFormatting.GRAY));
        } else {
            tooltip.add(Component.translatable("tooltip.aftercritical.universal_tank.content",
                            stored.getHoverName().getString(), stored.getAmount(), CAPACITY)
                    .withStyle(ChatFormatting.GRAY));
        }
        Fluid preset = getPreset(stack);
        if (preset != null) {
            tooltip.add(Component.translatable("tooltip.aftercritical.universal_tank.preset",
                            new FluidStack(preset, 1).getHoverName().getString())
                    .withStyle(ChatFormatting.AQUA));
        }
        tooltip.add(Component.translatable("tooltip.aftercritical.universal_tank.hint")
                .withStyle(ChatFormatting.DARK_GRAY));
    }

    /** 装了东西就画一条小进度条（底下的耐久条位置）。 */
    @Override
    public boolean isBarVisible(ItemStack stack) {
        return isFilled(stack);
    }

    @Override
    public int getBarWidth(ItemStack stack) {
        FluidStack stored = getFluid(stack);
        return Math.round(MAX_BAR_WIDTH * Math.min(1.0F, stored.getAmount() / (float) CAPACITY));
    }

    /** 进度条颜色跟着里面的流体走。 */
    @Override
    public int getBarColor(ItemStack stack) {
        FluidStack stored = getFluid(stack);
        return stored.isEmpty() ? 0xFFFFFFFF : ModFluids.colorOf(stored.getFluid());
    }

    /** 客户端用：这个罐子该染成什么颜色（空罐是原色，预设罐染成预设的颜色）。 */
    @Nullable
    public static Integer tintOf(ItemStack stack) {
        FluidStack stored = getFluid(stack);
        if (!stored.isEmpty()) {
            return ModFluids.colorOf(stored.getFluid());
        }
        Fluid preset = getPreset(stack);
        return preset == null ? null : ModFluids.colorOf(preset);
    }
}
