package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.energy.MachineEnergyStorage;
import cn.blockforge.generated.aftercritical.energy.RatedEnergyConsumer;
import cn.blockforge.generated.aftercritical.itemhandler.ContainerItemHandler;
import cn.blockforge.generated.aftercritical.menu.AssemblerT1Menu;
import cn.blockforge.generated.aftercritical.recipe.AssemblerIngredient;
import cn.blockforge.generated.aftercritical.recipe.AssemblerRecipe;
import cn.blockforge.generated.aftercritical.recipe.AssemblerRecipeInput;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import cn.blockforge.generated.aftercritical.registry.ModRecipes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.items.IItemHandler;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 装配机 T1：LV 机器，额定 50 FE/t，10,000 FE 缓存。
 *
 * <p>和破碎机那三台的差别：装配机一次要吃好几种原料（电路板、金粒、红石、玻璃……），
 * 所以有 6 个普通输入槽 + 1 个「流体槽」（放硫酸桶这类瓶装化学品）+ 1 个输出槽。
 *
 * <p>配方来自 {@link ModRecipes#ASSEMBLER}（JSON 在 {@code data/aftercritical/recipe/assembling/}），
 * 每条配方自己规定了要多少 tick、每 tick 吃多少电。
 */
public class AssemblerT1BlockEntity extends BlockEntity
        implements MenuProvider, EnergyMachineHost, TickableBlockEntity, RatedEnergyConsumer {

    /** 6 个普通输入槽：0 ~ 5。 */
    public static final int SLOT_INPUT_FIRST = 0;
    public static final int INPUT_SLOT_COUNT = 6;

    /** 输出槽。 */
    public static final int SLOT_OUTPUT = 6;
    /** 流体槽：只收装好的化学品（比如硫酸桶），用法和普通输入槽一样，只是位置单独摆。 */
    public static final int SLOT_FLUID = 7;
    public static final int SLOT_COUNT = 8;

    /** 额定运行功率：50 FE/t（最终定稿 v4）。配方可以在 JSON 里单独写更高的耗电。 */
    public static final int ENERGY_PER_TICK = 50;
    public static final int ENERGY_CAPACITY = 10_000;
    public static final int MAX_PULL_PER_TICK = 512;

    private final MachineEnergyStorage energy =
            new MachineEnergyStorage(ENERGY_CAPACITY, MAX_PULL_PER_TICK, this::setChanged);
    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);

    /**
     * 给物品管道用的物品接口。
     *
     * <p>能往 6 个输入槽和流体槽塞原料，只能从输出槽抽成品。
     */
    private final IItemHandler itemHandler = new ContainerItemHandler(this,
            slot -> (slot >= SLOT_INPUT_FIRST && slot < SLOT_INPUT_FIRST + INPUT_SLOT_COUNT) || slot == SLOT_FLUID,
            slot -> slot == SLOT_OUTPUT);

    private int progress;
    private int maxProgress;
    private int activeEnergyPerTick;
    private int status = STATUS_IDLE;

    @Nullable
    private AssemblerRecipe activeRecipe;

    public AssemblerT1BlockEntity(BlockPos pos, BlockState state) {
        this(ModBlockEntities.ASSEMBLER_T1.get(), pos, state);
    }

    /**
     * 给子类（装配机 T2）用的构造器：方块实体类型由子类自己指定。
     *
     * <p>两种装配机的加工逻辑一模一样，只有「额定功率、界面标题、菜单类型」不同，
     * 所以 T2 直接继承 T1，用几个 protected 方法把不一样的地方换掉。
     */
    protected AssemblerT1BlockEntity(net.minecraft.world.level.block.entity.BlockEntityType<?> type,
                                     BlockPos pos, BlockState state) {
        super(type, pos, state);
        this.activeEnergyPerTick = baseEnergyPerTick();
    }

    /** 这台装配机的额定功率，FE/t；T1 是 50，T2 覆盖成 100。 */
    protected int baseEnergyPerTick() {
        return ENERGY_PER_TICK;
    }

    /**
     * 这台装配机能做几级配方：T1 = 1，T2 = 2。
     *
     * <p>配方 JSON 里的 {@code "tier"} 大于这个数的，T1 根本看不见，
     * 也就不可能出现「T1 直接把 HV 线缆造出来」这种事。
     */
    protected int machineTier() {
        return ASSEMBLER_TIER;
    }

    /** 装配机 T1 的配方等级。 */
    public static final int ASSEMBLER_TIER = 1;

    /** 打开哪个菜单（T1 / T2 各一个）。 */
    protected net.minecraft.world.inventory.MenuType<?> menuType() {
        return ModMenus.ASSEMBLER_T1.get();
    }

    /** 界面标题和物品提示用的语言键。 */
    protected String titleKey() {
        return "container.aftercritical.assembler_t1";
    }

    public IEnergyStorage getEnergyStorage() {
        return this.energy;
    }

    /** 对外暴露的物品接口：物品管道从这里塞原料、抽成品。 */
    public IItemHandler getItemHandler() {
        return this.itemHandler;
    }

    /** 线缆用它判断自己扛不扛得住：装配机 T1 额定 50 FE/t，T2 是 100 FE/t。 */
    @Override
    public int ratedEnergyPerTick() {
        return baseEnergyPerTick();
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        pullEnergyFromNeighbours();

        AssemblerRecipe recipe = findRecipe();
        if (recipe != this.activeRecipe) {
            boolean restoredFromSave = this.activeRecipe == null && this.progress > 0;
            this.activeRecipe = recipe;
            this.maxProgress = recipe == null ? 0 : recipe.duration();
            this.activeEnergyPerTick = recipe == null ? baseEnergyPerTick() : recipe.energyPerTick();
            if (!restoredFromSave) {
                this.progress = 0;
            }
            this.progress = Math.min(this.progress, this.maxProgress);
            setChanged();
        }

        boolean outputBlocked = false;
        boolean working = false;

        if (recipe != null) {
            if (!canOutput(recipe)) {
                outputBlocked = true;
            } else if (this.energy.getEnergyStored() >= this.activeEnergyPerTick) {
                this.energy.consume(this.activeEnergyPerTick);
                this.progress++;
                working = true;
                if (this.progress >= this.maxProgress) {
                    craft(recipe);
                    this.progress = 0;
                }
                setChanged();
            }
        }

        int newStatus;
        if (working) {
            newStatus = STATUS_RUNNING;
        } else if (recipe == null) {
            newStatus = STATUS_IDLE;
        } else if (outputBlocked) {
            newStatus = STATUS_OUTPUT_BLOCKED;
        } else {
            newStatus = STATUS_NO_ENERGY;
        }
        if (this.status != newStatus) {
            this.status = newStatus;
            setChanged();
        }
    }

    /** 在配方表里找一条「这 7 个槽能凑齐」的装配配方。 */
    @Nullable
    public AssemblerRecipe findRecipe() {
        if (this.level == null) {
            return null;
        }
        AssemblerRecipeInput input = snapshotInput();
        if (input.isEmpty()) {
            return null;
        }
        List<RecipeHolder<AssemblerRecipe>> recipes =
                this.level.getRecipeManager().getAllRecipesFor(ModRecipes.ASSEMBLER);
        for (RecipeHolder<AssemblerRecipe> holder : recipes) {
            AssemblerRecipe recipe = holder.value();
            if (!recipe.canCraftOn(machineTier())) {
                continue;
            }
            if (recipe.matches(input, this.level)) {
                return recipe;
            }
        }
        return null;
    }

    /** 把 6 个输入槽 + 流体槽里的东西打包成一份「原料快照」。 */
    private AssemblerRecipeInput snapshotInput() {
        List<ItemStack> stacks = new ArrayList<>(INPUT_SLOT_COUNT + 1);
        for (int i = 0; i < INPUT_SLOT_COUNT; i++) {
            stacks.add(this.items.get(SLOT_INPUT_FIRST + i));
        }
        stacks.add(this.items.get(SLOT_FLUID));
        return new AssemblerRecipeInput(stacks);
    }

    /** 第 i 个输入槽（0 ~ 5 是普通槽，6 是流体槽）对应的真实槽号。 */
    private static int slotForInputIndex(int index) {
        return index < INPUT_SLOT_COUNT ? SLOT_INPUT_FIRST + index : SLOT_FLUID;
    }

    /** 输出槽放得下这条配方的产物吗（空格子，或同一种物品且没堆满）。 */
    public boolean canOutput(AssemblerRecipe recipe) {
        if (this.level == null) {
            return false;
        }
        ItemStack result = recipe.getResultItem(this.level.registryAccess());
        if (result.isEmpty()) {
            return true;
        }
        ItemStack existing = this.items.get(SLOT_OUTPUT);
        if (existing.isEmpty()) {
            return true;
        }
        if (!ItemStack.isSameItemSameComponents(existing, result)) {
            return false;
        }
        int limit = Math.min(existing.getMaxStackSize(), result.getMaxStackSize());
        return existing.getCount() + result.getCount() <= limit;
    }

    /** 完成一次装配：扣掉每种原料，把产物放进输出槽。 */
    private void craft(AssemblerRecipe recipe) {
        if (this.level == null) {
            return;
        }
        boolean[] used = new boolean[INPUT_SLOT_COUNT + 1];
        for (AssemblerIngredient spec : recipe.ingredients()) {
            for (int i = 0; i < used.length; i++) {
                if (used[i]) {
                    continue;
                }
                int slot = slotForInputIndex(i);
                ItemStack stack = this.items.get(slot);
                if (spec.test(stack)) {
                    used[i] = true;
                    stack.shrink(spec.count());
                    if (stack.isEmpty()) {
                        this.items.set(slot, ItemStack.EMPTY);
                    }
                    break;
                }
            }
        }

        ItemStack result = recipe.getResultItem(this.level.registryAccess());
        ItemStack existing = this.items.get(SLOT_OUTPUT);
        if (existing.isEmpty()) {
            this.items.set(SLOT_OUTPUT, result);
        } else {
            existing.grow(result.getCount());
        }
        setChanged();
    }

    /** 从六个方向挨个问邻居要电，能抽多少算多少。 */
    private void pullEnergyFromNeighbours() {
        if (this.level == null) {
            return;
        }
        int space = this.energy.getFreeSpace();
        if (space <= 0) {
            return;
        }
        int budget = Math.min(space, MAX_PULL_PER_TICK);
        for (Direction side : Direction.values()) {
            if (budget <= 0) {
                break;
            }
            IEnergyStorage source = this.level.getCapability(
                    Capabilities.EnergyStorage.BLOCK, this.worldPosition.relative(side), side.getOpposite());
            if (source == null || !source.canExtract()) {
                continue;
            }
            int moved = source.extractEnergy(budget, true);
            if (moved <= 0) {
                continue;
            }
            moved = source.extractEnergy(moved, false);
            if (moved > 0) {
                this.energy.receiveEnergy(moved, false);
                budget -= moved;
            }
        }
    }

    // ------------------------------------------------------------------
    // GUI 数据
    // ------------------------------------------------------------------

    @Override
    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    @Override
    public int getEnergyCapacity() {
        return this.energy.getMaxEnergyStored();
    }

    @Override
    public int getStatus() {
        return this.status;
    }

    @Override
    public int getProgress() {
        return this.progress;
    }

    @Override
    public int getMaxProgress() {
        return this.maxProgress;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable(titleKey());
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new AssemblerT1Menu(menuType(), containerId, playerInventory, this);
    }

    // ------------------------------------------------------------------
    // 物品槽
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return this.items.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        stack.limitSize(getMaxStackSize(stack));
        setChanged();
    }

    /** 输出槽谁都塞不进去；化学品槽只收通用流体罐（配方里写的是「装着某种液体的罐子」）。 */
    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        if (slot == SLOT_OUTPUT) {
            return false;
        }
        if (slot == SLOT_FLUID) {
            return stack.getItem() instanceof UniversalTankItem;
        }
        return true;
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
        tag.putInt("Progress", this.progress);
        tag.putInt("MaxProgress", this.maxProgress);
        tag.putInt("EnergyPerTick", this.activeEnergyPerTick);
        tag.putInt("Status", this.status);
        ContainerHelper.saveAllItems(tag, this.items, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
        this.progress = tag.getInt("Progress");
        this.maxProgress = tag.getInt("MaxProgress");
        this.activeEnergyPerTick = tag.contains("EnergyPerTick")
                ? tag.getInt("EnergyPerTick")
                : baseEnergyPerTick();
        this.status = tag.getInt("Status");
        ContainerHelper.loadAllItems(tag, this.items, registries);
    }
}
