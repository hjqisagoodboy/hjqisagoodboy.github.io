package cn.blockforge.generated.aftercritical.recipe;

import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * 装配机 T1 的配方：好几种原料 + 一样产物。
 *
 * <p>和 {@link MachineRecipe} 的区别：那边一次只吃一种原料（矿石→粉），
 * 这边要同时吃好几种（电路板 T1 ×2、金粒 ×2、红石 ×4、玻璃 ×1……），
 * 每行还带自己的数量。
 *
 * <p>配方写在 {@code data/aftercritical/recipe/assembling/} 下，例如：
 * <pre>{@code
 * {
 *   "type": "aftercritical:assembler",
 *   "ingredients": [
 *     {"ingredient": {"item": "aftercritical:circuit_board_t1"}, "count": 2},
 *     {"ingredient": {"item": "minecraft:gold_nugget"}, "count": 2}
 *   ],
 *   "result": {"id": "aftercritical:circuit_board_t2", "count": 1},
 *   "time": 200,
 *   "energy": 100
 * }
 * }</pre>
 */
public final class AssemblerRecipe implements Recipe<AssemblerRecipeInput> {

    private final List<AssemblerIngredient> ingredients;
    private final ItemStack result;
    private final int duration;
    private final int energyPerTick;
    private final int tier;
    private final AssemblerRecipeSerializer serializer;

    public AssemblerRecipe(List<AssemblerIngredient> ingredients, ItemStack result, int duration,
                           int energyPerTick, int tier, AssemblerRecipeSerializer serializer) {
        this.ingredients = List.copyOf(ingredients);
        this.result = result;
        this.duration = Math.max(1, duration);
        this.energyPerTick = Math.max(1, energyPerTick);
        this.tier = Math.max(1, tier);
        this.serializer = serializer;
    }

    /**
     * 输入槽里的东西能不能凑齐这条配方的全部原料。
     *
     * <p>做法很朴素：一种原料一种原料地找空格子，一个格子只能用一次。
     * 这样同一种物品分两堆放（比如两次各放 1 个电路板）也能凑成「要 2 个」。
     */
    @Override
    public boolean matches(AssemblerRecipeInput input, Level level) {
        boolean[] used = new boolean[input.size()];
        for (AssemblerIngredient spec : this.ingredients) {
            boolean found = false;
            for (int i = 0; i < input.size(); i++) {
                if (used[i]) {
                    continue;
                }
                if (spec.test(input.getItem(i))) {
                    used[i] = true;
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack assemble(AssemblerRecipeInput input, HolderLookup.Provider registries) {
        return this.result.copy();
    }

    @Override
    public ItemStack getResultItem(HolderLookup.Provider registries) {
        return this.result.copy();
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return true;
    }

    @Override
    public boolean isSpecial() {
        return true;
    }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        NonNullList<Ingredient> list = NonNullList.create();
        for (AssemblerIngredient spec : this.ingredients) {
            list.add(spec.ingredient());
        }
        return list;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return this.serializer;
    }

    @Override
    public RecipeType<?> getType() {
        return this.serializer.type();
    }

    public List<AssemblerIngredient> ingredients() {
        return this.ingredients;
    }

    public ItemStack result() {
        return this.result;
    }

    /** 加工时长，单位 tick（20 tick = 1 秒）。 */
    public int duration() {
        return this.duration;
    }

    /** 这条配方加工时每 tick 吃多少 FE。 */
    public int energyPerTick() {
        return this.energyPerTick;
    }

    /**
     * 这条配方要几级装配机才做得出来：1 = 装配机 T1，2 = 装配机 T2。
     *
     * <p>以前两种装配机共用一份配方表，结果 T1 也能造 T2 专属的东西（HV 线缆、
     * 变压器 MV→HV、电路板 T3……），等于跳过了造 T2 机器的理由。
     * 现在每条配方自带等级，低等级的机器会直接跳过它，界面里也看不到。
     */
    public int tier() {
        return this.tier;
    }

    /** 这台机器（按等级）能不能做这条配方。 */
    public boolean canCraftOn(int machineTier) {
        return machineTier >= this.tier;
    }
}
