package cn.blockforge.generated.aftercritical.energy;

import cn.blockforge.generated.aftercritical.AfterCritical;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;

/**
 * 服务端关掉时把无线供电网的名单清空。
 *
 * <p>不清也不会算错（端口会按维度 + 方块实体是否失效自动淘汰），但会一直攥着上一局
 * 那个存档的方块实体不放，单人切存档就是一次内存泄漏，所以干脆在 ServerStopped 时倒干净。
 */
@EventBusSubscriber(modid = AfterCritical.MOD_ID)
public final class WirelessGridEvents {

    private WirelessGridEvents() {}

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        WirelessEnergyGrid.clearAll();
        CableNetwork.clearAll();
    }
}
