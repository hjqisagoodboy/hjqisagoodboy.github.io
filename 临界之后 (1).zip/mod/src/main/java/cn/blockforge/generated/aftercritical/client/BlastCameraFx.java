package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.network.BlastFxState;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

/**
 * 核爆时镜头本身的反应：视野冲击 + 镜头抖动。
 *
 * <p>这两样改的不是屏幕上的贴图，而是「镜头」这个虚拟相机——所以它们是唯一能在
 * 光影 mod、第一人称手部模型、第三人称视角上全都生效的做法。
 *
 * <h2>视野冲击</h2>
 * 改的是 FOV（视野角度）。爆炸瞬间把视野推宽，等于「眼睛一下适应不过来」，
 * 然后像弹簧一样弹回来，中途还会往窄的方向过冲一点点，2.5 秒内回正。
 *
 * <h2>镜头抖</h2>
 * 改的是相机的偏航 / 俯仰 / 滚转。三个方向各叠两个不同频率的正弦波，
 * 频率故意错开（5 Hz 和 2 Hz 混在一起），所以不会看出「规律地左右摆」的假动作；
 * 滚转让画面歪一下，是「整台摄影机被冲击波掀到」的感觉。
 * 强度从 0 秒满格，7 秒后开始减，45 秒前彻底停。
 */
@EventBusSubscriber(modid = AfterCritical.MOD_ID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class BlastCameraFx {

    /** 抖动里两个频率的配比：快的那一层占大头，抖起来才「碎」。 */
    private static final double FAST_WEIGHT = 0.62;
    private static final double SLOW_WEIGHT = 0.38;

    /** 上下抖比左右抖略小——人的脖子本来就更少上下晃，太大反而像晕船。 */
    private static final float PITCH_SCALE = 0.80F;

    private BlastCameraFx() {}

    /**
     * 视野冲击：把 FOV 按 {@link BlastFxState#fovPulse()} 推宽。
     *
     * <p>只加不减：{@code setFOV} 是在原版算好的值上叠加，所以玩家的视野设置、
     * 疾跑加速、水下缩小这些原版效果都还在，我们只是叠了一层。
     */
    @SubscribeEvent
    public static void onComputeFov(ViewportEvent.ComputeFov event) {
        float pulse = BlastFxState.fovPulse();
        if (pulse > -0.001F && pulse < 0.001F) {
            return;
        }
        event.setFOV(event.getFOV() + pulse * BlastFxState.MAX_FOV_BOOST);
    }

    /** 镜头抖：按时间叠正弦波，强度走 {@link BlastFxState#shakeAmount()} 的曲线。 */
    @SubscribeEvent
    public static void onComputeCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        float amount = BlastFxState.shakeAmount();
        if (amount <= 0.0005F) {
            return;
        }
        double t = BlastFxState.ageSeconds();
        if (t == Float.MAX_VALUE) {
            return;
        }

        double yawNoise = Math.sin(t * 29.7) * FAST_WEIGHT + Math.sin(t * 13.1 + 1.3) * SLOW_WEIGHT;
        double pitchNoise = Math.sin(t * 24.3 + 0.7) * FAST_WEIGHT
                + Math.sin(t * 9.4 + 2.1) * SLOW_WEIGHT;
        double rollNoise = Math.sin(t * 17.9 + 2.6) * FAST_WEIGHT + Math.sin(t * 7.3) * SLOW_WEIGHT;

        event.setYaw(event.getYaw() + (float) (yawNoise * amount * BlastFxState.MAX_SHAKE_DEGREES));
        event.setPitch(event.getPitch()
                + (float) (pitchNoise * amount * BlastFxState.MAX_SHAKE_DEGREES * PITCH_SCALE));
        event.setRoll(event.getRoll() + (float) (rollNoise * amount * BlastFxState.MAX_ROLL_DEGREES));
    }

    /** 退出世界时把时钟归零，下次进来不会带着上一局的余震。 */
    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        BlastFxState.clear();
    }
}
