package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.BatteryMvBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/** 电池 MV 的 GUI 菜单：没有机器槽，只有电量和玩家背包。 */
public class BatteryMvMenu extends AbstractMachineMenu {

    public BatteryMvMenu(int containerId, Inventory playerInventory, BatteryMvBlockEntity battery) {
        this(containerId, playerInventory, battery, battery);
    }

    public BatteryMvMenu(int containerId, Inventory playerInventory, Container container,
                         @Nullable EnergyMachineHost machine) {
        super(ModMenus.BATTERY_MV.get(), containerId, playerInventory, 0, machine);
        this.addPlayerInventory(playerInventory);
    }

    public static BatteryMvMenu fromNetwork(int containerId, Inventory playerInventory,
                                            RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof BatteryMvBlockEntity battery) {
            return new BatteryMvMenu(containerId, playerInventory, battery);
        }
        return new BatteryMvMenu(containerId, playerInventory, new SimpleContainer(0), null);
    }
}
