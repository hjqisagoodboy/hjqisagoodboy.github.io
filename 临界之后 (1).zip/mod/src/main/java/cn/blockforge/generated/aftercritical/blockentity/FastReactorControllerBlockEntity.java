package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.block.FastReactorControllerBlock;
import cn.blockforge.generated.aftercritical.itemhandler.ContainerItemHandler;
import cn.blockforge.generated.aftercritical.menu.FastReactorMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModBlocks;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;
import net.neoforged.neoforge.items.IItemHandler;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 钠冷快堆控制器：阶段 6 的 7×7×7 多方块。
 *
 * <p>快堆和压水堆的差别只有两句话：
 * <ul>
 *   <li><b>冷却剂是液态钠</b>，不是水——钠不慢化中子，所以能烧 MOX，还能把铀238 撞成钚239；</li>
 *   <li><b>电不在控制器里发</b>：热量送给结构里的【钠-水蒸汽发生器】，由它们各发 3,000 FE/t。</li>
 * </ul>
 *
 * <p>玩法：
 * <ol>
 *   <li>控制器贴在正面墙、贴地那排正中间，方块朝哪堆就往哪长；</li>
 *   <li>7×7×7 的外壳用钢块 / 铅块砌，里面塞 ≥2 个快中子探测器、≥2 个钠-水蒸汽发生器、
 *       ≥2 个控制棒端口（插上控制棒组件）；</li>
 *   <li>控制器界面里放 4~8 个 MOX 燃料组件；</li>
 *   <li>用管道往控制器里灌钠（内部 8,000 mB），钠够、燃料够、控制棒够就自动开堆；</li>
 *   <li>MOX 烧完（10 分钟一支）会在产物槽里留下【乏燃料组件（快堆）】，
 *       拿回后处理线又能榨出钚239，闭环就成了。</li>
 * </ol>
 */
public class FastReactorControllerBlockEntity extends BlockEntity
        implements Container, net.minecraft.world.MenuProvider, TickableBlockEntity {

    // ------------------------------------------------------------------
    // 结构
    // ------------------------------------------------------------------

    public static final int SIZE_W = 7;
    public static final int SIZE_D = 7;
    public static final int SIZE_H = 7;

    /** 外壳（钢块 + 铅块）至少多少块。 */
    public static final int MIN_SHELL = 150;
    /** 快中子探测器至少几个。 */
    public static final int MIN_DETECTORS = 2;
    /** 钠-水蒸汽发生器至少几台。 */
    public static final int MIN_GENERATORS = 2;
    /** 控制棒端口至少几个。 */
    public static final int MIN_ROD_PORTS = 2;

    /** 结构每 2 秒重查一次。 */
    public static final int VALIDATE_INTERVAL = 40;

    // ------------------------------------------------------------------
    // 数值（定稿 v4）
    // ------------------------------------------------------------------

    /** 一台钠-水蒸汽发生器满热时的输出。 */
    public static final int OUTPUT_PER_GENERATOR = 3_000;
    /** 界面里放 MOX 燃料组件的格子数。 */
    public static final int FUEL_SLOTS = 8;
    /** 产物槽：烧完的乏燃料组件（快堆）。 */
    public static final int SLOT_OUTPUT = FUEL_SLOTS;
    public static final int SLOT_COUNT = FUEL_SLOTS + 1;
    /** 至少 4 个 MOX 组件才能开堆。 */
    public static final int MIN_FUEL = 4;
    /** 钠罐容量：8,000 mB。 */
    public static final int SODIUM_CAPACITY = 8_000;
    /** 每 tick 吃掉多少钠。 */
    public static final int SODIUM_PER_TICK = 1;
    /** 一个 MOX 组件烧多少 tick（10 分钟）。 */
    public static final int BURN_TICKS = 12_000;
    /** 控制棒插到底时功率压到一半。 */
    public static final double ROD_REDUCTION = 0.5D;

    // ------------------------------------------------------------------
    // 界面状态码
    // ------------------------------------------------------------------

    public static final int STATUS_UNFORMED = 0;
    public static final int STATUS_NO_FUEL = 1;
    public static final int STATUS_NO_RODS = 2;
    public static final int STATUS_NO_SODIUM = 3;
    public static final int STATUS_RUNNING = 4;
    public static final int STATUS_OUTPUT_FULL = 5;
    public static final int STATUS_IDLE = 6;

    // ------------------------------------------------------------------
    // 状态
    // ------------------------------------------------------------------

    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);
    private final FluidTank sodiumTank = new FluidTank(SODIUM_CAPACITY);

    private final IItemHandler itemHandler = new ContainerItemHandler(this,
            slot -> slot >= 0 && slot < FUEL_SLOTS,
            slot -> slot == SLOT_OUTPUT);

    private boolean formed;
    private int shellCount;
    private int detectorCount;
    private int generatorCount;
    private int rodPortCount;
    private int validateTimer;

    private List<BlockPos> detectors = List.of();
    private List<BlockPos> generators = List.of();
    private List<BlockPos> rodPorts = List.of();

    /** 控制棒插入深度 0~100%。 */
    private int rodDepth;
    /** 这一支 MOX 已经烧了多少 tick。 */
    private int burnProgress;
    private int fuelCount;
    private int rodCount;
    private int status = STATUS_UNFORMED;
    /** 每 tick 实际送给发生器的热量（千分数，1000 = 满热）。 */
    private int heatPermille;

    /** 成就「快堆临界」只记一次。 */
    private boolean runMilestoneFired;

    private final IFluidHandler fluidHandler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return 1;
        }

        @Override
        public FluidStack getFluidInTank(int tank) {
            return sodiumTank.getFluid();
        }

        @Override
        public int getTankCapacity(int tank) {
            return SODIUM_CAPACITY;
        }

        @Override
        public boolean isFluidValid(int tank, FluidStack stack) {
            return stack.getFluid().isSame(ModFluids.SODIUM.source.get());
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            if (!isFluidValid(0, resource)) {
                return 0;
            }
            int filled = sodiumTank.fill(resource, action);
            if (filled > 0) {
                setChanged();
            }
            return filled;
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            // 钠是初级冷却剂，只进不出（免得玩家把钠抽回去当电池用）
            return FluidStack.EMPTY;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            return FluidStack.EMPTY;
        }
    };

    public FastReactorControllerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.FAST_REACTOR_CONTROLLER.get(), pos, state);
    }

    public IFluidHandler getFluidHandler() {
        return this.fluidHandler;
    }

    /**
     * 手拿通用流体罐右键：罐子里是钠就往堆里灌，灌多少算多少。
     *
     * <p>没接管道的时候靠它先把钠加进去，新手不至于卡在「怎么把钠弄进堆里」。
     *
     * @return 真的灌进去了返回 true
     */
    public boolean fillSodiumFromHand(net.minecraft.world.entity.player.Player player,
                                      net.minecraft.world.InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (!(held.getItem() instanceof cn.blockforge.generated.aftercritical.item.UniversalTankItem)) {
            return false;
        }
        FluidStack stored = cn.blockforge.generated.aftercritical.item.UniversalTankItem.getFluid(held);
        if (stored.isEmpty() || !stored.getFluid().isSame(ModFluids.SODIUM.source.get())) {
            return false;
        }
        int filled = this.sodiumTank.fill(stored, IFluidHandler.FluidAction.EXECUTE);
        if (filled <= 0) {
            return false;
        }
        ItemStack leftover = cn.blockforge.generated.aftercritical.item.UniversalTankItem.withFluid(
                held, stored.getFluid(), stored.getAmount() - filled);
        if (held.getCount() <= 1) {
            player.setItemInHand(hand, leftover);
        } else {
            held.shrink(1);
            if (!player.getInventory().add(leftover)) {
                player.drop(leftover, false);
            }
        }
        setChanged();
        return true;
    }

    public IItemHandler getItemHandler() {
        return this.itemHandler;
    }

    public void validateSoon() {
        this.validateTimer = 1;
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        if (--this.validateTimer <= 0) {
            this.validateTimer = VALIDATE_INTERVAL;
            validateStructure();
        }

        pullSodiumFromNeighbours();
        this.fuelCount = countFuel();
        this.rodCount = countRods();

        boolean canRun = this.formed && this.fuelCount >= MIN_FUEL && this.rodCount >= MIN_ROD_PORTS
                && !this.sodiumTank.isEmpty() && hasOutputRoom();

        int heat = canRun ? computeHeatPermille() : 0;
        this.heatPermille = heat;

        // 第一次出热：成就「快堆临界」
        if (!this.runMilestoneFired && heat > 0) {
            this.runMilestoneFired = true;
            ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 48.0,
                    ModAdvancementTriggers.FAST_REACTOR);
        }

        if (canRun) {
            this.sodiumTank.drain(SODIUM_PER_TICK, IFluidHandler.FluidAction.EXECUTE);
            this.burnProgress++;
            if (this.burnProgress >= BURN_TICKS) {
                this.burnProgress = 0;
                burnOneAssembly();
            }
            spawnParticles();
        } else if (this.burnProgress > 0 && !this.formed) {
            // 结构散了就别再攒进度，免得拆了一半又拼回来白赚
            this.burnProgress = 0;
        }

        pushHeatToGenerators(heat);

        int newStatus = computeStatus(canRun);
        if (this.status != newStatus) {
            this.status = newStatus;
            setChanged();
        }
        setChanged();
    }

    /** 现在这套堆有多热（千分数）：燃料越满越热，控制棒插得越深越冷。 */
    private int computeHeatPermille() {
        double fuelFraction = Math.min(this.fuelCount, FUEL_SLOTS) / (double) FUEL_SLOTS;
        double rodFactor = 1.0D - ROD_REDUCTION * this.rodDepth / 100.0D;
        return (int) Math.round(1000.0D * fuelFraction * rodFactor);
    }

    /** 把热量分给结构里的每一台钠-水蒸汽发生器。 */
    private void pushHeatToGenerators(int heat) {
        for (BlockPos pos : this.generators) {
            if (this.level.getBlockEntity(pos) instanceof SodiumSteamGeneratorBlockEntity generator) {
                generator.receiveHeat(heat);
            }
        }
    }

    private int computeStatus(boolean canRun) {
        if (!this.formed) {
            return STATUS_UNFORMED;
        }
        if (this.fuelCount < MIN_FUEL) {
            return STATUS_NO_FUEL;
        }
        if (this.rodCount < MIN_ROD_PORTS) {
            return STATUS_NO_RODS;
        }
        if (this.sodiumTank.isEmpty()) {
            return STATUS_NO_SODIUM;
        }
        if (!hasOutputRoom()) {
            return STATUS_OUTPUT_FULL;
        }
        return canRun ? STATUS_RUNNING : STATUS_IDLE;
    }

    private void spawnParticles() {
        if (!(this.level instanceof ServerLevel server) || server.getGameTime() % 10 != 0) {
            return;
        }
        server.sendParticles(ParticleTypes.END_ROD,
                this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 1.2,
                this.worldPosition.getZ() + 0.5, 2, 0.3, 0.2, 0.3, 0.01);
    }

    /** 产物槽放得下下一块乏燃料吗。 */
    private boolean hasOutputRoom() {
        ItemStack out = this.items.get(SLOT_OUTPUT);
        if (out.isEmpty()) {
            return true;
        }
        if (!out.is(ModItems.FAST_SPENT_ASSEMBLY.get())) {
            return false;
        }
        return out.getCount() < out.getMaxStackSize();
    }

    /** 烧完一支 MOX：从燃料格里拿走一个，往产物槽放一块乏燃料组件（快堆）。 */
    private void burnOneAssembly() {
        if (!hasOutputRoom()) {
            return;
        }
        for (int i = 0; i < FUEL_SLOTS; i++) {
            ItemStack stack = this.items.get(i);
            if (!stack.is(ModItems.MOX_FUEL_ASSEMBLY.get())) {
                continue;
            }
            stack.shrink(1);
            if (stack.isEmpty()) {
                this.items.set(i, ItemStack.EMPTY);
            }
            ItemStack out = this.items.get(SLOT_OUTPUT);
            if (out.isEmpty()) {
                this.items.set(SLOT_OUTPUT, new ItemStack(ModItems.FAST_SPENT_ASSEMBLY.get()));
            } else {
                out.grow(1);
            }
            if (this.level instanceof ServerLevel server) {
                server.playSound(null, this.worldPosition, SoundEvents.NETHERITE_BLOCK_PLACE,
                        SoundSource.BLOCKS, 0.6F, 1.4F);
            }
            setChanged();
            return;
        }
    }

    /** 用管道 / 相邻流体容器补钠：每 tick 从邻居身上抽，直到罐子满。 */
    private void pullSodiumFromNeighbours() {
        if (this.level == null) {
            return;
        }
        int room = SODIUM_CAPACITY - this.sodiumTank.getFluidAmount();
        if (room <= 0) {
            return;
        }
        for (Direction side : Direction.values()) {
            if (room <= 0) {
                return;
            }
            IFluidHandler source = this.level.getCapability(Capabilities.FluidHandler.BLOCK,
                    this.worldPosition.relative(side), side.getOpposite());
            if (source == null) {
                continue;
            }
            FluidStack probe = source.drain(new FluidStack(ModFluids.SODIUM.source.get(), Math.min(room, 200)),
                    IFluidHandler.FluidAction.SIMULATE);
            if (probe.isEmpty() || !probe.getFluid().isSame(ModFluids.SODIUM.source.get())) {
                continue;
            }
            FluidStack taken = source.drain(probe, IFluidHandler.FluidAction.EXECUTE);
            if (!taken.isEmpty()) {
                int filled = this.sodiumTank.fill(taken, IFluidHandler.FluidAction.EXECUTE);
                room -= filled;
                setChanged();
            }
        }
    }

    // ------------------------------------------------------------------
    // 结构检测
    // ------------------------------------------------------------------

    /** 数一遍 7×7×7 的区域，同时把探测器、发生器、控制棒端口的位置记下来。 */
    public void validateStructure() {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        Direction facing = facing();
        int px = facing.getStepZ();
        int pz = -facing.getStepX();
        int radius = (SIZE_W - 1) / 2;

        int shell = 0;
        List<BlockPos> foundDetectors = new ArrayList<>();
        List<BlockPos> foundGenerators = new ArrayList<>();
        List<BlockPos> foundRods = new ArrayList<>();
        boolean complete = true;

        for (int depth = 0; depth < SIZE_D && complete; depth++) {
            for (int side = -radius; side <= radius && complete; side++) {
                for (int up = 0; up < SIZE_H && complete; up++) {
                    BlockPos pos = this.worldPosition.offset(
                            facing.getStepX() * depth + px * side, up, facing.getStepZ() * depth + pz * side);
                    if (!server.isLoaded(pos)) {
                        complete = false;
                        break;
                    }
                    if (pos.equals(this.worldPosition)) {
                        continue;
                    }
                    Block block = server.getBlockState(pos).getBlock();
                    if (block == ModBlocks.STEEL_BLOCK.get() || block == ModBlocks.LEAD_BLOCK.get()) {
                        shell++;
                    } else if (block == ModBlocks.FAST_NEUTRON_DETECTOR.get()) {
                        foundDetectors.add(pos);
                    } else if (block == ModBlocks.SODIUM_STEAM_GENERATOR.get()) {
                        foundGenerators.add(pos);
                    } else if (block == ModBlocks.CONTROL_ROD_PORT.get()) {
                        foundRods.add(pos);
                    }
                }
            }
        }

        this.formed = complete && shell >= MIN_SHELL
                && foundDetectors.size() >= MIN_DETECTORS
                && foundGenerators.size() >= MIN_GENERATORS
                && foundRods.size() >= MIN_ROD_PORTS;
        this.shellCount = shell;
        this.detectors = List.copyOf(foundDetectors);
        this.generators = List.copyOf(foundGenerators);
        this.rodPorts = List.copyOf(foundRods);
        this.detectorCount = foundDetectors.size();
        this.generatorCount = foundGenerators.size();
        this.rodPortCount = foundRods.size();
        setChanged();
    }

    /** 方块朝哪，结构就往哪长。 */
    private Direction facing() {
        BlockState state = getBlockState();
        if (state.hasProperty(FastReactorControllerBlock.FACING)) {
            return state.getValue(FastReactorControllerBlock.FACING);
        }
        return Direction.NORTH;
    }

    private int countFuel() {
        int total = 0;
        for (int i = 0; i < FUEL_SLOTS; i++) {
            ItemStack stack = this.items.get(i);
            if (stack.is(ModItems.MOX_FUEL_ASSEMBLY.get())) {
                total += stack.getCount();
            }
        }
        return total;
    }

    private int countRods() {
        int total = 0;
        for (BlockPos pos : this.rodPorts) {
            if (this.level != null && this.level.getBlockEntity(pos) instanceof ControlRodPortBlockEntity port
                    && port.hasRod()) {
                total++;
            }
        }
        return total;
    }

    // ------------------------------------------------------------------
    // 给界面看的数
    // ------------------------------------------------------------------

    public boolean isFormed() {
        return this.formed;
    }

    public int shellCount() {
        return this.shellCount;
    }

    public int detectorCount() {
        return this.detectorCount;
    }

    public int generatorCount() {
        return this.generatorCount;
    }

    public int rodPortCount() {
        return this.rodPortCount;
    }

    public int fuelCount() {
        return this.fuelCount;
    }

    public int rodCount() {
        return this.rodCount;
    }

    public int rodDepth() {
        return this.rodDepth;
    }

    public void setRodDepth(int depth) {
        this.rodDepth = Math.max(0, Math.min(100, depth));
        setChanged();
    }

    public int sodiumAmount() {
        return this.sodiumTank.getFluidAmount();
    }

    public int sodiumCapacity() {
        return SODIUM_CAPACITY;
    }

    /** 整座堆现在每 tick 往电网送多少 FE（所有发生器加起来）。 */
    public int outputFePerTick() {
        return (int) ((long) this.generatorCount * OUTPUT_PER_GENERATOR * this.heatPermille / 1000L);
    }

    public int heatPermille() {
        return this.heatPermille;
    }

    /** 这一支 MOX 烧到百分之几（0~100），界面上画进度条用。 */
    public int burnPercent() {
        return Math.round(100.0F * Math.max(0, Math.min(this.burnProgress, BURN_TICKS)) / BURN_TICKS);
    }

    public int statusCode() {
        return this.status;
    }

    public boolean isRunning() {
        return this.status == STATUS_RUNNING;
    }

    // ------------------------------------------------------------------
    // 菜单 / 物品槽
    // ------------------------------------------------------------------

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.fast_reactor_controller");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new FastReactorMenu(containerId, playerInventory, this);
    }

    @Override
    public int getContainerSize() {
        return this.items.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        stack.limitSize(getMaxStackSize(stack));
        setChanged();
    }

    /** 只有前 8 格收 MOX 燃料组件，产物槽谁都不能塞。 */
    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot >= 0 && slot < FUEL_SLOTS && stack.is(ModItems.MOX_FUEL_ASSEMBLY.get());
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("RodDepth", this.rodDepth);
        tag.putInt("BurnProgress", this.burnProgress);
        tag.put("Sodium", this.sodiumTank.writeToNBT(registries, new CompoundTag()));
        ContainerHelper.saveAllItems(tag, this.items, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.rodDepth = tag.getInt("RodDepth");
        this.burnProgress = tag.getInt("BurnProgress");
        this.sodiumTank.readFromNBT(registries, tag.getCompound("Sodium"));
        ContainerHelper.loadAllItems(tag, this.items, registries);
    }
}
