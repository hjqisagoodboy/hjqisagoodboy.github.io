package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.energy.MachineEnergyStorage;
import cn.blockforge.generated.aftercritical.energy.RatedEnergyConsumer;
import cn.blockforge.generated.aftercritical.item.MoldItem;
import cn.blockforge.generated.aftercritical.itemhandler.ContainerItemHandler;
import cn.blockforge.generated.aftercritical.recipe.MachineRecipe;
import cn.blockforge.generated.aftercritical.recipe.MachineRecipeInput;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.items.IItemHandler;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 所有「吃原料、吐产物」的机器共用的方块实体骨架。
 *
 * <p>它负责这些事：
 * <ol>
 *   <li>一个 10,000 FE 的内部能量缓存；</li>
 *   <li>每 tick 从相邻方块的 FE 缓存（线缆、发电机、其他机器）里抽电；</li>
 *   <li>把所有输入槽里的东西凑一起，在配方表里找「这一堆能做什么」；</li>
 *   <li>找到配方后每 tick 扣电、攒进度，进度满了就把原料换成产物；</li>
 *   <li>把电量、进度、当前状态同步给 GUI。</li>
 * </ol>
 *
 * <p>槽位数量不固定：破碎机、球磨机、锻压机是 1 进 1 出，压块机是 6 进 6 出，
 * 以后的新机器想要几进几出都行，只要在子类里回答「输入槽是哪几个、输出槽是哪几个」。
 *
 * <p>配方本身不写死在代码里，而是从数据包的 JSON 读进来（见 {@link MachineRecipe}）。
 */
public abstract class MachineBlockEntity extends BlockEntity
        implements Container, MenuProvider, EnergyMachineHost, RatedEnergyConsumer, TickableBlockEntity {

    /** 每台机器固定的内部储能上限，单位 FE。 */
    public static final int ENERGY_CAPACITY = 10_000;

    /** 每 tick 最多从相邻方块抽进来多少 FE（线缆推电不受这个限制）。 */
    public static final int MAX_PULL_PER_TICK = 512;

    /** GUI 状态：待机（没东西可加工 / 没有匹配配方）。 */
    public static final int STATUS_IDLE = EnergyMachineHost.STATUS_IDLE;
    /** GUI 状态：正在加工。 */
    public static final int STATUS_RUNNING = EnergyMachineHost.STATUS_RUNNING;
    /** GUI 状态：配方找到了，但电不够。 */
    public static final int STATUS_NO_ENERGY = EnergyMachineHost.STATUS_NO_ENERGY;
    /** GUI 状态：输出槽放不下了。 */
    public static final int STATUS_OUTPUT_BLOCKED = EnergyMachineHost.STATUS_OUTPUT_BLOCKED;
    /** GUI 状态：锻压机的工具槽没放模具。 */
    public static final int STATUS_NO_MOLD = EnergyMachineHost.STATUS_NO_MOLD;

    private final MachineEnergyStorage energy =
            new MachineEnergyStorage(ENERGY_CAPACITY, MAX_PULL_PER_TICK, this::setChanged);
    private final NonNullList<ItemStack> items;
    private final int energyPerTick;

    /**
     * 给物品管道、漏斗用的物品接口。
     *
     * <p>规则：只能往输入槽和工具槽塞，只能从输出槽抽。
     * 所以管道不会把玩家放进去的矿石、模具又偷走。
     */
    private final IItemHandler itemHandler = new ContainerItemHandler(this,
            slot -> isInputSlot(slot) || slot == moldSlot(),
            this::isOutputSlot);

    private boolean running;
    private int status = STATUS_IDLE;
    private int progress;
    private int maxProgress;

    /** 当前正在加工的配方；同一条配方会一直复用这个对象，换原料后下一 tick 自动换掉。 */
    @Nullable
    private MachineRecipe activeRecipe;

    protected MachineBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state,
                                 int slotCount, int energyPerTick) {
        super(type, pos, state);
        this.items = NonNullList.withSize(slotCount, ItemStack.EMPTY);
        this.energyPerTick = energyPerTick;
    }

    // ------------------------------------------------------------------
    // 子类要回答的问题
    // ------------------------------------------------------------------

    /** 物品输入槽的槽号（可以有多个，压块机是 0..5）。 */
    protected abstract int[] inputSlots();

    /** 物品输出槽的槽号（可以有多个，压块机是 6..11）。 */
    protected abstract int[] outputSlots();

    /** 工具槽（放模具）的槽号；不需要模具的机器返回 -1。 */
    protected int moldSlot() {
        return -1;
    }

    /** 这台机器去 RecipeManager 里找哪一类配方。 */
    protected abstract RecipeType<MachineRecipe> recipeType();

    /**
     * 配方除了原料之外还要满足的条件，默认没有。
     * 锻压机会在这里检查工具槽里的模具对不对。
     */
    protected boolean isRecipeUsable(MachineRecipe recipe) {
        return true;
    }

    /** 这个槽是不是输入槽。 */
    protected final boolean isInputSlot(int slot) {
        for (int input : inputSlots()) {
            if (input == slot) {
                return true;
            }
        }
        return false;
    }

    /** 这个槽是不是输出槽。 */
    protected final boolean isOutputSlot(int slot) {
        for (int output : outputSlots()) {
            if (output == slot) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------
    // 能量
    // ------------------------------------------------------------------

    /** 对外暴露的 FE 接口，供 {@code RegisterCapabilitiesEvent} 注册到方块能力上。 */
    public IEnergyStorage getEnergyStorage() {
        return this.energy;
    }

    /** 对外暴露的物品接口：物品管道从这里塞原料、抽产物。 */
    public IItemHandler getItemHandler() {
        return this.itemHandler;
    }

    /** 线缆用它判断自己扛不扛得住：破碎机 30、球磨机 60、锻压机 40、压块机 100 FE/t。 */
    @Override
    public int ratedEnergyPerTick() {
        return this.energyPerTick;
    }

    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    /**
     * 人力补电：特殊来源要直接往缓存里塞 FE 时用，不受管道每 tick 上限限制。
     *
     * @return 实际补进去的量（缓存满了就是 0）
     */
    public int manualAddEnergy(int amount) {
        return this.energy.charge(amount);
    }

    public int getEnergyCapacity() {
        return this.energy.getMaxEnergyStored();
    }

    /** 额定运行功率，FE/t。 */
    public int getEnergyPerTick() {
        return this.energyPerTick;
    }

    public boolean isRunning() {
        return this.running;
    }

    /** 当前 GUI 状态，取值见本类的 {@code STATUS_*} 常量。 */
    public int getStatus() {
        return this.status;
    }

    public int getProgress() {
        return this.progress;
    }

    /** 当前配方一共要多少 tick；0 表示当前没有配方。 */
    public int getMaxProgress() {
        return this.maxProgress;
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    /**
     * 每 tick 的加工逻辑（只在服务端跑）。
     *
     * <p>烧结炉、磨削机、焊接机这些「新机器」的方块（{@code TickingMachineBlock}）只认
     * {@link TickableBlockEntity}，所以这个类必须实现它，否则这几台机器放下去一动不动。
     */
    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        pullEnergyFromNeighbours();

        MachineRecipe recipe = findRecipe();
        if (recipe != this.activeRecipe) {
            // 刚读档时 activeRecipe 还是空的，此时不要把存档里的进度清掉；
            // 真正换了原料（或者是别的配方）才从头开始。
            boolean restoredFromSave = this.activeRecipe == null && this.progress > 0;
            this.activeRecipe = recipe;
            this.maxProgress = recipe == null ? 0 : recipe.duration();
            if (!restoredFromSave) {
                this.progress = 0;
            }
            this.progress = Math.min(this.progress, this.maxProgress);
            setChanged();
        }

        boolean outputBlocked = false;
        boolean working = false;

        if (recipe != null) {
            if (!canOutput(recipe)) {
                outputBlocked = true;
            } else if (this.energy.getEnergyStored() >= this.energyPerTick) {
                this.energy.consume(this.energyPerTick);
                this.progress++;
                working = true;
                if (this.progress >= this.maxProgress) {
                    craft(recipe);
                    this.progress = 0;
                }
                setChanged();
            }
        }

        int newStatus = computeStatus(recipe, working, outputBlocked);
        if (this.status != newStatus) {
            this.status = newStatus;
            setChanged();
        }
        if (this.running != working) {
            this.running = working;
            setChanged();
        }
    }

    private int computeStatus(@Nullable MachineRecipe recipe, boolean working, boolean outputBlocked) {
        if (working) {
            return STATUS_RUNNING;
        }
        int mold = moldSlot();
        if (mold >= 0 && !this.items.get(inputSlots()[0]).isEmpty() && this.items.get(mold).isEmpty()) {
            return STATUS_NO_MOLD;
        }
        if (recipe == null) {
            return STATUS_IDLE;
        }
        return outputBlocked ? STATUS_OUTPUT_BLOCKED : STATUS_NO_ENERGY;
    }

    /** 所有输入槽里的东西（配方匹配时看这一堆）。 */
    public List<ItemStack> inputStacks() {
        List<ItemStack> stacks = new ArrayList<>();
        for (int slot : inputSlots()) {
            stacks.add(this.items.get(slot));
        }
        return stacks;
    }

    /** 在配方表里找一条「输入槽这些东西能做、模具也对」的配方。 */
    @Nullable
    public MachineRecipe findRecipe() {
        if (this.level == null) {
            return null;
        }
        MachineRecipeInput input = new MachineRecipeInput(inputStacks());
        if (input.isEmpty()) {
            return null;
        }
        List<RecipeHolder<MachineRecipe>> candidates = this.level.getRecipeManager()
                .getRecipesFor(recipeType(), input, this.level);
        for (RecipeHolder<MachineRecipe> holder : candidates) {
            MachineRecipe recipe = holder.value();
            if (isRecipeUsable(recipe)) {
                return recipe;
            }
        }
        return null;
    }

    /**
     * 这条配方的产物该放进哪个输出槽：第一个「空着」或「同一种物品且没堆满」的输出槽。
     *
     * <p>只看主产物，给老代码留的接口；带副产物的配方请用 {@link #planOutputs}。
     *
     * @return 槽号；所有输出槽都放不下时返回 -1
     */
    public int targetOutputSlot(MachineRecipe recipe) {
        if (this.level == null) {
            return -1;
        }
        return findOutputSlot(copySlots(), recipe.getResultItem(this.level.registryAccess()));
    }

    /** 输出槽放得下这条配方的全部产物（主产物 + 副产物）吗。 */
    public boolean canOutput(MachineRecipe recipe) {
        return planOutputs(recipe) != null;
    }

    /**
     * 算一遍「主产物和副产物各自该进哪个输出槽」。
     *
     * <p>先在槽位的副本上模拟放一遍，所以只会占一个槽、不会真的动东西；
     * 任何一样放不下就整条返回 {@code null}，这一轮先不加工，等玩家腾出地方。
     */
    @Nullable
    private int[] planOutputs(MachineRecipe recipe) {
        if (this.level == null) {
            return null;
        }
        ItemStack[] simulated = copySlots();
        List<ItemStack> results = recipe.results();
        int[] plan = new int[results.size()];
        for (int index = 0; index < results.size(); index++) {
            ItemStack result = results.get(index);
            if (result.isEmpty()) {
                plan[index] = -1;
                continue;
            }
            int slot = findOutputSlot(simulated, result);
            if (slot < 0) {
                return null;
            }
            plan[index] = slot;
            ItemStack existing = simulated[slot];
            if (existing.isEmpty()) {
                simulated[slot] = result.copy();
            } else {
                existing.grow(result.getCount());
            }
        }
        return plan;
    }

    /** 槽位的副本（模拟放产物时用，避免真的改到机器里的东西）。 */
    private ItemStack[] copySlots() {
        ItemStack[] copy = new ItemStack[this.items.size()];
        for (int i = 0; i < copy.length; i++) {
            copy[i] = this.items.get(i).copy();
        }
        return copy;
    }

    /** 在一堆槽位里找一个能放 {@code result} 的输出槽；找不到返回 -1。 */
    private int findOutputSlot(ItemStack[] pool, ItemStack result) {
        if (result.isEmpty()) {
            return outputSlots().length > 0 ? outputSlots()[0] : -1;
        }
        for (int slot : outputSlots()) {
            ItemStack existing = pool[slot];
            if (existing.isEmpty()) {
                return slot;
            }
            if (ItemStack.isSameItemSameComponents(existing, result)
                    && existing.getCount() + result.getCount()
                    <= Math.min(existing.getMaxStackSize(), result.getMaxStackSize())) {
                return slot;
            }
        }
        return -1;
    }

    /** 真正完成一次加工：扣掉原料，把产物（含副产物）放进输出槽。 */
    private void craft(MachineRecipe recipe) {
        if (this.level == null) {
            return;
        }
        int[] plan = planOutputs(recipe);
        if (plan == null) {
            return;
        }

        // 扣料：配方自己知道每种原料要几个、从哪些槽里拿
        recipe.consume(inputStacks());
        for (int slot : inputSlots()) {
            if (this.items.get(slot).isEmpty()) {
                this.items.set(slot, ItemStack.EMPTY);
            }
        }

        List<ItemStack> results = recipe.results();
        for (int index = 0; index < results.size(); index++) {
            ItemStack result = results.get(index);
            int target = plan[index];
            if (result.isEmpty() || target < 0) {
                continue;
            }
            ItemStack existing = this.items.get(target);
            if (existing.isEmpty()) {
                this.items.set(target, result.copy());
            } else {
                existing.grow(result.getCount());
            }
        }
        setChanged();
        onCrafted(recipe, results);
    }

    /**
     * 刚做完一炉：子类可以在这里做「配方之外」的事（比如点亮成就）。
     *
     * <p>默认什么都不做。注意这时候原料已经扣完、产物已经进槽，
     * 想判断「做出来的是什么」直接看 {@code results} 就行。
     */
    protected void onCrafted(MachineRecipe recipe, List<ItemStack> results) {
    }

    /** 从六个方向挨个问邻居要电，能抽多少算多少。 */
    private void pullEnergyFromNeighbours() {
        if (this.level == null) {
            return;
        }
        int space = this.energy.getFreeSpace();
        if (space <= 0) {
            return;
        }
        int budget = Math.min(space, MAX_PULL_PER_TICK);
        for (Direction side : Direction.values()) {
            if (budget <= 0) {
                break;
            }
            IEnergyStorage source = this.level.getCapability(
                    Capabilities.EnergyStorage.BLOCK, this.worldPosition.relative(side), side.getOpposite());
            if (source == null || !source.canExtract()) {
                continue;
            }
            int moved = source.extractEnergy(budget, true);
            if (moved <= 0) {
                continue;
            }
            moved = source.extractEnergy(moved, false);
            if (moved > 0) {
                this.energy.receiveEnergy(moved, false);
                budget -= moved;
            }
        }
    }

    // ------------------------------------------------------------------
    // 物品槽（Container）
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return this.items.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        stack.limitSize(getMaxStackSize(stack));
        setChanged();
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    /**
     * 漏斗、管道这类自动化往机器里塞东西时也走这里：
     * 输出槽谁都不许塞；有工具槽的机器，工具槽只收模具、输入槽反过来不收模具。
     */
    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        if (isOutputSlot(slot)) {
            return false;
        }
        int mold = moldSlot();
        if (mold >= 0) {
            boolean isMold = stack.getItem() instanceof MoldItem;
            if (slot == mold) {
                return isMold;
            }
            if (isInputSlot(slot)) {
                return !isMold;
            }
        }
        return true;
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
        tag.putBoolean("Running", this.running);
        tag.putInt("Status", this.status);
        tag.putInt("Progress", this.progress);
        tag.putInt("MaxProgress", this.maxProgress);
        ContainerHelper.saveAllItems(tag, this.items, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
        this.running = tag.getBoolean("Running");
        this.status = tag.getInt("Status");
        this.progress = tag.getInt("Progress");
        this.maxProgress = tag.getInt("MaxProgress");
        ContainerHelper.loadAllItems(tag, this.items, registries);
    }
}
