package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.NukeMenu;
import cn.blockforge.generated.aftercritical.nuke.NukeComponent;
import cn.blockforge.generated.aftercritical.nuke.NukeKind;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

import java.util.List;

/**
 * 核弹装配界面：和别的机器一样用代码画面板（不依赖贴图）。
 *
 * <p>上面画的是这颗弹的剖面示意图——枪式画成一根长管子、内爆式画成一圈同心圆、
 * 氢弹画成「初级 + 次级」两节（带减速伞的多一顶伞）。组件槽就摆在这张图上它们
 * 现实里该在的位置，鼠标停在空格上会告诉你这里要装什么、装上去有什么用。
 *
 * <p>下面实时显示装完之后这颗弹有多大、多深、多脏、引信多长。
 */
public class NukeScreen extends AbstractContainerScreen<NukeMenu> {

    private static final int PANEL_BG = 0xFFC6C6C6;
    private static final int PANEL_DARK = 0xFF373737;
    private static final int PANEL_LIGHT = 0xFFFFFFFF;
    private static final int SLOT_BG = 0xFF8B8B8B;
    private static final int TEXT_DARK = 0x404040;
    private static final int TEXT_GRAY = 0x6E6E6E;
    private static final int TEXT_GOLD = 0x8A6A00;

    // 示意图配色：外壳 / 内层 / 核心 / 伞布
    private static final int CASE = 0xFF6F7A63;
    private static final int CASE_EDGE = 0xFF3C4237;
    private static final int LENS = 0xFFA8903F;
    private static final int INNER = 0xFF7E8279;
    private static final int CORE = 0xFFC8D79A;
    private static final int CANOPY = 0xFFB9C4C9;
    private static final int FIN = 0xFF5A6350;

    /** 示意图在面板里的区域：顶 14，底 98。 */
    private static final int ART_TOP = 14;
    private static final int ART_BOTTOM = 98;

    public NukeScreen(NukeMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
        this.imageWidth = NukeMenu.IMAGE_WIDTH;
        this.imageHeight = NukeMenu.IMAGE_HEIGHT;
        this.titleLabelX = 8;
        this.titleLabelY = 4;
        this.inventoryLabelX = 8;
        this.inventoryLabelY = NukeMenu.INVENTORY_LABEL_Y;
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        // 光标停在空格上：直接告诉玩家这个位置该装哪个组件、装上去有什么用
        if (this.hoveredSlot != null && this.hoveredSlot instanceof NukeMenu.ComponentSlot component
                && !component.hasItem()) {
            NukeComponent required = component.required();
            List<Component> lines = List.of(
                    Component.translatable(required.langKey()),
                    Component.translatable(required.effectKey()).withStyle(ChatFormatting.GRAY));
            // 这里没有悬停的物品栈，所以用带「额外 TooltipComponent」参数的那个重载，传空即可
            guiGraphics.renderTooltip(this.font, lines, java.util.Optional.empty(),
                    net.minecraft.world.item.ItemStack.EMPTY, mouseX, mouseY);
        }
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        int x = this.leftPos;
        int y = this.topPos;
        int w = this.imageWidth;
        int h = this.imageHeight;

        guiGraphics.fill(x, y, x + w, y + h, PANEL_BG);
        guiGraphics.fill(x, y, x + w, y + 1, PANEL_DARK);
        guiGraphics.fill(x, y + h - 1, x + w, y + h, PANEL_DARK);
        guiGraphics.fill(x, y, x + 1, y + h, PANEL_DARK);
        guiGraphics.fill(x + w - 1, y, x + w, y + h, PANEL_DARK);
        guiGraphics.fill(x + 1, y + 1, x + w - 1, y + 2, PANEL_LIGHT);
        guiGraphics.fill(x + 1, y + 1, x + 2, y + h - 1, PANEL_LIGHT);

        // 剖面示意图（画在槽位下面，槽位再盖上去）
        int artLeft = x + 4;
        int artRight = x + w - 4;
        guiGraphics.fill(artLeft, y + ART_TOP, artRight, y + ART_BOTTOM, 0xFFB4B4B4);
        guiGraphics.fill(artLeft, y + ART_TOP, artRight, y + ART_TOP + 1, 0xFF8F8F8F);
        guiGraphics.fill(artLeft, y + ART_BOTTOM - 1, artRight, y + ART_BOTTOM, PANEL_LIGHT);
        switch (this.menu.kind().shape) {
            case GUN -> drawGun(guiGraphics, x, y);
            case IMPLOSION -> drawImplosion(guiGraphics, x, y);
            case TWO_STAGE -> drawTwoStage(guiGraphics, x, y, this.menu.kind());
        }

        int split = this.topPos + NukeMenu.INVENTORY_LABEL_Y - 8;
        guiGraphics.fill(x + 6, split, x + w - 6, split + 1, 0xFF9A9A9A);
        guiGraphics.fill(x + 6, split + 1, x + w - 6, split + 2, PANEL_LIGHT);

        for (Slot slot : this.menu.slots) {
            drawSlot(guiGraphics, this.leftPos + slot.x - 1, this.topPos + slot.y - 1);
        }
    }

    // ------------------------------------------------------------------
    // 三种剖面示意图
    // ------------------------------------------------------------------

    /** 枪式：一根长管子，左端是整流头锥、右端是尾翼。 */
    private void drawGun(GuiGraphics guiGraphics, int ox, int oy) {
        // 弹体
        guiGraphics.fill(ox + 26, oy + 42, ox + 152, oy + 66, CASE);
        guiGraphics.fill(ox + 26, oy + 42, ox + 152, oy + 43, CASE_EDGE);
        guiGraphics.fill(ox + 26, oy + 65, ox + 152, oy + 66, CASE_EDGE);
        // 头锥
        for (int step = 0; step < 12; step++) {
            guiGraphics.fill(ox + 26 - step, oy + 42 + step, ox + 26 - step + 1, oy + 66 - step, CASE);
        }
        // 尾翼
        guiGraphics.fill(ox + 138, oy + 26, ox + 152, oy + 42, FIN);
        guiGraphics.fill(ox + 138, oy + 66, ox + 152, oy + 82, FIN);
        // 弹体上的加强箍
        for (int band = 0; band < 3; band++) {
            int bx = ox + 60 + band * 26;
            guiGraphics.fill(bx, oy + 42, bx + 1, oy + 66, CASE_EDGE);
        }
        // 炮管（示意：弹体里那根细管）
        guiGraphics.fill(ox + 62, oy + 52, ox + 120, oy + 56, INNER);
    }

    /** 内爆式：一圈同心圆，从外到内是外壳、炸药透镜、惰层、核心。 */
    private void drawImplosion(GuiGraphics guiGraphics, int ox, int oy) {
        int cx = ox + 88;
        int cy = oy + 56;
        circle(guiGraphics, cx, cy, 36, CASE);
        circle(guiGraphics, cx, cy, 31, LENS);
        circle(guiGraphics, cx, cy, 21, INNER);
        circle(guiGraphics, cx, cy, 9, CORE);
        // 透镜之间的分割线（八块透镜）
        for (int spoke = 0; spoke < 8; spoke++) {
            double angle = Math.PI * spoke / 4.0;
            for (int r = 21; r < 31; r++) {
                int px = cx + (int) (Math.cos(angle) * r);
                int py = cy + (int) (Math.sin(angle) * r);
                guiGraphics.fill(px, py, px + 1, py + 1, CASE_EDGE);
            }
        }
    }

    /** 两级氢弹：左边初级、右边次级，中间一条辐射通道；有减速伞的在顶上画一顶伞。 */
    private void drawTwoStage(GuiGraphics guiGraphics, int ox, int oy, NukeKind kind) {
        // 顶部挂架：三个上排槽位坐在这一根梁上
        guiGraphics.fill(ox + 24, oy + 46, ox + 126, oy + 47, CASE_EDGE);

        // 初级（裂变扳机）
        guiGraphics.fill(ox + 22, oy + 50, ox + 50, oy + 78, CASE);
        guiGraphics.fill(ox + 22, oy + 50, ox + 50, oy + 51, CASE_EDGE);
        guiGraphics.fill(ox + 22, oy + 77, ox + 50, oy + 78, CASE_EDGE);
        circle(guiGraphics, ox + 36, oy + 64, 8, CORE);
        // 辐射通道
        guiGraphics.fill(ox + 50, oy + 60, ox + 58, oy + 68, LENS);
        // 次级（氘化锂 / 低温杜瓦）
        guiGraphics.fill(ox + 58, oy + 46, ox + 118, oy + 82, CASE);
        guiGraphics.fill(ox + 58, oy + 46, ox + 118, oy + 47, CASE_EDGE);
        guiGraphics.fill(ox + 58, oy + 81, ox + 118, oy + 82, CASE_EDGE);
        guiGraphics.fill(ox + 64, oy + 52, ox + 112, oy + 76, INNER);
        // 惰层包在外面
        guiGraphics.fill(ox + 110, oy + 46, ox + 118, oy + 82, LENS);

        boolean parachute = kind.slots().stream()
                .anyMatch(slot -> slot.component() == NukeComponent.PARACHUTE);
        if (parachute) {
            // 伞盖（在右上角那个槽位上方）
            for (int step = 0; step < 8; step++) {
                int half = 18 - step * 2;
                guiGraphics.fill(ox + 118 - half, oy + 16 + step, ox + 118 + half, oy + 17 + step, CANOPY);
            }
            // 伞绳
            for (int line = 0; line < 4; line++) {
                int fromX = ox + 104 + line * 9;
                for (int step = 0; step < 13; step++) {
                    int px = fromX + (118 - 104 - line * 9) * step / 13;
                    guiGraphics.fill(px, oy + 24 + step, px + 1, oy + 25 + step, CASE_EDGE);
                }
            }
        } else {
            // 没有减速伞的那一颗：画常青藤那套的钢塔架
            guiGraphics.fill(ox + 104, oy + 16, ox + 106, oy + 46, CASE_EDGE);
            guiGraphics.fill(ox + 126, oy + 16, ox + 128, oy + 46, CASE_EDGE);
            guiGraphics.fill(ox + 104, oy + 16, ox + 128, oy + 18, CASE_EDGE);
        }
    }

    private void circle(GuiGraphics guiGraphics, int cx, int cy, int radius, int color) {
        for (int dy = -radius; dy <= radius; dy++) {
            int half = (int) Math.sqrt((double) (radius * radius - dy * dy));
            guiGraphics.fill(cx - half, cy + dy, cx + half, cy + dy + 1, color);
        }
    }

    private void drawSlot(GuiGraphics guiGraphics, int x, int y) {
        guiGraphics.fill(x, y, x + 18, y + 18, SLOT_BG);
        guiGraphics.fill(x, y, x + 18, y + 1, PANEL_DARK);
        guiGraphics.fill(x, y, x + 1, y + 18, PANEL_DARK);
        guiGraphics.fill(x, y + 17, x + 18, y + 18, PANEL_LIGHT);
        guiGraphics.fill(x + 17, y, x + 18, y + 18, PANEL_LIGHT);
    }

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        guiGraphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, TEXT_GOLD, false);
        guiGraphics.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX,
                this.inventoryLabelY, TEXT_DARK, false);

        NukeComponent.Loadout loadout = NukeComponent.loadout(this.menu.kind(),
                this.menu.installedComponents());
        guiGraphics.drawString(this.font,
                Component.translatable("gui.aftercritical.nuke.installed",
                        loadout.installed(), loadout.capacity()),
                8, 100, TEXT_DARK, false);
        guiGraphics.drawString(this.font,
                Component.translatable("gui.aftercritical.nuke.blast",
                        loadout.radius(), loadout.depth()),
                8, 112, TEXT_DARK, false);
        guiGraphics.drawString(this.font,
                Component.translatable("gui.aftercritical.nuke.radiation", loadout.radiationTicks() / 20),
                8, 124, TEXT_DARK, false);
        guiGraphics.drawString(this.font,
                Component.translatable("gui.aftercritical.nuke.fuse", loadout.fuseTicks() / 20),
                8, 136, TEXT_DARK, false);

        guiGraphics.drawString(this.font,
                Component.translatable("gui.aftercritical.nuke.hint1"),
                8, 150, TEXT_GRAY, false);
        guiGraphics.drawString(this.font,
                Component.translatable("gui.aftercritical.nuke.hint2"),
                8, 160, TEXT_GRAY, false);
    }
}
