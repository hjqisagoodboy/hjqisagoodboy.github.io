package cn.blockforge.generated.aftercritical.compat.jei;

import cn.blockforge.generated.aftercritical.registry.ModBlocks;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.widgets.IRecipeExtrasBuilder;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

import java.util.ArrayList;
import java.util.List;

/**
 * 「多方块预览」在 JEI 里的样子：一层一层地画。
 *
 * <p>JEI 没有通用的 3D 结构预览接口，所以这里用最直观的办法：
 * 每个多方块的每一层单独做一条「配方」，格子里直接摆方块物品——
 * 玩家看到的就是这一层横截面长什么样，翻页就是往上/往下看一层。
 *
 * <p>格子里的方块是真实物品，鼠标放上去就有名字，所以图例只需要解释「哪些是必需件」。
 */
public class MultiblockPreviewCategory implements IRecipeCategory<MultiblockPreviewCategory.Entry> {

    /** 一层预览：标题、按行写的方块代号、底部说明。 */
    public record Entry(Component title, String[] rows, List<Component> notes) {
    }

    private static final int CELL = 18;

    private final RecipeType<Entry> recipeType;
    private final Component title;
    private final IDrawable icon;

    public MultiblockPreviewCategory(IGuiHelper guiHelper, RecipeType<Entry> recipeType,
                                     Component title, Block iconBlock) {
        this.recipeType = recipeType;
        this.title = title;
        this.icon = guiHelper.createDrawableItemLike(iconBlock);
    }

    @Override
    public RecipeType<Entry> getRecipeType() {
        return this.recipeType;
    }

    @Override
    public Component getTitle() {
        return this.title;
    }

    @Override
    public IDrawable getIcon() {
        return this.icon;
    }

    @Override
    public int getWidth() {
        return 8 + 9 * CELL + 8;
    }

    @Override
    public int getHeight() {
        return 22 + 9 * CELL + 34;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, Entry recipe, IFocusGroup focuses) {
        for (int row = 0; row < recipe.rows().length; row++) {
            String line = recipe.rows()[row];
            for (int column = 0; column < line.length(); column++) {
                Block block = blockFor(line.charAt(column));
                if (block == null) {
                    continue;
                }
                builder.addSlot(RecipeIngredientRole.RENDER_ONLY, 8 + column * CELL, 22 + row * CELL)
                        .addItemStack(new ItemStack(block));
            }
        }
    }

    @Override
    public void createRecipeExtras(IRecipeExtrasBuilder builder, Entry recipe, IFocusGroup focuses) {
        builder.addText(recipe.title(), 8, 8);
        int y = 22 + recipe.rows().length * CELL + 2;
        for (Component note : recipe.notes()) {
            builder.addText(note, 8, y);
            y += 10;
        }
    }

    /** 代号 → 方块。空格和 {@code .} 表示空的。 */
    private static Block blockFor(char code) {
        return switch (code) {
            case 'C' -> ModBlocks.FUSION_RING_CASING.get();
            case 'S' -> ModBlocks.SUPERCONDUCTING_COIL.get();
            case 'B' -> ModBlocks.BREEDING_BLANKET.get();
            case 'I' -> ModBlocks.FUEL_INJECTOR_PORT.get();
            case 'D' -> ModBlocks.PLASMA_DIAGNOSTIC.get();
            case 'K' -> ModBlocks.CRYOGENIC_COOLER.get();
            case 'L' -> ModBlocks.FUSION_CONTROL_LOGIC.get();
            case 'T' -> ModBlocks.TOKAMAK_CONTROLLER.get();
            case 'X' -> ModBlocks.TRANSMUTATOR_CASING.get();
            case 'P' -> ModBlocks.ENERGY_PORT.get();
            case 'M' -> ModBlocks.TRANSMUTATOR_CONTROLLER.get();
            default -> null;
        };
    }

    // ------------------------------------------------------------------
    // 托卡马克：9×9×9，一层一条
    // ------------------------------------------------------------------

    /** 托卡马克第 {@code up} 层（0 = 地面那层）的横截面，行 = 由前到后，列 = 由左到右。 */
    public static Entry tokamakLayer(int up) {
        int size = 9;
        int center = size / 2;
        char[][] grid = new char[size][size];
        for (char[] row : grid) {
            java.util.Arrays.fill(row, '.');
        }
        for (int depth = 0; depth < size; depth++) {
            for (int side = 0; side < size; side++) {
                boolean shell = depth == 0 || depth == size - 1 || side == 0 || side == size - 1
                        || up == 0 || up == size - 1;
                if (shell) {
                    grid[depth][side] = 'C';
                } else if ((side == 1 || side == size - 2 || depth == 1 || depth == size - 2)
                        && up >= 2 && up <= 6) {
                    grid[depth][side] = 'S';
                }
            }
        }
        // 控制器：正面墙、贴地那排正中间
        grid[0][center] = 'T';
        // 燃料注入端口：正面墙中腰左右各一个
        grid[0][2] = 'I';
        grid[0][6] = 'I';
        // 诊断器、低温冷却器、控制逻辑：正面墙上层
        grid[0][1] = 'D';
        grid[0][7] = 'K';
        grid[0][3] = 'L';
        // 增殖包层：中间层 4 个，围住等离子体
        if (up == 4) {
            grid[4][3] = 'B';
            grid[4][5] = 'B';
            grid[3][4] = 'B';
            grid[5][4] = 'B';
        }
        List<Component> notes = List.of(
                Component.translatable("jei.aftercritical.tokamak.legend1"),
                Component.translatable("jei.aftercritical.tokamak.legend2"),
                Component.translatable("jei.aftercritical.tokamak.layer", up + 1, size));
        return new Entry(Component.translatable("jei.aftercritical.tokamak.layer_title", up + 1),
                toRows(grid), notes);
    }

    public static List<Entry> tokamakLayers() {
        List<Entry> entries = new ArrayList<>();
        for (int up = 0; up < 9; up++) {
            entries.add(tokamakLayer(up));
        }
        return entries;
    }

    // ------------------------------------------------------------------
    // 物质嬗变器：7×7×7
    // ------------------------------------------------------------------

    public static Entry transmutatorLayer(int up) {
        int size = 7;
        int center = size / 2;
        char[][] grid = new char[size][size];
        for (char[] row : grid) {
            java.util.Arrays.fill(row, '.');
        }
        for (int depth = 0; depth < size; depth++) {
            for (int side = 0; side < size; side++) {
                boolean shell = depth == 0 || depth == size - 1 || side == 0 || side == size - 1
                        || up == 0 || up == size - 1;
                if (shell) {
                    grid[depth][side] = 'X';
                }
            }
        }
        // 控制器：正面墙、贴地正中间；能量端口：正面墙中腰
        grid[0][center] = 'M';
        if (up == 3) {
            grid[0][center] = 'P';
            // 8 个超导线圈围在中间一圈
            grid[3][1] = 'S';
            grid[3][2] = 'S';
            grid[3][4] = 'S';
            grid[3][5] = 'S';
            grid[1][3] = 'S';
            grid[2][3] = 'S';
            grid[4][3] = 'S';
            grid[5][3] = 'S';
        }
        List<Component> notes = List.of(
                Component.translatable("jei.aftercritical.transmutator.legend"),
                Component.translatable("jei.aftercritical.tokamak.layer", up + 1, size));
        return new Entry(Component.translatable("jei.aftercritical.transmutator.layer_title", up + 1),
                toRows(grid), notes);
    }

    public static List<Entry> transmutatorLayers() {
        List<Entry> entries = new ArrayList<>();
        for (int up = 0; up < 7; up++) {
            entries.add(transmutatorLayer(up));
        }
        return entries;
    }

    private static String[] toRows(char[][] grid) {
        String[] rows = new String[grid.length];
        for (int i = 0; i < grid.length; i++) {
            rows[i] = new String(grid[i]);
        }
        return rows;
    }
}
