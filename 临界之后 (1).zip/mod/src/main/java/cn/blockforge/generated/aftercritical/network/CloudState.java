package cn.blockforge.generated.aftercritical.network;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 客户端手里的「现在世界上有哪几朵蘑菇云」。
 *
 * <p>放在公共包（不是 client 包）是故意的：专用服务器也会加载这个类，但它不引用任何
 * 客户端类，所以服务端不会因为找不到渲染类而崩。真正把包塞进来的动作由客户端
 * （{@code ClientSetup}）注册的 {@link Sink} 完成，服务端那份是空的。
 *
 * <h2>时间轴只认「出生那一刻」</h2>
 * <p>服务器每 20 tick 会补发一次「这朵云已经活了多久」，那是给后来走进视野的玩家看的，
 * 不是用来校正已经在看的玩家的。所以收到一条包时，这里把「现在 − 已经活了多久」
 * 换算成这朵云的**出生时间**（{@link Cloud#bornGameTime()}）存下来，之后年龄一律用
 * 「现在的世界时间 − 出生时间」算，同一朵云的补发包一概不理。
 *
 * <p>以前是每次补发都把基准重置成「这条包说自己活了多久」，服务器和客户端的时钟只要差
 * 一点点（服务器那边慢几 tick），云就会**往回退**——表现出来就是火球冲上去那一段
 * 一遍一遍重播。改用出生时间以后，年龄只可能往前走，动画也就只播一遍。
 *
 * <p>世界时间在单人暂停时也会停，所以开菜单不会让云偷偷散掉。
 */
public final class CloudState {

    private static final Logger LOGGER = LoggerFactory.getLogger("aftercritical/mushroom-cloud");

    /** 收到一条云数据之后要做什么（客户端注册；服务端什么都不做）。 */
    public interface Sink {
        void accept(MushroomCloudPayload payload);
    }

    private static volatile Sink sink = payload -> {};

    /**
     * 一朵活着的云。
     *
     * @param bornGameTime 出生时的世界时间（tick），由「收到包时的世界时间 − 包里说已活多久」倒推
     */
    public record Cloud(int id, double x, double y, double z, float scale,
                        int duration, long bornGameTime) {

        /** 现在这个云活了多少 tick（加上渲染插值，动画才不会一顿一顿的）。 */
        public float age(long gameTime, float partialTick) {
            float age = (float) (gameTime - this.bornGameTime) + partialTick;
            // 插值那一小段可能把 0 拉成负数，夹住，免得后面算百分比时算出怪东西
            return age < 0.0F ? 0.0F : age;
        }

        /** 还活着吗（活到头了就从列表里踢掉）。 */
        public boolean alive(long gameTime, float partialTick) {
            return age(gameTime, partialTick) < this.duration;
        }
    }

    private static final Map<Integer, Cloud> CLOUDS = new ConcurrentHashMap<>();

    /**
     * 每朵云「报到过的最大年龄」。
     *
     * <p>世界时间理论上只增不减，但单人存档切时间、补时间包都可能让它抖一下。
     * 年龄一旦倒退，动画就会重播（火球再冲一次）。这里记住已经报到过哪儿，
     * 倒退的那一下直接把年龄顶在前面的位置——云只会变老，不会变年轻。
     */
    private static final Map<Integer, Float> REPORTED_AGE = new ConcurrentHashMap<>();

    private CloudState() {}

    public static void setSink(Sink handler) {
        sink = handler == null ? payload -> {} : handler;
    }

    /** 网络包收到时调（服务端和客户端都会走这里，实际干活的是 sink）。 */
    public static void accept(MushroomCloudPayload payload) {
        sink.accept(payload);
    }

    /** 客户端专用：登记一朵云（已经登记过的编号直接忽略，见类注释）。 */
    public static void store(MushroomCloudPayload payload, long gameTime) {
        if (CLOUDS.containsKey(payload.id())) {
            return;
        }
        long bornGameTime = gameTime - payload.age();
        CLOUDS.put(payload.id(), new Cloud(payload.id(), payload.x(), payload.y(), payload.z(),
                payload.scale(), payload.duration(), bornGameTime));
        // 一行日志：外面要是有一天说「还是重播」，看这行就知道是「同一朵云被算了两次」
        // 还是「真的起了好几朵云」（每次核爆只该有一行）。
        LOGGER.info("蘑菇云 #{} 进场：位置 ({}, {}, {})，放大 {} 倍，活 {} tick，进场时已活 {} tick",
                payload.id(), String.format("%.1f", payload.x()), String.format("%.1f", payload.y()),
                String.format("%.1f", payload.z()), String.format("%.2f", payload.scale()),
                payload.duration(), payload.age());
    }

    /**
     * 这朵云现在多大岁数（渲染用）。
     *
     * <p>年龄按「现在的世界时间 − 出生时间」算，并且记下最大值：哪怕外面给的年龄
     * 因为时间包抖动往回退了一点，也只会「停住」，不会让动画倒着重播。
     */
    public static float ageOf(Cloud cloud, long gameTime, float partialTick) {
        float age = cloud.age(gameTime, partialTick);
        float reported = REPORTED_AGE.getOrDefault(cloud.id(), 0.0F);
        if (age < reported) {
            return reported;
        }
        REPORTED_AGE.put(cloud.id(), age);
        return age;
    }

    /** 所有还活着的云（渲染用）。 */
    public static List<Cloud> clouds() {
        return new ArrayList<>(CLOUDS.values());
    }

    public static void remove(int id) {
        CLOUDS.remove(id);
        REPORTED_AGE.remove(id);
    }

    /** 换维度 / 退世界时清空：别的世界的云不该飘到这个世界来。 */
    public static void clear() {
        CLOUDS.clear();
        REPORTED_AGE.clear();
    }
}
