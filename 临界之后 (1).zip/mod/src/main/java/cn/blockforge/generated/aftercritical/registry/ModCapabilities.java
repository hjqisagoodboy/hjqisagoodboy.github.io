package cn.blockforge.generated.aftercritical.registry;

import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

/**
 * 把 FE 能量接口接到机器方块上。
 *
 * <p>NeoForge 1.21.1 用能力（capability）系统：别的模组的线缆只要拿
 * {@code Capabilities.EnergyStorage.BLOCK} 往我们机器上一问，就能拿到
 * {@link cn.blockforge.generated.aftercritical.energy.MachineEnergyStorage} 这个 FE 接口，
 * 然后调用 receiveEnergy 灌电。
 */
public final class ModCapabilities {

    private ModCapabilities() {}

    public static void register(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.CRUSHER.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.BALL_MILL.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.FORGING_PRESS.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.ASSEMBLER_T1.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.ASSEMBLER_T2.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        // 发电机和电池：canExtract 为 true，别的机器、以后的线缆可以从这里抽电
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.COMBUSTION_GENERATOR.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.FUEL_ROD_GENERATOR.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.BATTERY_LV.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        // 十台流体机器：既吃电，也吃/吐流体（智能流体管道能直接接上）
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.FLUID_MACHINE.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.FLUID_MACHINE.get(),
                (blockEntity, side) -> blockEntity.getFluidHandler());
        // 线缆：六个方向各一个 FE 口，线缆、机器、发电机、变压器都能直接接上
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.CABLE.get(),
                (blockEntity, side) -> blockEntity.getStorage(side));
        // 变压器：只有正面（MV 输出）和背面（LV 输入）有 FE 口
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.TRANSFORMER.get(),
                (blockEntity, side) -> blockEntity.getStorage(side));

        // ------------------------------------------------------------------
        // 物品接口：物品管道靠它从输出槽抽货、往输入槽塞货
        // ------------------------------------------------------------------
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.CRUSHER.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.BALL_MILL.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.FORGING_PRESS.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.ASSEMBLER_T1.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.ASSEMBLER_T2.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.FLUID_MACHINE.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());
        // 发电机：管道能把燃料自动喂进燃料槽
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.COMBUSTION_GENERATOR.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.FUEL_ROD_GENERATOR.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());

        // ------------------------------------------------------------------
        // 级联控制器：吃电、收 / 放流体，罐子槽能被管道塞空罐
        // ------------------------------------------------------------------
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.CASCADE_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.CASCADE_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getFluidHandler());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.CASCADE_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());

        // ------------------------------------------------------------------
        // 阶段 2 燃料链：烧结炉 / 磨削机 / 焊接机吃电，管道能塞原料、抽成品
        // ------------------------------------------------------------------
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.ITEM_MACHINE.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.ITEM_MACHINE.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());

        // ------------------------------------------------------------------
        // 物流控制器：吃电，管道往它的九格缓冲里塞货
        // ------------------------------------------------------------------
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.LOGISTICS_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.LOGISTICS_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());

        // ------------------------------------------------------------------
        // 储罐多方块：控制器自己有一个大罐子，两个口是它的「面」
        // ------------------------------------------------------------------
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.TANK_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getFluidHandler());
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.TANK_PORT.get(),
                (blockEntity, side) -> blockEntity.getFluidHandler());
        // ------------------------------------------------------------------
        // 阶段 3：反应堆控制器（硼酸接口 + 燃料槽）和硼酸储罐
        // ------------------------------------------------------------------
        // ------------------------------------------------------------------
        // 阶段 3：反应堆控制器（硼酸接口 + 燃料槽）和通用储罐
        // ------------------------------------------------------------------
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.REACTOR_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getFluidHandler());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.REACTOR_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.UNIVERSAL_TANK.get(),
                (blockEntity, side) -> blockEntity.getFluidHandler());
        // 旧版硼酸储罐的兼容壳：老存档里的罐子还能接管子
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.BORIC_ACID_TANK.get(),
                (blockEntity, side) -> blockEntity.getFluidHandler());

        // ------------------------------------------------------------------
        // 阶段 4：装配机 T3 吃电、管道能塞原料抽成品；研究堆控制器同样接电和物品
        // ------------------------------------------------------------------
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.ASSEMBLER_T3.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.ASSEMBLER_T3.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.RESEARCH_REACTOR.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.RESEARCH_REACTOR.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());

        // 储罐控制器也开一个物品口：管道能往操作槽塞空罐、从返还槽取满罐
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.TANK_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());

        // ------------------------------------------------------------------
        // 阶段 5：热室机械臂、压水堆端口、汽轮发电机、冷凝器
        // ------------------------------------------------------------------

        // 热室机械臂：吃电；物品口只让塞、不让抽（真抽会掉一地 + 辐射，见方块实体）
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.HOT_CELL_ARM.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.HOT_CELL_ARM.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());

        // 冷却剂端口：进水罐能灌、出汽罐能抽
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.COOLANT_PORT.get(),
                (blockEntity, side) -> blockEntity.getFluidHandler());

        // 汽轮发电机：蒸汽进、乏蒸汽出，电从这边送走
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.STEAM_GENERATOR.get(),
                (blockEntity, side) -> blockEntity.getFluidHandler());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.STEAM_GENERATOR.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());

        // ------------------------------------------------------------------
        // 阶段 6：快堆控制器（灌钠 + 塞 MOX）与钠-水蒸汽发生器（抽水、送我蒸汽、送电）
        // ------------------------------------------------------------------
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.FAST_REACTOR_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getFluidHandler());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.FAST_REACTOR_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());
        event.registerBlockEntity(Capabilities.FluidHandler.BLOCK, ModBlockEntities.SODIUM_STEAM_GENERATOR.get(),
                (blockEntity, side) -> blockEntity.getFluidHandler());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.SODIUM_STEAM_GENERATOR.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());

        // ------------------------------------------------------------------
        // 阶段 7：托卡马克（送电 + 塞燃料）、能量端口（无线收发）、嬗变器
        // ------------------------------------------------------------------
        // 托卡马克：电可以往外抽（接 HV 线缆），也能被灌电（点火前从电池组充能）
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.TOKAMAK_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.TOKAMAK_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());

        // 电池 MV：托卡马克点火的标准启动电源
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.BATTERY_MV.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());

        // 巨型储能库：1.2 亿 FE，汽轮机的电先灌到这里，蒸汽就不会堵
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.GIANT_BATTERY.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());

        // 能量端口：既能被线缆抽走，也能被线缆灌电
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.ENERGY_PORT.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());

        // 嬗变器：控制器自己也能被线缆灌电（应急），管道能塞锕系元素、抽同位素
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModBlockEntities.TRANSMUTATOR_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getEnergyStorage());
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.TRANSMUTATOR_CONTROLLER.get(),
                (blockEntity, side) -> blockEntity.getItemHandler());
    }
}
