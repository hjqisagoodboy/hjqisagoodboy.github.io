package cn.blockforge.generated.aftercritical.block;

/**
 * 变压器的等级（进多少、出多少）。
 *
 * <p>变压器只做「透传」：背面按 {@code inputLimit} 收电，正面按 {@code outputLimit} 往外送，
 * 中间是一个小缓存。所以 LV→MV 就是「背面 80 FE/t、正面 320 FE/t」，
 * MV→HV 就是「背面 320 FE/t、正面 2,560 FE/t」。
 */
public enum TransformerTier {

    /** LV → MV：低压进、中压出。 */
    LV_MV("LV → MV", "MV", 80, 320,

            "tooltip.aftercritical.transformer.desc"),

    /** MV → HV：中压进、高压出（高压线缆上限 2,560 FE/t）。 */
    MV_HV("MV → HV", "HV", 320, 2_560,

            "tooltip.aftercritical.transformer.hv_desc");

    private final String label;
    private final String outputTier;
    private final int inputLimit;
    private final int outputLimit;
    private final String descriptionKey;

    TransformerTier(String label, String outputTier, int inputLimit, int outputLimit, String descriptionKey) {
        this.label = label;
        this.outputTier = outputTier;
        this.inputLimit = inputLimit;
        this.outputLimit = outputLimit;
        this.descriptionKey = descriptionKey;
    }

    /** 提示里显示的「LV → MV」这种文字。 */
    public String label() {
        return this.label;
    }

    /** 输出侧的等级文字（外观提示用）。 */
    public String outputTier() {
        return this.outputTier;
    }

    /** 输入面每 tick 最多接多少 FE。 */
    public int inputLimit() {
        return this.inputLimit;
    }

    /** 输出面每 tick 最多送多少 FE。 */
    public int outputLimit() {
        return this.outputLimit;
    }

    /** 物品提示里那句说明的语言键。 */
    public String descriptionKey() {
        return this.descriptionKey;
    }
}
