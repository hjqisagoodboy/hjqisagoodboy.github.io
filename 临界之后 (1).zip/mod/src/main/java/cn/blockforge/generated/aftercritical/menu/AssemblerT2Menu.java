package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.AssemblerT1BlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 装配机 T2 的菜单：槽位和 T1 完全一样（6 个输入槽 + 1 个流体槽 + 1 个输出槽），
 * 只是菜单类型不同，这样客户端能认出「打开的是 T2」并套用对的界面。
 */
public class AssemblerT2Menu extends AssemblerT1Menu {

    /** 服务端用：直接拿方块实体当容器。 */
    public AssemblerT2Menu(int containerId, Inventory playerInventory, AssemblerT1BlockEntity machine) {
        super(ModMenus.ASSEMBLER_T2.get(), containerId, playerInventory, machine);
    }

    /** 客户端用：拿不到方块实体时，容器可以是个空壳，内容由同步包填。 */
    public AssemblerT2Menu(int containerId, Inventory playerInventory, Container container,
                           @Nullable EnergyMachineHost machine) {
        super(ModMenus.ASSEMBLER_T2.get(), containerId, playerInventory, container, machine);
    }

    /** 客户端收到「打开菜单」的包后调用：从包里的坐标找回方块实体。 */
    public static AssemblerT2Menu fromNetwork(int containerId, Inventory playerInventory,
                                              RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof AssemblerT1BlockEntity assembler) {
            return new AssemblerT2Menu(containerId, playerInventory, assembler);
        }
        return new AssemblerT2Menu(containerId, playerInventory,
                new SimpleContainer(AssemblerT1BlockEntity.SLOT_COUNT), null);
    }
}
