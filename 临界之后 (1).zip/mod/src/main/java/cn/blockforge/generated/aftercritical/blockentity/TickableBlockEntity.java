package cn.blockforge.generated.aftercritical.blockentity;

/**
 * 需要在服务端每 tick 跑一次逻辑的方块实体。
 *
 * <p>方块那边（{@code TickingMachineBlock}）只认这个接口，所以发电机、电池、装配机
 * 这些完全不同的机器可以用同一套「每 tick 干活」的架子。
 */
public interface TickableBlockEntity {

    /** 只在服务端调用。 */
    void serverTick();
}
