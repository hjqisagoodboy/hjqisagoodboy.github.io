package cn.blockforge.generated.aftercritical.item;

import cn.blockforge.generated.aftercritical.block.NukeBlock;
import cn.blockforge.generated.aftercritical.blockentity.NukeBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModDataComponents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 起爆器：核弹的遥控器。
 *
 * <p>用法（和 HBM 一样）：
 * <ol>
 *   <li>潜行 + 右键核弹 → 绑定，弹上会出现一行「已绑定」的提示；</li>
 *   <li>拿着起爆器右键空气 → 五秒倒计时之后起爆；</li>
 *   <li>潜行 + 右键空气 → 解绑（绑错了或者想换一颗时用）。</li>
 * </ol>
 *
 * <p>起爆器本身不会被消耗，可以反复用；绑定的坐标存在数据组件里，
 * 换维度、退出游戏都还在。
 */
public class DetonatorItem extends Item {

    /**
     * 倒计时不再是固定 5 秒：每颗弹有自己基础引信（小男孩 5 秒，沙皇 8 秒），
     * 装上减速伞再翻倍。倒计时长度由核弹自己算（{@code NukeBlockEntity#arm}），
     * 起爆器这边只负责把火点上。
     */

    public DetonatorItem(Properties properties) {
        super(properties);
    }

    /** 起爆器绑的是哪颗核弹；没绑定时返回 {@code null}。 */
    @Nullable
    public static GlobalPos target(ItemStack stack) {
        return stack.get(ModDataComponents.DETONATOR_TARGET.get());
    }

    private static void bind(ItemStack stack, @Nullable GlobalPos pos) {
        if (pos == null) {
            stack.remove(ModDataComponents.DETONATOR_TARGET.get());
        } else {
            stack.set(ModDataComponents.DETONATOR_TARGET.get(), pos);
        }
    }

    // ------------------------------------------------------------------
    // 潜行右键核弹：绑定
    // ------------------------------------------------------------------

    /**
     * 绑定走 {@code onItemUseFirst}：它在「方块自身的右键行为」之前跑，
     * 所以潜行右键核弹时能抢在「打开装配界面」前面把绑定做完。
     */
    @Override
    public InteractionResult onItemUseFirst(ItemStack stack, UseOnContext context) {
        Player player = context.getPlayer();
        if (player == null || !player.isShiftKeyDown()) {
            return InteractionResult.PASS;
        }
        BlockState state = context.getLevel().getBlockState(context.getClickedPos());
        if (!(state.getBlock() instanceof NukeBlock nuke)) {
            return InteractionResult.PASS;
        }
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos().immutable();
        if (!level.isClientSide) {
            bind(stack, GlobalPos.of(level.dimension(), pos));
            player.displayClientMessage(Component.translatable(
                    "message.aftercritical.detonator.bound",
                    Component.translatable(nuke.kind().langKey()),
                    pos.getX(), pos.getY(), pos.getZ()), true);
            level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.PLAYERS, 0.8F, 1.6F);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    // ------------------------------------------------------------------
    // 右键空气：引爆 / 解绑
    // ------------------------------------------------------------------

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        GlobalPos target = target(stack);

        // 潜行右键空气 = 解绑
        if (player.isShiftKeyDown()) {
            if (!level.isClientSide && target != null) {
                bind(stack, null);
                player.displayClientMessage(
                        Component.translatable("message.aftercritical.detonator.unbound"), true);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }

        if (target == null) {
            if (!level.isClientSide) {
                player.displayClientMessage(
                        Component.translatable("message.aftercritical.detonator.no_target"), true);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }

        if (!level.isClientSide && level instanceof ServerLevel server) {
            arm(server, player, stack, target);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** 把绑定的那颗核弹点着；核弹已经被拆了就把绑定清掉。 */
    private static void arm(ServerLevel level, Player player, ItemStack stack, GlobalPos target) {
        ResourceKey<Level> dimension = target.dimension();
        if (!level.dimension().equals(dimension)) {
            // 起爆器只能引爆自己这个维度里的目标，跨维度不乱开
            player.displayClientMessage(
                    Component.translatable("message.aftercritical.detonator.wrong_dimension"), true);
            return;
        }
        BlockPos pos = target.pos();
        if (!level.isLoaded(pos) || !(level.getBlockEntity(pos) instanceof NukeBlockEntity nuke)) {
            bind(stack, null);
            player.displayClientMessage(
                    Component.translatable("message.aftercritical.detonator.missing"), true);
            return;
        }
        if (!nuke.arm(player)) {
            player.displayClientMessage(
                    Component.translatable("message.aftercritical.detonator.already_armed"), true);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        GlobalPos target = target(stack);
        if (target == null) {
            tooltip.add(Component.translatable("tooltip.aftercritical.detonator.unbound")
                    .withStyle(ChatFormatting.GRAY));
        } else {
            BlockPos pos = target.pos();
            tooltip.add(Component.translatable("tooltip.aftercritical.detonator.bound",
                            pos.getX(), pos.getY(), pos.getZ())
                    .withStyle(ChatFormatting.GOLD));
        }
        tooltip.add(Component.translatable("tooltip.aftercritical.detonator.usage")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
