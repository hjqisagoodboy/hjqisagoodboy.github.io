package cn.blockforge.generated.aftercritical.compat.jei;

import cn.blockforge.generated.aftercritical.recipe.AssemblerIngredient;
import cn.blockforge.generated.aftercritical.recipe.FluidAmount;
import cn.blockforge.generated.aftercritical.recipe.FluidProcessRecipe;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.builder.ITooltipBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.widgets.IRecipeExtrasBuilder;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.material.Fluid;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 流体机器在 JEI 里的样子：电解槽、化工厂、空气分离器共用这一个类别。
 *
 * <p>左边是物品原料和液体原料，中间一个箭头，右边是物品产物和液体产物；
 * 最下面一行写要多久、吃多少电。配方里没有的那一栏（比如空气分离器没有物品）就不画。
 */
public class FluidProcessRecipeCategory implements IRecipeCategory<FluidProcessRecipe> {

    private static final int WIDTH = 156;
    private static final int HEIGHT = 112;
    /** 带底部提示的页面要多留一行。 */
    private static final int HEIGHT_WITH_HINT = 126;

    /** 物品原料列、液体原料列、物品产物列、液体产物列。 */
    private static final int ITEM_IN_X = 6;
    private static final int FLUID_IN_X = 30;
    private static final int ITEM_OUT_X = 108;
    private static final int FLUID_OUT_X = 132;

    private static final int ARROW_X = 82;
    private static final int ARROW_Y = 26;

    /** 每个槽占多少像素。 */
    private static final int ROW_STEP = 22;

    /**
     * 物品原料一列最多摆几个。
     *
     * <p>以前这里是 2，于是玻璃固化炉的「同位素路线」三样原料（短寿命同位素、玻璃、铅板）
     * 只画得出前两样，铅板在 JEI 里凭空消失，玩家会以为这条配方根本不收铅板。
     * 现在按实际最挤的配方（三样）留位置。
     */
    private static final int ITEM_IN_ROWS = 3;
    /** 液体原料一列摆两个，第三样换到右边一列（化工厂、沉淀槽最多三样）。 */
    private static final int FLUID_IN_ROWS = 2;
    /** 产物一列最多摆三个：离心萃取器一次会甩出三样固体（钚 / 铀 / 锕系）。 */
    private static final int OUTPUT_ROWS = 3;

    /** 第一行槽的 y、催化剂槽的 y（排在物品原料下面）、底部两行说明文字的 y。 */
    private static final int FIRST_ROW_Y = 6;
    private static final int CATALYST_Y = FIRST_ROW_Y + ITEM_IN_ROWS * ROW_STEP;
    private static final int INFO_TEXT_Y = 96;
    private static final int HINT_TEXT_Y = 108;

    /** JEI 里液体槽的显示尺寸（和物品槽一样大）。 */
    private static final int FLUID_SLOT = 16;

    private final RecipeType<FluidProcessRecipe> recipeType;
    private final Component title;
    private final IDrawable icon;
    /** 不为空时，这一页每张配方底下多写一句提示（比如离心机那页的电网规模提示）。 */
    @Nullable
    private final String hintKey;

    public FluidProcessRecipeCategory(IGuiHelper guiHelper, RecipeType<FluidProcessRecipe> recipeType,
                                      Component title, ItemLike machine) {
        this(guiHelper, recipeType, title, machine, null);
    }

    public FluidProcessRecipeCategory(IGuiHelper guiHelper, RecipeType<FluidProcessRecipe> recipeType,
                                      Component title, ItemLike machine, @Nullable String hintKey) {
        this.recipeType = recipeType;
        this.title = title;
        this.icon = guiHelper.createDrawableItemLike(machine);
        this.hintKey = hintKey;
    }

    @Override
    public RecipeType<FluidProcessRecipe> getRecipeType() {
        return this.recipeType;
    }

    @Override
    public Component getTitle() {
        return this.title;
    }

    @Override
    public IDrawable getIcon() {
        return this.icon;
    }


    @Override
    public int getWidth() {
        return WIDTH;
    }

    @Override
    public int getHeight() {
        return this.hintKey == null ? HEIGHT : HEIGHT_WITH_HINT;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, FluidProcessRecipe recipe, IFocusGroup focuses) {
        List<AssemblerIngredient> itemInputs = recipe.itemInputs();
        for (int i = 0; i < Math.min(ITEM_IN_ROWS, itemInputs.size()); i++) {
            AssemblerIngredient ingredient = itemInputs.get(i);
            int count = ingredient.count();
            builder.addSlot(RecipeIngredientRole.INPUT, ITEM_IN_X, FIRST_ROW_Y + i * ROW_STEP)
                    .setStandardSlotBackground()
                    .addIngredients(ingredient.ingredient())
                    .addRichTooltipCallback((slot, tooltip) -> addCountTooltip(tooltip, count));
        }

        // 催化剂（不消耗）：单独摆在物品原料列下面，鼠标悬停会写明「放进去就行，不消耗」
        recipe.catalyst().ifPresent(catalyst -> {
            int count = catalyst.count();
            builder.addSlot(RecipeIngredientRole.CATALYST, ITEM_IN_X, CATALYST_Y)
                    .setStandardSlotBackground()
                    .addIngredients(catalyst.ingredient())
                    .addRichTooltipCallback((slot, tooltip) -> {
                        tooltip.add(Component.translatable("jei.aftercritical.catalyst"));
                        addCountTooltip(tooltip, count);
                    });
        });

        List<FluidAmount> fluidInputs = recipe.fluidInputs();
        for (int i = 0; i < Math.min(FLUID_IN_ROWS * 2, fluidInputs.size()); i++) {
            addFluidSlot(builder, RecipeIngredientRole.INPUT, FLUID_IN_X + (i / FLUID_IN_ROWS) * 24,
                    FIRST_ROW_Y + (i % FLUID_IN_ROWS) * ROW_STEP, fluidInputs.get(i));
        }

        // 物品产物最多列三行：离心萃取器一次会甩出三样固体（钚 / 铀 / 锕系）
        List<ItemStack> itemOutputs = recipe.itemOutputs();
        for (int i = 0; i < Math.min(OUTPUT_ROWS, itemOutputs.size()); i++) {
            builder.addSlot(RecipeIngredientRole.OUTPUT, ITEM_OUT_X, FIRST_ROW_Y + i * ROW_STEP)
                    .setOutputSlotBackground()
                    .addItemStack(itemOutputs.get(i));
        }

        // 液体产物最多列三行：电解槽电解水会同时出氘、氢、氧三样（以前第三样在 JEI 里看不见）
        List<FluidAmount> fluidOutputs = recipe.fluidOutputs();
        for (int i = 0; i < Math.min(OUTPUT_ROWS, fluidOutputs.size()); i++) {
            addFluidSlot(builder, RecipeIngredientRole.OUTPUT, FLUID_OUT_X,
                    FIRST_ROW_Y + i * ROW_STEP, fluidOutputs.get(i));
        }
    }

    @Override
    public void createRecipeExtras(IRecipeExtrasBuilder builder, FluidProcessRecipe recipe, IFocusGroup focuses) {
        builder.addRecipeArrow().setPosition(ARROW_X, ARROW_Y);
        builder.addText(Component.translatable("jei.aftercritical.recipe_info",
                String.format("%.1f", recipe.duration() / 20.0F), recipe.energyPerTick()), 6, INFO_TEXT_Y);
        if (this.hintKey != null) {
            builder.addText(Component.translatable(this.hintKey), 6, HINT_TEXT_Y);
        }
    }

    /** 一个带液体图标的槽；液体查不到（模组被删了）就跳过。 */
    private static void addFluidSlot(IRecipeLayoutBuilder builder, RecipeIngredientRole role, int x, int y,
                                     FluidAmount amount) {
        Fluid fluid = amount.resolve();
        if (fluid == null) {
            return;
        }
        builder.addSlot(role, x, y)
                .setFluidRenderer(amount.amount(), true, FLUID_SLOT, FLUID_SLOT)
                .addFluidStack(fluid, amount.amount());
    }

    private static void addCountTooltip(ITooltipBuilder tooltip, int count) {
        if (count > 1) {
            tooltip.add(Component.translatable("jei.aftercritical.count", count));
        }
    }
}
