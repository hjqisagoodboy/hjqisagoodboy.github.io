package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.GeneratorMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * 两种发电机共用的界面：一个燃料槽 + 能量条 + 燃烧进度。
 *
 * <p>燃料槽右边的箭头里灌的就是「这份燃料烧到哪了」。
 */
public class GeneratorScreen extends AbstractMachineScreen<GeneratorMenu> {

    public GeneratorScreen(GeneratorMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }
}
