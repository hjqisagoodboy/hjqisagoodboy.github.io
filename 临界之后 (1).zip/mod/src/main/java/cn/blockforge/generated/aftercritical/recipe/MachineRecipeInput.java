package cn.blockforge.generated.aftercritical.recipe;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeInput;

import java.util.List;

/**
 * 机器配方匹配时用的「原料快照」：把机器所有输入槽里的东西排成一个列表。
 *
 * <p>原版只有一个输入槽时用 {@code SingleRecipeInput}，
 * 但压块机有 6 个输入槽、以后的新机器可能更多，
 * 所以配方需要一次看到全部输入槽，才能判断「这些槽加起来够不够」。
 */
public record MachineRecipeInput(List<ItemStack> items) implements RecipeInput {

    public MachineRecipeInput {
        items = List.copyOf(items);
    }

    @Override
    public ItemStack getItem(int index) {
        return this.items.get(index);
    }

    @Override
    public int size() {
        return this.items.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }
}
