package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.blockentity.FluidMachineBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.FluidMachineKind;
import cn.blockforge.generated.aftercritical.blockentity.FluidTankHost;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

import javax.annotation.Nullable;

/**
 * 十台流体机器共用的界面菜单。
 *
 * <p>版式（和 {@link MachineLayout} 一致）：
 * <ul>
 *   <li>左边：竖直能量条；</li>
 *   <li>中间：物品输入槽 → 箭头 → 产物槽；</li>
 *   <li>右边：一根根流体长条，长条右边紧跟着<b>两个</b>罐子槽——
 *       <b>操作槽</b>（放要处理的罐子）和<b>返还槽</b>（处理完的罐子在这里等你拿）。</li>
 * </ul>
 *
 * <p>这样自动化的接法很固定：管道往操作槽塞罐子、从返还槽抽罐子，
 * 机器自己在中间把 1000 mB 换来换去；而长条本身还是 {@code IFluidHandler}，
 * 智能流体管道可以直接接长条，完全不受罐子槽影响。
 */
public class FluidMachineMenu extends AbstractMachineMenu implements FluidBarHost {

    /** 右键长条时，发给服务端的按钮号 = 这个基数 + 长条编号。 */
    public static final int TANK_BUTTON_BASE = 100;

    private final FluidMachineKind kind;
    @Nullable
    private final FluidTankHost tankHost;
    @Nullable
    private final FluidMachineBlockEntity machineEntity;

    /** 每根长条同步两个数：装了多少、装的是什么。 */
    private static final int TANK_FIELDS = 2;

    private final int[] tankAmount = new int[FluidMachineBlockEntity.MAX_JAR_SLOTS];
    private final int[] tankFluid = new int[FluidMachineBlockEntity.MAX_JAR_SLOTS];

    private final ContainerData tankData = new ContainerData() {
        @Override
        public int get(int index) {
            int tank = index / TANK_FIELDS;
            return index % TANK_FIELDS == 0 ? tankAmount[tank] : tankFluid[tank];
        }

        @Override
        public void set(int index, int value) {
            int tank = index / TANK_FIELDS;
            if (index % TANK_FIELDS == 0) {
                tankAmount[tank] = value;
            } else {
                tankFluid[tank] = value;
            }
        }

        @Override
        public int getCount() {
            return FluidMachineBlockEntity.MAX_JAR_SLOTS * TANK_FIELDS;
        }
    };

    public FluidMachineMenu(MenuType<?> type, int containerId, Inventory playerInventory, FluidMachineKind kind,
                            @Nullable EnergyMachineHost machine, @Nullable FluidTankHost tankHost,
                            Container container, @Nullable FluidMachineBlockEntity machineEntity) {
        super(type, containerId, playerInventory, machineSlotCount(kind), machine, tankCount(kind));
        this.kind = kind;
        this.tankHost = tankHost;
        this.machineEntity = machineEntity;

        // 输入槽：一行两个，摆满换行。玻璃固化炉有 3 个输入，第三格就落到第二行，
        // 不会压到中间那根「输入 → 输出」箭头上（以前三格排一行时它和箭头叠在一起）。
        for (int i = 0; i < kind.itemInputSlots(); i++) {
            this.addSlot(new InputSlot(container, i,
                    MachineLayout.inputSlotX(i), MachineLayout.inputSlotY(i)));
        }
        // 产物槽：多数机器 1 格，离心萃取器 3 格，竖直排在物品区右边
        for (int i = 0; i < kind.itemOutputSlots(); i++) {
            this.addSlot(new OutputSlot(container, FluidMachineBlockEntity.outputSlot(kind, i),
                    MachineLayout.ITEM_X + 72, MachineLayout.ITEM_Y + i * MachineLayout.ITEM_STEP));
        }
        for (int i = 0; i < getTankCount(); i++) {
            this.addSlot(new OperateSlot(container, FluidMachineBlockEntity.jarOpSlotIndex(kind, i),
                    jarOpX(i), jarY(i)));
            this.addSlot(new ReturnSlot(container, FluidMachineBlockEntity.jarReturnSlotIndex(kind, i),
                    jarReturnX(i), jarY(i)));
        }
        this.addPlayerInventory(playerInventory);
        this.addDataSlots(this.tankData);
    }

    /** 这台机器在菜单里实际占几个槽（物品输入 + 产物 + 罐子槽），Shift 点击要靠它分界。 */
    private static int machineSlotCount(FluidMachineKind kind) {
        return kind.itemInputSlots() + kind.itemOutputSlots() + tankSlots(kind);
    }

    /** 客户端兜底用的空容器：槽数必须和真正的方块实体一致，否则罐子槽会错位。 */
    private static int slotCount(FluidMachineKind kind) {
        return FluidMachineBlockEntity.slotCount(kind);
    }

    /** 这台机器有几根流体长条（最多 5 根）。 */
    public static int tankCount(FluidMachineKind kind) {
        return Math.min(FluidMachineBlockEntity.MAX_JAR_SLOTS,
                kind.fluidInputTanks() + kind.fluidOutputTanks());
    }

    /** 罐子槽的个数：每根长条两个。 */
    public static int tankSlots(FluidMachineKind kind) {
        return tankCount(kind) * FluidMachineBlockEntity.JAR_SLOTS_PER_TANK;
    }

    /** 第 {@code tankIndex} 根长条（面板坐标）。 */
    public static int barXOf(int tankIndex) {
        return MachineLayout.FLUID_X;
    }

    public static int barYOf(int tankIndex) {
        return MachineLayout.FLUID_TOP + tankIndex * MachineLayout.FLUID_STEP;
    }

    /** 第 {@code tankIndex} 根长条的操作槽 x。 */
    public static int jarOpX(int tankIndex) {
        return MachineLayout.FLUID_X + MachineLayout.FLUID_OP_DX;
    }

    /** 第 {@code tankIndex} 根长条的返还槽 x。 */
    public static int jarReturnX(int tankIndex) {
        return MachineLayout.FLUID_X + MachineLayout.FLUID_RET_DX;
    }

    /** 罐子槽的 y：和长条齐平，格子比长条高 2 像素，上面露出 1 像素。 */
    public static int jarY(int tankIndex) {
        return barYOf(tankIndex) - 1;
    }

    /** 客户端收到「打开菜单」的包后调用。 */
    public static FluidMachineMenu fromNetwork(MenuType<?> type, int containerId, Inventory playerInventory,
                                               RegistryFriendlyByteBuf buffer, FluidMachineKind kind) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof FluidMachineBlockEntity machine) {
            return new FluidMachineMenu(type, containerId, playerInventory, kind, machine, machine, machine, machine);
        }
        return new FluidMachineMenu(type, containerId, playerInventory, kind, null, null,
                new SimpleContainer(slotCount(kind)), null);
    }

    @Override
    public void broadcastChanges() {
        if (this.tankHost != null) {
            for (int i = 0; i < FluidMachineBlockEntity.MAX_JAR_SLOTS; i++) {
                this.tankAmount[i] = this.tankHost.getTankAmount(i);
                this.tankFluid[i] = this.tankHost.getTankFluidId(i);
            }
        }
        super.broadcastChanges();
    }

    public FluidMachineKind kind() {
        return this.kind;
    }

    /** 界面上要画几根长条。 */
    public int getTankCount() {
        return Math.min(FluidMachineBlockEntity.MAX_JAR_SLOTS,
                this.kind.fluidInputTanks() + this.kind.fluidOutputTanks());
    }

    /** 前几根是进液长条（界面提示「往这里灌」）。 */
    public int getFluidInputTankCount() {
        return this.kind.fluidInputTanks();
    }

    public int getTankAmount(int index) {
        return index >= 0 && index < this.tankAmount.length ? this.tankAmount[index] : 0;
    }

    public int getTankFluidId(int index) {
        return index >= 0 && index < this.tankFluid.length ? this.tankFluid[index] : -1;
    }

    public int getTankCapacity() {
        return FluidMachineBlockEntity.TANK_CAPACITY;
    }

    // ------------------------------------------------------------------
    // FluidBarHost：界面照着这些坐标画长条
    // ------------------------------------------------------------------

    @Override
    public int barCount() {
        return getTankCount();
    }

    @Override
    public int barX(int index) {
        return barXOf(index);
    }

    @Override
    public int barY(int index) {
        return barYOf(index);
    }

    @Override
    public int barWidth(int index) {
        return MachineLayout.FLUID_BAR_W;
    }

    @Override
    public int barHeight(int index) {
        return MachineLayout.FLUID_BAR_H;
    }

    @Override
    public int barAmount(int index) {
        return getTankAmount(index);
    }

    @Override
    public int barFluidId(int index) {
        return getTankFluidId(index);
    }

    @Override
    public int barCapacity() {
        return getTankCapacity();
    }

    @Override
    public boolean barIsInput(int index) {
        return index < getFluidInputTankCount();
    }

    @Override
    public int barButtonBase() {
        return TANK_BUTTON_BASE;
    }

    @Override
    public MachineLayout.Arrow arrowGeometry() {
        // 沉淀槽这类「只有流体进、没有物品槽」的机器，画箭头会指着空气
        if (this.kind.itemInputSlots() == 0 && this.kind.itemOutputSlots() == 0) {
            return null;
        }
        return ARROW;
    }

    /** 物品输入 → 产物那段箭头。 */
    public static final MachineLayout.Arrow ARROW =
            new MachineLayout.Arrow(MachineLayout.ITEM_X + 40, MachineLayout.ITEM_Y + 8, 28);

    // ------------------------------------------------------------------
    // 右键长条：用鼠标上拿着的罐子装 / 卸
    // ------------------------------------------------------------------

    /**
     * 客户端右键第 {@code tankIndex} 根长条时，会发一个按钮包过来。
     *
     * <p>服务端在这里动真格：鼠标上拿着一个通用流体罐，
     * 空罐就从长条里装，满罐就往进液长条里倒。
     */
    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (id < TANK_BUTTON_BASE || this.machineEntity == null) {
            return false;
        }
        int tankIndex = id - TANK_BUTTON_BASE;
        if (tankIndex < 0 || tankIndex >= getTankCount()) {
            return false;
        }
        FluidTank tank = this.machineEntity.tankForGui(tankIndex);
        if (tank == null) {
            return false;
        }
        ItemStack carried = this.getCarried();
        if (!(carried.getItem() instanceof UniversalTankItem) || carried.getCount() != 1) {
            // 右键只处理「鼠标上拿着一个罐子」；罐子的位置只看罐里装着什么，
            // 空了就自动让位，不需要再留一个「空手右键」的手动操作
            return false;
        }
        boolean changed = exchange(tank, tankIndex, carried);
        if (changed) {
            this.machineEntity.setChanged();
            this.broadcastChanges();
        }
        return changed;
    }

    /** 一个罐子和一根长条交换一次流体。 */
    private boolean exchange(FluidTank tank, int tankIndex, ItemStack carried) {
        FluidStack inJar = UniversalTankItem.getFluid(carried);
        if (inJar.isEmpty()) {
            // 空罐：从长条里装（进液、出液长条都能装，方便玩家挪液体）
            if (tank.isEmpty() || !UniversalTankItem.accepts(carried, tank.getFluid().getFluid())) {
                return false;
            }
            int moved = Math.min(UniversalTankItem.CAPACITY, tank.getFluidAmount());
            FluidStack drained = tank.drain(moved, IFluidHandler.FluidAction.EXECUTE);
            if (drained.isEmpty()) {
                return false;
            }
            this.setCarried(UniversalTankItem.withFluid(carried, drained.getFluid(), drained.getAmount()));
            return true;
        }
        // 满罐：只能往进液长条里倒
        if (tankIndex >= this.kind.fluidInputTanks()) {
            return false;
        }
        // 统一入口：倒进哪个罐由分配器决定，不认「你点的是哪根长条」。
        // 于是水永远进同一个罐，绝不会三个罐都变成水。
        int target = this.machineEntity == null
                ? tankIndex
                : this.machineEntity.findInputTankFor(inJar.getFluid());
        if (target < 0) {
            return false;
        }
        FluidTank targetTank = this.machineEntity == null ? tank : this.machineEntity.tankForGui(target);
        if (targetTank == null) {
            return false;
        }
        int space = targetTank.getCapacity() - targetTank.getFluidAmount();
        if (space <= 0) {
            return false;
        }
        int filled = targetTank.fill(inJar.copyWithAmount(Math.min(space, inJar.getAmount())),
                IFluidHandler.FluidAction.EXECUTE);
        if (filled <= 0) {
            return false;
        }
        this.setCarried(UniversalTankItem.withFluid(carried, inJar.getFluid(), inJar.getAmount() - filled));
        return true;
    }

    /**
     * 操作槽：只放通用流体罐，能叠 64 个。
     *
     * <p>一叠罐子机器会一个一个处理，处理完的自己往右边的返还槽跑。
     */
    public static class OperateSlot extends Slot {

        public OperateSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.getItem() instanceof UniversalTankItem;
        }
    }

    /** 返还槽：机器放处理好的罐子，玩家 / 管道只能拿、不能塞。 */
    public static class ReturnSlot extends Slot {

        public ReturnSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return false;
        }
    }
}
