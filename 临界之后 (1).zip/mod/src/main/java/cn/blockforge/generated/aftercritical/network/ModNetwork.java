package cn.blockforge.generated.aftercritical.network;

import cn.blockforge.generated.aftercritical.AfterCritical;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * 本模组的客户端包：核爆全屏爆闪 + 蘑菇云。
 *
 * <p>注册在模组总线上（由主类调 {@code modBus.addListener(ModNetwork::register)}）。
 * 处理函数只改 {@link BlastFxState} 这个纯数据类，不碰任何客户端界面类，
 * 所以专用服务器不会因为缺客户端类而崩。
 */
public final class ModNetwork {

    /** 协议版本：以后改了包结构就往上加一。 */
    private static final String VERSION = "1";

    private ModNetwork() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(VERSION);
        registrar.playToClient(BlastFlashPayload.TYPE, BlastFlashPayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() -> BlastFxState.trigger(payload.intensity())));
        // 蘑菇云：一朵云只发一条「在哪、多大、活多久」，怎么画是客户端的事
        registrar.playToClient(MushroomCloudPayload.TYPE, MushroomCloudPayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() -> CloudState.accept(payload)));
    }
}
