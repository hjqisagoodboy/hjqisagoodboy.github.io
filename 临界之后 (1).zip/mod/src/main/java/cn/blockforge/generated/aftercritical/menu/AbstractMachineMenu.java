package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.blockentity.MachineBlockEntity;
import cn.blockforge.generated.aftercritical.item.MoldItem;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

import javax.annotation.Nullable;

/**
 * 三台机器共用的菜单基类。
 *
 * <p>它把「服务端的能量数字」同步给客户端 GUI，并把玩家背包的 36 个槽统一摆好，
 * 这样每台具体机器只需要再摆自己的机器槽。
 *
 * <p>同步方式：{@link ContainerData}（数据槽）。服务端每 tick 在 {@link #broadcastChanges()}
 * 里把最新的电量/运行状态塞进去，客户端收到后写回本地字段，GUI 直接读。
 */
public abstract class AbstractMachineMenu extends AbstractContainerMenu {

    public static final int DATA_ENERGY = 0;
    public static final int DATA_STATUS = 1;
    public static final int DATA_PROGRESS = 2;
    public static final int DATA_PROGRESS_MAX = 3;

    /** 玩家背包（3 行 9 列）左上角位置，和 {@link MachineLayout} 共用一套坐标。 */
    public static final int PLAYER_INV_X = MachineLayout.INVENTORY_X;
    public static final int PLAYER_INV_Y = MachineLayout.inventoryYFor(0);
    /** 快捷栏那一行的 y。 */
    public static final int HOTBAR_Y = PLAYER_INV_Y + 58;

    /** 客户端兜底用：拿不到方块实体时也要能建出菜单（例如区块还没加载）。 */
    @Nullable
    private final EnergyMachineHost machine;
    private final int machineSlotCount;
    /** 这台机器界面上有几行流体长条（决定面板多高）。 */
    private final int fluidRows;

    /**
     * 底部读数占几行（默认 3 行）。读数多的界面（托卡马克、嬗变器）把面板往下长，
     * 免得字压到背包格子上。
     */
    private int textLines = 3;

    private int energyStored;
    private int status = MachineBlockEntity.STATUS_IDLE;
    private int progress;
    private int maxProgress;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case DATA_ENERGY -> energyStored;
                case DATA_STATUS -> status;
                case DATA_PROGRESS -> progress;
                case DATA_PROGRESS_MAX -> maxProgress;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case DATA_ENERGY -> energyStored = value;
                case DATA_STATUS -> status = value;
                case DATA_PROGRESS -> progress = value;
                case DATA_PROGRESS_MAX -> maxProgress = value;
                default -> {
                }
            }
        }

        @Override
        public int getCount() {
            return 4;
        }
    };

    protected AbstractMachineMenu(@Nullable MenuType<?> type, int containerId, Inventory playerInventory,
                                  int machineSlotCount, @Nullable EnergyMachineHost machine) {
        this(type, containerId, playerInventory, machineSlotCount, machine, 0);
    }

    /**
     * 带「流体行数」的版本：右边有几根流体长条，面板就按它长高。
     *
     * @param fluidRows 0 = 没有流体的机器（破碎机、装配机……），最多 5 行
     */
    protected AbstractMachineMenu(@Nullable MenuType<?> type, int containerId, Inventory playerInventory,
                                  int machineSlotCount, @Nullable EnergyMachineHost machine, int fluidRows) {
        super(type, containerId);
        this.machineSlotCount = machineSlotCount;
        this.machine = machine;
        this.fluidRows = Math.max(0, fluidRows);
        this.addDataSlots(this.data);
    }

    /** 底部读数有几行。 */
    public int textLines() {
        return this.textLines;
    }

    /** 读数超过 3 行的界面在构造时调一下，面板会按行数长高。 */
    protected void setTextLines(int lines) {
        this.textLines = Math.max(3, lines);
    }

    /** 面板高度（和界面、背包槽位用的是同一个算法）。 */
    public int guiHeight() {
        return inventoryY() + 58 + 18 + 6;
    }

    /** 底部数字块第一行的 y。 */
    public int textY() {
        return MachineLayout.textY(this.fluidRows);
    }

    /** 「背包」两个字的位置：读数行数多了就往下让。 */
    public int inventoryLabelY() {
        return MachineLayout.inventoryLabelY(this.fluidRows) + (this.textLines - 3) * MachineLayout.TEXT_STEP;
    }

    /** 玩家背包第一行的 y。 */
    public int inventoryY() {
        return inventoryLabelY() + 10;
    }

    /** 这台机器界面右边有几行流体。 */
    public int fluidRows() {
        return this.fluidRows;
    }

    /** 摆在下方：玩家背包 3 行 + 快捷栏 1 行（y 跟着面板高度走）。 */
    protected void addPlayerInventory(Inventory playerInventory) {
        addPlayerInventory(playerInventory, inventoryY());
    }

    /** 自定义高度的界面用：{@code inventoryY} 是第一行背包的 y，快捷栏自动再往下 58 像素。 */
    protected void addPlayerInventory(Inventory playerInventory, int inventoryY) {
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                this.addSlot(new Slot(playerInventory, column + row * 9 + 9,
                        PLAYER_INV_X + column * 18, inventoryY + row * 18));
            }
        }
        for (int column = 0; column < 9; column++) {
            this.addSlot(new Slot(playerInventory, column, PLAYER_INV_X + column * 18, inventoryY + 58));
        }
    }

    /** 服务端每 tick 刷新一次数字，再交给父类同步到客户端。 */
    @Override
    public void broadcastChanges() {
        if (this.machine != null) {
            this.energyStored = this.machine.getEnergyStored();
            this.status = this.machine.getStatus();
            this.progress = this.machine.getProgress();
            this.maxProgress = this.machine.getMaxProgress();
        }
        super.broadcastChanges();
    }

    @Override
    public boolean stillValid(Player player) {
        return this.machine == null || this.machine.stillValid(player);
    }

    public int getEnergyStored() {
        return this.energyStored;
    }

    /** 储能上限；没有能量系统的方块（储罐）返回 0，界面就不会画能量条。 */
    public int getEnergyCapacity() {
        return this.machine == null ? 0 : this.machine.getEnergyCapacity();
    }

    /** 当前状态，取值见 {@link MachineBlockEntity} 里的 {@code STATUS_*} 常量。 */
    public int getStatus() {
        return this.status;
    }

    public boolean isRunning() {
        return this.status == MachineBlockEntity.STATUS_RUNNING;
    }

    /**
     * 这台机器界面上「输入 → 输出」箭头的位置；没有箭头的（电池、储罐）返回 {@code null}。
     *
     * <p>界面会把箭头画出来，并把加工进度灌进箭杆里——所以进度条不用再单独找地方摆。
     */
    @Nullable
    public MachineLayout.Arrow arrowGeometry() {
        return null;
    }

    /** 当前配方的加工进度，单位 tick。 */
    public int getProgress() {
        return this.progress;
    }

    /** 当前配方一共要多少 tick；0 表示没有配方。 */
    public int getMaxProgress() {
        return this.maxProgress;
    }

    /** Shift + 点击：机器槽和玩家背包互相搬。 */
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack moved = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stackInSlot = slot.getItem();
        moved = stackInSlot.copy();

        if (index < this.machineSlotCount) {
            if (!this.moveItemStackTo(stackInSlot, this.machineSlotCount, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else if (!this.moveItemStackTo(stackInSlot, 0, this.machineSlotCount, false)) {
            return ItemStack.EMPTY;
        }

        if (stackInSlot.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return moved;
    }

    /** 输出槽：只能拿，不能放。 */
    public static class OutputSlot extends Slot {

        public OutputSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return false;
        }
    }

    /** 锻压机的工具槽：只认模具（板材模具、线材模具），别的物品塞不进去。 */
    public static class MoldSlot extends Slot {

        public MoldSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.getItem() instanceof MoldItem;
        }
    }

    /**
     * 普通输入槽：放要加工的东西。
     *
     * <p>模具是「工具」不是「原料」，拖到输入槽会被弹回玩家背包——要去左边的工具槽。
     */
    public static class InputSlot extends Slot {

        public InputSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return !(stack.getItem() instanceof MoldItem);
        }
    }
}
