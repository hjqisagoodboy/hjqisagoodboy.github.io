package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.BatteryMvBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/** 电池 MV 方块：存 160,000 FE，最大输出 320 FE/t。 */
public class BatteryMvBlock extends TickingMachineBlock {

    public BatteryMvBlock(Properties properties) {
        super(properties, "MV", "tooltip.aftercritical.storage",
                BatteryMvBlockEntity.ENERGY_CAPACITY, "block.aftercritical.battery_mv.desc");
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(BatteryMvBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new BatteryMvBlockEntity(pos, state);
    }
}
