package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.AssemblerT1BlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.AssemblerT3BlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 装配机 T3 的菜单：一排 3 个输入槽 + 1 个产物槽，比 T1/T2 清爽。
 *
 * <p>三级配方最多三样原料，所以多余的槽不摆出来，玩家一眼就知道该放什么。
 * 槽号仍然用 {@link AssemblerT1BlockEntity} 那一套（输入 0~2、产物 6），
 * 所以方块实体那边一份代码三台机器通用。
 */
public class AssemblerT3Menu extends AbstractMachineMenu {

    /** 第一个输入槽的左上角。 */
    public static final int INPUT_X = 30;
    public static final int INPUT_Y = 30;
    /** 第一个输出槽的左上角。 */
    public static final int OUTPUT_X = 128;
    /** 格子间距（16 像素格子 + 2 像素缝）。 */
    public static final int STEP = 18;

    /** 服务端用：直接拿方块实体当容器。 */
    public AssemblerT3Menu(int containerId, Inventory playerInventory, AssemblerT3BlockEntity machine) {
        this(containerId, playerInventory, machine, machine);
    }

    /** 客户端用：拿不到方块实体时，容器可以是个空壳，内容由同步包填。 */
    public AssemblerT3Menu(int containerId, Inventory playerInventory, Container container,
                           @Nullable EnergyMachineHost machine) {
        super(ModMenus.ASSEMBLER_T3.get(), containerId, playerInventory,
                AssemblerT1BlockEntity.SLOT_COUNT, machine);

        for (int i = 0; i < 3; i++) {
            this.addSlot(new InputSlot(container, AssemblerT1BlockEntity.SLOT_INPUT_FIRST + i,
                    INPUT_X + i * STEP, INPUT_Y));
        }
        this.addSlot(new OutputSlot(container, AssemblerT1BlockEntity.SLOT_OUTPUT, OUTPUT_X, INPUT_Y));
        this.addPlayerInventory(playerInventory);
    }

    /** 3 个输入槽跟产物槽之间那根箭头。 */
    @Override
    public MachineLayout.Arrow arrowGeometry() {
        int start = INPUT_X + 3 * STEP + 2;
        int end = OUTPUT_X - 6;
        return new MachineLayout.Arrow(start, INPUT_Y + 8, Math.max(18, end - start));
    }

    /** 客户端收到「打开菜单」的包后调用。 */
    public static AssemblerT3Menu fromNetwork(int containerId, Inventory playerInventory,
                                              RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof AssemblerT3BlockEntity assembler) {
            return new AssemblerT3Menu(containerId, playerInventory, assembler);
        }
        return new AssemblerT3Menu(containerId, playerInventory,
                new SimpleContainer(AssemblerT1BlockEntity.SLOT_COUNT), null);
    }
}
