package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import cn.blockforge.generated.aftercritical.blockentity.MachineBlockEntity;
import cn.blockforge.generated.aftercritical.menu.AbstractMachineMenu;
import cn.blockforge.generated.aftercritical.menu.FluidBarHost;
import cn.blockforge.generated.aftercritical.menu.MachineLayout;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

import java.util.ArrayList;
import java.util.List;

/**
 * 所有机器界面共用的「画布」。
 *
 * <p>这一版把原来的「一张张 GUI 贴图」换成了代码画的统一面板，好处是十台机器长得一模一样，
 * 改一次布局全都跟着变，也不会再出现「槽位和贴图凹槽错开两像素」这种问题。
 *
 * <p>一块面板从左到右分三栏：
 * <ol>
 *   <li><b>左边</b>：竖直的能量条，顶上一个闪电图标；</li>
 *   <li><b>中间</b>：物品槽，输入 → 输出中间画一根醒目的箭头，箭杆里灌的就是加工进度；</li>
 *   <li><b>右边</b>：流体长条，颜色是流体色、高度是装了多少；每根长条右边跟两个罐子槽
 *       （左「操作」右「返还」），最右边一列是当前 mB 数字。</li>
 * </ol>
 *
 * <p>能量、状态、进度这些数字统一排在面板下方，字号一样、颜色统一（深灰 + 阴影），
 * 不再压在槽位上。
 */
public abstract class AbstractMachineScreen<T extends AbstractMachineMenu> extends AbstractContainerScreen<T> {

    // ------------------------------------------------------------------
    // 配色（整个模组就这一套，改颜色改这里）
    // ------------------------------------------------------------------

    protected static final int PANEL_BG = 0xFFC6C6C6;
    protected static final int PANEL_DARK = 0xFF373737;
    protected static final int PANEL_LIGHT = 0xFFFFFFFF;
    protected static final int SLOT_BG = 0xFF8B8B8B;
    protected static final int ENERGY_TRACK = 0xFF4A4A4A;
    protected static final int ENERGY_FILL = 0xFFFF8A1F;
    protected static final int ARROW_TRACK = 0xFF8B8B8B;
    protected static final int ARROW_EDGE = 0xFF5A5A5A;
    protected static final int ARROW_FILL = 0xFFFFC04A;
    protected static final int BOLT_COLOR = 0xFFFFD43B;
    protected static final int BOLT_EDGE = 0xFF8A6A00;
    protected static final int TANK_BG = 0xFF4A4A4A;
    protected static final int TANK_EDGE = 0xFF2A2A2A;
    /** 长条装满时的红色边框。 */
    protected static final int TANK_FULL_EDGE = 0xFFC02A1A;
    /** 长条里方向箭头的描边（半透明黑）和本体（白）。 */
    protected static final int ARROW_SHADOW = 0x99000000;
    protected static final int ARROW_GLYPH = 0xFFFFFFFF;

    protected static final int TEXT_DARK = 0x404040;
    protected static final int TEXT_GRAY = 0x6E6E6E;
    protected static final int TEXT_OK = 0x1B7A1B;
    protected static final int TEXT_WARN = 0xB07020;
    protected static final int TEXT_BAD = 0xB02020;

    /** 闪电图标，'#' 就是要填的像素。 */
    private static final String[] BOLT = {
            "....###..",
            "...###...",
            "..###....",
            ".######..",
            "#######..",
            "...###...",
            "..###....",
            ".###.....",
            ".##......",
            "#........"
    };

    protected AbstractMachineScreen(T menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
        this.imageWidth = MachineLayout.WIDTH;
        this.imageHeight = this.menu.guiHeight();
        // 标题往右让开一点：左上角要留给能量条的闪电
        this.titleLabelX = 30;
        this.titleLabelY = 6;
        this.inventoryLabelX = 30;
        this.inventoryLabelY = this.menu.inventoryLabelY();
    }

    // ------------------------------------------------------------------
    // 背景：面板 + 槽框 + 能量 + 箭头 + 流体条
    // ------------------------------------------------------------------

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        drawPanel(guiGraphics);
        drawFluidGroupFrame(guiGraphics);
        drawSlotFrames(guiGraphics);
        drawEnergyBar(guiGraphics);
        drawArrow(guiGraphics);
        drawFluidBars(guiGraphics);
    }

    /** 一块带立体边的浅灰面板，底部再用一条线把背包区和机器区分开。 */
    protected void drawPanel(GuiGraphics guiGraphics) {
        int x = this.leftPos;
        int y = this.topPos;
        int w = this.imageWidth;
        int h = this.imageHeight;

        guiGraphics.fill(x, y, x + w, y + h, PANEL_BG);
        // 外框
        guiGraphics.fill(x, y, x + w, y + 1, PANEL_DARK);
        guiGraphics.fill(x, y + h - 1, x + w, y + h, PANEL_DARK);
        guiGraphics.fill(x, y, x + 1, y + h, PANEL_DARK);
        guiGraphics.fill(x + w - 1, y, x + w, y + h, PANEL_DARK);
        // 内亮边
        guiGraphics.fill(x + 1, y + 1, x + w - 1, y + 2, PANEL_LIGHT);
        guiGraphics.fill(x + 1, y + 1, x + 2, y + h - 1, PANEL_LIGHT);
        // 背包区上方的分割线
        int split = this.topPos + this.menu.inventoryLabelY() - 4;
        guiGraphics.fill(x + 6, split, x + w - 6, split + 1, 0xFF9A9A9A);
        guiGraphics.fill(x + 6, split + 1, x + w - 6, split + 2, PANEL_LIGHT);
    }

    /** 给每个真实槽位画一个原版风格的凹槽底（不再依赖贴图）。 */
    protected void drawSlotFrames(GuiGraphics guiGraphics) {
        for (Slot slot : this.menu.slots) {
            if (slot.x < -1000 || slot.y < -1000) {
                continue;
            }
            drawSlot(guiGraphics, this.leftPos + slot.x - 1, this.topPos + slot.y - 1);
        }
    }

    protected void drawSlot(GuiGraphics guiGraphics, int x, int y) {
        guiGraphics.fill(x, y, x + 18, y + 18, SLOT_BG);
        guiGraphics.fill(x, y, x + 18, y + 1, PANEL_DARK);
        guiGraphics.fill(x, y, x + 1, y + 18, PANEL_DARK);
        guiGraphics.fill(x, y + 17, x + 18, y + 18, PANEL_LIGHT);
        guiGraphics.fill(x + 17, y, x + 18, y + 18, PANEL_LIGHT);
    }

    /** 左侧能量条 + 顶上的闪电图标。 */
    protected void drawEnergyBar(GuiGraphics guiGraphics) {
        int capacity = this.menu.getEnergyCapacity();
        if (capacity <= 0) {
            return;
        }
        drawBolt(guiGraphics, this.leftPos + MachineLayout.BOLT_X, this.topPos + MachineLayout.BOLT_Y);

        int x = this.leftPos + MachineLayout.ENERGY_X;
        int y = this.topPos + MachineLayout.ENERGY_Y;
        int w = MachineLayout.ENERGY_W;
        int h = MachineLayout.ENERGY_H;
        guiGraphics.fill(x - 1, y - 1, x + w + 1, y + h + 1, PANEL_DARK);
        guiGraphics.fill(x, y, x + w, y + h, ENERGY_TRACK);

        int stored = Math.max(0, Math.min(this.menu.getEnergyStored(), capacity));
        int inner = h - 2;
        int filled = Math.round(inner * (float) stored / capacity);
        if (filled > 0) {
            guiGraphics.fill(x + 1, y + h - 1 - filled, x + w - 1, y + h - 1, ENERGY_FILL);
        }
    }

    /** 一个小小的闪电图标（纯代码画，不需要贴图）。 */
    protected void drawBolt(GuiGraphics guiGraphics, int x, int y) {
        for (int row = 0; row < BOLT.length; row++) {
            String line = BOLT[row];
            for (int column = 0; column < line.length(); column++) {
                if (line.charAt(column) != '#') {
                    continue;
                }
                // 先画一格深色当描边，再画亮色，浅色面板上也看得清
                guiGraphics.fill(x + column + 1, y + row + 1, x + column + 2, y + row + 2, BOLT_EDGE);
            }
        }
        for (int row = 0; row < BOLT.length; row++) {
            String line = BOLT[row];
            for (int column = 0; column < line.length(); column++) {
                if (line.charAt(column) != '#') {
                    continue;
                }
                guiGraphics.fill(x + column, y + row, x + column + 1, y + row + 1, BOLT_COLOR);
            }
        }
    }

    /** 「输入 → 输出」的箭头；箭杆里按进度灌橙色。 */
    protected void drawArrow(GuiGraphics guiGraphics) {
        MachineLayout.Arrow arrow = this.menu.arrowGeometry();
        if (arrow == null) {
            return;
        }
        int x = this.leftPos + arrow.x();
        int y = this.topPos + arrow.y();
        int half = MachineLayout.ARROW_HEIGHT / 2;
        int shaft = arrow.shaftLength();

        // 箭杆底
        guiGraphics.fill(x, y - half - 1, x + shaft, y + half + 1, ARROW_EDGE);
        guiGraphics.fill(x, y - half, x + shaft, y + half, ARROW_TRACK);

        int max = this.menu.getMaxProgress();
        if (max > 0) {
            int done = Math.max(0, Math.min(this.menu.getProgress(), max));
            int filled = Math.round(shaft * (float) done / max);
            if (filled > 0) {
                guiGraphics.fill(x, y - half, x + filled, y + half, ARROW_FILL);
            }
        }

        // 箭头尖：一排排越来越短的竖条，画出来是个三角形
        int headX = x + shaft;
        for (int i = 0; i < MachineLayout.Arrow.HEAD; i++) {
            int rowHalf = half - i;
            if (rowHalf < 0) {
                break;
            }
            guiGraphics.fill(headX + i, y - rowHalf, headX + i + 1, y + rowHalf, ARROW_EDGE);
        }
    }

    /** 把右边的流体区和别的东西用一条细框分开，一眼能看出「这一块都是流体」。 */
    protected void drawFluidGroupFrame(GuiGraphics guiGraphics) {
        if (!(this.menu instanceof FluidBarHost host) || host.barCount() <= 0) {
            return;
        }
        int last = host.barCount() - 1;
        int x0 = this.leftPos + MachineLayout.FLUID_X - 5;
        int y0 = this.topPos + MachineLayout.FLUID_TOP - 3;
        int x1 = this.leftPos + this.imageWidth - 8;
        int y1 = this.topPos + host.barY(last) + host.barHeight(last) + 4;
        guiGraphics.fill(x0, y0, x1, y0 + 1, 0xFF9A9A9A);
        guiGraphics.fill(x0, y1 - 1, x1, y1, 0xFF9A9A9A);
        guiGraphics.fill(x0, y0, x0 + 1, y1, 0xFF9A9A9A);
        guiGraphics.fill(x1 - 1, y0, x1, y1, 0xFF9A9A9A);
    }

    /** 右侧的流体长条 + 每根长条右边那一列 mB 数字。 */
    protected void drawFluidBars(GuiGraphics guiGraphics) {
        if (!(this.menu instanceof FluidBarHost host)) {
            return;
        }
        int capacity = Math.max(1, host.barCapacity());
        for (int i = 0; i < host.barCount(); i++) {
            int x = this.leftPos + host.barX(i);
            int y = this.topPos + host.barY(i);
            int w = host.barWidth(i);
            int h = host.barHeight(i);
            int amount = Math.max(0, Math.min(host.barAmount(i), capacity));
            // 满了：边框刷红，隔着界面一眼就能看出「这根抽不动了」
            boolean full = amount >= capacity;
            guiGraphics.fill(x - 1, y - 1, x + w + 1, y + h + 1, full ? TANK_FULL_EDGE : TANK_EDGE);
            guiGraphics.fill(x, y, x + w, y + h, TANK_BG);

            if (amount > 0) {
                int filled = Math.max(1, Math.round((h - 2) * (float) amount / capacity));
                int color = ModFluids.colorOf(host.barFluidId(i));
                guiGraphics.fill(x + 1, y + h - 1 - filled, x + w - 1, y + h - 1, color);
                if (filled > 1) {
                    // 液面上一格亮一点，看着像有反光
                    guiGraphics.fill(x + 1, y + h - 1 - filled, x + w - 1, y + h - 2 - filled,
                            brighten(color));
                }
                // 左边一条高光、右边一条阴影：长条看起来是根圆柱，不是一块色块
                guiGraphics.fill(x + 1, y + h - 1 - filled, x + 2, y + h - 1, brighten(color));
                guiGraphics.fill(x + w - 2, y + h - 1 - filled, x + w - 1, y + h - 1, darken(color));
            }

            // 方向箭头：进液朝下（流进机器），出液朝上（流出机器）
            drawFlowArrow(guiGraphics, x + w / 2, y + h / 2, host.barIsInput(i));
        }
    }

    /** 长条里的方向箭头，'#' 是要填的像素。进液是「朝下」，出液是「朝上」。 */
    private static final String[] ARROW_DOWN = {
            "...#...",
            "...#...",
            "...#...",
            "#######",
            ".#####.",
            "..###..",
            "...#..."
    };

    /**
     * 在流体长条中间画一个小箭头，告诉玩家这根长条是「往里灌」还是「往外送」。
     *
     * <p>先按图案铺一层 3×3 的半透明黑当描边，再叠白色箭头本体，
     * 所以不管长条里是深灰底还是亮黄色的液体，箭头都看得清。
     */
    private void drawFlowArrow(GuiGraphics guiGraphics, int centerX, int centerY, boolean input) {
        String[] pattern = ARROW_DOWN;
        int height = pattern.length;
        int width = pattern[0].length();
        int originX = centerX - width / 2;
        int originY = centerY - height / 2;
        for (int row = 0; row < height; row++) {
            // 出液长条的箭头上下翻转：同一个图案，行号反过来取
            String line = pattern[input ? row : height - 1 - row];
            for (int column = 0; column < width; column++) {
                if (line.charAt(column) != '#') {
                    continue;
                }
                int px = originX + column;
                int py = originY + row;
                guiGraphics.fill(px - 1, py - 1, px + 2, py + 2, ARROW_SHADOW);
            }
        }
        for (int row = 0; row < height; row++) {
            String line = pattern[input ? row : height - 1 - row];
            for (int column = 0; column < width; column++) {
                if (line.charAt(column) != '#') {
                    continue;
                }
                int px = originX + column;
                int py = originY + row;
                guiGraphics.fill(px, py, px + 1, py + 1, ARROW_GLYPH);
            }
        }
    }

    private static int darken(int argb) {
        int a = (argb >>> 24) & 0xFF;
        int r = Math.max(0, ((argb >> 16) & 0xFF) - 40);
        int g = Math.max(0, ((argb >> 8) & 0xFF) - 40);
        int b = Math.max(0, (argb & 0xFF) - 40);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int brighten(int argb) {
        int a = (argb >>> 24) & 0xFF;
        int r = Math.min(255, ((argb >> 16) & 0xFF) + 40);
        int g = Math.min(255, ((argb >> 8) & 0xFF) + 40);
        int b = Math.min(255, (argb & 0xFF) + 40);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    // ------------------------------------------------------------------
    // 文字：全部排在面板下方，字号统一、带阴影
    // ------------------------------------------------------------------

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        // 浅灰面板上不画投影：深灰字再叠一层近乎全黑的影子，字会像描了两遍（重影）。
        // 原版箱子界面也是这个做法——浅底只画一遍实心字。
        guiGraphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, TEXT_DARK, false);
        guiGraphics.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY,
                TEXT_DARK, false);

        drawStatLine(guiGraphics, 0, statusLine(), statusColor());
        drawStatLine(guiGraphics, 1, energyLine(), TEXT_DARK);
        Component hint = hintLine();
        if (hint != null) {
            drawStatLine(guiGraphics, 2, hint, TEXT_GRAY);
        }
        if (this.menu instanceof FluidBarHost host && host.barCount() > 0) {
            // 表头：两根罐子槽上方写「操作 / 返还」，最右边一列写单位 mB
            int headerY = MachineLayout.FLUID_TOP - 12;
            guiGraphics.drawString(this.font,
                    Component.translatable("gui.aftercritical.fluid.op_slot_short"),
                    MachineLayout.FLUID_X + MachineLayout.FLUID_OP_DX - 1, headerY, TEXT_DARK, false);
            guiGraphics.drawString(this.font,
                    Component.translatable("gui.aftercritical.fluid.return_slot_short"),
                    MachineLayout.FLUID_X + MachineLayout.FLUID_RET_DX - 1, headerY, TEXT_DARK, false);
            guiGraphics.drawString(this.font, "mB",
                    MachineLayout.FLUID_X + MachineLayout.FLUID_TEXT_DX, headerY, TEXT_GRAY, false);
        }
        drawBarAmounts(guiGraphics);
    }

    private void drawStatLine(GuiGraphics guiGraphics, int index, Component text, int color) {
        if (text == null) {
            return;
        }
        guiGraphics.drawString(this.font, text, MachineLayout.TEXT_X,
                this.menu.textY() + index * MachineLayout.TEXT_STEP, color, false);
    }

    /** 每根长条右边那个数字：当前装了多少 mB。 */
    private void drawBarAmounts(GuiGraphics guiGraphics) {
        if (!(this.menu instanceof FluidBarHost host)) {
            return;
        }
        for (int i = 0; i < host.barCount(); i++) {
            int x = MachineLayout.FLUID_X + MachineLayout.FLUID_TEXT_DX;
            int y = host.barY(i) + (host.barHeight(i) - 8) / 2;
            guiGraphics.drawString(this.font, String.valueOf(host.barAmount(i)), x, y, TEXT_DARK, false);
        }
    }

    /** 第一行：状态 + 进度百分比。 */
    protected Component statusLine() {
        Component status = Component.translatable("gui.aftercritical.stat.status", statusText());
        int max = this.menu.getMaxProgress();
        if (max > 0) {
            int percent = Math.round(100.0F * Math.max(0, Math.min(this.menu.getProgress(), max)) / max);
            return Component.literal(status.getString() + "  " + percent + "%");
        }
        return status;
    }

    /** 第二行：能量。 */
    protected Component energyLine() {
        if (this.menu.getEnergyCapacity() <= 0) {
            return null;
        }
        return Component.translatable("gui.aftercritical.stat.energy",
                this.menu.getEnergyStored(), this.menu.getEnergyCapacity());
    }

    /** 第三行：这台机器的操作提示（默认没有）。 */
    protected Component hintLine() {
        return null;
    }

    /** 运行中 / 能量不足 / 输出已满 / 缺模具 / 待机 / 电力已满 / 充电中 / 放电中。 */
    protected Component statusText() {
        return switch (this.menu.getStatus()) {
            case MachineBlockEntity.STATUS_RUNNING -> Component.translatable("gui.aftercritical.status.running");
            case MachineBlockEntity.STATUS_NO_ENERGY -> Component.translatable("gui.aftercritical.status.no_energy");
            case MachineBlockEntity.STATUS_OUTPUT_BLOCKED ->
                    Component.translatable("gui.aftercritical.status.output_blocked");
            case MachineBlockEntity.STATUS_NO_MOLD -> Component.translatable("gui.aftercritical.status.no_mold");
            case EnergyMachineHost.STATUS_FULL -> Component.translatable("gui.aftercritical.status.full");
            case EnergyMachineHost.STATUS_CHARGING -> Component.translatable("gui.aftercritical.status.charging");
            case EnergyMachineHost.STATUS_DISCHARGING ->
                    Component.translatable("gui.aftercritical.status.discharging");
            case EnergyMachineHost.STATUS_NO_FLUID ->
                    Component.translatable("gui.aftercritical.status.no_fluid");
            case EnergyMachineHost.STATUS_DUMPING ->
                    Component.translatable("gui.aftercritical.status.dumping");
            default -> Component.translatable("gui.aftercritical.status.idle");
        };
    }

    protected int statusColor() {
        return switch (this.menu.getStatus()) {
            case MachineBlockEntity.STATUS_RUNNING, EnergyMachineHost.STATUS_CHARGING,
                 EnergyMachineHost.STATUS_DISCHARGING -> TEXT_OK;
            case MachineBlockEntity.STATUS_NO_ENERGY, MachineBlockEntity.STATUS_OUTPUT_BLOCKED -> TEXT_BAD;
            case MachineBlockEntity.STATUS_NO_MOLD, EnergyMachineHost.STATUS_FULL,
                 EnergyMachineHost.STATUS_NO_FLUID, EnergyMachineHost.STATUS_DUMPING -> TEXT_WARN;
            default -> TEXT_GRAY;
        };
    }

    /**
     * 右键点长条：把「拿着罐子对着长条右键」这件事发给服务端。
     *
     * <p>罐子槽已经能自动装 / 卸了，这里只是留一条熟悉的老路子，两种做法都能用。
     */
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 1 && this.menu instanceof FluidBarHost host && host.barButtonBase() >= 0
                && this.minecraft != null && this.minecraft.gameMode != null) {
            for (int i = 0; i < host.barCount(); i++) {
                int x = this.leftPos + host.barX(i);
                int y = this.topPos + host.barY(i);
                if (mouseX >= x - 1 && mouseX < x + host.barWidth(i) + 1
                        && mouseY >= y - 1 && mouseY < y + host.barHeight(i) + 1) {
                    this.minecraft.gameMode.handleInventoryButtonClick(
                            this.menu.containerId, host.barButtonBase() + i);
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        List<Component> tooltip = customTooltip(mouseX, mouseY);
        if (tooltip != null && !tooltip.isEmpty()) {
            guiGraphics.renderComponentTooltip(this.font, tooltip, mouseX, mouseY);
        }
    }

    /** 鼠标停在流体长条上时给的提示；子类可以覆盖成别的。 */
    protected List<Component> customTooltip(int mouseX, int mouseY) {
        if (!(this.menu instanceof FluidBarHost host)) {
            return null;
        }
        for (int i = 0; i < host.barCount(); i++) {
            int x = this.leftPos + host.barX(i);
            int y = this.topPos + host.barY(i);
            if (mouseX >= x - 1 && mouseX < x + host.barWidth(i) + 1
                    && mouseY >= y - 1 && mouseY < y + host.barHeight(i) + 1) {
                int fluidId = host.barFluidId(i);
                String name = fluidId < 0
                        ? Component.translatable("gui.aftercritical.fluid.empty").getString()
                        : ModFluids.displayName(fluidId).getString();
                String kind = Component.translatable(host.barIsInput(i)
                        ? "gui.aftercritical.fluid.input_tank"
                        : "gui.aftercritical.fluid.output_tank").getString();
                List<Component> lines = new ArrayList<>(3);
                int amount = host.barAmount(i);
                lines.add(Component.literal(kind + "：" + name + " "
                        + amount + "/" + host.barCapacity() + " mB"));
                if (amount >= host.barCapacity()) {
                    // 满了：直接告诉玩家下一步该干什么
                    lines.add(Component.translatable("gui.aftercritical.fluid.full", name));
                }
                if (host.barIsInput(i)) {
                    // 进液罐空着 = 谁都能倒；装着液体时第一行已经写了名字
                    if (amount <= 0) {
                        lines.add(Component.translatable("gui.aftercritical.fluid.claim.none"));
                    }
                }
                return lines;
            }
        }
        return null;
    }
}
