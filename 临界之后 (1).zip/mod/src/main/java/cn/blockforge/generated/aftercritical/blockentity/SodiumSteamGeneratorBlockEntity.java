package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.energy.BufferedEnergyStorage;
import cn.blockforge.generated.aftercritical.energy.EnergyTransfer;
import cn.blockforge.generated.aftercritical.menu.SodiumSteamGeneratorMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

import javax.annotation.Nullable;

/**
 * 钠-水蒸汽发生器：快堆的二回路，也是快堆真正「发电」的地方。
 *
 * <p>钠冷快堆的一回路是钠（放射性钠，不能直接拿去烧水），所以中间要换热：
 * 热钠把二回路的水烧成蒸汽，蒸汽再去推汽轮机。为了不做两套管道，这里把
 * 「蒸汽发生器 + 汽轮机」合成一台：水进去、乏蒸汽出来、电从旁边送走。
 *
 * <p>数值：控制器把「热量千分数」每 tick 递过来，满热时这台发生器输出
 * <b>3,000 FE/t</b>，吃 <b>75 mB/t</b> 水、吐同样多的乏蒸汽（1 mB 水 = 40 FE，和汽轮机一个折算）。
 * 淡蒸汽再拿去冷凝器换回水，二回路就闭合了。
 */
public class SodiumSteamGeneratorBlockEntity extends BlockEntity
        implements EnergyMachineHost, TickableBlockEntity, net.minecraft.world.MenuProvider {

    /** 满热时的输出功率。 */
    public static final int OUTPUT_PER_TICK = 3_000;
    /** 1 mB 水发多少 FE（和汽轮发电机一致）。 */
    public static final int FE_PER_MB = 40;
    /** 满热时每 tick 吃多少水。 */
    public static final int WATER_PER_TICK = OUTPUT_PER_TICK / FE_PER_MB;
    /** 两个罐子各装 8,000 mB。 */
    public static final int TANK_CAPACITY = 8_000;
    private static final int ENERGY_CAPACITY = 150_000;

    /** 多久收不到控制器递来的热量就当成堆停了。 */
    public static final int HEAT_TIMEOUT = 5;

    private final BufferedEnergyStorage energy =
            new BufferedEnergyStorage(ENERGY_CAPACITY, 0, OUTPUT_PER_TICK, this::setChanged);
    private final FluidTank waterTank = new FluidTank(TANK_CAPACITY);
    private final FluidTank exhaustTank = new FluidTank(TANK_CAPACITY);

    /** 控制器这一 tick 给的热量（千分数）。 */
    private int heatPermille;
    private long lastHeatTick = Long.MIN_VALUE;
    private int status = STATUS_IDLE;
    private int lastWaterPerTick;

    private final IFluidHandler fluidHandler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return 2;
        }

        @Override
        public FluidStack getFluidInTank(int tank) {
            return tank == 0 ? waterTank.getFluid() : tank == 1 ? exhaustTank.getFluid() : FluidStack.EMPTY;
        }

        @Override
        public int getTankCapacity(int tank) {
            return TANK_CAPACITY;
        }

        @Override
        public boolean isFluidValid(int tank, FluidStack stack) {
            return tank == 0;
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            if (resource.isEmpty() || !resource.getFluid().isSame(net.minecraft.world.level.material.Fluids.WATER)
                    && !resource.getFluid().isSame(ModFluids.HEAVY_WATER.source.get())) {
                return 0;
            }
            int filled = waterTank.fill(resource, action);
            if (filled > 0) {
                setChanged();
            }
            return filled;
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            FluidStack drained = exhaustTank.drain(resource, action);
            if (!drained.isEmpty()) {
                setChanged();
            }
            return drained;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            FluidStack drained = exhaustTank.drain(maxDrain, action);
            if (!drained.isEmpty()) {
                setChanged();
            }
            return drained;
        }
    };

    public SodiumSteamGeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.SODIUM_STEAM_GENERATOR.get(), pos, state);
    }

    public IFluidHandler getFluidHandler() {
        return this.fluidHandler;
    }

    /**
     * 手拿通用流体罐右键：装的是水就往罐里灌。
     *
     * <p>没有管道的时候靠它补水；装了管道以后相邻的管道/储罐会自动被抽。
     *
     * @return 真的灌进去了返回 true
     */
    public boolean fillWaterFromHand(Player player, net.minecraft.world.InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (!(held.getItem() instanceof cn.blockforge.generated.aftercritical.item.UniversalTankItem)) {
            return false;
        }
        FluidStack stored = cn.blockforge.generated.aftercritical.item.UniversalTankItem.getFluid(held);
        if (stored.isEmpty() || !stored.getFluid().isSame(net.minecraft.world.level.material.Fluids.WATER)
                && !stored.getFluid().isSame(ModFluids.HEAVY_WATER.source.get())) {
            return false;
        }
        int filled = this.waterTank.fill(stored, IFluidHandler.FluidAction.EXECUTE);
        if (filled <= 0) {
            return false;
        }
        ItemStack leftover = cn.blockforge.generated.aftercritical.item.UniversalTankItem.withFluid(
                held, stored.getFluid(), stored.getAmount() - filled);
        if (held.getCount() <= 1) {
            player.setItemInHand(hand, leftover);
        } else {
            held.shrink(1);
            if (!player.getInventory().add(leftover)) {
                player.drop(leftover, false);
            }
        }
        setChanged();
        return true;
    }

    public IEnergyStorage getEnergyStorage() {
        return this.energy;
    }

    /** 控制器每 tick 调一次：告诉自己「现在这套堆有多热」（千分数）。 */
    public void receiveHeat(int permille) {
        this.heatPermille = Math.max(0, Math.min(1000, permille));
        this.lastHeatTick = this.level == null ? 0L : this.level.getGameTime();
    }

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        long now = this.level.getGameTime();
        if (now - this.lastHeatTick > HEAT_TIMEOUT) {
            this.heatPermille = 0;
        }
        pullWaterFromNeighbours();

        int desired = (int) ((long) OUTPUT_PER_TICK * this.heatPermille / 1000L);
        int wanted = desired / FE_PER_MB;
        int exhaustSpace = this.exhaustTank.getCapacity() - this.exhaustTank.getFluidAmount();
        int convert = Math.min(wanted, Math.min(this.waterTank.getFluidAmount(), exhaustSpace));
        int fe = convert * FE_PER_MB;
        boolean bufferFull = this.energy.getFreeSpace() < fe && convert > 0;

        if (convert > 0 && !bufferFull) {
            this.waterTank.drain(convert, IFluidHandler.FluidAction.EXECUTE);
            this.exhaustTank.fill(new FluidStack(ModFluids.EXHAUST_STEAM.source.get(), convert),
                    IFluidHandler.FluidAction.EXECUTE);
            this.energy.grow(fe);
            this.lastWaterPerTick = convert;
            this.status = STATUS_RUNNING;
            setChanged();
        } else {
            this.lastWaterPerTick = 0;
            if (this.heatPermille <= 0) {
                this.status = STATUS_IDLE;
            } else if (bufferFull) {
                this.status = STATUS_FULL;
            } else if (exhaustSpace <= 0) {
                this.status = STATUS_OUTPUT_BLOCKED;
            } else {
                this.status = STATUS_NO_FLUID;
            }
        }
        EnergyTransfer.push(this.level, this.worldPosition, this.energy, OUTPUT_PER_TICK);
    }

    /** 从相邻的流体容器（管道、储罐、别的水管）把水抽进自己的罐子。 */
    private void pullWaterFromNeighbours() {
        if (this.level == null) {
            return;
        }
        int room = TANK_CAPACITY - this.waterTank.getFluidAmount();
        if (room <= 0) {
            return;
        }
        for (Direction side : Direction.values()) {
            if (room <= 0) {
                return;
            }
            IFluidHandler source = this.level.getCapability(Capabilities.FluidHandler.BLOCK,
                    this.worldPosition.relative(side), side.getOpposite());
            if (source == null) {
                continue;
            }
            FluidStack probe = source.drain(new FluidStack(
                    net.minecraft.world.level.material.Fluids.WATER, Math.min(room, 200)),
                    IFluidHandler.FluidAction.SIMULATE);
            if (probe.isEmpty()) {
                continue;
            }
            FluidStack taken = source.drain(probe, IFluidHandler.FluidAction.EXECUTE);
            if (!taken.isEmpty()) {
                room -= this.waterTank.fill(taken, IFluidHandler.FluidAction.EXECUTE);
                setChanged();
            }
        }
    }

    // ------------------------------------------------------------------
    // 界面数据
    // ------------------------------------------------------------------

    public int waterAmount() {
        return this.waterTank.getFluidAmount();
    }

    public int exhaustAmount() {
        return this.exhaustTank.getFluidAmount();
    }

    public int tankCapacity() {
        return TANK_CAPACITY;
    }

    public int waterPerTick() {
        return this.lastWaterPerTick;
    }

    public int outputFePerTick() {
        return this.lastWaterPerTick * FE_PER_MB;
    }

    public int heatPermille() {
        return this.heatPermille;
    }

    @Override
    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    @Override
    public int getEnergyCapacity() {
        return this.energy.getMaxEnergyStored();
    }

    @Override
    public int getStatus() {
        return this.status;
    }

    @Override
    public int getProgress() {
        return this.lastWaterPerTick;
    }

    @Override
    public int getMaxProgress() {
        return 0;
    }

    // ------------------------------------------------------------------
    // 没有物品槽的容器（菜单接口要用）
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return 0;
    }

    @Override
    public boolean isEmpty() {
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        return ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        // 没有物品槽
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        // 没有物品槽
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.sodium_steam_generator");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new SodiumSteamGeneratorMenu(containerId, playerInventory, this);
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
        tag.put("Water", this.waterTank.writeToNBT(registries, new CompoundTag()));
        tag.put("Exhaust", this.exhaustTank.writeToNBT(registries, new CompoundTag()));
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
        this.waterTank.readFromNBT(registries, tag.getCompound("Water"));
        this.exhaustTank.readFromNBT(registries, tag.getCompound("Exhaust"));
    }
}
