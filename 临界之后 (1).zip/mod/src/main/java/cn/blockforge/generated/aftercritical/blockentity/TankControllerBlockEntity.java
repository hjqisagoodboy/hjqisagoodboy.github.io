package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.block.TankControllerBlock;
import cn.blockforge.generated.aftercritical.block.TankPortBlock;
import cn.blockforge.generated.aftercritical.block.TankPortKind;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import cn.blockforge.generated.aftercritical.menu.TankControllerMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 储罐多方块的控制器：一个 64,000 mB 的大罐子 + 一套「3×3×3 外壳对不对」的检查。
 *
 * <p>外壳长这样（每一面都是 3×3，中间那一格是空的）：
 * <pre>
 *   铅块 / 玻璃 / 控制器 / 输入口 / 输出口 围成壳，中间 1 格留空
 * </pre>
 *
 * <p>检查通过之后两个「口」才会接到这个罐子上（口自己不做存储，只是把这一面开给管道）。
 * 外壳被拆掉任意一块，最多 2 秒后就会重新检查一次、把口断开，不会漏出一堆假接口。
 *
 * <p>罐子槽有两个，方向是分开的，不会来回倒：
 * <ul>
 *   <li>左边的「装罐」槽：罐子是空的就从这个大罐子里灌满；</li>
 *   <li>右边的「倒罐」槽：罐子里装着东西就倒进大罐子。</li>
 * </ul>
 */
public class TankControllerBlockEntity extends BlockEntity
        implements MenuProvider, TickableBlockEntity, Container {

    /** 罐子容量：64 桶。 */
    public static final int CAPACITY = 64_000;

    /** 3×3×3 的边长。 */
    public static final int SIZE = 3;
    /** 外壳至少要几块玻璃、几块铅块（剩下 23 格由这两种填满）。 */
    public static final int MIN_GLASS = 6;
    public static final int MIN_LEAD = 8;

    /** 「操作槽」：放满罐就倒进大罐子，放空罐就从大罐子灌满。 */
    public static final int SLOT_OP_JAR = 0;
    /** 「返还槽」：处理完的罐子在这里，只能拿不能塞。 */
    public static final int SLOT_RETURN_JAR = 1;
    public static final int SLOT_COUNT = 2;

    /** 多久重新检查一次外壳（tick）。 */
    private static final int VALIDATE_INTERVAL = 40;

    private final FluidTank tank = new FluidTank(CAPACITY);
    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);

    /**
     * 物品接口：管道能往操作槽塞罐子、从返还槽抽罐子。
     *
     * <p>这样「储罐 + 管道 + 罐子」就能全自动：管道把空罐送进操作槽，罐子灌满后自己跑到返还槽，
     * 管道再从返还槽把满罐接走。
     */
    private final net.neoforged.neoforge.items.IItemHandler itemHandler =
            new cn.blockforge.generated.aftercritical.itemhandler.ContainerItemHandler(this,
                    slot -> slot == SLOT_OP_JAR,
                    slot -> slot == SLOT_RETURN_JAR,
                    slot -> getMaxStackSize());

    /** 外壳现在是完整的吗。 */
    private boolean formed;
    private int validateTimer;

    /** 当前结构里的两个口（输入、输出各一个）。 */
    private final List<BlockPos> boundPorts = new ArrayList<>();

    public TankControllerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.TANK_CONTROLLER.get(), pos, state);
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        if (++this.validateTimer >= VALIDATE_INTERVAL) {
            this.validateTimer = 0;
            validateStructure();
        }
        serviceJars();
    }

    // ------------------------------------------------------------------
    // 3×3×3 外壳检查
    // ------------------------------------------------------------------

    /** 现在算不算凑齐了。 */
    public boolean isFormed() {
        return this.formed;
    }

    /** 结构里的某个位置是不是这个储罐的口（口用它确认自己还接在罐子上）。 */
    public boolean containsPort(BlockPos pos) {
        return this.boundPorts.contains(pos);
    }

    /**
     * 重新找一遍外壳。
     *
     * <p>控制器可以装在外壳的任意一格上，所以这里把「3×3×3 的角」挨个试一遍：
     * 哪一组能通过检查，那一组就是这口罐子的外壳。
     */
    public void validateStructure() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        BlockPos foundMin = null;
        for (int ox = 0; ox < SIZE && foundMin == null; ox++) {
            for (int oy = 0; oy < SIZE && foundMin == null; oy++) {
                for (int oz = 0; oz < SIZE && foundMin == null; oz++) {
                    BlockPos min = this.worldPosition.offset(-ox, -oy, -oz);
                    if (checkShell(min)) {
                        foundMin = min;
                    }
                }
            }
        }

        List<BlockPos> ports = new ArrayList<>();
        if (foundMin != null) {
            collectPorts(foundMin, ports);
        }
        boolean nowFormed = foundMin != null;
        if (nowFormed == this.formed && ports.equals(this.boundPorts)) {
            return;
        }

        // 先把旧的口断开，再接上新的
        for (BlockPos pos : this.boundPorts) {
            if (this.level.getBlockEntity(pos) instanceof TankPortBlockEntity port) {
                port.unbind();
            }
        }
        this.boundPorts.clear();
        this.boundPorts.addAll(ports);
        for (BlockPos pos : this.boundPorts) {
            if (this.level.getBlockEntity(pos) instanceof TankPortBlockEntity port) {
                port.bind(this.worldPosition);
            }
        }
        this.formed = nowFormed;
        setChanged();
    }

    /** 以 {@code min} 为最小角的那一组 3×3×3 是不是合格的外壳。 */
    private boolean checkShell(BlockPos min) {
        Level level = this.level;
        if (level == null) {
            return false;
        }
        BlockPos center = min.offset(1, 1, 1);
        if (!level.isLoaded(center) || !level.getBlockState(center).isAir()) {
            return false;
        }
        int lead = 0;
        int glass = 0;
        int controllers = 0;
        int inputs = 0;
        int outputs = 0;
        for (int x = 0; x < SIZE; x++) {
            for (int y = 0; y < SIZE; y++) {
                for (int z = 0; z < SIZE; z++) {
                    BlockPos pos = min.offset(x, y, z);
                    // 没加载的区块不算数：既不能当外壳，也不去强行加载它
                    if (!level.isLoaded(pos)) {
                        return false;
                    }
                    if (pos.equals(center)) {
                        continue;
                    }
                    BlockState state = level.getBlockState(pos);
                    Block block = state.getBlock();
                    if (block == cn.blockforge.generated.aftercritical.registry.ModBlocks.LEAD_BLOCK.get()) {
                        lead++;
                    } else if (state.is(Blocks.GLASS)) {
                        glass++;
                    } else if (block instanceof TankControllerBlock) {
                        // 只能有一个控制器，而且必须是我自己
                        if (!pos.equals(this.worldPosition)) {
                            return false;
                        }
                        controllers++;
                    } else if (block instanceof TankPortBlock port) {
                        if (port.kind() == TankPortKind.INPUT) {
                            inputs++;
                        } else {
                            outputs++;
                        }
                    } else {
                        return false;
                    }
                }
            }
        }
        return controllers == 1 && inputs == 1 && outputs == 1
                && glass >= MIN_GLASS && lead >= MIN_LEAD;
    }

    private void collectPorts(BlockPos min, List<BlockPos> into) {
        for (int x = 0; x < SIZE; x++) {
            for (int y = 0; y < SIZE; y++) {
                for (int z = 0; z < SIZE; z++) {
                    BlockPos pos = min.offset(x, y, z);
                    if (this.level != null && this.level.getBlockState(pos).getBlock() instanceof TankPortBlock) {
                        into.add(pos);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // 流体接口（给智能流体管道、通用流体罐用）
    // ------------------------------------------------------------------

    public net.neoforged.neoforge.items.IItemHandler getItemHandler() {
        return this.itemHandler;
    }

    public IFluidHandler getFluidHandler() {
        return this.fluidHandler;
    }

    private final IFluidHandler fluidHandler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return 1;
        }

        @Override
        public FluidStack getFluidInTank(int tank) {
            return TankControllerBlockEntity.this.tank.getFluid();
        }

        @Override
        public int getTankCapacity(int tank) {
            return CAPACITY;
        }

        @Override
        public boolean isFluidValid(int tank, FluidStack stack) {
            return true;
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            int filled = TankControllerBlockEntity.this.tank.fill(resource, action);
            if (filled > 0 && action.execute()) {
                setChanged();
            }
            return filled;
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            FluidStack drained = TankControllerBlockEntity.this.tank.drain(resource, action);
            if (!drained.isEmpty() && action.execute()) {
                setChanged();
            }
            return drained;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            FluidStack drained = TankControllerBlockEntity.this.tank.drain(maxDrain, action);
            if (!drained.isEmpty() && action.execute()) {
                setChanged();
            }
            return drained;
        }
    };

    /** 里面装的是什么；空的返回 -1。 */
    public int getFluidId() {
        if (this.tank.isEmpty()) {
            return -1;
        }
        int id = BuiltInRegistries.FLUID.getId(this.tank.getFluid().getFluid());
        return id <= 0 ? -1 : id;
    }

    public int getFluidAmount() {
        return this.tank.getFluidAmount();
    }

    public FluidTank tank() {
        return this.tank;
    }

    // ------------------------------------------------------------------
    // 罐子槽
    // ------------------------------------------------------------------

    /**
     * 操作槽里放什么就干什么：
     * 满罐 → 倒进这个大罐子；空罐 → 从大罐子灌满，罐子自动挪到返还槽。
     */
    private void serviceJars() {
        ItemStack jar = this.items.get(SLOT_OP_JAR);
        if (!(jar.getItem() instanceof UniversalTankItem)) {
            return;
        }
        boolean changed = UniversalTankItem.isFilled(jar)
                ? JarSlotService.pour(this.tank, this.items, SLOT_OP_JAR, SLOT_RETURN_JAR)
                : JarSlotService.fill(this.tank, this.items, SLOT_OP_JAR, SLOT_RETURN_JAR);
        if (changed) {
            setChanged();
        }
    }

    /**
     * 拿着流体容器右键控制器。
     *
     * <p>通用流体罐自己不在这里处理：它右键时走方块身上的流体接口（见 {@link #getFluidHandler()}）。
     * 这里只管原版桶——水桶往罐里倒、空桶从罐里舀一桶。
     */
    public boolean handleFluidInteraction(Player player, InteractionHand hand) {
        if (this.level == null) {
            return false;
        }
        ItemStack held = player.getItemInHand(hand);
        if (!held.is(Items.BUCKET) && !(held.getItem() instanceof net.minecraft.world.item.BucketItem)) {
            return false;
        }
        IFluidHandler handler = getFluidHandler();
        net.neoforged.neoforge.fluids.FluidActionResult action = held.is(Items.BUCKET)
                ? net.neoforged.neoforge.fluids.FluidUtil.tryFillContainer(held, handler,
                        UniversalTankItem.CAPACITY, player, true)
                : net.neoforged.neoforge.fluids.FluidUtil.tryEmptyContainer(held, handler,
                        UniversalTankItem.CAPACITY, player, true);
        ItemStack result = action.getResult();
        if (!action.isSuccess() || result.isEmpty() || ItemStack.isSameItemSameComponents(result, held)) {
            return false;
        }
        if (held.getCount() <= 1) {
            player.setItemInHand(hand, result);
        } else {
            held.shrink(1);
            if (!player.getInventory().add(result)) {
                player.drop(result, false);
            }
        }
        this.level.playSound(null, this.worldPosition, SoundEvents.BUCKET_FILL, SoundSource.BLOCKS, 1.0F, 1.0F);
        setChanged();
        return true;
    }

    // ------------------------------------------------------------------
    // 界面
    // ------------------------------------------------------------------

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new TankControllerMenu(containerId, playerInventory, this);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.tank_controller");
    }

    // ------------------------------------------------------------------
    // 物品槽（两个罐子槽）
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return SLOT_COUNT;
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        stack.limitSize(getMaxStackSize(stack));
        setChanged();
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot == SLOT_OP_JAR && stack.getItem() instanceof UniversalTankItem;
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Tank", this.tank.writeToNBT(registries, new CompoundTag()));
        tag.putBoolean("Formed", this.formed);
        ContainerHelper.saveAllItems(tag, this.items, registries);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.tank.readFromNBT(registries, tag.getCompound("Tank"));
        this.formed = tag.getBoolean("Formed");
        ContainerHelper.loadAllItems(tag, this.items, registries);
        this.validateTimer = VALIDATE_INTERVAL - 1;
    }

    /** 方块实体被放下来 / 区块加载完，立刻检查一次外壳。 */
    @Override
    public void setLevel(Level level) {
        super.setLevel(level);
        if (!level.isClientSide) {
            this.validateTimer = VALIDATE_INTERVAL - 1;
        }
    }
}
