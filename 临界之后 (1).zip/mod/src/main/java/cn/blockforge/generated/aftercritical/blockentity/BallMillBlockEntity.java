package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.menu.BallMillMenu;
import cn.blockforge.generated.aftercritical.recipe.MachineRecipe;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModRecipes;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * 球磨机方块实体：LV，运行功率 60 FE/t，10,000 FE 缓存，1 输入槽 + 1 输出槽。
 *
 * <p>配方来自 {@link ModRecipes#BALL_MILLING}：把粗粉磨成细粉，或者把硼砂 / 绿柱石 / 锂辉石的
 * 矿石块磨成对应的粉（一次要放 4 个矿石块）。
 */
public class BallMillBlockEntity extends MachineBlockEntity {

    public static final int SLOT_INPUT = 0;
    public static final int SLOT_OUTPUT = 1;
    public static final int SLOT_COUNT = 2;

    /** 额定运行功率：60 FE/t（最终定稿 v4）。 */
    public static final int ENERGY_PER_TICK = 60;

    public BallMillBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.BALL_MILL.get(), pos, state, SLOT_COUNT, ENERGY_PER_TICK);
    }

    @Override
    protected int[] inputSlots() {
        return new int[]{SLOT_INPUT};
    }

    @Override
    protected int[] outputSlots() {
        return new int[]{SLOT_OUTPUT};
    }

    @Override
    protected RecipeType<MachineRecipe> recipeType() {
        return ModRecipes.BALL_MILLING;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.ball_mill");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new BallMillMenu(containerId, playerInventory, this);
    }
}
