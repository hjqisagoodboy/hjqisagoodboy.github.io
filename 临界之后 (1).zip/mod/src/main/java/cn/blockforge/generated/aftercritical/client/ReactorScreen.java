package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.blockentity.ReactorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.ReactorKind;
import cn.blockforge.generated.aftercritical.menu.MachineLayout;
import cn.blockforge.generated.aftercritical.menu.ReactorMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 反应堆控制器的界面。
 *
 * <p>左边那一列本来是能量条，反应堆不烧电，就把这一列改成了 <b>k_eff 仪表</b>：
 * 绿色 = 次临界、橙色 = 接近临界、红色 = 超临界，白色横线是 1.000 的刻度。
 *
 * <p>实验堆还有一条「控制棒插入深度」滑块：点「−」「+」一次动 5%，直接点滑块就跳过去。
 * 试着把 k_eff 稳在 1.000 附近就是这一阶段的核心玩法。
 */
public class ReactorScreen extends StatPanelScreen<ReactorMenu> {

    /** k 仪表的显示范围：0.80 ~ 1.20。 */
    private static final double METER_MIN = 0.80;
    private static final double METER_MAX = 1.20;

    // 控制棒滑块的布局（面板坐标）
    private static final int SLIDER_X = 46;
    private static final int SLIDER_Y = 53;
    private static final int SLIDER_W = 58;
    private static final int SLIDER_H = 8;
    private static final int BUTTON_MINUS_X = 30;
    private static final int BUTTON_PLUS_X = 106;
    private static final int BUTTON_Y = 51;
    private static final int BUTTON_W = 14;
    private static final int BUTTON_H = 12;

    private static final int COLOR_OK = 0xFF3FA34D;
    private static final int COLOR_NEAR = 0xFFE08A1F;
    private static final int COLOR_HOT = 0xFFD23B2E;
    private static final int COLOR_COLD = 0xFF55606B;

    public ReactorScreen(ReactorMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    // ------------------------------------------------------------------
    // 底部读数
    // ------------------------------------------------------------------

    @Override
    protected List<Line> statLines() {
        ReactorKind kind = this.menu.kind();
        List<Line> lines = new ArrayList<>(ReactorMenu.STAT_LINES);

        boolean formed = this.menu.isFormed();
        lines.add(new Line(Component.translatable(formed
                ? "gui.aftercritical.reactor.structure_ok"
                : "gui.aftercritical.reactor.structure_missing"),
                formed ? TEXT_OK : TEXT_BAD));

        // 材料两行：写成「有/需要」，没搭好一眼就能看出缺哪样、差多少
        lines.add(new Line(Component.translatable("gui.aftercritical.reactor.mat_graphite",
                this.menu.graphite(), kind.minGraphite(),
                this.menu.reflector(), kind.minReflector()), TEXT_GRAY));

        // 第三行：屏蔽 / 玻璃 / 探测器的「有/需要」。
        // 次临界结构里没有玻璃，翻译也只有 4 个坑，所以必须用 4 参数的版本；
        // 以前两种堆共用 6 参数的句子，次临界的「探测」被玻璃的 0/0 顶掉了。
        if (kind.minGlass() > 0) {
            lines.add(new Line(Component.translatable("gui.aftercritical.reactor.mat_shield_glass",
                    this.menu.shield(), kind.minShield(),
                    this.menu.glass(), kind.minGlass(),
                    this.menu.detectors(), kind.minDetectors()), TEXT_GRAY));
        } else {
            lines.add(new Line(Component.translatable("gui.aftercritical.reactor.mat_shield",
                    this.menu.shield(), kind.minShield(),
                    this.menu.detectors(), kind.minDetectors()), TEXT_GRAY));
        }

        lines.add(new Line(Component.translatable("gui.aftercritical.reactor.k_eff",
                formatK(this.menu.kScaled()), statusName(this.menu.status())), kColor(this.menu.kScaled())));

        lines.add(new Line(Component.translatable("gui.aftercritical.reactor.flux_temp",
                formatFlux(this.menu.flux()), this.menu.temperature()), TEXT_DARK));

        if (kind == ReactorKind.CRITICAL) {
            lines.add(new Line(Component.translatable("gui.aftercritical.reactor.fuel_critical",
                    this.menu.fuel(), this.menu.aux(), ReactorControllerBlockEntity.CONTROL_ROD_PORTS),
                    TEXT_DARK));
        } else {
            lines.add(new Line(Component.translatable("gui.aftercritical.reactor.fuel_subcritical",
                    this.menu.fuel(), ReactorControllerBlockEntity.SUBCRITICAL_FUEL_NEEDED,
                    Component.translatable(this.menu.aux() > 0
                            ? "gui.aftercritical.reactor.source_ok"
                            : "gui.aftercritical.reactor.source_missing")), TEXT_DARK));
        }
        return lines;
    }

    /** k_eff 的同步刻度：和方块实体那边保持一致（k × 100000）。 */
    private static final double KEFF_SCALE = ReactorControllerBlockEntity.KEFF_SYNC_SCALE;

    /**
     * k_eff 怎么显示：离 1 很近（0.999 往上）时给 5 位小数，其它时候 3 位。
     *
     * <p>次临界的 k 是渐近的，0.99966 这种数字用 3 位小数会显示成「0.999」，
     * 看起来像到了天花板；多给两位才看得出「它还在一丝丝往 1 靠」。
     */
    public static String formatK(int kScaled) {
        double k = kScaled / KEFF_SCALE;
        if (k >= 0.999 && k < 1.0) {
            return String.format(Locale.ROOT, "%.5f", k);
        }
        return String.format(Locale.ROOT, "%.3f", k);
    }

    /** 通量按千分位写，几十万也是七位数，不至于挤成一团看不清。 */
    public static String formatFlux(int flux) {
        return String.format(Locale.ROOT, "%,d", flux);
    }

    /** 状态码 → 中文。 */
    public static Component statusName(int status) {
        return switch (status) {
            case ReactorControllerBlockEntity.STATUS_SUBCRITICAL ->
                    Component.translatable("gui.aftercritical.reactor.state.subcritical");
            case ReactorControllerBlockEntity.STATUS_CRITICAL ->
                    Component.translatable("gui.aftercritical.reactor.state.critical");
            case ReactorControllerBlockEntity.STATUS_SUPERCRITICAL ->
                    Component.translatable("gui.aftercritical.reactor.state.supercritical");
            case ReactorControllerBlockEntity.STATUS_MELTED ->
                    Component.translatable("gui.aftercritical.reactor.state.melted");
            case ReactorControllerBlockEntity.STATUS_IDLE ->
                    Component.translatable("gui.aftercritical.reactor.state.idle");
            default -> Component.translatable("gui.aftercritical.reactor.state.unformed");
        };
    }

    private static int kColor(int kScaled) {
        double k = kScaled / KEFF_SCALE;
        if (k <= 0.0) {
            return TEXT_GRAY;
        }
        if (k > 1.05) {
            return TEXT_BAD;
        }
        if (k > 1.0) {
            return TEXT_WARN;
        }
        return TEXT_OK;
    }

    // ------------------------------------------------------------------
    // 背景：k 仪表 + 控制棒滑块
    // ------------------------------------------------------------------

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        super.renderBg(guiGraphics, partialTick, mouseX, mouseY);
        drawKEffMeter(guiGraphics);
        if (this.menu.kind() == ReactorKind.CRITICAL) {
            drawRodSlider(guiGraphics);
        }
    }

    /** 左边那一列：k_eff 仪表，中间那条白线是 1.000。 */
    private void drawKEffMeter(GuiGraphics guiGraphics) {
        int x = this.leftPos + MachineLayout.ENERGY_X;
        int y = this.leftPos + MachineLayout.ENERGY_Y;
        int w = MachineLayout.ENERGY_W;
        int h = MachineLayout.ENERGY_H;

        guiGraphics.fill(x - 1, y - 1, x + w + 1, y + h + 1, PANEL_DARK);
        guiGraphics.fill(x, y, x + w, y + h, ENERGY_TRACK);

        int inner = h - 2;
        double k = this.menu.kScaled() / KEFF_SCALE;
        float ratio = (float) Math.max(0.0, Math.min(1.0, (k - METER_MIN) / (METER_MAX - METER_MIN)));
        int filled = Math.round(inner * ratio);
        if (filled > 0 && k > 0.0) {
            guiGraphics.fill(x + 1, y + h - 1 - filled, x + w - 1, y + h - 1, meterColor(k));
        }
        // k = 1.000 的刻度线：玩家就是盯着这条线把控制棒往里推
        int markY = y + h - 1 - Math.round(inner * (float) ((1.0 - METER_MIN) / (METER_MAX - METER_MIN)));
        guiGraphics.fill(x, markY, x + w, markY + 1, 0xFFFFFFFF);
        // 顶上写个 k，提醒这一列不是电量
        guiGraphics.drawString(this.font, "k", x + 4, y - 11, TEXT_DARK, false);
    }

    private static int meterColor(double k) {
        if (k <= 0.0) {
            return COLOR_COLD;
        }
        if (k > 1.05) {
            return COLOR_HOT;
        }
        if (k > 1.0) {
            return COLOR_NEAR;
        }
        return COLOR_OK;
    }

    /** 控制棒插入深度：左「−」右「+」，中间是可以直接点的滑块。 */
    private void drawRodSlider(GuiGraphics guiGraphics) {
        int x = this.leftPos + SLIDER_X;
        int y = this.topPos + SLIDER_Y;
        int w = SLIDER_W;
        int h = SLIDER_H;

        guiGraphics.fill(x - 1, y - 1, x + w + 1, y + h + 1, PANEL_DARK);
        guiGraphics.fill(x, y, x + w, y + h, ENERGY_TRACK);
        int filled = Math.round(w * this.menu.rodDepth() / 100.0F);
        if (filled > 0) {
            guiGraphics.fill(x, y, x + filled, y + h, 0xFF4A9BD8);
            guiGraphics.fill(x, y, x + filled, y + 1, 0xFF8FD0FF);
        }

        drawButton(guiGraphics, this.leftPos + BUTTON_MINUS_X, this.topPos + BUTTON_Y, "-");
        drawButton(guiGraphics, this.leftPos + BUTTON_PLUS_X, this.topPos + BUTTON_Y, "+");

        // 滑块下面写当前深度：滑块本身只有 58 像素宽，数字单独排一行更好认
        Component depth = Component.translatable("gui.aftercritical.reactor.depth", this.menu.rodDepth());
        guiGraphics.drawString(this.font, depth, this.leftPos + SLIDER_X, this.topPos + SLIDER_Y + 12,
                TEXT_DARK, false);
    }

    private void drawButton(GuiGraphics guiGraphics, int x, int y, String text) {
        guiGraphics.fill(x, y, x + BUTTON_W, y + BUTTON_H, PANEL_BG);
        guiGraphics.fill(x, y, x + BUTTON_W, y + 1, PANEL_LIGHT);
        guiGraphics.fill(x, y + BUTTON_H - 1, x + BUTTON_W, y + BUTTON_H, PANEL_DARK);
        guiGraphics.fill(x, y, x + 1, y + BUTTON_H, PANEL_LIGHT);
        guiGraphics.fill(x + BUTTON_W - 1, y, x + BUTTON_W, y + BUTTON_H, PANEL_DARK);
        int textWidth = this.font.width(text);
        guiGraphics.drawString(this.font, text,
                x + (BUTTON_W - textWidth) / 2, y + (BUTTON_H - 8) / 2 + 1, TEXT_DARK, false);
    }

    // ------------------------------------------------------------------
    // 点按钮
    // ------------------------------------------------------------------

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && this.menu.kind() == ReactorKind.CRITICAL
                && this.minecraft != null && this.minecraft.gameMode != null) {
            int x = (int) mouseX - this.leftPos;
            int y = (int) mouseY - this.topPos;
            if (inside(x, y, BUTTON_MINUS_X, BUTTON_Y, BUTTON_W, BUTTON_H)) {
                send(ReactorMenu.BUTTON_ROD_LESS);
                return true;
            }
            if (inside(x, y, BUTTON_PLUS_X, BUTTON_Y, BUTTON_W, BUTTON_H)) {
                send(ReactorMenu.BUTTON_ROD_MORE);
                return true;
            }
            if (inside(x, y, SLIDER_X, SLIDER_Y, SLIDER_W, SLIDER_H)) {
                int percent = Math.round((x - SLIDER_X) * 100.0F / SLIDER_W);
                send(ReactorMenu.BUTTON_ROD_ABSOLUTE + Math.max(0, Math.min(100, percent)));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void send(int buttonId) {
        if (this.minecraft != null && this.minecraft.gameMode != null) {
            this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, buttonId);
        }
    }

    private static boolean inside(int x, int y, int left, int top, int width, int height) {
        return x >= left && x < left + width && y >= top && y < top + height;
    }
}
