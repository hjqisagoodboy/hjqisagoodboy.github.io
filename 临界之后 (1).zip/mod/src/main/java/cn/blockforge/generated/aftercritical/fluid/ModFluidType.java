package cn.blockforge.generated.aftercritical.fluid;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.fluids.FluidType;

import java.util.function.Consumer;

/**
 * 模组流体的「性格」：颜色 + 客户端怎么画。
 *
 * <p>每种流体都有自己的一份 {@code FluidType}，里面有密度、粘度这些物理属性
 * （见 {@code ModFluids}）。这个类额外多两样东西：
 * <ul>
 *   <li>{@link #tintColor()}：这个流体是什么颜色。储罐界面、单元贴图、世界里的液体都用它上色；</li>
 *   <li>{@link #initializeClient}：告诉客户端「用哪张贴图画静止/流动的液体」。</li>
 * </ul>
 *
 * <p>所有流体共用同一组灰白色贴图（{@code block/fluid/still.png} 和 {@code flowing.png}），
 * 全靠颜色相乘来区分——所以这里只用两张图，而不是每种流体各画两张。
 * 以后想给某种流体换专属贴图，只要在它自己的 {@code FluidType} 里改成别的路径就行。
 */
public class ModFluidType extends FluidType {

    /** 静止液体的贴图。 */
    public static final ResourceLocation STILL_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("aftercritical", "block/fluid/still");

    /** 流动液体的贴图。 */
    public static final ResourceLocation FLOWING_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("aftercritical", "block/fluid/flowing");

    /** 颜色（ARGB，带不透明度的 0xFF 前缀）。 */
    private final int tintColor;

    public ModFluidType(Properties properties, int tintColor) {
        super(properties);
        this.tintColor = tintColor;
    }

    /** 这个流体画出来是什么颜色。 */
    public int tintColor() {
        return this.tintColor;
    }

    /**
     * 客户端才会调用：把贴图和颜色交给渲染器。
     *
     * <p>服务端永远走不到这里，所以引用客户端专属的 {@link IClientFluidTypeExtensions} 是安全的。
     */
    @Override
    public void initializeClient(Consumer<IClientFluidTypeExtensions> consumer) {
        consumer.accept(new IClientFluidTypeExtensions() {
            @Override
            public ResourceLocation getStillTexture() {
                return STILL_TEXTURE;
            }

            @Override
            public ResourceLocation getFlowingTexture() {
                return FLOWING_TEXTURE;
            }

            @Override
            public int getTintColor() {
                return ModFluidType.this.tintColor;
            }
        });
    }
}
