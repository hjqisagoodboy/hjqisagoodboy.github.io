package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.ForgingPressBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 锻压机方块：LV，40 FE/t，装模具压板、拉铜线。
 *
 * <p>开局没电怎么办：铁板和铜线在工作台里也能用锤子直接敲出来
 * （铁块 → 铁板 ×3、铜块 → 铜线 ×16，锤子掉 1 点耐久），
 * 那点材料足够造出第一台燃烧发电机。发电机一响，板材就交给这台机器量产。
 */
public class ForgingPressBlock extends MachineBlock {

    public ForgingPressBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(ForgingPressBlock::new);
    }

    @Override
    protected int energyPerTick() {
        return ForgingPressBlockEntity.ENERGY_PER_TICK;
    }

    @Override
    protected String recipeHintKey() {
        return "tooltip.aftercritical.forging_press.recipes";
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ForgingPressBlockEntity(pos, state);
    }

    /** 物品栏里多给一句「没电就先用手敲」，新手最容易卡在这一步。 */
    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.aftercritical.forging_press.no_power")
                .withStyle(ChatFormatting.GREEN));
    }
}
