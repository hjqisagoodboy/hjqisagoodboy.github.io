package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.block.SmartFluidDuctBlock;
import cn.blockforge.generated.aftercritical.blockentity.SmartFluidDuctBlockEntity;
import cn.blockforge.generated.aftercritical.item.FluidIdentifierItem;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import cn.blockforge.generated.aftercritical.registry.ModBlocks;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import cn.blockforge.generated.aftercritical.network.CloudState;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/**
 * 客户端专用：把「菜单类型」和「界面类」绑起来，顺便给流体容器上色。
 *
 * <p>只在客户端加载（{@code value = Dist.CLIENT}），服务端不会碰到界面相关的类。
 */
@EventBusSubscriber(modid = AfterCritical.MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {

    /** 上色时表示「别染色，用贴图原色」。 */
    private static final int NO_TINT = 0xFFFFFFFF;

    /** 智能流体管道没盖章时的颜色（金属灰）。 */
    private static final int UNMARKED_DUCT_COLOR = 0xFFB4BCC4;

    /** 管道盖的是「不认识的流体」（别的模组加的）时用的颜色。 */
    private static final int UNKNOWN_FLUID_COLOR = 0xFFB07FD0;

    /** 冷却靶材的冷蓝色蒙版。 */
    private static final int COOLED_TINT = 0xFFA9C6E8;

    private ClientSetup() {}

    @SubscribeEvent
    public static void onRegisterMenuScreens(RegisterMenuScreensEvent event) {
        event.register(ModMenus.CRUSHER.get(), CrusherScreen::new);
        event.register(ModMenus.BALL_MILL.get(), BallMillScreen::new);
        event.register(ModMenus.FORGING_PRESS.get(), ForgingPressScreen::new);
        event.register(ModMenus.COMPACTOR.get(), CompactorScreen::new);
        event.register(ModMenus.ASSEMBLER_T1.get(), AssemblerT1Screen::new);
        event.register(ModMenus.ASSEMBLER_T2.get(), AssemblerT2Screen::new);
        event.register(ModMenus.COMBUSTION_GENERATOR.get(), GeneratorScreen::new);
        event.register(ModMenus.FUEL_ROD_GENERATOR.get(), GeneratorScreen::new);
        event.register(ModMenus.BATTERY_LV.get(), BatteryLvScreen::new);
        event.register(ModMenus.BATTERY_MV.get(), BatteryMvScreen::new);
        event.register(ModMenus.ELECTROLYZER.get(), FluidMachineScreen::new);
        event.register(ModMenus.CHEMICAL_PLANT.get(), FluidMachineScreen::new);
        event.register(ModMenus.AIR_SEPARATOR.get(), FluidMachineScreen::new);
        event.register(ModMenus.GROUNDWATER_PUMP.get(), FluidMachineScreen::new);
        event.register(ModMenus.LEACHING_TANK.get(), FluidMachineScreen::new);
        event.register(ModMenus.PRECIPITATION_TANK.get(), FluidMachineScreen::new);
        event.register(ModMenus.DRYING_OVEN.get(), FluidMachineScreen::new);
        event.register(ModMenus.CONVERTER.get(), FluidMachineScreen::new);
        event.register(ModMenus.FLUORINATION_REACTOR.get(), FluidMachineScreen::new);
        event.register(ModMenus.GAS_CENTRIFUGE.get(), FluidMachineScreen::new);
        event.register(ModMenus.HYDROLYSIS_REACTOR.get(), FluidMachineScreen::new);
        event.register(ModMenus.CASCADE_CONTROLLER.get(), CascadeControllerScreen::new);
        event.register(ModMenus.SINTERING_FURNACE.get(), ItemMachineScreen::new);
        event.register(ModMenus.GRINDING_MACHINE.get(), ItemMachineScreen::new);
        event.register(ModMenus.WELDING_MACHINE.get(), ItemMachineScreen::new);
        event.register(ModMenus.LOGISTICS_CONTROLLER.get(), LogisticsControllerScreen::new);
        event.register(ModMenus.FLUID_IDENTIFIER.get(), FluidIdentifierScreen::new);
        event.register(ModMenus.TANK_CONTROLLER.get(), TankControllerScreen::new);
        event.register(ModMenus.SUBCRITICAL_CONTROLLER.get(), ReactorScreen::new);
        event.register(ModMenus.CRITICAL_REACTOR_CONTROLLER.get(), ReactorScreen::new);
        event.register(ModMenus.NEUTRON_FLUX_RECORDER.get(), NeutronFluxRecorderScreen::new);

        // 阶段 4
        event.register(ModMenus.ASSEMBLER_T3.get(), AssemblerT3Screen::new);
        event.register(ModMenus.GAMMA_IRRADIATOR.get(), ItemMachineScreen::new);
        event.register(ModMenus.IRRADIATION_POOL.get(), FluidMachineScreen::new);
        event.register(ModMenus.RESEARCH_REACTOR.get(), ResearchReactorScreen::new);

        // 阶段 6：后处理线 + 快堆
        event.register(ModMenus.SPENT_FUEL_POOL.get(), FluidMachineScreen::new);
        event.register(ModMenus.DISSOLUTION_TANK.get(), FluidMachineScreen::new);
        event.register(ModMenus.EXTRACTION_COLUMN.get(), FluidMachineScreen::new);
        event.register(ModMenus.CENTRIFUGAL_EXTRACTOR.get(), FluidMachineScreen::new);
        event.register(ModMenus.VITRIFICATION_FURNACE.get(), FluidMachineScreen::new);
        event.register(ModMenus.SHEARING_MACHINE.get(), ItemMachineScreen::new);
        event.register(ModMenus.FAST_REACTOR_CONTROLLER.get(), FastReactorScreen::new);
        event.register(ModMenus.SODIUM_STEAM_GENERATOR.get(), SodiumSteamGeneratorScreen::new);

        // 阶段 5
        event.register(ModMenus.HOT_CELL_ARM.get(), HotCellArmScreen::new);
        event.register(ModMenus.PWR_CONTROLLER.get(), PwrControllerScreen::new);
        event.register(ModMenus.STEAM_GENERATOR.get(), SteamGeneratorScreen::new);
        event.register(ModMenus.CONDENSER.get(), FluidMachineScreen::new);
        event.register(ModMenus.FUEL_PORT.get(), FuelPortScreen::new);
        event.register(ModMenus.GIANT_BATTERY.get(), GiantBatteryScreen::new);

        // 阶段 7：托卡马克 + 物质嬗变器
        event.register(ModMenus.TOKAMAK_CONTROLLER.get(), TokamakScreen::new);
        event.register(ModMenus.TRANSMUTATOR_CONTROLLER.get(), TransmutatorScreen::new);

        // 武器：核装置总装台 + 核弹装配界面
        event.register(ModMenus.WARHEAD_ASSEMBLER.get(), ItemMachineScreen::new);
        event.register(ModMenus.NUKE.get(), NukeScreen::new);
    }

    /**
     * 通用流体罐的「换贴图」开关。
     *
     * <p>整个模组只有一个罐子物品，空罐和满罐靠物品模型的 override 区分：
     * 这里注册一个 {@code aftercritical:filled} 判断值，罐子里有流体就返回 1，
     * 模型 JSON 里写着「=1 时换成带液面那一层的模型」，所以装没装东西一眼就能看出来。
     *
     * <p>和「给物品加一个 custom_model_data 组件」相比，这样做不会给物品本身上面乱加数据，
     * 空罐和空罐还是完完全全一样的东西，能正常叠 64。
     */
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            // 蘑菇云的包：服务器只说「这朵云在哪、多大、活了多久」，这里记下来交给渲染器画。
            // 年龄按世界时间算（暂停时世界时间也停，云不会趁开菜单偷偷散掉）。
            CloudState.setSink(payload -> {
                Minecraft minecraft = Minecraft.getInstance();
                if (minecraft.level != null) {
                    CloudState.store(payload, minecraft.level.getGameTime());
                }
            });

            ItemProperties.register(
                    ModItems.UNIVERSAL_FLUID_TANK.get(),
                    ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "filled"),
                    (stack, level, entity, seed) -> UniversalTankItem.isFilled(stack) ? 1.0F : 0.0F);

            // 插在土里的熔毁燃料棒是十字模型，贴图大半是透明的。
            // 不登记成 cutout 的话，透明的地方会画成黑方块——跟一根黑柱子似的。
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.MELTED_FUEL_ROD_STUB.get(), RenderType.cutout());

            // 核废水要和原版水一样「透」：液体本身是半透明的，得走半透明渲染层，
            // 不然整片水会被画成一块不透明的黑板，底下的坑壁、矿石全都看不见。
            // 两处都要登记：方块那一层管「这块方块怎么画」，流体那一层才是液面真正用的
            // （原版的水平时就是靠流体这一层登记成 translucent 才半透明的）。
            ItemBlockRenderTypes.setRenderLayer(ModBlocks.NUCLEAR_WASTEWATER_FLUID.get(),
                    RenderType.translucent());
            ItemBlockRenderTypes.setRenderLayer(ModFluids.NUCLEAR_WASTEWATER.source.get(),
                    RenderType.translucent());
            ItemBlockRenderTypes.setRenderLayer(ModFluids.NUCLEAR_WASTEWATER.flowing.get(),
                    RenderType.translucent());
        });
    }

    /**
     * 给「白色的贴图」染上颜色。
     *
     * <p>通用流体罐是两层：第 0 层是铁皮 + 玻璃罐体（不染色），
     * 第 1 层是液面（一张纯白的图形），染成里面那种流体的颜色——
     * 所以硫酸罐是琥珀色、水罐是蓝色，玩家不用看名字。
     */
    @SubscribeEvent
    public static void onRegisterItemColors(RegisterColorHandlersEvent.Item event) {
        // 通用流体罐：第 0 层罐体保持原色，第 1 层液面按流体颜色染
        event.register((stack, tintIndex) -> {
            if (tintIndex != 1) {
                return NO_TINT;
            }
            Integer tint = UniversalTankItem.tintOf(stack);
            return tint == null ? NO_TINT : tint;
        }, ModItems.UNIVERSAL_FLUID_TANK.get());

        // 流体识别码：绑定了哪种流体就染成那种颜色
        event.register((stack, tintIndex) -> {
            Integer tint = FluidIdentifierItem.tintOf(stack);
            return tint == null ? NO_TINT : tint;
        }, ModItems.FLUID_IDENTIFIER.get());

        // 冷却的靶材：直接复用「辐照过的靶」那张贴图，再统一蒙一层冷蓝色，
        // 一眼就能和还烫手的辐照靶分开（也省得为 7 种靶各画一张新图）
        event.register((stack, tintIndex) -> COOLED_TINT,
                ModItems.COOLED_COBALT59.get(), ModItems.COOLED_LITHIUM6.get(),
                ModItems.COOLED_URANIUM238.get(), ModItems.COOLED_CESIUM133.get(),
                ModItems.COOLED_STRONTIUM88.get(), ModItems.COOLED_PLUTONIUM239.get(),
                ModItems.COOLED_SILICON30.get());
    }

    /**
     * 智能流体管道的颜色。
     *
     * <p>管道那张贴图是金属灰白，这里按「盖的章」乘上流体颜色：
     * 盖了氢的章就是浅蓝、盖了硫酸的章就是琥珀，没盖章的保持金属灰——
     * 玩家一眼就能看出这根管子搬的是什么。
     */
    @SubscribeEvent
    public static void onRegisterBlockColors(RegisterColorHandlersEvent.Block event) {
        event.register((state, level, pos, tintIndex) -> {
            if (tintIndex != 0) {
                return UNMARKED_DUCT_COLOR;
            }
            int index = state.getValue(SmartFluidDuctBlock.FLUID_INDEX);
            // 本模组七种流体、水、岩浆的颜色直接来自编号，不依赖方块实体到没到客户端
            int known = ModFluids.ductIndexColor(index);
            if (known != -1) {
                return known;
            }
            // 别的模组的流体：编号只是「15」，具体颜色要问方块实体
            if (level != null && pos != null
                    && level.getBlockEntity(pos) instanceof SmartFluidDuctBlockEntity duct
                    && duct.getMarker() != null) {
                return ModFluids.colorOf(duct.getMarker());
            }
            return index == ModFluids.DUCT_INDEX_NONE ? UNMARKED_DUCT_COLOR : UNKNOWN_FLUID_COLOR;
        }, ModBlocks.SMART_FLUID_DUCT.get());
    }
}
