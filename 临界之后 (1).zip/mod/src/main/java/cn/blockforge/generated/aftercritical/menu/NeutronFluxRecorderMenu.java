package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.NeutronFluxRecorderBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 中子通量记录仪的界面：一个没有槽位的小仪表盘，只有四行读数。
 *
 * <p>版式还是全模组那一套面板，只是中间没有机器槽，所以面板也矮一些。
 */
public class NeutronFluxRecorderMenu extends AbstractMachineMenu {

    /** 底部读数一共几行。 */
    public static final int STAT_LINES = 4;

    /** 表头留白：标题下面直接开始写读数。 */
    public static final int TEXT_TOP = 20;

    private static final int DATA_LINKED = 0;
    private static final int DATA_KEFF = 1;
    private static final int DATA_FLUX = 2;
    private static final int DATA_STATUS = 3;
    private static final int DATA_KIND = 4;
    private static final int DATA_COUNT = 5;

    @Nullable
    private final NeutronFluxRecorderBlockEntity recorder;

    private boolean linked;
    private int kScaled;
    private int flux;
    private int status;
    private boolean criticalKind;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case DATA_LINKED -> linked ? 1 : 0;
                case DATA_KEFF -> kScaled;
                case DATA_FLUX -> flux;
                case DATA_STATUS -> status;
                case DATA_KIND -> criticalKind ? 1 : 0;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case DATA_LINKED -> linked = value != 0;
                case DATA_KEFF -> kScaled = value;
                case DATA_FLUX -> flux = value;
                case DATA_STATUS -> status = value;
                case DATA_KIND -> criticalKind = value != 0;
                default -> {
                }
            }
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    /** 服务端用。 */
    public NeutronFluxRecorderMenu(int containerId, Inventory playerInventory,
                                   NeutronFluxRecorderBlockEntity recorder) {
        this(ModMenus.NEUTRON_FLUX_RECORDER.get(), containerId, playerInventory, recorder);
    }

    private NeutronFluxRecorderMenu(MenuType<?> type, int containerId, Inventory playerInventory,
                                    @Nullable NeutronFluxRecorderBlockEntity recorder) {
        super(type, containerId, playerInventory, 0, null, 0);
        this.recorder = recorder;
        this.addPlayerInventory(playerInventory, inventoryY());
        this.addDataSlots(this.data);
    }

    /** 客户端收到「打开菜单」的包后调用。 */
    public static NeutronFluxRecorderMenu fromNetwork(int containerId, Inventory playerInventory,
                                                      RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof NeutronFluxRecorderBlockEntity recorder) {
            return new NeutronFluxRecorderMenu(ModMenus.NEUTRON_FLUX_RECORDER.get(), containerId,
                    playerInventory, recorder);
        }
        return new NeutronFluxRecorderMenu(ModMenus.NEUTRON_FLUX_RECORDER.get(), containerId,
                playerInventory, null);
    }

    @Override
    public void broadcastChanges() {
        if (this.recorder != null) {
            this.linked = this.recorder.isLinked();
            this.kScaled = this.recorder.kScaled();
            this.flux = this.recorder.flux();
            this.status = this.recorder.status();
            this.criticalKind = this.recorder.isCriticalKind();
        }
        super.broadcastChanges();
    }

    public boolean isLinked() {
        return this.linked;
    }

    public int kScaled() {
        return this.kScaled;
    }

    public int flux() {
        return this.flux;
    }

    public int status() {
        return this.status;
    }

    public boolean isCriticalKind() {
        return this.criticalKind;
    }

    @Override
    public boolean stillValid(Player player) {
        return this.recorder == null || (!this.recorder.isRemoved()
                && player.distanceToSqr(this.recorder.getBlockPos().getCenter()) <= 64.0);
    }

    @Override
    public int textY() {
        return TEXT_TOP;
    }

    @Override
    public int inventoryLabelY() {
        return textY() + STAT_LINES * MachineLayout.TEXT_STEP + 3;
    }

    @Override
    public int inventoryY() {
        return inventoryLabelY() + 10;
    }

    @Override
    public int guiHeight() {
        return inventoryY() + 58 + 18 + 6;
    }
}
