package cn.blockforge.generated.aftercritical.registry;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.block.AssemblerT1Block;
import cn.blockforge.generated.aftercritical.block.AssemblerT2Block;
import cn.blockforge.generated.aftercritical.block.AssemblerT3Block;
import cn.blockforge.generated.aftercritical.block.BallMillBlock;
import cn.blockforge.generated.aftercritical.block.BatteryLvBlock;
import cn.blockforge.generated.aftercritical.block.BatteryMvBlock;
import cn.blockforge.generated.aftercritical.block.BoricAcidTankBlock;
import cn.blockforge.generated.aftercritical.block.CableBlock;
import cn.blockforge.generated.aftercritical.block.UniversalTankBlock;
import cn.blockforge.generated.aftercritical.block.CascadeControllerBlock;
import cn.blockforge.generated.aftercritical.block.CableTier;
import cn.blockforge.generated.aftercritical.block.CombustionGeneratorBlock;
import cn.blockforge.generated.aftercritical.block.CompactorBlock;
import cn.blockforge.generated.aftercritical.block.ContaminatedSoilBlock;
import cn.blockforge.generated.aftercritical.block.ControlRodPortBlock;
import cn.blockforge.generated.aftercritical.block.CoolantPortBlock;
import cn.blockforge.generated.aftercritical.block.CoreRemnantBlock;
import cn.blockforge.generated.aftercritical.block.CriticalAlarmBlock;
import cn.blockforge.generated.aftercritical.block.CrusherBlock;
import cn.blockforge.generated.aftercritical.block.EnergyPortBlock;
import cn.blockforge.generated.aftercritical.block.FastReactorControllerBlock;
import cn.blockforge.generated.aftercritical.block.ForgingPressBlock;
import cn.blockforge.generated.aftercritical.block.FuelPortBlock;
import cn.blockforge.generated.aftercritical.block.FuelRodGeneratorBlock;
import cn.blockforge.generated.aftercritical.block.GeologicRepositoryBlock;
import cn.blockforge.generated.aftercritical.block.GiantBatteryBlock;
import cn.blockforge.generated.aftercritical.block.FluidMachineBlock;
import cn.blockforge.generated.aftercritical.block.HotCellArmBlock;
import cn.blockforge.generated.aftercritical.block.ItemMachineBlock;
import cn.blockforge.generated.aftercritical.block.ItemPipeBlock;
import cn.blockforge.generated.aftercritical.block.LogisticsControllerBlock;
import cn.blockforge.generated.aftercritical.block.MoltenOreBlock;
import cn.blockforge.generated.aftercritical.block.MoltenWasteBlock;
import cn.blockforge.generated.aftercritical.block.MeltedFuelRodStubBlock;
import cn.blockforge.generated.aftercritical.block.NeutronDetectorBlock;
import cn.blockforge.generated.aftercritical.block.NukeBlock;
import cn.blockforge.generated.aftercritical.block.NeutronFluxRecorderBlock;
import cn.blockforge.generated.aftercritical.block.PwrControllerBlock;
import cn.blockforge.generated.aftercritical.block.RadioactiveDustBlock;
import cn.blockforge.generated.aftercritical.block.ReactorControllerBlock;
import cn.blockforge.generated.aftercritical.block.ReactorPartBlock;
import cn.blockforge.generated.aftercritical.block.ResearchReactorControllerBlock;
import cn.blockforge.generated.aftercritical.block.ScorchedEarthBlock;
import cn.blockforge.generated.aftercritical.block.SmartFluidDuctBlock;
import cn.blockforge.generated.aftercritical.block.SodiumSteamGeneratorBlock;
import cn.blockforge.generated.aftercritical.block.SteamGeneratorBlock;
import cn.blockforge.generated.aftercritical.block.TankControllerBlock;
import cn.blockforge.generated.aftercritical.block.TankPortBlock;
import cn.blockforge.generated.aftercritical.block.TankPortKind;
import cn.blockforge.generated.aftercritical.block.TokamakControllerBlock;
import cn.blockforge.generated.aftercritical.block.TransformerBlock;
import cn.blockforge.generated.aftercritical.block.TransformerTier;
import cn.blockforge.generated.aftercritical.block.TransmutatorControllerBlock;
import cn.blockforge.generated.aftercritical.blockentity.FluidMachineKind;
import cn.blockforge.generated.aftercritical.blockentity.ItemMachineKind;
import cn.blockforge.generated.aftercritical.blockentity.ReactorKind;
import cn.blockforge.generated.aftercritical.block.UraniumOreBlock;
import cn.blockforge.generated.aftercritical.block.WastewaterBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

/** 6 种矿石方块。都是普通方块：铁镐及以上可挖，掉落自身。 */
public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(AfterCritical.MOD_ID);

    /** 铀矿石：深绿带一点蓝，挖掉会沾染辐射。 */
    public static final DeferredBlock<Block> URANIUM_ORE =
            BLOCKS.registerBlock("uranium_ore", UraniumOreBlock::new, ore(MapColor.COLOR_GREEN));
    /** 铅矿石：深灰蓝。 */
    public static final DeferredBlock<Block> LEAD_ORE =
            BLOCKS.registerBlock("lead_ore", Block::new, ore(MapColor.COLOR_GRAY));
    /** 锂辉石矿石：淡紫灰。 */
    public static final DeferredBlock<Block> SPODUMENE_ORE =
            BLOCKS.registerBlock("spodumene_ore", Block::new, ore(MapColor.COLOR_PURPLE));
    /** 硼砂矿石：白中带灰。 */
    public static final DeferredBlock<Block> BORAX_ORE =
            BLOCKS.registerBlock("borax_ore", Block::new, ore(MapColor.QUARTZ));
    /** 绿柱石矿石：浅绿。 */
    public static final DeferredBlock<Block> BERYL_ORE =
            BLOCKS.registerBlock("beryl_ore", Block::new, ore(MapColor.COLOR_LIGHT_GREEN));
    /** 锆石矿石：棕黄。 */
    public static final DeferredBlock<Block> ZIRCON_ORE =
            BLOCKS.registerBlock("zircon_ore", Block::new, ore(MapColor.COLOR_BROWN));
    /** 钯矿石：浅灰带银白，全世界 -32~32 层才有，矿脉很小，是稀有矿。 */
    public static final DeferredBlock<Block> PALLADIUM_ORE =
            BLOCKS.registerBlock("palladium_ore", Block::new, ore(MapColor.COLOR_LIGHT_GRAY));
    /** 钴矿石：钴蓝色的金属矿，钴59靶的原料。 */
    public static final DeferredBlock<Block> COBALT_ORE =
            BLOCKS.registerBlock("cobalt_ore", Block::new, ore(MapColor.COLOR_BLUE));
    /** 铯矿石：黄橙色的铯榴石，铯133靶的原料，比钴矿少见。 */
    public static final DeferredBlock<Block> CESIUM_ORE =
            BLOCKS.registerBlock("cesium_ore", Block::new, ore(MapColor.COLOR_YELLOW));
    /** 锶矿石：砖红色的天青石，锶88靶的原料。 */
    public static final DeferredBlock<Block> STRONTIUM_ORE =
            BLOCKS.registerBlock("strontium_ore", Block::new, ore(MapColor.COLOR_RED));

    /** 破碎机：LV 机器，30 FE/t。 */
    public static final DeferredBlock<CrusherBlock> CRUSHER =
            BLOCKS.registerBlock("crusher", CrusherBlock::new, machine(MapColor.COLOR_GRAY));

    /** 球磨机：LV 机器，60 FE/t。 */
    public static final DeferredBlock<BallMillBlock> BALL_MILL =
            BLOCKS.registerBlock("ball_mill", BallMillBlock::new, machine(MapColor.COLOR_GRAY));

    /** 锻压机：LV 机器，40 FE/t。 */
    public static final DeferredBlock<ForgingPressBlock> FORGING_PRESS =
            BLOCKS.registerBlock("forging_press", ForgingPressBlock::new, machine(MapColor.COLOR_GRAY));

    /** 压块机：MV 机器，100 FE/t，把散装原料压成燃料棒。 */
    public static final DeferredBlock<CompactorBlock> COMPACTOR =
            BLOCKS.registerBlock("compactor", CompactorBlock::new, machine(MapColor.COLOR_GRAY));

    /** 装配机 T1：LV，50 FE/t，吃多种原料做零件和机器。 */
    public static final DeferredBlock<AssemblerT1Block> ASSEMBLER_T1 =
            BLOCKS.registerBlock("assembler_t1", AssemblerT1Block::new, machine(MapColor.COLOR_GRAY));

    /** 装配机 T2：MV，100 FE/t，装配机 T1 的升级版。 */
    public static final DeferredBlock<AssemblerT2Block> ASSEMBLER_T2 =
            BLOCKS.registerBlock("assembler_t2", AssemblerT2Block::new, machine(MapColor.COLOR_GRAY));

    /** 燃烧发电机：LV，输出 80 FE/t。 */
    public static final DeferredBlock<CombustionGeneratorBlock> COMBUSTION_GENERATOR =
            BLOCKS.registerBlock("combustion_generator", CombustionGeneratorBlock::new, machine(MapColor.COLOR_GRAY));

    /** 燃料棒发电机：MV，输出 320 FE/t。 */
    public static final DeferredBlock<FuelRodGeneratorBlock> FUEL_ROD_GENERATOR =
            BLOCKS.registerBlock("fuel_rod_generator", FuelRodGeneratorBlock::new, machine(MapColor.COLOR_GRAY));

    /** 电池 LV：存 40,000 FE。 */
    public static final DeferredBlock<BatteryLvBlock> BATTERY_LV =
            BLOCKS.registerBlock("battery_lv", BatteryLvBlock::new, machine(MapColor.COLOR_GRAY));

    /** 电解槽：LV，40 FE/t，水 → 氢 + 氧。 */
    public static final DeferredBlock<FluidMachineBlock> ELECTROLYZER = BLOCKS.registerBlock(
            "electrolyzer",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.ELECTROLYZER),
            machine(MapColor.COLOR_GRAY));

    /** 化工厂：MV，80 FE/t，做硫酸和氨。 */
    public static final DeferredBlock<FluidMachineBlock> CHEMICAL_PLANT = BLOCKS.registerBlock(
            "chemical_plant",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.CHEMICAL_PLANT),
            machine(MapColor.COLOR_GRAY));

    /** 空气分离器：MV，120 FE/t，把空气分成氮和氧。 */
    public static final DeferredBlock<FluidMachineBlock> AIR_SEPARATOR = BLOCKS.registerBlock(
            "air_separator",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.AIR_SEPARATOR),
            machine(MapColor.COLOR_GRAY));

    /** 地下水开采机：LV，最低 30 FE/t，通电每 10 秒出 200 mB 水，电越多越快。 */
    public static final DeferredBlock<FluidMachineBlock> GROUNDWATER_PUMP = BLOCKS.registerBlock(
            "groundwater_pump",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.GROUNDWATER_PUMP),
            machine(MapColor.COLOR_CYAN));

    // ------------------------------------------------------------------
    // 阶段 1 的五台流体机器（和上面三台共用方块实体和界面，只是型号不同）
    // ------------------------------------------------------------------

    /** 浸出槽：LV，50 FE/t，矿粉 + 硫酸 → 铀酰溶液。 */
    public static final DeferredBlock<FluidMachineBlock> LEACHING_TANK = BLOCKS.registerBlock(
            "leaching_tank",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.LEACHING_TANK),
            machine(MapColor.COLOR_GRAY));

    /** 沉淀槽：LV，40 FE/t，铀酰溶液 + 沉淀剂 → 黄饼。 */
    public static final DeferredBlock<FluidMachineBlock> PRECIPITATION_TANK = BLOCKS.registerBlock(
            "precipitation_tank",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.PRECIPITATION_TANK),
            machine(MapColor.COLOR_GRAY));

    /** 干燥炉：LV，60 FE/t，只烤物品。 */
    public static final DeferredBlock<FluidMachineBlock> DRYING_OVEN = BLOCKS.registerBlock(
            "drying_oven",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.DRYING_OVEN),
            machine(MapColor.COLOR_GRAY));

    /** 转化炉：MV，120 FE/t，铀氧化物 + 氢氟酸 → 六氟化铀。 */
    public static final DeferredBlock<FluidMachineBlock> CONVERTER = BLOCKS.registerBlock(
            "converter",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.CONVERTER),
            machine(MapColor.COLOR_GRAY));

    /** 氟化反应器：MV，160 FE/t，氟化物 + 氟气 → 氟化产物。 */
    public static final DeferredBlock<FluidMachineBlock> FLUORINATION_REACTOR = BLOCKS.registerBlock(
            "fluorination_reactor",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.FLUORINATION_REACTOR),
            machine(MapColor.COLOR_GRAY));

    // ------------------------------------------------------------------
    // 阶段 2 的三台新机器
    // ------------------------------------------------------------------

    /** 气体离心机：MV，200 FE/t，六氟化铀 → 低浓缩铀 + 贫铀。 */
    public static final DeferredBlock<FluidMachineBlock> GAS_CENTRIFUGE = BLOCKS.registerBlock(
            "gas_centrifuge",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.GAS_CENTRIFUGE),
            machine(MapColor.COLOR_GRAY));

    /** 水解反应器：MV，80 FE/t，低浓缩六氟化铀 + 水 → 二氧化铀粉 + 氢氟酸。 */
    public static final DeferredBlock<FluidMachineBlock> HYDROLYSIS_REACTOR = BLOCKS.registerBlock(
            "hydrolysis_reactor",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.HYDROLYSIS_REACTOR),
            machine(MapColor.COLOR_GRAY));

    /** 级联控制器：HV，32 FE/t，管着半径 8 格内最多 32 台气体离心机的进出料。 */
    public static final DeferredBlock<CascadeControllerBlock> CASCADE_CONTROLLER = BLOCKS.registerBlock(
            "cascade_controller", CascadeControllerBlock::new, machine(MapColor.COLOR_GRAY));

    // ------------------------------------------------------------------
    // 阶段 2 燃料制造链的三台物品机器（共用方块类和方块实体）
    // ------------------------------------------------------------------

    /** 烧结炉：HV，150 FE/t，把芯块坯烧成烧结芯块。 */
    public static final DeferredBlock<ItemMachineBlock> SINTERING_FURNACE = BLOCKS.registerBlock(
            "sintering_furnace",
            properties -> new ItemMachineBlock(properties, ItemMachineKind.SINTERING_FURNACE),
            machine(MapColor.COLOR_GRAY));

    /** 磨削机：MV，80 FE/t，把烧结芯块磨成精磨芯块，顺带掉废粉。 */
    public static final DeferredBlock<ItemMachineBlock> GRINDING_MACHINE = BLOCKS.registerBlock(
            "grinding_machine",
            properties -> new ItemMachineBlock(properties, ItemMachineKind.GRINDING_MACHINE),
            machine(MapColor.COLOR_GRAY));

    /** 焊接机：MV，100 FE/t，燃料棒 + 端塞 → 密封燃料棒。 */
    public static final DeferredBlock<ItemMachineBlock> WELDING_MACHINE = BLOCKS.registerBlock(
            "welding_machine",
            properties -> new ItemMachineBlock(properties, ItemMachineKind.WELDING_MACHINE),
            machine(MapColor.COLOR_GRAY));

    /** 物流控制器：MV，16 FE/t，把物品管道的货朝六个方向轮流分出去。 */
    public static final DeferredBlock<LogisticsControllerBlock> LOGISTICS_CONTROLLER = BLOCKS.registerBlock(
            "logistics_controller", LogisticsControllerBlock::new, machine(MapColor.COLOR_GRAY));

    /** LV 线缆：80 FE/t 的输电方块，六面自动接邻居。 */
    public static final DeferredBlock<CableBlock> LV_CABLE = BLOCKS.registerBlock(
            "lv_cable",
            properties -> new CableBlock(properties, CableTier.LV),
            cable());

    /** MV 线缆：320 FE/t 的输电方块，六面自动接邻居。 */
    public static final DeferredBlock<CableBlock> MV_CABLE = BLOCKS.registerBlock(
            "mv_cable",
            properties -> new CableBlock(properties, CableTier.MV),
            cable());

    /** HV 线缆：2,560 FE/t 的输电方块，六面自动接邻居。 */
    public static final DeferredBlock<CableBlock> HV_CABLE = BLOCKS.registerBlock(
            "hv_cable",
            properties -> new CableBlock(properties, CableTier.HV),
            cable());

    /** 变压器 LV→MV：背面 80 FE/t 进，正面 320 FE/t 出。 */
    public static final DeferredBlock<TransformerBlock> TRANSFORMER_LV_MV =
            BLOCKS.registerBlock("transformer_lv_mv", TransformerBlock::new, machine(MapColor.METAL));

    /** 变压器 MV→HV：背面 320 FE/t 进，正面 2,560 FE/t 出。 */
    public static final DeferredBlock<TransformerBlock> TRANSFORMER_MV_HV = BLOCKS.registerBlock(
            "transformer_mv_hv",
            properties -> new TransformerBlock(properties, TransformerTier.MV_HV),
            machine(MapColor.METAL));

    /** 物品管道：每 tick 搬 1 个物品，不耗电。 */
    public static final DeferredBlock<ItemPipeBlock> ITEM_PIPE =
            BLOCKS.registerBlock("item_pipe", ItemPipeBlock::new, pipe(MapColor.COLOR_GRAY));

    /**
     * 智能流体管道：盖了章才搬东西、只搬盖章的那种流体，每 tick 100 mB，不耗电。
     */
    public static final DeferredBlock<SmartFluidDuctBlock> SMART_FLUID_DUCT =
            BLOCKS.registerBlock("smart_fluid_duct", SmartFluidDuctBlock::new, pipe(MapColor.COLOR_ORANGE));

    // ------------------------------------------------------------------
    // 阶段 1：铅块 + 储罐多方块
    // ------------------------------------------------------------------

    /** 铅块：9 个铅锭压成一块，储罐的外壳用它砌。 */
    public static final DeferredBlock<Block> LEAD_BLOCK =
            BLOCKS.registerBlock("lead_block", Block::new, metalBlock(MapColor.COLOR_GRAY));

    /** 储罐多方块控制器：3×3×3 外壳的心脏，64,000 mB。 */
    public static final DeferredBlock<TankControllerBlock> TANK_CONTROLLER = BLOCKS.registerBlock(
            "tank_controller", TankControllerBlock::new, machine(MapColor.COLOR_GRAY));

    /** 储罐流体输入口：只能往罐子里灌。 */
    public static final DeferredBlock<TankPortBlock> TANK_INPUT_PORT = BLOCKS.registerBlock(
            "tank_input_port",
            properties -> new TankPortBlock(properties, TankPortKind.INPUT),
            machine(MapColor.COLOR_GRAY));

    /** 储罐流体输出口：只能从罐子里抽。 */
    public static final DeferredBlock<TankPortBlock> TANK_OUTPUT_PORT = BLOCKS.registerBlock(
            "tank_output_port",
            properties -> new TankPortBlock(properties, TankPortKind.OUTPUT),
            machine(MapColor.COLOR_GRAY));

    // ------------------------------------------------------------------
    // 7 种模组流体的方块（用桶倒出来才看得到，物品栏里没有对应的方块物品）
    // ------------------------------------------------------------------

    /** 氢方块。 */
    public static final DeferredBlock<LiquidBlock> HYDROGEN_FLUID = BLOCKS.registerBlock("hydrogen_fluid",
            properties -> new LiquidBlock(ModFluids.HYDROGEN.source.get(), properties),
            fluidBlock(MapColor.COLOR_LIGHT_BLUE));

    /** 氧方块。 */
    public static final DeferredBlock<LiquidBlock> OXYGEN_FLUID = BLOCKS.registerBlock("oxygen_fluid",
            properties -> new LiquidBlock(ModFluids.OXYGEN.source.get(), properties),
            fluidBlock(MapColor.COLOR_LIGHT_BLUE));

    /** 氮方块。 */
    public static final DeferredBlock<LiquidBlock> NITROGEN_FLUID = BLOCKS.registerBlock("nitrogen_fluid",
            properties -> new LiquidBlock(ModFluids.NITROGEN.source.get(), properties),
            fluidBlock(MapColor.COLOR_LIGHT_BLUE));

    /** 氯气方块。 */
    public static final DeferredBlock<LiquidBlock> CHLORINE_FLUID = BLOCKS.registerBlock("chlorine_fluid",
            properties -> new LiquidBlock(ModFluids.CHLORINE.source.get(), properties),
            fluidBlock(MapColor.COLOR_LIGHT_GREEN));

    /** 钠方块。 */
    public static final DeferredBlock<LiquidBlock> SODIUM_FLUID = BLOCKS.registerBlock("sodium_fluid",
            properties -> new LiquidBlock(ModFluids.SODIUM.source.get(), properties),
            fluidBlock(MapColor.COLOR_ORANGE));

    /** 氨方块。 */
    public static final DeferredBlock<LiquidBlock> AMMONIA_FLUID = BLOCKS.registerBlock("ammonia_fluid",
            properties -> new LiquidBlock(ModFluids.AMMONIA.source.get(), properties),
            fluidBlock(MapColor.COLOR_CYAN));

    /** 硫酸方块。 */
    public static final DeferredBlock<LiquidBlock> SULFURIC_ACID_FLUID = BLOCKS.registerBlock("sulfuric_acid_fluid",
            properties -> new LiquidBlock(ModFluids.SULFURIC_ACID.source.get(), properties),
            fluidBlock(MapColor.COLOR_YELLOW));

    // ------------------------------------------------------------------
    // 阶段 1 的 9 种流体方块（同样只用于「用桶倒出来」和创造模式测试）
    // ------------------------------------------------------------------

    /** 铀酰溶液方块。 */
    public static final DeferredBlock<LiquidBlock> URANYL_SOLUTION_FLUID = BLOCKS.registerBlock(
            "uranyl_solution_fluid",
            properties -> new LiquidBlock(ModFluids.URANYL_SOLUTION.source.get(), properties),
            fluidBlock(MapColor.COLOR_LIGHT_GREEN));

    /** 硝酸铀酰方块。 */
    public static final DeferredBlock<LiquidBlock> URANYL_NITRATE_FLUID = BLOCKS.registerBlock(
            "uranyl_nitrate_fluid",
            properties -> new LiquidBlock(ModFluids.URANYL_NITRATE.source.get(), properties),
            fluidBlock(MapColor.COLOR_YELLOW));

    /** 氢氟酸方块。 */
    public static final DeferredBlock<LiquidBlock> HYDROFLUORIC_ACID_FLUID = BLOCKS.registerBlock(
            "hydrofluoric_acid_fluid",
            properties -> new LiquidBlock(ModFluids.HYDROFLUORIC_ACID.source.get(), properties),
            fluidBlock(MapColor.TERRACOTTA_WHITE));

    /** 氟气方块。 */
    public static final DeferredBlock<LiquidBlock> FLUORINE_FLUID = BLOCKS.registerBlock("fluorine_fluid",
            properties -> new LiquidBlock(ModFluids.FLUORINE.source.get(), properties),
            fluidBlock(MapColor.COLOR_LIGHT_GREEN));

    /** 硼酸方块。 */
    public static final DeferredBlock<LiquidBlock> BORIC_ACID_FLUID = BLOCKS.registerBlock("boric_acid_fluid",
            properties -> new LiquidBlock(ModFluids.BORIC_ACID.source.get(), properties),
            fluidBlock(MapColor.SNOW));

    /** 粘合剂方块。 */
    public static final DeferredBlock<LiquidBlock> ADHESIVE_FLUID = BLOCKS.registerBlock("adhesive_fluid",
            properties -> new LiquidBlock(ModFluids.ADHESIVE.source.get(), properties),
            fluidBlock(MapColor.COLOR_BROWN));

    /** 过氧化氢方块。 */
    public static final DeferredBlock<LiquidBlock> HYDROGEN_PEROXIDE_FLUID = BLOCKS.registerBlock(
            "hydrogen_peroxide_fluid",
            properties -> new LiquidBlock(ModFluids.HYDROGEN_PEROXIDE.source.get(), properties),
            fluidBlock(MapColor.COLOR_LIGHT_BLUE));

    /** 硝酸方块。 */
    public static final DeferredBlock<LiquidBlock> NITRIC_ACID_FLUID = BLOCKS.registerBlock("nitric_acid_fluid",
            properties -> new LiquidBlock(ModFluids.NITRIC_ACID.source.get(), properties),
            fluidBlock(MapColor.COLOR_YELLOW));

    /** 氮氧化物方块。 */
    public static final DeferredBlock<LiquidBlock> NITROGEN_OXIDE_FLUID = BLOCKS.registerBlock(
            "nitrogen_oxide_fluid",
            properties -> new LiquidBlock(ModFluids.NITROGEN_OXIDE.source.get(), properties),
            fluidBlock(MapColor.COLOR_BROWN));

    /** 废液方块。 */
    public static final DeferredBlock<LiquidBlock> WASTE_LIQUID_FLUID = BLOCKS.registerBlock(
            "waste_liquid_fluid",
            properties -> new LiquidBlock(ModFluids.WASTE_LIQUID.source.get(), properties),
            fluidBlock(MapColor.COLOR_BLACK));

    /** 六氟化铀方块。 */
    public static final DeferredBlock<LiquidBlock> URANIUM_HEXAFLUORIDE_FLUID = BLOCKS.registerBlock(
            "uranium_hexafluoride_fluid",
            properties -> new LiquidBlock(ModFluids.URANIUM_HEXAFLUORIDE.source.get(), properties),
            fluidBlock(MapColor.COLOR_YELLOW));

    /** 低浓缩六氟化铀方块（离心机甩出来的轻的那一半）。 */
    public static final DeferredBlock<LiquidBlock> LEU_URANIUM_HEXAFLUORIDE_FLUID = BLOCKS.registerBlock(
            "leu_uranium_hexafluoride_fluid",
            properties -> new LiquidBlock(ModFluids.LEU_URANIUM_HEXAFLUORIDE.source.get(), properties),
            fluidBlock(MapColor.COLOR_YELLOW));

    /** 贫化六氟化铀方块（离心机留下来的重的那一半）。 */
    public static final DeferredBlock<LiquidBlock> DEPLETED_URANIUM_HEXAFLUORIDE_FLUID = BLOCKS.registerBlock(
            "depleted_uranium_hexafluoride_fluid",
            properties -> new LiquidBlock(ModFluids.DEPLETED_URANIUM_HEXAFLUORIDE.source.get(), properties),
            fluidBlock(MapColor.COLOR_GRAY));

    /** 蒸汽方块（白色，一冒就散）。 */
    public static final DeferredBlock<LiquidBlock> STEAM_FLUID = BLOCKS.registerBlock("steam_fluid",
            properties -> new LiquidBlock(ModFluids.STEAM.source.get(), properties),
            fluidBlock(MapColor.SNOW));

    /** 乏蒸汽方块（淡灰色）。 */
    public static final DeferredBlock<LiquidBlock> EXHAUST_STEAM_FLUID = BLOCKS.registerBlock("exhaust_steam_fluid",
            properties -> new LiquidBlock(ModFluids.EXHAUST_STEAM.source.get(), properties),
            fluidBlock(MapColor.COLOR_LIGHT_GRAY));

    /** 重水方块（深蓝色）。 */
    public static final DeferredBlock<LiquidBlock> HEAVY_WATER_FLUID = BLOCKS.registerBlock("heavy_water_fluid",
            properties -> new LiquidBlock(ModFluids.HEAVY_WATER.source.get(), properties),
            fluidBlock(MapColor.COLOR_BLUE));

    /** 乏燃料溶解液方块（深绿色）。 */
    public static final DeferredBlock<LiquidBlock> DISSOLVED_FUEL_FLUID = BLOCKS.registerBlock(
            "dissolved_fuel_fluid",
            properties -> new LiquidBlock(ModFluids.DISSOLVED_FUEL.source.get(), properties),
            fluidBlock(MapColor.COLOR_GREEN));

    /** 铀钚萃取液方块（荧光绿）。 */
    public static final DeferredBlock<LiquidBlock> URANIUM_PLUTONIUM_EXTRACT_FLUID = BLOCKS.registerBlock(
            "uranium_plutonium_extract_fluid",
            properties -> new LiquidBlock(ModFluids.URANIUM_PLUTONIUM_EXTRACT.source.get(), properties),
            fluidBlock(MapColor.COLOR_LIGHT_GREEN));

    /** 裂变产物废液方块（深棕色）。 */
    public static final DeferredBlock<LiquidBlock> FISSION_PRODUCT_WASTE_FLUID = BLOCKS.registerBlock(
            "fission_product_waste_fluid",
            properties -> new LiquidBlock(ModFluids.FISSION_PRODUCT_WASTE.source.get(), properties),
            fluidBlock(MapColor.COLOR_BROWN));

    /** 有机相（TBP）方块（淡黄色）。 */
    public static final DeferredBlock<LiquidBlock> TBP_ORGANIC_PHASE_FLUID = BLOCKS.registerBlock(
            "tbp_organic_phase_fluid",
            properties -> new LiquidBlock(ModFluids.TBP_ORGANIC_PHASE.source.get(), properties),
            fluidBlock(MapColor.COLOR_YELLOW));

    /** 氘方块（淡蓝白）：电解水顺带分离出来的聚变燃料。 */
    public static final DeferredBlock<LiquidBlock> DEUTERIUM_FLUID = BLOCKS.registerBlock("deuterium_fluid",
            properties -> new LiquidBlock(ModFluids.DEUTERIUM.source.get(), properties),
            fluidBlock(MapColor.COLOR_LIGHT_BLUE));

    // ------------------------------------------------------------------
    // 核爆废土：两种脏水（爆炸范围内的水 / 岩浆会变成它们）
    // ------------------------------------------------------------------

    /**
     * 核废水方块：灰黑色、半透明，流动性和水一模一样。
     *
     * <p>爆炸范围内的水全都会变成它，所以炸完的河、湖是一片发暗的脏水；
     * 泡在里面会持续吃辐射（逻辑在 {@link WastewaterBlock} 里）。
     * 客户端把它登记成半透明渲染层，才看得见水底下的方块。
     */
    public static final DeferredBlock<LiquidBlock> NUCLEAR_WASTEWATER_FLUID = BLOCKS.registerBlock(
            "nuclear_wastewater_fluid",
            properties -> new WastewaterBlock(ModFluids.NUCLEAR_WASTEWATER.source.get(), properties),
            fluidBlock(MapColor.COLOR_GRAY));

    /**
     * 核熔废水方块：深绿色、很稠、发光，是「被掺脏的岩浆」。
     *
     * <p>流动距离和速度全按岩浆来（见 {@code ModFluids}），方块光给到 15，
     * 炸出来的坑底会有一片绿油油的光。泡进去会烧起来，同时吃辐射
     * （逻辑在 {@link MoltenWasteBlock} 里）。
     */
    public static final DeferredBlock<LiquidBlock> NUCLEAR_MOLTEN_WASTE_FLUID = BLOCKS.registerBlock(
            "nuclear_molten_waste_fluid",
            properties -> new MoltenWasteBlock(ModFluids.NUCLEAR_MOLTEN_WASTE.source.get(), properties),
            fluidBlock(MapColor.COLOR_GREEN).lightLevel(state -> 15));


    // ------------------------------------------------------------------
    // 阶段 3：中子物理与临界实验
    // ------------------------------------------------------------------

    /** 石墨块：9 个煤炭在工作台压成一块，是慢化剂块和中子反射层的原料。 */
    public static final DeferredBlock<Block> GRAPHITE_BLOCK =
            BLOCKS.registerBlock("graphite_block", Block::new, metalBlock(MapColor.COLOR_BLACK));

    /** 钢块：9 个钢锭压成一块，做反射层块要用。 */
    public static final DeferredBlock<Block> STEEL_BLOCK =
            BLOCKS.registerBlock("steel_block", Block::new, metalBlock(MapColor.METAL));

    /** 石墨慢化剂块：把快中子磨慢，让链式反应更容易维持。结构里至少要几十块。 */
    public static final DeferredBlock<Block> GRAPHITE_MODERATOR =
            BLOCKS.registerBlock("graphite_moderator", Block::new, metalBlock(MapColor.COLOR_BLACK));

    /** 铍反射层块：把漏出去的中子反射回堆芯。 */
    public static final DeferredBlock<Block> BERYLLIUM_REFLECTOR =
            BLOCKS.registerBlock("beryllium_reflector", Block::new, metalBlock(MapColor.COLOR_LIGHT_GREEN));

    /** 辐射屏蔽块：铅块加混凝土，专门挡辐射。 */
    public static final DeferredBlock<Block> RADIATION_SHIELD =
            BLOCKS.registerBlock("radiation_shield", Block::new, stoneBlock(MapColor.COLOR_GRAY));

    /** 中子探测器：放在结构里，把中子通量变成 0~15 的红石信号。 */
    public static final DeferredBlock<NeutronDetectorBlock> NEUTRON_DETECTOR = BLOCKS.registerBlock(
            "neutron_detector", NeutronDetectorBlock::new, machine(MapColor.COLOR_ORANGE));

    /** 临界报警器：k_eff > 1.0 的时候亮起来、响铃、往外发红石。 */
    public static final DeferredBlock<CriticalAlarmBlock> CRITICAL_ALARM = BLOCKS.registerBlock(
            "critical_alarm", CriticalAlarmBlock::new, machine(MapColor.COLOR_RED));

    /** 中子通量记录仪：右击看附近反应堆的 k_eff 和通量。 */
    public static final DeferredBlock<NeutronFluxRecorderBlock> NEUTRON_FLUX_RECORDER = BLOCKS.registerBlock(
            "neutron_flux_recorder", NeutronFluxRecorderBlock::new, machine(MapColor.COLOR_LIGHT_BLUE));

    /** 次临界增殖装置控制器：5×5×5 的控制器。 */
    public static final DeferredBlock<ReactorControllerBlock> SUBCRITICAL_CONTROLLER = BLOCKS.registerBlock(
            "subcritical_controller",
            properties -> new ReactorControllerBlock(properties, ReactorKind.SUBCRITICAL),
            machine(MapColor.COLOR_GRAY));

    /** 临界实验堆控制器：7×7×7 的控制器，k_eff 就是从这里调的。 */
    public static final DeferredBlock<ReactorControllerBlock> CRITICAL_REACTOR_CONTROLLER = BLOCKS.registerBlock(
            "critical_reactor_controller",
            properties -> new ReactorControllerBlock(properties, ReactorKind.CRITICAL),
            machine(MapColor.COLOR_GRAY));

    /** 通用储罐：32,000 mB，用流体识别码绑定流体，什么都能装（取代原来的硼酸储罐）。 */
    public static final DeferredBlock<UniversalTankBlock> UNIVERSAL_TANK = BLOCKS.registerBlock(
            "universal_tank", UniversalTankBlock::new, machine(MapColor.COLOR_LIGHT_GRAY));

    /**
     * 旧版硼酸储罐：已经从物品 / 配方 / 创造栏里删了，<b>只保留方块本体</b>给老存档兜底。
     *
     * <p>删掉一个注册过的方块会让老世界读区块时找不到它；保留这个「空壳」以后，
     * 老存档里摆着的硼酸储罐能正常加载（还能灌/舀硼酸），挖掉不掉东西。
     */
    public static final DeferredBlock<BoricAcidTankBlock> BORIC_ACID_TANK = BLOCKS.registerBlock(
            "boric_acid_tank", BoricAcidTankBlock::new, machine(MapColor.QUARTZ));

    /**
     * 堆芯残骸：临界实验堆熔毁后，控制器那一格被炸成的东西。
     *
     * <p>抗爆 1200，后面的爆炸再也炸不掉它；没有燃料槽、打不开界面，只能拆掉重造。
     */
    public static final DeferredBlock<CoreRemnantBlock> CORE_REMNANT =
            BLOCKS.registerBlock("core_remnant", CoreRemnantBlock::new, remnant());

    /**
     * 污染土：熔毁炸出来的脏土，踩上去一直吃辐射。
     *
     * <p>永久存在，不会自己变回泥土；挖掉掉的是普通泥土。
     */
    public static final DeferredBlock<ContaminatedSoilBlock> CONTAMINATED_SOIL =
            BLOCKS.registerBlock("contaminated_soil", ContaminatedSoilBlock::new, contaminatedSoil());

    /**
     * 烧结砂：沙漠 / 沙滩被核爆的高温烧熔、又冷下来结成的硬壳。
     *
     * <p>以前这里直接变成玻璃，方块是透光的，一炸完地上反光一大片很出戏；
     * 现在换成不透光的烧结质地下脚料，颜色是烧焦的灰紫，跟弹坑边的污染土接得上。
     */
    public static final DeferredBlock<Block> SCORCHED_SAND =
            BLOCKS.registerBlock("scorched_sand", Block::new, scorchedSand());

    /**
     * 焦木：被冲击波和火球烧成炭的树干。
     *
     * <p>爆炸半径里炸不到（弹坑边）的树，树叶被烤掉、树干整根留下变黑，
     * 远处看就是一片立着的焦黑树桩。带着原木的朝向，所以树不会歪。
     */
    public static final DeferredBlock<RotatedPillarBlock> CHARRED_LOG =
            BLOCKS.registerBlock("charred_log", RotatedPillarBlock::new, charredLog());

    /**
     * 焦土：核爆中心 100 格以内，不管原来是什么自然方块，炸完都变成这一种黑灰色的焦壳。
     *
     * <p>和「污染土」「烧结砂」的区别是：那两个还看得出原来的质地，焦土就是彻底烧透的
     * 一层黑壳，踩上去沙沙响。它只是难看，不会自己散辐射；真正脏的是旁边的辐射焦土。
     * 地壳还是烫的——脚踩上去就一直着火。
     */
    public static final DeferredBlock<ScorchedEarthBlock> SCORCHED_EARTH =
            BLOCKS.registerBlock("scorched_earth", p -> new ScorchedEarthBlock(p, 3), scorchedEarth());

    /**
     * 辐射焦土：焦土里掺了没烧干净的裂变产物那一部分，颜色更深、裂缝里透一点绿。
     *
     * <p>和焦土混着铺满爆心，踩上去不会额外吃辐射——它只是「看着更毒」，
     * 真正会沾染的是污染土和辐射尘。这一种温度更高：烧得更久，还每隔一秒补一点烧伤。
     */
    public static final DeferredBlock<ScorchedEarthBlock> RADIOACTIVE_SCORCHED_EARTH =
            BLOCKS.registerBlock("radioactive_scorched_earth", p -> new ScorchedEarthBlock(p, 5, 20),
                    scorchedEarth());

    /**
     * 辐射尘：爆炸下风向 130~180 格之间稀稀拉拉落下来的一层灰，薄得像雪。
     *
     * <p>贴地只有 2 像素高、可以踩上去，用手就能撸下来装进背包；
     * 踩在上面、揣在包里、或者拿在手上，隔一会儿就沾染一次辐射。
     */
    public static final DeferredBlock<RadioactiveDustBlock> RADIOACTIVE_DUST =
            BLOCKS.registerBlock("radioactive_dust", RadioactiveDustBlock::new, radioactiveDust());

    /**
     * 插在土里的熔毁燃料棒：核爆把燃料棒从堆芯里掀出来，一头扎进焦土。
     *
     * <p>没有方块物品（创造模式里拿不到），只能用镐或者手掰下来，
     * 掰下来得到的才是「熔毁的燃料棒」物品。十字模型、四个朝向随机，
     * 所以一片残桩看上去歪歪斜斜的。
     */
    public static final DeferredBlock<MeltedFuelRodStubBlock> MELTED_FUEL_ROD_STUB =
            BLOCKS.registerBlock("melted_fuel_rod_stub", MeltedFuelRodStubBlock::new, fuelRodStub());

    /**
     * 核熔的钻石矿：核爆把坑底、坑壁往下 24 格里的煤矿 / 钻石矿烧熔之后结成的东西。
     *
     * <p>挖下来掉的是<b>它自己</b>（不会掉原版钻石），以后要拿去加工才有用。
     * 自带一点冷青色的光，黑暗的坑底也能一眼看见。
     *
     * <p>方块里带一个「是不是核弹炸出来的」标记（{@link MoltenOreBlock#FROM_NUKE}），
     * 成就「轮回」只认核弹炸出来的那一种，熔毁废墟里的不算。
     */
    public static final DeferredBlock<MoltenOreBlock> NUCLEAR_MOLTEN_DIAMOND_ORE = BLOCKS.registerBlock(
            "nuclear_molten_diamond_ore", MoltenOreBlock::new, moltenOre(MapColor.COLOR_CYAN));

    /**
     * 核熔的绿宝石矿：同上，爆炸前是煤矿或者绿宝石矿，炸完就成这样了。
     *
     * <p>挖下来掉它自己（不会掉原版绿宝石）。
     */
    public static final DeferredBlock<MoltenOreBlock> NUCLEAR_MOLTEN_EMERALD_ORE = BLOCKS.registerBlock(
            "nuclear_molten_emerald_ore", MoltenOreBlock::new, moltenOre(MapColor.COLOR_GREEN));

    // ------------------------------------------------------------------
    // 阶段 4：研究堆与同位素
    // ------------------------------------------------------------------

    /** 装配机 T3：HV 级装配机，300 FE/t，做三级配方。 */
    public static final DeferredBlock<AssemblerT3Block> ASSEMBLER_T3 =
            BLOCKS.registerBlock("assembler_t3", AssemblerT3Block::new, machine(MapColor.COLOR_GRAY));

    /** 伽马辐照器：HV，100 FE/t，用钴60源照东西。 */
    public static final DeferredBlock<ItemMachineBlock> GAMMA_IRRADIATOR = BLOCKS.registerBlock(
            "gamma_irradiator",
            properties -> new ItemMachineBlock(properties, ItemMachineKind.GAMMA_IRRADIATOR),
            machine(MapColor.COLOR_YELLOW));

    /** 辐照靶冷却池：HV，60 FE/t，往池子里灌水泡靶。 */
    public static final DeferredBlock<FluidMachineBlock> IRRADIATION_POOL = BLOCKS.registerBlock(
            "irradiation_pool",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.IRRADIATION_POOL),
            machine(MapColor.COLOR_CYAN));

    /** 研究堆控制器：7×8×7 的多方块控制器。 */
    public static final DeferredBlock<ResearchReactorControllerBlock> RESEARCH_REACTOR_CONTROLLER =
            BLOCKS.registerBlock("research_reactor_controller", ResearchReactorControllerBlock::new,
                    machine(MapColor.COLOR_GRAY));

    /** 辐照孔道：研究堆里放靶的通道，结构里至少 4 条。 */
    public static final DeferredBlock<Block> IRRADIATION_CHANNEL =
            BLOCKS.registerBlock("irradiation_channel", Block::new, metalBlock(MapColor.COLOR_LIGHT_BLUE));

    /** 热室机械臂：带界面的热室机械臂，专门把冷却好的靶材拆成同位素。 */
    public static final DeferredBlock<HotCellArmBlock> HOT_CELL_ARM =
            BLOCKS.registerBlock("hot_cell_arm", HotCellArmBlock::new, machine(MapColor.COLOR_ORANGE));

    // ------------------------------------------------------------------
    // 阶段 5：压水堆与蒸汽发电
    // ------------------------------------------------------------------

    /** 反应堆压力壳：压水堆的外壳方块，7×7×8 的堆体主要靠它砌。 */
    public static final DeferredBlock<ReactorPartBlock> REACTOR_PRESSURE_VESSEL = BLOCKS.registerBlock(
            "reactor_pressure_vessel",
            properties -> new ReactorPartBlock(properties, "block.aftercritical.reactor_pressure_vessel.desc"),
            metalBlock(MapColor.COLOR_GRAY));

    /** 控制棒端口：插控制棒组件的地方，堆体里至少要 4 个。 */
    public static final DeferredBlock<ControlRodPortBlock> CONTROL_ROD_PORT = BLOCKS.registerBlock(
            "control_rod_port", ControlRodPortBlock::new, machine(MapColor.COLOR_LIGHT_BLUE));

    /** 燃料端口：放 LEU 燃料组件的地方，一个堆至少要 1 个、总共放 4~8 支。 */
    public static final DeferredBlock<FuelPortBlock> FUEL_PORT = BLOCKS.registerBlock(
            "fuel_port", FuelPortBlock::new, machine(MapColor.COLOR_ORANGE));

    /** 冷却剂端口：水从这进、蒸汽从这出，一个堆至少 2 个。 */
    public static final DeferredBlock<CoolantPortBlock> COOLANT_PORT = BLOCKS.registerBlock(
            "coolant_port", CoolantPortBlock::new, machine(MapColor.COLOR_CYAN));

    /** 压水堆控制器：7×7×8 多方块的心脏，右键开控制界面。 */
    public static final DeferredBlock<PwrControllerBlock> PWR_CONTROLLER = BLOCKS.registerBlock(
            "pwr_controller", PwrControllerBlock::new, machine(MapColor.COLOR_GRAY));

    /** 汽轮发电机：吃蒸汽出电，单台最大 2,000 FE/t。 */
    public static final DeferredBlock<SteamGeneratorBlock> STEAM_GENERATOR = BLOCKS.registerBlock(
            "steam_generator", SteamGeneratorBlock::new, machine(MapColor.COLOR_GRAY));

    /** 冷凝器：把乏蒸汽换回水，HV，32 FE/t。 */
    public static final DeferredBlock<FluidMachineBlock> CONDENSER = BLOCKS.registerBlock(
            "condenser",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.CONDENSER),
            machine(MapColor.COLOR_LIGHT_BLUE));

    /** 冷却塔：立在冷凝器旁边的混凝土大烟囱，纯结构方块（散热靠它撑着）。 */
    public static final DeferredBlock<ReactorPartBlock> COOLING_TOWER = BLOCKS.registerBlock(
            "cooling_tower",
            properties -> new ReactorPartBlock(properties, "block.aftercritical.cooling_tower.desc"),
            stoneBlock(MapColor.COLOR_GRAY));

    // ------------------------------------------------------------------
    // 阶段 6：乏燃料后处理线
    // ------------------------------------------------------------------

    /** 乏燃料冷却池：HV，80 FE/t，乏燃料组件泡水 10 分钟。 */
    public static final DeferredBlock<FluidMachineBlock> SPENT_FUEL_POOL = BLOCKS.registerBlock(
            "spent_fuel_pool",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.SPENT_FUEL_POOL),
            machine(MapColor.COLOR_CYAN));

    /** 剪切机：HV，200 FE/t，把冷却的乏燃料组件剪成碎块。 */
    public static final DeferredBlock<ItemMachineBlock> SHEARING_MACHINE = BLOCKS.registerBlock(
            "shearing_machine",
            properties -> new ItemMachineBlock(properties, ItemMachineKind.SHEARING_MACHINE),
            machine(MapColor.COLOR_GRAY));

    /** 溶解槽：HV，250 FE/t，乏燃料碎块 + 硝酸 → 溶解液。 */
    public static final DeferredBlock<FluidMachineBlock> DISSOLUTION_TANK = BLOCKS.registerBlock(
            "dissolution_tank",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.DISSOLUTION_TANK),
            machine(MapColor.COLOR_GREEN));

    /** 萃取柱：HV，300 FE/t，溶解液 + TBP → 铀钚萃取液 + 裂变产物废液。 */
    public static final DeferredBlock<FluidMachineBlock> EXTRACTION_COLUMN = BLOCKS.registerBlock(
            "extraction_column",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.EXTRACTION_COLUMN),
            machine(MapColor.COLOR_LIGHT_GREEN));

    /** 离心萃取器：HV，350 FE/t，把萃取液甩成钚239 和回收铀。 */
    public static final DeferredBlock<FluidMachineBlock> CENTRIFUGAL_EXTRACTOR = BLOCKS.registerBlock(
            "centrifugal_extractor",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.CENTRIFUGAL_EXTRACTOR),
            machine(MapColor.COLOR_GRAY));

    /** 玻璃固化炉：HV，300 FE/t，高放废液烧成固化玻璃。 */
    public static final DeferredBlock<FluidMachineBlock> VITRIFICATION_FURNACE = BLOCKS.registerBlock(
            "vitrification_furnace",
            properties -> new FluidMachineBlock(properties, FluidMachineKind.VITRIFICATION_FURNACE),
            machine(MapColor.COLOR_BROWN));

    // ------------------------------------------------------------------
    // 阶段 6：钠冷快堆
    // ------------------------------------------------------------------

    /** 钠冷快堆控制器：7×7×7 多方块的心脏，界面里放 MOX 燃料、看钠和功率。 */
    public static final DeferredBlock<FastReactorControllerBlock> FAST_REACTOR_CONTROLLER = BLOCKS.registerBlock(
            "fast_reactor_controller", FastReactorControllerBlock::new, machine(MapColor.COLOR_GRAY));

    /** 快中子探测器：快堆结构里至少要 2 个，数中子通量。 */
    public static final DeferredBlock<ReactorPartBlock> FAST_NEUTRON_DETECTOR = BLOCKS.registerBlock(
            "fast_neutron_detector",
            properties -> new ReactorPartBlock(properties, "block.aftercritical.fast_neutron_detector.desc"),
            machine(MapColor.COLOR_ORANGE));

    /** 钠-水蒸汽发生器：快堆的二回路，一个进钠出蒸汽、顺带发 3,000 FE/t 的电。 */
    public static final DeferredBlock<SodiumSteamGeneratorBlock> SODIUM_STEAM_GENERATOR = BLOCKS.registerBlock(
            "sodium_steam_generator", SodiumSteamGeneratorBlock::new, machine(MapColor.COLOR_LIGHT_BLUE));

    // ------------------------------------------------------------------
    // 阶段 7：聚变与嬗变
    // ------------------------------------------------------------------

    /** 聚变环外壳：托卡马克的「墙」，9×9×9 结构里至少 64 块。 */
    public static final DeferredBlock<ReactorPartBlock> FUSION_RING_CASING = BLOCKS.registerBlock(
            "fusion_ring_casing",
            properties -> new ReactorPartBlock(properties, "block.aftercritical.fusion_ring_casing.desc"),
            metalBlock(MapColor.COLOR_LIGHT_BLUE));

    /** 超导线圈：托卡马克的磁笼，至少 32 块；嬗变器里也要 8 块。 */
    public static final DeferredBlock<ReactorPartBlock> SUPERCONDUCTING_COIL = BLOCKS.registerBlock(
            "superconducting_coil",
            properties -> new ReactorPartBlock(properties, "block.aftercritical.superconducting_coil.desc"),
            metalBlock(MapColor.COLOR_ORANGE));

    /** 增殖包层模块：锂6 吃中子吐氚，至少 4 块。 */
    public static final DeferredBlock<ReactorPartBlock> BREEDING_BLANKET = BLOCKS.registerBlock(
            "breeding_blanket",
            properties -> new ReactorPartBlock(properties, "block.aftercritical.breeding_blanket.desc"),
            metalBlock(MapColor.COLOR_LIGHT_GREEN));

    /** 燃料注入端口：氘氚燃料单元从这里打进等离子体，至少 2 个。 */
    public static final DeferredBlock<ReactorPartBlock> FUEL_INJECTOR_PORT = BLOCKS.registerBlock(
            "fuel_injector_port",
            properties -> new ReactorPartBlock(properties, "block.aftercritical.fuel_injector_port.desc"),
            machine(MapColor.COLOR_ORANGE));

    /** 等离子体诊断器：看等离子体温度、密度，结构里要 1 个。 */
    public static final DeferredBlock<ReactorPartBlock> PLASMA_DIAGNOSTIC = BLOCKS.registerBlock(
            "plasma_diagnostic",
            properties -> new ReactorPartBlock(properties, "block.aftercritical.plasma_diagnostic.desc"),
            machine(MapColor.COLOR_CYAN));

    /** 低温冷却器：把超导线圈泡在低温里，结构里要 1 个。 */
    public static final DeferredBlock<ReactorPartBlock> CRYOGENIC_COOLER = BLOCKS.registerBlock(
            "cryogenic_cooler",
            properties -> new ReactorPartBlock(properties, "block.aftercritical.cryogenic_cooler.desc"),
            machine(MapColor.COLOR_LIGHT_BLUE));

    /** 聚变控制逻辑：磁场、加热、燃料注入的总调度，结构里要 1 个。 */
    public static final DeferredBlock<ReactorPartBlock> FUSION_CONTROL_LOGIC = BLOCKS.registerBlock(
            "fusion_control_logic",
            properties -> new ReactorPartBlock(properties, "block.aftercritical.fusion_control_logic.desc"),
            machine(MapColor.COLOR_PURPLE));

    /** 托卡马克控制器：9×9×9 多方块的心脏，右键开界面、按点火。 */
    public static final DeferredBlock<TokamakControllerBlock> TOKAMAK_CONTROLLER = BLOCKS.registerBlock(
            "tokamak_controller", TokamakControllerBlock::new, machine(MapColor.COLOR_LIGHT_BLUE));

    /** 嬗变器外壳：物质嬗变器的墙，7×7×7 结构里至少 48 块。 */
    public static final DeferredBlock<ReactorPartBlock> TRANSMUTATOR_CASING = BLOCKS.registerBlock(
            "transmutator_casing",
            properties -> new ReactorPartBlock(properties, "block.aftercritical.transmutator_casing.desc"),
            metalBlock(MapColor.COLOR_PURPLE));

    /** 能量端口：接收 256 格内托卡马克的无线供电，嬗变器结构里至少 1 个。 */
    public static final DeferredBlock<EnergyPortBlock> ENERGY_PORT = BLOCKS.registerBlock(
            "energy_port", EnergyPortBlock::new, machine(MapColor.COLOR_ORANGE));

    /** 物质嬗变器控制器：7×7×7 多方块的心脏，1,000,000 FE 换 1 个短寿命同位素。 */
    public static final DeferredBlock<TransmutatorControllerBlock> TRANSMUTATOR_CONTROLLER = BLOCKS.registerBlock(
            "transmutator_controller", TransmutatorControllerBlock::new, machine(MapColor.COLOR_PURPLE));

    /** 电池 MV：160,000 FE 的启动电源，8 块并联正好给托卡马克点火。 */
    public static final DeferredBlock<BatteryMvBlock> BATTERY_MV = BLOCKS.registerBlock(
            "battery_mv", BatteryMvBlock::new, machine(MapColor.COLOR_GRAY));

    /** 巨型储能库：单方块 1.2 亿 FE，充放 20,000 FE/t，专门吃掉一炉燃料棒发的电。 */
    public static final DeferredBlock<GiantBatteryBlock> GIANT_BATTERY = BLOCKS.registerBlock(
            "giant_battery", GiantBatteryBlock::new, machine(MapColor.COLOR_GRAY));

    /** 地质处置库：结局 A 的深埋点，塞进去的固化玻璃再也拿不出来，但绝对安全。 */
    public static final DeferredBlock<GeologicRepositoryBlock> GEOLOGIC_REPOSITORY = BLOCKS.registerBlock(
            "geologic_repository", GeologicRepositoryBlock::new, stoneBlock(MapColor.COLOR_GRAY));

    // ------------------------------------------------------------------
    // 武器：六颗核弹（模型不是方块，超出自己那一格，右键开装配界面）
    // ------------------------------------------------------------------

    /**
     * 核装置总装台：HV、400 FE/t，专门造核弹和它们的模块化组件。
     *
     * <p>四进一出：空弹体、高能炸药、核装料、还有一件结构件，一起进去，
     * 出来就是一颗能装的弹。组件（引信、透镜、惰层……）也在这台上做，
     * 免得为了一件小东西再开一条产线。
     */
    public static final DeferredBlock<ItemMachineBlock> WARHEAD_ASSEMBLER = BLOCKS.registerBlock(
            "warhead_assembler",
            properties -> new ItemMachineBlock(properties, ItemMachineKind.WARHEAD_ASSEMBLY),
            machine(MapColor.COLOR_GRAY));

    /** 小男孩：1.5 万吨，半径 140 格。 */
    public static final DeferredBlock<NukeBlock> NUKE_LITTLE_BOY = BLOCKS.registerBlock(
            "nuke_little_boy", NukeBlock::new, nuke());

    /** 胖子：2.1 万吨，半径 155 格。 */
    public static final DeferredBlock<NukeBlock> NUKE_FAT_MAN = BLOCKS.registerBlock(
            "nuke_fat_man", NukeBlock::new, nuke());

    /** 邱小姐（596）：2.2 万吨，半径 160 格。 */
    public static final DeferredBlock<NukeBlock> NUKE_QIU = BLOCKS.registerBlock(
            "nuke_qiu", NukeBlock::new, nuke());

    /** 639-23：330 万吨，半径 220 格、坑深 100 格。 */
    public static final DeferredBlock<NukeBlock> NUKE_639 = BLOCKS.registerBlock(
            "nuke_639", NukeBlock::new, nuke());

    /** 常青藤（Ivy Mike）：1040 万吨，半径 260 格。 */
    public static final DeferredBlock<NukeBlock> NUKE_IVY_MIKE = BLOCKS.registerBlock(
            "nuke_ivy_mike", NukeBlock::new, nuke());

    /** 沙皇氢弹：5000 万吨，半径 300 格、坑深 155 格。 */
    public static final DeferredBlock<NukeBlock> NUKE_TSAR = BLOCKS.registerBlock(
            "nuke_tsar", NukeBlock::new, nuke());

    private ModBlocks() {}

    /**
     * 核弹方块属性：硬度 3、抗爆 20，不收光（模型比一格大，会探到相邻格子里）。
     *
     * <p>抗爆给 20 是「别的爆炸炸不烂，只有自己起爆时由代码清掉」，
     * 免得旁边的反应堆熔毁顺手把这颗还没用的弹也点着了。
     */
    private static BlockBehaviour.Properties nuke() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.METAL)
                .strength(3.0F, 20.0F)
                .requiresCorrectToolForDrops()
                .noOcclusion()
                .sound(SoundType.METAL);
    }

    /**
     * 流体方块通用属性。
     *
     * <p>和原版水一模一样的一串：能穿过去、能被更液体的东西替换、
     * 不掉落物品（{@code noLootTable} 就是「没有掉落表」）、不带碰撞箱。
     */
    private static BlockBehaviour.Properties fluidBlock(MapColor color) {
        return BlockBehaviour.Properties.of()
                .mapColor(color)
                .replaceable()
                .noCollission()
                .strength(100.0F)
                .pushReaction(PushReaction.DESTROY)
                .noLootTable()
                .liquid()
                .sound(SoundType.EMPTY);
    }

    /** 金属块（铅块这种）通用属性：硬度 5、抗爆 6，必须用镐挖。 */
    private static BlockBehaviour.Properties metalBlock(MapColor color) {
        return BlockBehaviour.Properties.of()
                .mapColor(color)
                .strength(5.0F, 6.0F)
                .requiresCorrectToolForDrops()
                .sound(SoundType.METAL);
    }

    /** 机器通用属性：硬度 4、抗爆 6，金属质感，必须用镐挖。 */
    private static BlockBehaviour.Properties machine(MapColor color) {
        return BlockBehaviour.Properties.of()
                .mapColor(color)
                .strength(4.0F, 6.0F)
                .requiresCorrectToolForDrops()
                .sound(SoundType.METAL);
    }

    /**
     * 堆芯残骸的通用属性：硬度 12、抗爆 1200（黑曜石一个量级，后续爆炸炸不烂），
     * 自带一点暗红的光，像炉渣里还闷着火。硬度 12 是为了让玩家拿铁镐挖三四秒就能拆掉重造，
     * 跟黑曜石一样要挖十秒就太折磨了。
     */
    private static BlockBehaviour.Properties remnant() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_GRAY)
                .strength(12.0F, 1200.0F)
                .requiresCorrectToolForDrops()
                .lightLevel(state -> 3)
                .sound(SoundType.STONE);
    }

    /** 污染土：跟泥土差不多软（硬度 2.5），空手也能挖，挖掉掉普通泥土。 */
    private static BlockBehaviour.Properties contaminatedSoil() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_GRAY)
                .strength(2.5F, 3.0F)
                .sound(SoundType.GRAVEL);
    }

    /** 烧结砂：比沙子硬一点（硬度 1.2），空手也能挖碎，掉自己。 */
    private static BlockBehaviour.Properties scorchedSand() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_GRAY)
                .strength(1.2F, 3.0F)
                .sound(SoundType.SAND);
    }

    /** 焦木：烧脆的木头（硬度 1.0），空手就能拆下来当柴烧。 */
    private static BlockBehaviour.Properties charredLog() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_BLACK)
                .strength(1.0F, 2.0F)
                .sound(SoundType.WOOD);
    }

    /** 焦土 / 辐射焦土：一层烧透的黑壳，比泥土硬一点点，铲子挖得最快，掉自己。 */
    private static BlockBehaviour.Properties scorchedEarth() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_BLACK)
                .strength(1.6F, 3.0F)
                .sound(SoundType.GRAVEL);
    }

    /** 辐射尘：跟雪一样软（硬度 0.3），薄薄一层、不收光、空手一撸就掉。 */
    private static BlockBehaviour.Properties radioactiveDust() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_GRAY)
                .strength(0.3F, 1.0F)
                .noOcclusion()
                .sound(SoundType.SAND);
    }

    /**
     * 熔毁燃料棒残桩：插在地上的一截棒子，没有碰撞体积，手一掰就下来。
     *
     * <p>给一点光（2 级）是为了在焦黑的坑底也能一眼看见它还在发烫。
     */
    private static BlockBehaviour.Properties fuelRodStub() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_BLACK)
                .strength(0.5F, 1.0F)
                .noCollission()
                .noOcclusion()
                .lightLevel(state -> 2)
                .sound(SoundType.GRAVEL);
    }

    /** 线缆通用属性：很脆、不收光、空手就能拆下来。 */
    private static BlockBehaviour.Properties cable() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_ORANGE)
                .strength(0.6F, 3.0F)
                .noOcclusion()
                .sound(SoundType.METAL);
    }

    /** 管道通用属性：细、不收光、空手就能拆下来（和线缆一个手感）。 */
    private static BlockBehaviour.Properties pipe(MapColor color) {
        return BlockBehaviour.Properties.of()
                .mapColor(color)
                .strength(0.8F, 3.0F)
                .noOcclusion()
                .sound(SoundType.METAL);
    }

    /** 石头质感的方块（辐射屏蔽块）：硬度 5、抗爆 6。 */
    private static BlockBehaviour.Properties stoneBlock(MapColor color) {
        return BlockBehaviour.Properties.of()
                .mapColor(color)
                .strength(5.0F, 6.0F)
                .requiresCorrectToolForDrops()
                .sound(SoundType.STONE);
    }

    /**
     * 核熔矿石的属性：硬度跟普通矿石差不多（3.5），必须用镐挖，挖下来掉自己。
     *
     * <p>给 6 级自发光：矿是「烧熔之后还没凉透」的状态，黑坑里能看见一点点光，
     * 找矿的时候不用拿着火把一格一格摸。
     */
    private static BlockBehaviour.Properties moltenOre(MapColor color) {
        return BlockBehaviour.Properties.of()
                .mapColor(color)
                .strength(3.5F, 3.0F)
                .requiresCorrectToolForDrops()
                .lightLevel(state -> 6)
                .sound(SoundType.STONE);
    }

    /** 矿石通用属性：硬度 3、抗爆 3，必须用正确工具才掉落。 */
    private static BlockBehaviour.Properties ore(MapColor color) {
        return BlockBehaviour.Properties.of()
                .mapColor(color)
                .strength(3.0F, 3.0F)
                .requiresCorrectToolForDrops()
                .sound(SoundType.STONE);
    }
}
