package cn.blockforge.generated.aftercritical.compat.jei;

import cn.blockforge.generated.aftercritical.recipe.AssemblerIngredient;
import cn.blockforge.generated.aftercritical.recipe.MachineRecipe;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.builder.ITooltipBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.widgets.IRecipeExtrasBuilder;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.ItemLike;

import java.util.List;

/**
 * 矿机类机器在 JEI 里的样子：破碎机、球磨机、锻压机、压块机共用这一个类别。
 *
 * <p>一条配方显示成「原料 → 产物」，下面写着要多久、吃多少电；锻压机多一个模具槽。
 *
 * <p>原料数量不固定：老机器只有一种（矿石 → 粉），压块机有两种（4 煤 + 1 粘土球）。
 * 原料按每行 3 个自动排，多出来的换行，所以以后新机器想吃几种就吃几种，这里不用改。
 */
public class MachineRecipeCategory implements IRecipeCategory<MachineRecipe> {

    /** 原料每行最多摆几个。 */
    private static final int MAX_COLUMNS = 3;
    private static final int STEP = 18;
    private static final int INPUT_X = 6;
    private static final int INPUT_Y = 8;

    private static final int HEIGHT = 62;

    private final RecipeType<MachineRecipe> recipeType;
    private final Component title;
    private final IDrawable icon;
    private final int energyPerTick;
    private final boolean showsMold;

    /** 箭头和产物槽的横向位置：跟在原料方阵后面。 */
    private final int arrowX = INPUT_X + MAX_COLUMNS * STEP + 6;
    private final int outputX = this.arrowX + 30;
    /** 副产物槽（磨削机的废粉）；没有副产物的配方这里就空着。 */
    private final int byproductX = this.outputX + 20;
    private final int moldX = this.byproductX + 24;
    private final int width;

    public MachineRecipeCategory(IGuiHelper guiHelper, RecipeType<MachineRecipe> recipeType, Component title,
                                 ItemLike machine, int energyPerTick, boolean showsMold) {
        this.recipeType = recipeType;
        this.title = title;
        this.icon = guiHelper.createDrawableItemLike(machine);
        this.energyPerTick = energyPerTick;
        this.showsMold = showsMold;
        this.width = showsMold ? this.moldX + 22 : this.byproductX + 20;
    }

    @Override
    public RecipeType<MachineRecipe> getRecipeType() {
        return this.recipeType;
    }

    @Override
    public Component getTitle() {
        return this.title;
    }

    @Override
    public IDrawable getIcon() {
        return this.icon;
    }

    @Override
    public int getWidth() {
        return this.width;
    }

    @Override
    public int getHeight() {
        return HEIGHT;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, MachineRecipe recipe, IFocusGroup focuses) {
        List<AssemblerIngredient> ingredients = recipe.ingredients();
        for (int index = 0; index < ingredients.size(); index++) {
            AssemblerIngredient spec = ingredients.get(index);
            int x = INPUT_X + (index % MAX_COLUMNS) * STEP;
            int y = INPUT_Y + (index / MAX_COLUMNS) * STEP;
            builder.addSlot(RecipeIngredientRole.INPUT, x, y)
                    .setStandardSlotBackground()
                    .addIngredients(spec.ingredient())
                    .addRichTooltipCallback((slot, tooltip) -> addCountTooltip(tooltip, spec.count()));
        }

        builder.addSlot(RecipeIngredientRole.OUTPUT, this.outputX, INPUT_Y)
                .setOutputSlotBackground()
                .addItemStack(recipe.result());

        // 副产物（磨削机磨芯块掉的废粉）：摆在主产物右边
        if (!recipe.byproduct().isEmpty()) {
            builder.addSlot(RecipeIngredientRole.OUTPUT, this.byproductX, INPUT_Y)
                    .setOutputSlotBackground()
                    .addItemStack(recipe.byproduct())
                    .addRichTooltipCallback((slot, tooltip) ->
                            tooltip.add(Component.translatable("jei.aftercritical.byproduct")));
        }

        if (this.showsMold) {
            recipe.mold().ifPresent(mold -> builder.addSlot(RecipeIngredientRole.INPUT, this.moldX, INPUT_Y)
                    .setStandardSlotBackground()
                    .addIngredients(mold));
        }
    }

    @Override
    public void createRecipeExtras(IRecipeExtrasBuilder builder, MachineRecipe recipe, IFocusGroup focuses) {
        builder.addRecipeArrow().setPosition(this.arrowX, INPUT_Y + 1);
        builder.addText(Component.translatable("jei.aftercritical.recipe_info",
                String.format("%.1f", recipe.duration() / 20.0F), this.energyPerTick), INPUT_X, HEIGHT - 14);
        if (this.showsMold) {
            builder.addText(Component.translatable("jei.aftercritical.needs_mold"), this.outputX, 30);
        }
    }

    /** 输入槽上补一句「要几个」，因为 JEI 的槽本身只显示物品、不显示数量。 */
    private static void addCountTooltip(ITooltipBuilder tooltip, int count) {
        if (count > 1) {
            tooltip.add(Component.translatable("jei.aftercritical.count", count));
        }
    }
}
