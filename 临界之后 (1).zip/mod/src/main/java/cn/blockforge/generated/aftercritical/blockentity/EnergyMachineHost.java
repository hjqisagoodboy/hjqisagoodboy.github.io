package cn.blockforge.generated.aftercritical.blockentity;

import net.minecraft.world.Container;

/**
 * 所有「界面里要显示电量和状态」的机器共用的接口。
 *
 * <p>GUI 只认这个接口，不关心背后是破碎机、发电机还是电池：
 * 它每 tick 从方块实体读这几个数字，打包同步给客户端画能量条和状态文字。
 */
public interface EnergyMachineHost extends Container {

    /** 待机：没有可干的活。 */
    int STATUS_IDLE = 0;
    /** 运行中：正在加工 / 正在发电。 */
    int STATUS_RUNNING = 1;
    /** 能量不足。 */
    int STATUS_NO_ENERGY = 2;
    /** 输出已满（产物放不下 / 电送不出去）。 */
    int STATUS_OUTPUT_BLOCKED = 3;
    /** 缺模具。 */
    int STATUS_NO_MOLD = 4;
    /** 电力已满：内部缓存装不下了。 */
    int STATUS_FULL = 5;
    /** 充电中（电池）。 */
    int STATUS_CHARGING = 6;
    /** 放电中（电池）。 */
    int STATUS_DISCHARGING = 7;
    /** 缺流体：配方认出来了，但进液罐里没有该有的液体。 */
    int STATUS_NO_FLUID = 8;
    /** 弃电保汽：电力已满，但仍在吃蒸汽（电直接丢掉）。 */
    int STATUS_DUMPING = 9;

    int getEnergyStored();

    int getEnergyCapacity();

    int getStatus();

    /** 进度：加工 tick 或已烧 tick。 */
    int getProgress();

    /** 进度上限：一条配方的总 tick 或一份燃料的总 tick；0 表示当前没有。 */
    int getMaxProgress();
}
