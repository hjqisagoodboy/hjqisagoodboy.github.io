package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.energy.BufferedEnergyStorage;
import cn.blockforge.generated.aftercritical.energy.EnergyTransfer;
import cn.blockforge.generated.aftercritical.menu.SteamGeneratorMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

import javax.annotation.Nullable;

/**
 * 汽轮发电机的方块实体：蒸汽进、乏蒸汽出、电从旁边送走。
 *
 * <p>数值按定稿 v4：单台最大 <b>2,000 FE/t</b>，正好吃 <b>1,000 mB/s（50 mB/t）</b>蒸汽。
 * 折算下来 1 mB 蒸汽发 40 FE，所以汽轮机和冷凝器的处理量天然对得上。
 *
 * <p>内部有 100,000 FE 的缓存。缓存满了有两种做法：默认「弃电保汽」（见下），
 * 或者关掉它、暂停吃蒸汽等电送走。
 *
 * <p><b>弃电保汽</b>（默认开）：缓存满了以后，「电送不出去」不该拖着整条水循环一起停。
 * 打开这个开关，汽轮机会继续吃蒸汽、继续产乏蒸汽，只是多出来的电直接丢掉——
 * 看上去浪费，但冷凝器有水可换、压水堆的蒸汽罐不会堵、温度就不会一路飙到熔毁。
 * 关掉它就回到老行为：缓存一满就停下等电送走。界面右下角有按钮可以随时切。
 */
public class SteamGeneratorBlockEntity extends BlockEntity
        implements EnergyMachineHost, TickableBlockEntity, net.minecraft.world.MenuProvider {

    /** 单台最大输出 2,000 FE/t。 */
    public static final int OUTPUT_PER_TICK = 2_000;
    /** 每秒吃 1,000 mB 蒸汽 = 每 tick 50 mB。 */
    public static final int STEAM_PER_TICK = 50;
    /** 1 mB 蒸汽发多少 FE。 */
    public static final int FE_PER_MB = OUTPUT_PER_TICK / STEAM_PER_TICK;
    /** 两个罐子各装 8,000 mB。 */
    public static final int TANK_CAPACITY = 8_000;

    private static final int ENERGY_CAPACITY = 100_000;

    private final BufferedEnergyStorage energy =
            new BufferedEnergyStorage(ENERGY_CAPACITY, 0, OUTPUT_PER_TICK, this::setChanged);
    private final FluidTank steamTank = new FluidTank(TANK_CAPACITY);
    private final FluidTank exhaustTank = new FluidTank(TANK_CAPACITY);

    private int status = STATUS_IDLE;
    private int lastSteamPerTick;
    /** 上一 tick 弃掉了多少 FE（电力满、蒸汽照走时才有）。 */
    private int lastWasted;

    /** 弃电保汽：电力满了以后继续吃蒸汽、把电丢掉。默认开。 */
    private boolean dumpPower = true;

    /** 成就「并网发电」只记一次。 */
    private boolean powerMilestoneFired;

    private final IFluidHandler fluidHandler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return 2;
        }

        @Override
        public FluidStack getFluidInTank(int tank) {
            return tank == 0 ? steamTank.getFluid() : tank == 1 ? exhaustTank.getFluid() : FluidStack.EMPTY;
        }

        @Override
        public int getTankCapacity(int tank) {
            return TANK_CAPACITY;
        }

        @Override
        public boolean isFluidValid(int tank, FluidStack stack) {
            return tank == 0;
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            if (resource.isEmpty() || !resource.getFluid().isSame(ModFluids.STEAM.source.get())) {
                return 0;
            }
            int filled = steamTank.fill(resource, action);
            if (filled > 0) {
                setChanged();
            }
            return filled;
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            FluidStack drained = exhaustTank.drain(resource, action);
            if (!drained.isEmpty()) {
                setChanged();
            }
            return drained;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            FluidStack drained = exhaustTank.drain(maxDrain, action);
            if (!drained.isEmpty()) {
                setChanged();
            }
            return drained;
        }
    };

    public SteamGeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.STEAM_GENERATOR.get(), pos, state);
    }

    public IEnergyStorage getEnergyStorage() {
        return this.energy;
    }

    public IFluidHandler getFluidHandler() {
        return this.fluidHandler;
    }

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        int exhaustSpace = this.exhaustTank.getCapacity() - this.exhaustTank.getFluidAmount();
        int steam = Math.min(STEAM_PER_TICK, this.steamTank.getFluidAmount());
        int convert = Math.min(steam, exhaustSpace);
        int fe = convert * FE_PER_MB;

        // 电缓存装不下这一 tick 发的电
        boolean full = this.energy.getFreeSpace() < fe && convert > 0;
        if (convert > 0 && (!full || this.dumpPower)) {
            this.steamTank.drain(convert, IFluidHandler.FluidAction.EXECUTE);
            this.exhaustTank.fill(new FluidStack(ModFluids.EXHAUST_STEAM.source.get(), convert),
                    IFluidHandler.FluidAction.EXECUTE);
            // grow 只收得下装得下的部分，剩下的就是弃掉的电
            int stored = this.energy.grow(fe);
            this.lastWasted = Math.max(0, fe - stored);
            this.lastSteamPerTick = convert;
            // 弃电保汽时状态写「弃电保汽」，玩家一眼知道蒸汽还在走、只是电被丢了
            this.status = full ? STATUS_DUMPING : STATUS_RUNNING;
            if (!this.powerMilestoneFired) {
                this.powerMilestoneFired = true;
                ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 48.0,
                        ModAdvancementTriggers.PWR_POWER);
            }
            setChanged();
        } else {
            this.lastSteamPerTick = 0;
            this.lastWasted = 0;
            if (full) {
                this.status = STATUS_FULL;
            } else if (this.steamTank.getFluidAmount() < STEAM_PER_TICK) {
                this.status = this.steamTank.isEmpty() ? STATUS_IDLE : STATUS_NO_FLUID;
            } else {
                // 蒸汽够，但乏蒸汽排不出去（冷凝器没接上）
                this.status = STATUS_OUTPUT_BLOCKED;
            }
        }
        EnergyTransfer.push(this.level, this.worldPosition, this.energy, OUTPUT_PER_TICK);
    }

    // ------------------------------------------------------------------
    // GUI 数据
    // ------------------------------------------------------------------

    public int steamAmount() {
        return this.steamTank.getFluidAmount();
    }

    public int exhaustAmount() {
        return this.exhaustTank.getFluidAmount();
    }

    public int tankCapacity() {
        return TANK_CAPACITY;
    }

    /** 上一 tick 实际吃了多少 mB 蒸汽。 */
    public int steamPerTick() {
        return this.lastSteamPerTick;
    }

    public int outputFePerTick() {
        return this.lastSteamPerTick * FE_PER_MB;
    }

    /** 上一 tick 弃掉了多少 FE（只在「弃电保汽」且缓存装满时才大于 0）。 */
    public int wastedFePerTick() {
        return this.lastWasted;
    }

    /** 弃电保汽开关：电力满了以后，是继续吃蒸汽（丢电）还是停下来等电送走。 */
    public boolean isDumpPower() {
        return this.dumpPower;
    }

    public void setDumpPower(boolean dumpPower) {
        if (this.dumpPower != dumpPower) {
            this.dumpPower = dumpPower;
            setChanged();
        }
    }

    @Override
    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    @Override
    public int getEnergyCapacity() {
        return this.energy.getMaxEnergyStored();
    }

    @Override
    public int getStatus() {
        return this.status;
    }

    @Override
    public int getProgress() {
        return this.lastSteamPerTick;
    }

    @Override
    public int getMaxProgress() {
        return 0;
    }

    // ------------------------------------------------------------------
    // 没有物品槽的容器（菜单接口要用）
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return 0;
    }

    @Override
    public boolean isEmpty() {
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        return ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        // 没有物品槽
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        // 没有物品槽
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.steam_generator");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new SteamGeneratorMenu(containerId, playerInventory, this);
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
        tag.putBoolean("DumpPower", this.dumpPower);
        tag.put("Steam", this.steamTank.writeToNBT(registries, new CompoundTag()));
        tag.put("Exhaust", this.exhaustTank.writeToNBT(registries, new CompoundTag()));
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
        // 老存档没有这个字段：按默认「开」处理，正好也帮玩家挡住熔毁
        this.dumpPower = !tag.contains("DumpPower") || tag.getBoolean("DumpPower");
        this.steamTank.readFromNBT(registries, tag.getCompound("Steam"));
        this.exhaustTank.readFromNBT(registries, tag.getCompound("Exhaust"));
    }
}
