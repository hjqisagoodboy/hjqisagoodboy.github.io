package cn.blockforge.generated.aftercritical.item;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * 辐射防护服的一件：就是普通护甲，只是多写两行说明。
 *
 * <p>「每件少 25%」这个数字写在装备说明里，玩家不用翻 JEI 就知道穿几件有用；
 * 第二行讲穿齐四件的效果——因为第四件才是质变（完全不沾染辐射）。
 * 真正的判定不在这个类里，而是 {@code RadiationProtection} 按护甲材质统一算的。
 */
public class RadiationSuitItem extends ArmorItem {

    public RadiationSuitItem(Holder<ArmorMaterial> material, ArmorItem.Type type, Item.Properties properties) {
        super(material, type, properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.radiation_suit")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.radiation_suit.full")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
