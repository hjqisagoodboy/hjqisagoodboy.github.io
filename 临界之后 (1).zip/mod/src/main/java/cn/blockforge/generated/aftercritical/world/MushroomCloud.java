package cn.blockforge.generated.aftercritical.world;

import cn.blockforge.generated.aftercritical.network.MushroomCloudPayload;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 核爆蘑菇云的「档期」：什么时候、在哪、多大、活多久。
 *
 * <h2>这一版换了什么</h2>
 * 以前云是几千颗大烟粒子拼出来的（服务器每 tick 算位置、一颗颗发给玩家）。
 * 现在换成用户自己做的模型：一朵云由客户端画一整个带骨骼动画的网格，
 * 服务器只负责在起爆时告诉附近玩家「这里有一朵云，多大，活多久」，
 * 之后每秒补发一次进度，让后走进视野的玩家也能接上同一朵云。
 *
 * <h2>大小怎么换算</h2>
 * 模型在 Blockbench 里伞盖宽 {@value #MODEL_CAP_DIAMETER} 格。游戏里让伞盖直径等于
 * 「爆炸半径 × 1.75」（跟以前粒子云的包络、也和之前给用户的尺寸表对得上），
 * 所以 {@code scale = 半径 × 1.75 ÷ 74.59}。只改外观，伤害、爆炸半径、辐射都不受影响。
 *
 * <h2>云脚踩在哪</h2>
 * 起爆那一刻地面还没塌，直接取高度图的话云会站在「原来的地面」上，等坑挖下去
 * 就变成悬在坑口的一朵云。所以这里减去坑深，把云脚放到坑底——尘裙正好铺在坑底，
 * 柱身从坑底往上拔。
 */
public final class MushroomCloud {

    /** 反应堆熔毁那一朵固定 30 秒（600 tick）。 */
    public static final int MELTDOWN_DURATION = 600;
    /** 基础时长（tick）。 */
    private static final int DURATION_BASE = 600;
    /** 每格爆炸半径再加多少 tick（半径 140 → 1440 tick = 72 秒）。 */
    private static final int DURATION_PER_RADIUS = 6;

    /** 最远发给多远的玩家（格）：云有几百格高，远处也看得见，所以比老版放宽。 */
    private static final double VIEW_RADIUS = 1024.0;

    /** 模型（没放大时）伞盖有多少格宽，尺寸表就是按它算的。 */
    private static final float MODEL_CAP_DIAMETER = 74.59F;
    /** 游戏里伞盖直径 = 爆炸半径 × 这个数。 */
    private static final float CAP_DIAMETER_PER_BLAST_RADIUS = 1.75F;

    /** 每多少 tick 补发一次进度（给后进来的玩家）。 */
    private static final int RESYNC_TICKS = 20;

    /** 云编号：客户端靠它区分「同一朵云的两次补发」和「两朵不同的云」。 */
    private static final AtomicInteger NEXT_ID = new AtomicInteger(1);

    private static final List<Task> TASKS = new ArrayList<>();

    private MushroomCloud() {}

    /** 这一炮的云该活多少 tick（600 + 半径 × 6）。 */
    public static int durationFor(int blastRadius) {
        return DURATION_BASE + blastRadius * DURATION_PER_RADIUS;
    }

    /** 起一朵云（跟挖掘进度无关，自己走自己的）。坑深按默认 35% 算。 */
    public static void start(ServerLevel level, BlockPos core, int blastRadius) {
        start(level, core, blastRadius, (int) Math.round(blastRadius * 0.35));
    }

    /** 起一朵云（指定坑深），时长按当量算。 */
    public static void start(ServerLevel level, BlockPos core, int blastRadius, int craterDepth) {
        start(level, core, blastRadius, craterDepth, durationFor(blastRadius));
    }

    /**
     * 起一朵云（坑深和时长都指定）。
     *
     * <p>坑深决定云脚踩多低：起爆时坑还没挖，所以按「原地面 − 坑深」把云脚直接放到
     * 坑底，等地面塌完正好对齐，不会悬在坑口（反应堆熔毁走同一条路，只是时长固定 30 秒）。
     */
    public static void start(ServerLevel level, BlockPos core, int blastRadius, int craterDepth,
                             int durationTicks) {
        Task task = new Task(level, core.immutable(), blastRadius, Math.max(1, craterDepth),
                Math.max(200, durationTicks));
        TASKS.add(task);
        task.broadcast(0);
    }

    /** 服务端每 tick 推进一次（由 {@code NuclearBlast} 统一调）。 */
    public static void tick(MinecraftServer server) {
        if (TASKS.isEmpty()) {
            return;
        }
        Iterator<Task> iterator = TASKS.iterator();
        while (iterator.hasNext()) {
            Task task = iterator.next();
            if (task.level.getServer() != server) {
                continue;
            }
            if (task.tick()) {
                iterator.remove();
            }
        }
    }

    private static final class Task {
        private final int id;
        private final ServerLevel level;
        /** 爆心的 x / z（方块中心）。 */
        private final double x;
        private final double z;
        /** 模型脚底踩的高度：坑底（原地面减去坑深），尘裙正好铺在坑底上。 */
        private final double baseY;
        /** 模型放大倍数。 */
        private final float scale;
        /** 这朵云活多少 tick。 */
        private final int duration;
        private int age;

        private Task(ServerLevel level, BlockPos core, int blastRadius, int craterDepth, int duration) {
            this.id = NEXT_ID.getAndIncrement();
            this.level = level;
            this.x = core.getX() + 0.5;
            this.z = core.getZ() + 0.5;
            // 坑是从爆心往下挖的（{@code floorY = 爆心 y − 挖深}），所以云脚也按同一个基准落：
            // 起爆这一 tick 地面还没塌，只能照「爆心 − 坑深」估算坑底，等地面塌完正好对齐。
            // 夹一下建筑高度下限，别让大当量把云脚怼到基岩底下去。
            this.baseY = Math.max(level.getMinBuildHeight() + 3, core.getY() - craterDepth);
            this.scale = blastRadius * CAP_DIAMETER_PER_BLAST_RADIUS / MODEL_CAP_DIAMETER;
            this.duration = duration;
        }

        private boolean tick() {
            this.age++;
            if (this.age > this.duration) {
                return true;
            }
            if (this.age % RESYNC_TICKS == 0) {
                this.broadcast(this.age);
            }
            return this.age >= this.duration;
        }

        /** 发给附近所有玩家：一朵云一条包，客户端自己按年龄画动画。 */
        private void broadcast(int currentAge) {
            MushroomCloudPayload payload = new MushroomCloudPayload(
                    this.id, this.x, this.baseY, this.z, this.scale, this.duration, currentAge);
            PacketDistributor.sendToPlayersNear(this.level, null, this.x, this.baseY, this.z,
                    VIEW_RADIUS, payload);
        }
    }
}
