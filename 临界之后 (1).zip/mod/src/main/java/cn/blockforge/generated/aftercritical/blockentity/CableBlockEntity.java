package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.block.CableBlock;
import cn.blockforge.generated.aftercritical.block.CableTier;
import cn.blockforge.generated.aftercritical.energy.CableNetwork;
import cn.blockforge.generated.aftercritical.energy.RatedEnergyConsumer;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;

import javax.annotation.Nullable;

/**
 * 线缆的方块实体：一个缓存 + 每 tick 交给整张网统一结算。
 *
 * <p>单根线缆不再自己「推来推去」，而是把整张连通的线缆网当成一个电池池：
 * 见 {@link cn.blockforge.generated.aftercritical.energy.CableNetwork}。
 * 每 tick 由这张网里第一根轮到的线缆算一遍（抽电、送机器、按容量分回每根线缆），
 * 同一张网的其它线缆这一 tick 直接跳过。
 *
 * <p><b>为什么这么改：</b>以前的「谁愿意收就推给谁 + 记住从哪面收的」在直线上一格一格接力没问题，
 * 但线缆一旦接成<b>闭环</b>，每根线缆前面永远有下一根，电就在圈里无限转圈——
 * 玩家看到的就是「闭环之后接上去的线缆通电量一直乱跳」。
 * 整网结算之后，闭环只是「同一批线缆多接了一条边」，池子里的电不会再兜圈子。
 *
 * <p>过载：机器从线缆里抽电时，如果这台机器的额定功率比线缆上限还大
 * （比如 120 FE/t 的空气分离器接在 80 FE/t 的 LV 线缆上），线缆当场烧毁：
 * 冒一阵烟、响一声，然后整根线缆变成空气（不掉落东西）。这个判断还在每根线缆自己的接口里。
 */
public class CableBlockEntity extends BlockEntity implements TickableBlockEntity {

    /** 连接状态多久重算一次（tick）。 */
    private static final int CONNECTION_REFRESH_INTERVAL = 20;

    private int energy;
    private boolean burnt;
    private int refreshTimer;

    /** 六个方向的 FE 接口 + 一个「不分面」的接口（能力系统不传面时用）。 */
    private final IEnergyStorage[] sidedStorages = new IEnergyStorage[Direction.values().length];
    private final IEnergyStorage unsidedStorage = new SideStorage(null);

    public CableBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CABLE.get(), pos, state);
        for (Direction direction : Direction.values()) {
            this.sidedStorages[direction.ordinal()] = new SideStorage(direction);
        }
        // 刚放下/刚读档的第一 tick 就重算接头，玩家不用等一秒才看见线缆连上
        this.refreshTimer = CONNECTION_REFRESH_INTERVAL - 1;
    }

    /** 这根线缆是 LV 还是 MV：直接问自己的方块。 */
    public CableTier tier() {
        return this.getBlockState().getBlock() instanceof CableBlock cable ? cable.tier() : CableTier.LV;
    }

    /** 能力注册用：{@code side} 为 null 时给一个通用的接口。 */
    @Nullable
    public IEnergyStorage getStorage(@Nullable Direction side) {
        if (side == null) {
            return this.unsidedStorage;
        }
        return this.sidedStorages[side.ordinal()];
    }

    public boolean isBurnt() {
        return this.burnt;
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        if (this.burnt) {
            meltDown();
            return;
        }
        if (++this.refreshTimer >= CONNECTION_REFRESH_INTERVAL) {
            this.refreshTimer = 0;
            refreshConnections();
        }
        // 整张线缆网一 tick 只算一次：谁先轮到自己，谁就把整网结算掉
        CableNetwork.tick(this);
    }

    // ------------------------------------------------------------------
    // 给整网结算用：读 / 写这根线缆的缓存
    // ------------------------------------------------------------------

    /** 这根线缆缓存里现在有多少 FE。 */
    public int getStoredEnergy() {
        return this.energy;
    }

    /** 整网结算算完把每根线缆该分到多少写回来。 */
    public void setStoredEnergy(int value) {
        int capped = Math.max(0, Math.min(value, tier().capacity()));
        if (this.energy == capped) {
            return;
        }
        this.energy = capped;
        setChanged();
    }

    /** 每 20 tick 重算一次接头，补上能力系统还没来得及通知的情况。 */
    private void refreshConnections() {
        if (!(this.level instanceof Level level)) {
            return;
        }
        BlockState state = getBlockState();
        if (!(state.getBlock() instanceof CableBlock cable)) {
            return;
        }
        BlockState updated = cable.refreshConnections(level, this.worldPosition, state);
        if (!updated.equals(state)) {
            level.setBlock(this.worldPosition, updated, Block.UPDATE_ALL);
        }
    }

    // ------------------------------------------------------------------
    // 过载
    // ------------------------------------------------------------------

    /**
     * 邻居是不是「吃电超过这根线缆上限」的机器。
     *
     * <p>只看本模组自己的机器（它们会声明额定功率 {@link RatedEnergyConsumer}）；
     * 别的模组的机器没有声明，就不做这个判断，免得误烧。
     */
    private boolean neighbourOverloads(Direction side, CableTier tier) {
        if (this.level == null) {
            return false;
        }
        BlockEntity neighbour = this.level.getBlockEntity(this.worldPosition.relative(side));
        return neighbour instanceof RatedEnergyConsumer consumer
                && consumer.ratedEnergyPerTick() > tier.maxTransfer();
    }

    /** 烧毁：冒烟 + 灭火声，下一 tick 变成空气。 */
    private void burnOut() {
        if (this.burnt) {
            return;
        }
        this.burnt = true;
        if (this.level instanceof ServerLevel server) {
            BlockPos pos = this.worldPosition;
            server.sendParticles(ParticleTypes.LARGE_SMOKE,
                    pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D,
                    8, 0.35D, 0.35D, 0.35D, 0.01D);
            server.playSound(null, pos, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 1.0F, 1.0F);
        }
        setChanged();
    }

    /** 真正把线缆从世界里抹掉（不掉落东西）。 */
    private void meltDown() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        // 已经是别的方块了就别乱拆
        if (this.level.getBlockEntity(this.worldPosition) != this) {
            return;
        }
        this.level.removeBlock(this.worldPosition, false);
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy = Math.max(0, Math.min(tag.getInt("Energy"), tier().capacity()));
    }

    // ------------------------------------------------------------------
    // 单个面的 FE 接口
    // ------------------------------------------------------------------

    /**
     * 一面的 FE 接口。
     *
     * <p>{@code side} 是用来判断「这一面外面接的是谁」的：机器来抽电时会先看一眼它够不够格。
     */
    private final class SideStorage implements IEnergyStorage {

        @Nullable
        private final Direction side;

        private SideStorage(@Nullable Direction side) {
            this.side = side;
        }

        @Override
        public int receiveEnergy(int toReceive, boolean simulate) {
            if (toReceive <= 0 || burnt) {
                return 0;
            }
            CableTier tier = tier();
            int accepted = Math.min(Math.min(toReceive, tier.maxTransfer()), tier.capacity() - energy);
            if (accepted <= 0) {
                return 0;
            }
            if (!simulate) {
                energy += accepted;
                setChanged();
            }
            return accepted;
        }

        @Override
        public int extractEnergy(int toExtract, boolean simulate) {
            if (toExtract <= 0 || burnt || energy <= 0) {
                return 0;
            }
            CableTier tier = tier();
            int given = Math.min(Math.min(toExtract, tier.maxTransfer()), energy);
            if (given <= 0) {
                return 0;
            }
            if (!simulate) {
                // 真正往外送电的这一刻判断过载：机器吃得太狠就把线缆烧了
                if (this.side != null && neighbourOverloads(this.side, tier)) {
                    burnOut();
                    return 0;
                }
                energy -= given;
                setChanged();
            }
            return given;
        }

        @Override
        public int getEnergyStored() {
            return energy;
        }

        @Override
        public int getMaxEnergyStored() {
            return tier().capacity();
        }

        @Override
        public boolean canExtract() {
            return !burnt;
        }

        @Override
        public boolean canReceive() {
            return !burnt && energy < tier().capacity();
        }
    }
}
