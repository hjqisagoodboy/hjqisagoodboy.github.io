package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.energy.MachineEnergyStorage;
import cn.blockforge.generated.aftercritical.energy.RatedEnergyConsumer;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import cn.blockforge.generated.aftercritical.itemhandler.ContainerItemHandler;
import cn.blockforge.generated.aftercritical.menu.CascadeControllerMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;
import net.neoforged.neoforge.items.IItemHandler;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 级联控制器：一堆气体离心机的「总调度台」。
 *
 * <p>它自己不做任何加工，只干三件事：
 * <ol>
 *   <li>每隔 1 秒扫一遍自己周围 {@value #RADIUS} 格内的方块，记下最多 {@value #MAX_CENTRIFUGES}
 *       台气体离心机；</li>
 *   <li>每 tick 把进料罐里的六氟化铀分给这些离心机的进液罐；</li>
 *   <li>把离心机吐出来的低浓缩六氟化铀和贫化六氟化铀收进自己的两个产物罐。</li>
 * </ol>
 *
 * <p>运行耗电 {@value #ENERGY_PER_TICK} FE/t：只要还连着离心机就一直在耗电，
 * 因为它是整条级联线的「大脑」。离心机自己的加工电还是各自去抽。
 *
 * <p>三个 4,000 mB 的罐子：
 * <ul>
 *   <li>0 号进料罐：玩家 / 管道往里灌六氟化铀；</li>
 *   <li>1、2 号产物罐：装离心机抽出来的两种六氟化铀，哪种先来就先进 1 号。</li>
 * </ul>
 */
public class CascadeControllerBlockEntity extends BlockEntity
        implements MenuProvider, TickableBlockEntity, Container, RatedEnergyConsumer, EnergyMachineHost {

    /** 扫描半径：以控制器为中心，前后左右上下各 8 格。 */
    public static final int RADIUS = 8;

    /** 最多管几台离心机（v4 定稿：32 台）。 */
    public static final int MAX_CENTRIFUGES = 32;

    /** 运行耗电：32 FE/t。 */
    public static final int ENERGY_PER_TICK = 32;
    public static final int ENERGY_CAPACITY = 10_000;
    public static final int MAX_PULL_PER_TICK = 512;

    /** 每个罐的容量。 */
    public static final int TANK_CAPACITY = 4_000;

    /** 每 tick 每台离心机最多搬多少流体：200 mB 已经远远够用（一台离心机 5 mB/t 而已）。 */
    public static final int FLOW_PER_TICK = 200;

    /** 三个罐：0 进料，1、2 产物。 */
    public static final int TANK_FEED = 0;
    public static final int TANK_OUTPUT_A = 1;
    public static final int TANK_OUTPUT_B = 2;
    public static final int TANK_COUNT = 3;

    /** 每根长条右边一对罐子槽：操作槽 + 返还槽，所以一共 6 格。 */
    public static final int SLOT_COUNT = TANK_COUNT * 2;

    /** 第 {@code tankIndex} 根长条的操作槽。 */
    public static int jarOpSlot(int tankIndex) {
        return tankIndex * 2;
    }

    /** 第 {@code tankIndex} 根长条的返还槽。 */
    public static int jarReturnSlot(int tankIndex) {
        return tankIndex * 2 + 1;
    }

    /** 多久重新扫一遍离心机（tick）。 */
    private static final int SCAN_INTERVAL = 20;

    private final MachineEnergyStorage energy =
            new MachineEnergyStorage(ENERGY_CAPACITY, MAX_PULL_PER_TICK, this::setChanged);
    private final FluidTank[] tanks = new FluidTank[TANK_COUNT];
    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);

    /** 记着的离心机坐标（每 {@value #SCAN_INTERVAL} tick 重扫一次）。 */
    private final List<BlockPos> centrifuges = new ArrayList<>();

    private int scanTimer;
    private int status = STATUS_IDLE;

    private final IItemHandler itemHandler = new ContainerItemHandler(this,
            slot -> slot >= 0 && slot < SLOT_COUNT && slot % 2 == 0,
            slot -> slot >= 0 && slot < SLOT_COUNT && slot % 2 == 1,
            slot -> getMaxStackSize());

    public CascadeControllerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CASCADE_CONTROLLER.get(), pos, state);
        for (int i = 0; i < TANK_COUNT; i++) {
            this.tanks[i] = new FluidTank(TANK_CAPACITY);
        }
    }

    // ------------------------------------------------------------------
    // 对外接口
    // ------------------------------------------------------------------

    public net.neoforged.neoforge.energy.IEnergyStorage getEnergyStorage() {
        return this.energy;
    }

    /** 管道、别的模组的机械臂能从三个罐子槽抽 / 塞罐子。 */
    public IItemHandler getItemHandler() {
        return this.itemHandler;
    }

    @Override
    public int ratedEnergyPerTick() {
        return ENERGY_PER_TICK;
    }

    /**
     * 对外暴露的流体接口：0 号罐能灌，1、2 号罐能抽（智能流体管道直接接上就能用）。
     */
    public IFluidHandler getFluidHandler() {
        return this.fluidHandler;
    }

    private final IFluidHandler fluidHandler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return TANK_COUNT;
        }

        @Override
        public FluidStack getFluidInTank(int tank) {
            return tank >= 0 && tank < TANK_COUNT ? CascadeControllerBlockEntity.this.tanks[tank].getFluid()
                    : FluidStack.EMPTY;
        }

        @Override
        public int getTankCapacity(int tank) {
            return TANK_CAPACITY;
        }

        @Override
        public boolean isFluidValid(int tank, FluidStack stack) {
            return tank == TANK_FEED;
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            int filled = CascadeControllerBlockEntity.this.tanks[TANK_FEED].fill(resource, action);
            if (filled > 0 && action.execute()) {
                setChanged();
            }
            return filled;
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            for (int i = TANK_OUTPUT_A; i <= TANK_OUTPUT_B; i++) {
                FluidTank tank = CascadeControllerBlockEntity.this.tanks[i];
                if (tank.isEmpty() || !FluidStack.isSameFluidSameComponents(tank.getFluid(), resource)) {
                    continue;
                }
                FluidStack drained = tank.drain(resource.getAmount(), action);
                if (!drained.isEmpty() && action.execute()) {
                    setChanged();
                }
                return drained;
            }
            return FluidStack.EMPTY;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            for (int i = TANK_OUTPUT_A; i <= TANK_OUTPUT_B; i++) {
                FluidTank tank = CascadeControllerBlockEntity.this.tanks[i];
                if (tank.isEmpty()) {
                    continue;
                }
                FluidStack drained = tank.drain(maxDrain, action);
                if (!drained.isEmpty() && action.execute()) {
                    setChanged();
                }
                return drained;
            }
            return FluidStack.EMPTY;
        }
    };

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        pullEnergyFromNeighbours();
        serviceJars();

        if (++this.scanTimer >= SCAN_INTERVAL) {
            this.scanTimer = 0;
            scanCentrifuges();
        }

        boolean working = false;
        if (!this.centrifuges.isEmpty() && this.energy.getEnergyStored() >= ENERGY_PER_TICK) {
            this.energy.consume(ENERGY_PER_TICK);
            working = transfer();
        }

        int newStatus;
        if (this.centrifuges.isEmpty()) {
            newStatus = STATUS_IDLE;
        } else if (this.energy.getEnergyStored() < ENERGY_PER_TICK) {
            newStatus = STATUS_NO_ENERGY;
        } else if (working) {
            newStatus = STATUS_RUNNING;
        } else {
            newStatus = STATUS_IDLE;
        }
        if (this.status != newStatus) {
            this.status = newStatus;
            setChanged();
        }
    }

    /** 扫一遍周围的离心机（最多记 32 台）。 */
    public void scanCentrifuges() {
        this.centrifuges.clear();
        if (this.level == null) {
            return;
        }
        for (BlockPos pos : BlockPos.betweenClosed(
                this.worldPosition.offset(-RADIUS, -RADIUS, -RADIUS),
                this.worldPosition.offset(RADIUS, RADIUS, RADIUS))) {
            if (this.centrifuges.size() >= MAX_CENTRIFUGES) {
                break;
            }
            if (!this.level.isLoaded(pos)) {
                continue;
            }
            if (this.level.getBlockEntity(pos) instanceof FluidMachineBlockEntity machine
                    && machine.kind() == FluidMachineKind.GAS_CENTRIFUGE) {
                this.centrifuges.add(pos.immutable());
            }
        }
        setChanged();
    }

    /**
     * 给每台离心机喂料、收成品。
     *
     * @return 这一 tick 真的有流体搬动过就返回 true
     */
    private boolean transfer() {
        if (this.level == null) {
            return false;
        }
        boolean moved = false;
        for (BlockPos pos : this.centrifuges) {
            if (!(this.level.getBlockEntity(pos) instanceof FluidMachineBlockEntity machine)) {
                continue;
            }
            IFluidHandler handler = machine.getFluidHandler();

            // 1) 喂料：进料罐 → 离心机的进液罐
            FluidStack feed = this.tanks[TANK_FEED].getFluid();
            if (!feed.isEmpty()) {
                int amount = Math.min(feed.getAmount(), FLOW_PER_TICK);
                int accepted = handler.fill(feed.copyWithAmount(amount), IFluidHandler.FluidAction.SIMULATE);
                if (accepted > 0) {
                    accepted = handler.fill(feed.copyWithAmount(accepted), IFluidHandler.FluidAction.EXECUTE);
                    if (accepted > 0) {
                        this.tanks[TANK_FEED].drain(accepted, IFluidHandler.FluidAction.EXECUTE);
                        moved = true;
                    }
                }
            }

            // 2) 收成品：离心机的出液罐 → 控制器的两个产物罐
            for (int i = 0; i < handler.getTanks(); i++) {
                FluidStack stored = handler.getFluidInTank(i);
                if (stored.isEmpty() || handler.isFluidValid(i, stored)) {
                    // 空的跳过；进液罐（isFluidValid 为 true）也不抽，免得把刚喂进去的料又抽回来
                    continue;
                }
                FluidStack drained = handler.drain(stored.copyWithAmount(Math.min(stored.getAmount(), FLOW_PER_TICK)),
                        IFluidHandler.FluidAction.EXECUTE);
                if (!drained.isEmpty()) {
                    storeOutput(drained);
                    moved = true;
                }
            }
        }
        if (moved) {
            setChanged();
        }
        return moved;
    }

    /**
     * 把收来的流体塞进 1、2 号产物罐。
     *
     * <p>规矩和别处一样（见 {@link cn.blockforge.generated.aftercritical.fluid.TankGroup}）：
     * 哪种流体已经在某个罐里就还灌那个罐，否则用第一个空罐。
     * 于是低浓缩、贫化各占一个罐，接走一罐之后也不会两个罐都变成同一种。
     */
    private void storeOutput(FluidStack stack) {
        cn.blockforge.generated.aftercritical.fluid.TankGroup.insert(
                this.tanks, TANK_OUTPUT_A, TANK_OUTPUT_B + 1, stack, true);
    }

    /** 从六个方向挨个问邻居要电。 */
    private void pullEnergyFromNeighbours() {
        if (this.level == null) {
            return;
        }
        int space = this.energy.getFreeSpace();
        if (space <= 0) {
            return;
        }
        int budget = Math.min(space, MAX_PULL_PER_TICK);
        for (Direction side : Direction.values()) {
            if (budget <= 0) {
                break;
            }
            net.neoforged.neoforge.energy.IEnergyStorage source = this.level.getCapability(
                    Capabilities.EnergyStorage.BLOCK, this.worldPosition.relative(side), side.getOpposite());
            if (source == null || !source.canExtract()) {
                continue;
            }
            int moved = source.extractEnergy(budget, true);
            if (moved <= 0) {
                continue;
            }
            moved = source.extractEnergy(moved, false);
            if (moved > 0) {
                this.energy.receiveEnergy(moved, false);
                budget -= moved;
            }
        }
    }

    // ------------------------------------------------------------------
    // 罐子槽：进料那根只倒进去，两根产物只装出来
    // ------------------------------------------------------------------

    private void serviceJars() {
        for (int i = 0; i < TANK_COUNT; i++) {
            boolean changed = i == TANK_FEED
                    ? JarSlotService.pour(this.tanks[i], this.items, jarOpSlot(i), jarReturnSlot(i))
                    : JarSlotService.fill(this.tanks[i], this.items, jarOpSlot(i), jarReturnSlot(i));
            if (changed) {
                setChanged();
            }
        }
    }

    // ------------------------------------------------------------------
    // 手持容器右键
    // ------------------------------------------------------------------

    /**
     * 拿着预装流体罐 / 通用流体罐右键控制器：整罐灌进 0 号进料罐。
     *
     * @return 真的灌了才返回 true，方块就不用再开界面
     */
    public boolean handleFluidInteraction(Player player, InteractionHand hand) {
        if (this.level == null) {
            return false;
        }
        ItemStack held = player.getItemInHand(hand);
        FluidStack offer;
        if (held.getItem() instanceof UniversalTankItem) {
            offer = UniversalTankItem.getFluid(held);
        } else {
            return false;
        }
        if (offer.isEmpty()) {
            return false;
        }
        FluidTank tank = this.tanks[TANK_FEED];
        if (!tank.isEmpty() && !FluidStack.isSameFluidSameComponents(tank.getFluid(), offer)) {
            return false;
        }
        int space = tank.getCapacity() - tank.getFluidAmount();
        if (space <= 0) {
            return false;
        }
        int filled = tank.fill(offer.copyWithAmount(Math.min(space, offer.getAmount())),
                IFluidHandler.FluidAction.EXECUTE);
        if (filled <= 0) {
            return false;
        }
        int left = offer.getAmount() - filled;
        ItemStack result = left > 0
                ? UniversalTankItem.withFluid(held, offer.getFluid(), left)
                : UniversalTankItem.empty();
        if (held.getCount() <= 1) {
            player.setItemInHand(hand, result);
        } else {
            held.shrink(1);
            if (!player.getInventory().add(result)) {
                player.drop(result, false);
            }
        }
        this.level.playSound(null, this.worldPosition, SoundEvents.BUCKET_EMPTY, SoundSource.BLOCKS, 1.0F, 1.0F);
        setChanged();
        return true;
    }

    // ------------------------------------------------------------------
    // 界面数据
    // ------------------------------------------------------------------

    @Override
    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    @Override
    public int getEnergyCapacity() {
        return this.energy.getMaxEnergyStored();
    }

    @Override
    public int getStatus() {
        return this.status;
    }

    @Override
    public int getProgress() {
        return 0;
    }

    @Override
    public int getMaxProgress() {
        return 0;
    }

    /** 现在连着几台离心机（界面显示用）。 */
    public int getConnectedCount() {
        return this.centrifuges.size();
    }

    public int getTankAmount(int index) {
        return index >= 0 && index < TANK_COUNT ? this.tanks[index].getFluidAmount() : 0;
    }

    public int getTankFluidId(int index) {
        if (index < 0 || index >= TANK_COUNT) {
            return -1;
        }
        FluidStack stored = this.tanks[index].getFluid();
        if (stored.isEmpty()) {
            return -1;
        }
        int id = BuiltInRegistries.FLUID.getId(stored.getFluid());
        return id <= 0 ? -1 : id;
    }

    public int getTankCapacity() {
        return TANK_CAPACITY;
    }

    @Nullable
    public FluidTank tankForGui(int index) {
        return index >= 0 && index < TANK_COUNT ? this.tanks[index] : null;
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new CascadeControllerMenu(containerId, playerInventory, this);
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.cascade_controller");
    }

    // ------------------------------------------------------------------
    // 物品槽
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return SLOT_COUNT;
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        stack.limitSize(getMaxStackSize(stack));
        setChanged();
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        // 只有操作槽（偶数号）能塞罐子；返还槽是给机器放成品罐的
        return slot >= 0 && slot < SLOT_COUNT && slot % 2 == 0
                && stack.getItem() instanceof UniversalTankItem;
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
        tag.putInt("Status", this.status);
        ContainerHelper.saveAllItems(tag, this.items, registries);
        CompoundTag stored = new CompoundTag();
        for (int i = 0; i < TANK_COUNT; i++) {
            stored.put("Tank" + i, this.tanks[i].writeToNBT(registries, new CompoundTag()));
        }
        tag.put("Tanks", stored);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
        this.status = tag.getInt("Status");
        ContainerHelper.loadAllItems(tag, this.items, registries);
        CompoundTag stored = tag.getCompound("Tanks");
        for (int i = 0; i < TANK_COUNT; i++) {
            this.tanks[i].readFromNBT(registries, stored.getCompound("Tank" + i));
        }
        // 老存档里两个产物罐可能都装的是同一种液体：并到一个罐里，腾出来的罐立刻能用
        if (cn.blockforge.generated.aftercritical.fluid.TankGroup.mergeDuplicates(
                this.tanks, TANK_OUTPUT_A, TANK_OUTPUT_B + 1)) {
            setChanged();
        }
        this.scanTimer = SCAN_INTERVAL - 1;
    }

    @Override
    public void setLevel(net.minecraft.world.level.Level level) {
        super.setLevel(level);
        if (!level.isClientSide) {
            // 刚放下来 / 区块加载完，第一次 tick 就扫一遍，玩家不用等
            this.scanTimer = SCAN_INTERVAL - 1;
        }
    }
}
