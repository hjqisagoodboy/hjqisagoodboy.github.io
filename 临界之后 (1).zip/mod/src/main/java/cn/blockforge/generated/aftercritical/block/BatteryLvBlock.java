package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.BatteryLvBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/** 电池 LV 方块：存 40,000 FE，最大输出 80 FE/t。 */
public class BatteryLvBlock extends TickingMachineBlock {

    public BatteryLvBlock(Properties properties) {
        super(properties, "LV", "tooltip.aftercritical.storage",
                BatteryLvBlockEntity.ENERGY_CAPACITY, "block.aftercritical.battery_lv.desc");
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(BatteryLvBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new BatteryLvBlockEntity(pos, state);
    }
}
