package cn.blockforge.generated.aftercritical.client.cloud;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.network.CloudState;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 把蘑菇云画到世界里。
 *
 * <p>一朵云是**一整个带骨骼动画的模型**（用户自己做的），不再是几千颗烟粒子。
 * 服务器发一条 {@code MushroomCloudPayload}，客户端这里按「活了多久」挑动画帧：
 * <ol>
 *   <li><b>grow</b>：成形，火球冲起来、伞盖摊开、尘环推出去；</li>
 *   <li><b>idle</b>：成形之后一直循环的缓慢翻卷；</li>
 *   <li><b>die</b>：最后几秒摊平、消散。</li>
 * </ol>
 * 三段是同一个模型的三个动画，用户的 bbmodel 里首尾正好接得上，所以切段不会跳。
 *
 * <h2>时间轴按「出生那一刻」算，grow 只播一遍</h2>
 * <p>服务器每 20 tick 会补发一次进度，那是给后来的人接上用的。以前每次补发都把云的时间
 * 基准重设成「包里说已经活了多久」，只要服务器和客户端的计时差一点点，云就会往回退几秒，
 * 于是<b>火球冲上去那一段一遍一遍重播</b>（看着像放了四次 grow 才进 idle）。
 * 现在时间轴在 {@code CloudState} 里，按「出生时间」定死，补发包不再改它；
 * 这里再把动画时间夹进 [0, 动画长度]，grow / die 这种只播一遍的段落从结构上不可能重播。
 *
 * <h2>往屏幕上送顶点时的两个坑</h2>
 * <ul>
 *   <li><b>这层渲染是「四边形」模式，不是三角形</b>：{@code entityTranslucentEmissive}
 *       的顶点模式是 {@code QUADS}，显卡每 4 个顶点拼一个四边形。以前按三角形一次喂 3 个
 *       顶点，第 4 个顶点就跨到下一个三角形去了——整朵云会被拼成一堆乱飞的碎片
 *       （看着像被撕碎的纸屑）。现在每个三角形都补一个重复顶点凑成四边形，
 *       第二个三角形面积为零、什么都不画。</li>
 *   <li><b>半透明要「远的先画」</b>：这层不写深度，谁先画谁就在下面。以前按模型自带的
 *       顺序画，前后乱套，烟会糊成一团。现在每帧按「三角形离相机多远」排一遍，
 *       远的先画、近的后画，层次才对。为了不来回切渲染层（切一次就是一次绘制调用），
 *       先按贴图分层，层内排三角形，层与层之间按距离从远到近画。</li>
 * </ul>
 *
 * <h2>什么时候画：要压在原版云上面</h2>
 * <p>原版那层白云是在 {@code AFTER_PARTICLES} 之后才画的，而且这层蘑菇云是半透明
 * （不写深度），所以以前在 {@code AFTER_PARTICLES} 里画完，白云会**整片盖在蘑菇云上**，
 * 看着就像「透过蘑菇云能看见天上的云」。
 * 现在改成 {@code AFTER_WEATHER}（原版云和雨都画完之后）再画，蘑菇云就压在白云上了；
 * 它自己仍然按深度测试走，所以在蘑菇云前面的山、树照样挡得住它。
 * <p>例外是「极佳」画质（Fabulous）：那时候原版云是先画进单独的缓冲、最后才合成的，
 * {@code AFTER_WEATHER} 这个点也在另一个（天气）缓冲里，画进去会丢掉地形遮挡。
 * 极佳画质下原版的粒子缓冲本来就是最后合成，所以那种情况仍旧用 {@code AFTER_PARTICLES}。
 *
 * <h2>其它必须自己处理的细节</h2>
 * <ul>
 *   <li><b>雾</b>：原版雾按视距算，几百格外的云会被雾吃干净。画之前把雾推到极远，
 *       画完立刻恢复，免得这一帧后面的雨雪也被弄没雾。</li>
 *   <li><b>全亮</b>：这是发光的东西（火球、被烤亮的烟），不受方块光照影响，
 *       夜里也看得到。</li>
 * </ul>
 */
@EventBusSubscriber(modid = AfterCritical.MOD_ID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class MushroomCloudRenderer {

    /** 多远的云就不画了（比服务器发包的 1024 格再宽一点，够看了）。 */
    private static final float MAX_VIEW = 1200.0F;

    /** 小男孩那一朵的寿命（720 tick = 72 秒），动画速度按它当 1.0 来换算。 */
    private static final float REFERENCE_SECONDS = 72.0F;

    /** 成形动画最长 / 最短播多少秒。 */
    private static final float GROW_MAX = 24.0F;
    private static final float GROW_MIN = 6.0F;
    /** 消散动画最长 / 最短播多少秒。 */
    private static final float DIE_MAX = 8.0F;
    private static final float DIE_MIN = 2.5F;

    /** 雾推到这么远，等于「这一朵云不吃雾」。 */
    private static final float FAR_FOG_START = 1.0E9F;
    private static final float FAR_FOG_END = 1.1E9F;

    /** 排序键里装三角形编号用的位数：低 20 位放三角形，高位放部件（部件撑死几十个）。 */
    private static final int TRI_BITS = 20;
    private static final int TRI_MASK = (1 << TRI_BITS) - 1;

    private static MushroomCloudModel model;
    /** 下次允许再试一次加载的 gameTime：资源读坏了不至于整局都画不出来（F3+T 重载资源就能修）。 */
    private static long nextLoadAttempt;
    private static ClientLevel lastLevel;

    // ---- 每帧复用的缓冲，免得一万个三角形每帧都新分配一次数组 ----
    /** 每个部件的顶点乘完骨骼矩阵之后的位置（云的本地坐标，还没乘整体缩放）。 */
    private static float[][] transformed = new float[0][];
    /** 排序键：高 32 位是「到相机的距离²」的浮点位模式，低 32 位是三角形编号。 */
    private static long[] sortKeys = new long[0];
    /** 每个渲染层的三角形在 {@link #sortKeys} 里的起点 / 个数 / 中位距离。 */
    private static int[] layerStart = new int[0];
    private static int[] layerSize = new int[0];
    private static int[] layerCursor = new int[0];
    private static float[] layerDepth = new float[0];
    private static int[] layerOrder = new int[0];

    private MushroomCloudRenderer() {}

    @SubscribeEvent
    public static void onRenderStage(RenderLevelStageEvent event) {
        Minecraft minecraft = Minecraft.getInstance();
        // 默认（流畅 / 高品质）在原版云、雨都画完之后再画，蘑菇云才压得住天上的白云；
        // 「极佳」画质的云是单独缓冲最后合成的，那就在粒子阶段画（会被一起合到最上层）。
        boolean fabulous = minecraft.options.graphicsMode().get() == GraphicsStatus.FABULOUS;
        RenderLevelStageEvent.Stage wanted = fabulous
                ? RenderLevelStageEvent.Stage.AFTER_PARTICLES
                : RenderLevelStageEvent.Stage.AFTER_WEATHER;
        if (event.getStage() != wanted) {
            return;
        }
        ClientLevel level = minecraft.level;
        if (level == null) {
            return;
        }
        // 换维度 / 退世界：把上一个世界的云清掉
        if (level != lastLevel) {
            CloudState.clear();
            lastLevel = level;
        }
        List<CloudState.Cloud> clouds = CloudState.clouds();
        if (clouds.isEmpty()) {
            return;
        }
        if (model == null) {
            long now = level.getGameTime();
            if (now < nextLoadAttempt) {
                return;
            }
            nextLoadAttempt = now + 100;
            model = MushroomCloudModel.load(minecraft.getResourceManager());
        }
        if (model == null) {
            return;
        }

        long gameTime = level.getGameTime();
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        PoseStack poseStack = event.getPoseStack();
        Camera camera = event.getCamera();
        Vec3 cameraPos = camera.getPosition();
        MultiBufferSource.BufferSource buffers = minecraft.renderBuffers().bufferSource();

        List<Integer> dead = new ArrayList<>();
        float savedFogStart = RenderSystem.getShaderFogStart();
        float savedFogEnd = RenderSystem.getShaderFogEnd();
        RenderSystem.setShaderFogStart(FAR_FOG_START);
        RenderSystem.setShaderFogEnd(FAR_FOG_END);

        for (CloudState.Cloud cloud : clouds) {
            float ageTicks = CloudState.ageOf(cloud, gameTime, partialTick);
            if (ageTicks >= cloud.duration()) {
                dead.add(cloud.id());
                continue;
            }
            double dx = cloud.x() - cameraPos.x;
            double dy = cloud.y() - cameraPos.y;
            double dz = cloud.z() - cameraPos.z;
            if (dx * dx + dy * dy + dz * dz > (double) MAX_VIEW * MAX_VIEW) {
                continue;
            }
            draw(poseStack, buffers, cloud, ageTicks, cameraPos);
        }

        for (RenderType layer : model.layers()) {
            buffers.endBatch(layer);
        }
        RenderSystem.setShaderFogStart(savedFogStart);
        RenderSystem.setShaderFogEnd(savedFogEnd);

        for (int id : dead) {
            CloudState.remove(id);
        }
    }

    /** 画一朵云；返回有没有真的画东西。 */
    private static boolean draw(PoseStack poseStack, MultiBufferSource.BufferSource buffers,
                                CloudState.Cloud cloud, float ageTicks, Vec3 cameraPos) {
        float totalSeconds = cloud.duration() / 20.0F;
        float ageSeconds = ageTicks / 20.0F;

        // 当量越大，云活得越久，长和散也按比例慢一点（小男孩是 1.0 倍）
        float rate = totalSeconds / REFERENCE_SECONDS;
        float growSeconds = clamp(12.0F * rate, GROW_MIN, GROW_MAX);
        float dieSeconds = clamp(4.0F * rate, DIE_MIN, DIE_MAX);
        if (growSeconds + dieSeconds > totalSeconds) {
            float squeeze = totalSeconds / (growSeconds + dieSeconds);
            growSeconds *= squeeze;
            dieSeconds *= squeeze;
        }

        MushroomCloudModel.Anim anim;
        float animTime;
        if (ageSeconds < growSeconds) {
            MushroomCloudModel.Anim grow = model.anim("grow");
            anim = grow;
            animTime = grow == null ? 0.0F : ageSeconds / growSeconds * grow.length;
        } else if (ageSeconds < totalSeconds - dieSeconds) {
            MushroomCloudModel.Anim idle = model.anim("idle");
            anim = idle;
            // idle 是首尾接得上的循环段，取余；长度是 0 的坏数据就别取余（会除出 NaN）
            animTime = idle == null ? 0.0F
                    : idle.length <= 0.0F ? 0.0F : (ageSeconds - growSeconds) % idle.length;
        } else {
            MushroomCloudModel.Anim die = model.anim("die");
            anim = die;
            float k = dieSeconds <= 0.0F ? 1.0F : (ageSeconds - (totalSeconds - dieSeconds)) / dieSeconds;
            animTime = die == null ? 0.0F : Math.min(1.0F, k) * die.length;
        }
        if (anim == null) {
            return false;
        }
        // 只播一遍的动画（grow / die）绝不越过自己的长度：越界就让关键帧夹在最后一帧上，
        // 这样不管外界给的年龄怎么抖，火球也不可能重播一遍。
        if (anim.length > 0.0F) {
            animTime = clamp(animTime, 0.0F, anim.length);
        }

        Matrix4f[] matrices = model.boneMatrices(anim, animTime);
        MushroomCloudModel.Part[] parts = model.parts();
        RenderType[] layers = model.layers();
        // 消散段整段一起淡出：die 动画本身会把伞盖摊平，单靠形状收尾会像一块饼，
        // 叠上透明度才是「慢慢散掉」。
        float fadeTicks = Math.max(1.0F, dieSeconds * 20.0F);
        float alpha = Math.min(1.0F, Math.max(0.0F, (cloud.duration() - ageTicks) / fadeTicks));
        float scale = cloud.scale();

        // 云和相机之间的位移：顶点坐标都是「云的本地坐标」，画的时候整体平移到这儿。
        double ox = cloud.x() - cameraPos.x;
        double oy = cloud.y() - cameraPos.y;
        double oz = cloud.z() - cameraPos.z;

        // 1) 先把每个部件的顶点乘上它这一帧的骨骼矩阵（每个顶点只算一次，排序和画都复用）
        if (transformed.length < parts.length) {
            transformed = new float[parts.length][];
        }
        int triangles = 0;
        for (int i = 0; i < parts.length; i++) {
            MushroomCloudModel.Part part = parts[i];
            float[] out = transformed[i];
            if (out == null || out.length < part.verts.length) {
                out = new float[part.verts.length];
                transformed[i] = out;
            }
            multiply(matrices[part.bone], part.verts, out);
            triangles += part.indices.length / 3;
        }

        // 2) 按渲染层分段：层内排三角形，层间按距离从远到近画（切一次层就是一次绘制调用）
        int layerTotal = layers.length;
        if (layerStart.length < layerTotal) {
            layerStart = new int[layerTotal];
            layerSize = new int[layerTotal];
            layerCursor = new int[layerTotal];
            layerDepth = new float[layerTotal];
            layerOrder = new int[layerTotal];
        }
        Arrays.fill(layerSize, 0, layerTotal, 0);
        for (MushroomCloudModel.Part part : parts) {
            layerSize[part.layerIndex] += part.indices.length / 3;
        }
        int offset = 0;
        for (int l = 0; l < layerTotal; l++) {
            layerStart[l] = offset;
            layerCursor[l] = offset;
            offset += layerSize[l];
        }

        if (sortKeys.length < triangles) {
            sortKeys = new long[triangles];
        }

        for (int i = 0; i < parts.length; i++) {
            MushroomCloudModel.Part part = parts[i];
            float[] verts = transformed[i];
            int[] indices = part.indices;
            int slot = layerCursor[part.layerIndex];
            for (int t = 0; t + 2 < indices.length; t += 3) {
                int a = indices[t] * 3;
                int b = indices[t + 1] * 3;
                int c = indices[t + 2] * 3;
                double cx = ox + scale * (verts[a] + verts[b] + verts[c]) / 3.0;
                double cy = oy + scale * (verts[a + 1] + verts[b + 1] + verts[c + 1]) / 3.0;
                double cz = oz + scale * (verts[a + 2] + verts[b + 2] + verts[c + 2]) / 3.0;
                float distanceSq = (float) (cx * cx + cy * cy + cz * cz);
                sortKeys[slot++] = ((long) (Float.floatToRawIntBits(distanceSq) & 0xFFFFFFFFL) << 32)
                        | ((long) i << TRI_BITS)
                        | (long) (t / 3);
            }
            layerCursor[part.layerIndex] = slot;
        }

        // 3) 每层内部按距离排序，顺便记下这层的中位距离，用来决定层与层的先后
        for (int l = 0; l < layerTotal; l++) {
            int from = layerStart[l];
            int to = from + layerSize[l];
            if (to <= from) {
                layerDepth[l] = Float.POSITIVE_INFINITY;
                continue;
            }
            Arrays.sort(sortKeys, from, to);
            layerDepth[l] = Float.intBitsToFloat((int) (sortKeys[(from + to) >> 1] >>> 32));
        }
        for (int l = 0; l < layerTotal; l++) {
            layerOrder[l] = l;
        }
        // 层数就四五个，插入排序足够（远的排前面）
        for (int i = 1; i < layerTotal; i++) {
            int current = layerOrder[i];
            int j = i - 1;
            while (j >= 0 && layerDepth[layerOrder[j]] < layerDepth[current]) {
                layerOrder[j + 1] = layerOrder[j];
                j--;
            }
            layerOrder[j + 1] = current;
        }

        // 4) 开画：远的先画、近的后画；每个三角形补一个重复顶点凑成四边形
        poseStack.pushPose();
        poseStack.translate(ox, oy, oz);
        poseStack.scale(scale, scale, scale);
        PoseStack.Pose pose = poseStack.last();

        for (int k = 0; k < layerTotal; k++) {
            int layer = layerOrder[k];
            int from = layerStart[layer];
            int to = from + layerSize[layer];
            if (to <= from) {
                continue;
            }
            VertexConsumer consumer = buffers.getBuffer(layers[layer]);
            for (int e = to - 1; e >= from; e--) {
                int id = (int) sortKeys[e];
                int partIndex = id >>> TRI_BITS;
                int triangle = id & TRI_MASK;
                MushroomCloudModel.Part part = parts[partIndex];
                float[] verts = transformed[partIndex];
                float[] uvs = part.uvs;
                int base = triangle * 3;
                int a = part.indices[base];
                int b = part.indices[base + 1];
                int c = part.indices[base + 2];
                vertex(consumer, pose, verts, uvs, a, alpha);
                vertex(consumer, pose, verts, uvs, b, alpha);
                vertex(consumer, pose, verts, uvs, c, alpha);
                // 这一层是 QUADS 模式：第 4 个顶点重复第 3 个，第二个三角形面积为零，不画东西。
                // 少了这个顶点，显卡会把下一个三角形的第一个顶点拉过来凑四边形——就是「破碎」的根源。
                vertex(consumer, pose, verts, uvs, c, alpha);
            }
        }
        poseStack.popPose();
        return true;
    }

    /** 往顶点缓冲里送一个顶点（位置已经是乘过骨骼矩阵的云本地坐标）。 */
    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose,
                               float[] verts, float[] uvs, int index, float alpha) {
        int v = index * 3;
        int u = index * 2;
        consumer.addVertex(pose, verts[v], verts[v + 1], verts[v + 2])
                .setColor(1.0F, 1.0F, 1.0F, alpha)
                .setUv(uvs[u], uvs[u + 1])
                .setLight(LightTexture.FULL_BRIGHT)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setNormal(0.0F, 1.0F, 0.0F);
    }

    /** 用一根骨骼这一帧的矩阵变换一整个部件的顶点（列主序，和 JOML 的 mXY 一致）。 */
    private static void multiply(Matrix4f matrix, float[] verts, float[] out) {
        for (int i = 0; i + 2 < verts.length; i += 3) {
            float x = verts[i];
            float y = verts[i + 1];
            float z = verts[i + 2];
            out[i] = matrix.m00() * x + matrix.m10() * y + matrix.m20() * z + matrix.m30();
            out[i + 1] = matrix.m01() * x + matrix.m11() * y + matrix.m21() * z + matrix.m31();
            out[i + 2] = matrix.m02() * x + matrix.m12() * y + matrix.m22() * z + matrix.m32();
        }
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
