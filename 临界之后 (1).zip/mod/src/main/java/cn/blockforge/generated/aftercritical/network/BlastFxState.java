package cn.blockforge.generated.aftercritical.network;

/**
 * 核爆视觉特效的「时钟」：爆闪、暖色滤镜、镜头抖、视野冲击，全部由这一个年龄算出来。
 *
 * <h2>为什么放在公共包而不是 client 包</h2>
 * 服务端也会加载这个类（网络包处理函数引用它），但它不引用任何客户端类，
 * 所以专用服务器不会因为找不到界面类而崩。
 *
 * <h2>时间轴怎么来的</h2>
 * 用户给的核爆录音长 70.35 秒，响度包络是：0–12 秒最响（主冲击），12–30 秒余震，
 * 30–50 秒低频隆隆，50–70 秒尾音散掉。下面每条曲线都按这个包络设计——
 * 声音响的时候特效强，声音弱下去特效跟着退，最后和音频一起归零。
 *
 * <table>
 *   <caption>关键时间点（单位：秒，t=0 是起爆那一帧）</caption>
 *   <tr><th>时间</th><th>画面</th></tr>
 *   <tr><td>0 – 0.32</td><td>全屏纯白，什么都看不见</td></tr>
 *   <tr><td>0.32 – 1.8</td><td>白色退去，露出橙色火球余晖再一起淡掉</td></tr>
 *   <tr><td>0 – 2.5</td><td>视野被推宽一下再回弹</td></tr>
 *   <tr><td>0 – 7</td><td>镜头抖得最厉害</td></tr>
 *   <tr><td>0.25 – 12</td><td>橙红滤镜升到最满</td></tr>
 *   <tr><td>12 – 30</td><td>滤镜跟着声音退到 45%</td></tr>
 *   <tr><td>7 – 45</td><td>抖动渐渐变轻微</td></tr>
 *   <tr><td>30 – 70</td><td>滤镜退回 0，完全恢复</td></tr>
 * </table>
 *
 * <h2>距离怎么算进来</h2>
 * 服务器发过来的 {@code intensity} 是 0~1 的「离爆心多近」。它只当总音量旋钮用：
 * 贴脸看和隔着四百格看，时间轴一样长，但远的人整体淡一些、抖得轻一些。
 * 远处不会一点都看不见——核爆就该在半个地图外都看得见，所以留了 30% 的底。
 */
public final class BlastFxState {

    /** 整套特效的时间轴长度（秒），跟核爆录音一样长。 */
    public static final float TIMELINE_SECONDS = 70.0F;

    /** 纯白全屏盖住的时长。 */
    private static final float WHITE_HOLD = 0.32F;
    /** 爆闪（白 + 橙）彻底结束的时刻。 */
    private static final float FLASH_END = 1.8F;

    /** 滤镜开始上色 / 升到最满 / 退到四成 / 完全退掉的时刻。 */
    private static final float FILTER_START = 0.25F;
    private static final float FILTER_RAMP_END = 1.5F;
    private static final float FILTER_FULL = 12.0F;
    private static final float FILTER_HALF = 30.0F;
    private static final float FILTER_END = 70.0F;

    /** 抖动最猛的那一段结束 / 彻底停下的时刻。 */
    private static final float SHAKE_HARD_END = 7.0F;
    private static final float SHAKE_SOFT_END = 45.0F;

    /** 视野冲击回正的时刻。 */
    private static final float FOV_END = 2.5F;
    /** 视野推到最宽用多久。 */
    private static final float FOV_ATTACK = 0.15F;
    /** 最宽保持到什么时候（差不多是白幕退干净的时候）。 */
    private static final float FOV_HOLD_END = 0.40F;

    /** 滤镜最满时盖多少不透明度（0~1）。再高就看不见地形了。 */
    private static final float MAX_FILTER_ALPHA = 0.42F;
    /** 暗角最重时多黑。 */
    private static final float MAX_VIGNETTE_ALPHA = 0.62F;
    /** 橙色火球余晖最浓时多浓。 */
    private static final float MAX_EMBER_ALPHA = 0.78F;

    /** 抖动最猛时镜头左右/上下偏多少度。 */
    public static final float MAX_SHAKE_DEGREES = 4.6F;
    /** 抖动最猛时画面滚转多少度（歪一下，这是「被冲击波掀到」的感觉）。 */
    public static final float MAX_ROLL_DEGREES = 3.4F;
    /** 视野冲击最多把 FOV 推宽多少度。 */
    public static final float MAX_FOV_BOOST = 15.0F;

    /** 最远的玩家也保留这个比例的特效，不至于什么都看不见。 */
    private static final float DISTANCE_FLOOR = 0.30F;

    /** 起爆时刻（纳秒）。用 {@link Long#MIN_VALUE} 的一半当「从来没炸过」。 */
    private static volatile long startNanos = Long.MIN_VALUE / 2;
    /** 这一发离玩家多近（0~1）。 */
    private static volatile float intensity;

    private BlastFxState() {}

    /**
     * 收到服务器的爆闪包：从现在开始走整条时间轴。
     *
     * <p>同一发里收到两次（比如附近炸了两颗）就取更亮的那一个，不让后到的把前一个打断。
     */
    public static void trigger(float value) {
        float clamped = Math.max(0.0F, Math.min(1.0F, value));
        if (active() && ageSeconds() < 0.5F) {
            // 刚炸过、还在前 0.5 秒：同一场爆炸的重复包，只补亮不重置时钟
            intensity = Math.max(intensity, clamped);
            return;
        }
        intensity = clamped;
        startNanos = System.nanoTime();
    }

    /** 断线/退出世界时清掉，下次进来不会带上一局的余韵。 */
    public static void clear() {
        startNanos = Long.MIN_VALUE / 2;
        intensity = 0.0F;
    }

    /** 这一整套特效还在不在走。 */
    public static boolean active() {
        return ageSeconds() < TIMELINE_SECONDS;
    }

    /** 起爆到现在过了多少秒。没炸过时给一个大数，所有曲线自然都是 0。 */
    public static float ageSeconds() {
        long elapsed = System.nanoTime() - startNanos;
        if (elapsed <= 0L) {
            return Float.MAX_VALUE;
        }
        return elapsed / 1.0E9F;
    }

    /** 这一发离玩家多近（0~1）。 */
    public static float intensity() {
        return intensity;
    }

    /** 总亮度旋钮：远处也有人看得见，所以留了 30% 的底。 */
    private static float gain() {
        return DISTANCE_FLOOR + (1.0F - DISTANCE_FLOOR) * intensity;
    }

    /**
     * 纯白爆闪的透明度（0~1）。
     *
     * <p>0–0.32 秒满白，之后按平方曲线退掉：平方是为了「先亮着不动，再一下子消失」，
     * 线性淡出会显得像慢慢调低屏幕亮度。
     */
    public static float whiteAlpha() {
        float t = ageSeconds();
        if (t < 0.0F || t > FLASH_END) {
            return 0.0F;
        }
        float g = gain();
        if (t <= WHITE_HOLD) {
            return g;
        }
        float x = (t - WHITE_HOLD) / (FLASH_END - WHITE_HOLD);
        float left = 1.0F - x;
        return g * left * left;
    }

    /**
     * 橙色火球余晖的透明度（0~1），画在白幕下面。
     *
     * <p>白幕退掉的过程中透出来的就是它：0.3 秒起迅速升起来，1.8 秒前淡干净。
     * 这样观感是「白闪 → 橙色火球 → 正常」，而不是「白闪 → 什么都没有」。
     */
    public static float emberAlpha() {
        float t = ageSeconds();
        if (t < 0.30F || t > FLASH_END) {
            return 0.0F;
        }
        float rise = smooth(clamp01((t - 0.30F) / 0.35F));
        float fall = 1.0F - smooth(clamp01((t - 0.55F) / (FLASH_END - 0.55F)));
        return MAX_EMBER_ALPHA * gain() * rise * fall;
    }

    /**
     * 橙红滤镜的强弱（0~1，乘完最浓不透明度之后才是 alpha）。
     *
     * <p>0.25 秒开始上色、1.5 秒到 85%，然后跟着声音慢慢顶到 100%（12 秒），
     * 12–30 秒退到 45%，30–70 秒随着尾音化到 0。
     */
    public static float filterLevel() {
        float t = ageSeconds();
        if (t < FILTER_START || t > FILTER_END) {
            return 0.0F;
        }
        float level;
        if (t < FILTER_RAMP_END) {
            level = 0.85F * smooth((t - FILTER_START) / (FILTER_RAMP_END - FILTER_START));
        } else if (t < FILTER_FULL) {
            level = 0.85F + 0.15F * smooth((t - FILTER_RAMP_END) / (FILTER_FULL - FILTER_RAMP_END));
        } else if (t < FILTER_HALF) {
            level = 1.0F - 0.55F * smooth((t - FILTER_FULL) / (FILTER_HALF - FILTER_FULL));
        } else {
            level = 0.45F * (1.0F - smooth((t - FILTER_HALF) / (FILTER_END - FILTER_HALF)));
        }
        return level * gain();
    }

    /** 滤镜那一层的实际 alpha。 */
    public static float filterAlpha() {
        return MAX_FILTER_ALPHA * filterLevel();
    }

    /** 暗角（四周压黑）的实际 alpha，比滤镜稍重一点，把视线往中间挤。 */
    public static float vignetteAlpha() {
        return MAX_VIGNETTE_ALPHA * filterLevel();
    }

    /**
     * 镜头抖的强度（0~1）。
     *
     * <p>0–7 秒最猛（冲击波还在推），7–45 秒一路减到很轻微，45 秒后彻底停。
     */
    public static float shakeAmount() {
        float t = ageSeconds();
        if (t < 0.0F || t > SHAKE_SOFT_END) {
            return 0.0F;
        }
        float amp;
        if (t < SHAKE_HARD_END) {
            amp = 1.0F - 0.55F * (t / SHAKE_HARD_END);
        } else {
            amp = 0.45F * (1.0F - 0.87F * ((t - SHAKE_HARD_END) / (SHAKE_SOFT_END - SHAKE_HARD_END)));
        }
        return amp * gain();
    }

    /**
     * 视野冲击（归一化，负数是回弹时反而缩窄）。
     *
     * <p>为什么不在 0 秒就顶到最宽：前 0.32 秒屏幕是全白的，推宽了也看不见。
     * 所以真正的节奏是——
     * <ul>
     *   <li>0–0.15 秒：白幕底下先推宽（看不见，但一退白就已经是宽的了）；</li>
     *   <li>0.15–0.40 秒：保持在最宽，这时候白幕正好开始退，眼睛「一下看到两边」；</li>
     *   <li>0.40–2.5 秒：像弹簧一样弹回来，中途往反方向过冲一点（视野反而比平时窄），</li>
     * </ul>
     * 这就是「被冲击波冲开了眼眶又猛地缩回来」的感觉。
     */
    public static float fovPulse() {
        float t = ageSeconds();
        if (t < 0.0F || t > FOV_END) {
            return 0.0F;
        }
        float envelope;
        if (t < FOV_ATTACK) {
            envelope = smooth(t / FOV_ATTACK);
        } else if (t < FOV_HOLD_END) {
            envelope = 1.0F;
        } else {
            double x = t - FOV_HOLD_END;
            envelope = (float) (Math.exp(-1.6 * x) * Math.cos(x * 2.0 * Math.PI * 0.65));
        }
        return envelope * gain();
    }

    // ------------------------------------------------------------------
    // 小工具
    // ------------------------------------------------------------------

    private static float clamp01(float x) {
        return x < 0.0F ? 0.0F : (x > 1.0F ? 1.0F : x);
    }

    /** 平滑曲线：两头都是 0 斜率，不会在关键时间点上出现折角。 */
    private static float smooth(float x) {
        float c = clamp01(x);
        return c * c * (3.0F - 2.0F * c);
    }
}
