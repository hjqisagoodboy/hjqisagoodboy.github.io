package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.blockentity.CombustionGeneratorBlockEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/** 燃烧发电机方块：LV，烧煤/木板/原木，输出 80 FE/t。 */
public class CombustionGeneratorBlock extends TickingMachineBlock {

    public CombustionGeneratorBlock(Properties properties) {
        super(properties, "LV", "tooltip.aftercritical.output_per_tick",
                CombustionGeneratorBlockEntity.OUTPUT_PER_TICK, "block.aftercritical.combustion_generator.desc");
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return simpleCodec(CombustionGeneratorBlock::new);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CombustionGeneratorBlockEntity(pos, state);
    }
}
