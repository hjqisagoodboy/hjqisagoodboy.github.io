package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.block.ItemMachineBlock;
import cn.blockforge.generated.aftercritical.menu.ItemMachineMenu;
import cn.blockforge.generated.aftercritical.recipe.MachineRecipe;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 烧结炉 / 磨削机 / 焊接机共用的方块实体。
 *
 * <p>加工流程完全来自 {@link MachineBlockEntity}（抽电、找配方、攒进度、出成品），
 * 这里只回答三个问题：自己是哪台机器（{@link ItemMachineKind}）、
 * 哪几个槽是输入、哪几个槽是输出。槽数、功率也都是从型号表里读的。
 *
 * <p>磨削机要吐两样东西（精磨芯块 + 废粉），配方里的副产物由基类负责放进第二个输出槽。
 */
public class ItemMachineBlockEntity extends MachineBlockEntity {

    public ItemMachineBlockEntity(BlockPos pos, BlockState state) {
        // 槽位数量和额定功率都写在型号表里；这里必须用 state 直接查，
        // 因为 super(...) 执行完之前还不能调 getBlockState()。
        super(ModBlockEntities.ITEM_MACHINE.get(), pos, state,
                kindOf(state).slotCount(), kindOf(state).energyPerTick());
    }

    /** 从方块状态认出这是哪台机器（方块实体要等 super 跑完才能 getBlockState）。 */
    public static ItemMachineKind kindOf(BlockState state) {
        return state.getBlock() instanceof ItemMachineBlock block
                ? block.kind()
                : ItemMachineKind.SINTERING_FURNACE;
    }

    /** 自己是烧结炉、磨削机还是焊接机，看方块。 */
    public ItemMachineKind kind() {
        return kindOf(getBlockState());
    }

    @Override
    protected int[] inputSlots() {
        int[] slots = new int[kind().itemInputs()];
        for (int i = 0; i < slots.length; i++) {
            slots[i] = kind().inputSlot(i);
        }
        return slots;
    }

    @Override
    protected int[] outputSlots() {
        int[] slots = new int[kind().itemOutputs()];
        for (int i = 0; i < slots.length; i++) {
            slots[i] = kind().outputSlot(i);
        }
        return slots;
    }

    @Override
    protected RecipeType<MachineRecipe> recipeType() {
        return kind().recipeType();
    }

    @Override
    public Component getDisplayName() {
        return kind().displayName();
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new ItemMachineMenu(ModMenus.menuForItemMachine(kind()), containerId, playerInventory,
                this, this, kind());
    }

    /**
     * 伽马辐照器做完一炉时点亮成就。
     *
     * <p>这台机器有两个「钴60源配方」——照生鸡肉、照腐肉。两边各做一次，
     * 成就「一源两用」的两个条件就都齐了。机器不知道是谁在玩，按距离给附近玩家记账。
     */
    @Override
    protected void onCrafted(MachineRecipe recipe, List<ItemStack> results) {
        super.onCrafted(recipe, results);
        if (this.level == null || kind() != ItemMachineKind.GAMMA_IRRADIATOR) {
            return;
        }
        for (ItemStack result : results) {
            if (result.is(Items.COOKED_CHICKEN)) {
                ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 32.0,
                        ModAdvancementTriggers.GAMMA_COOKED_CHICKEN);
            } else if (result.is(Items.LEATHER)) {
                ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 32.0,
                        ModAdvancementTriggers.GAMMA_LEATHER);
            }
        }
    }
}
