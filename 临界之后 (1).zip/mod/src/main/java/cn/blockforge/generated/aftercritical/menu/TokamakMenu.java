package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.TokamakControllerBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 托卡马克控制器的界面：一排 4 格氘氚燃料单元 + 右边 1 格氚产物，下面一个「点火」按钮，
 * 底下一串读数（结构部件、燃料、氚、点火进度、无线供电）。
 */
public class TokamakMenu extends AbstractMachineMenu {

    /** 按钮号：点火。 */
    public static final int BUTTON_IGNITE = 0;

    /** 底部读数行数。 */
    public static final int STAT_LINES = 6;

    private static final int DATA_STATUS = 0;
    private static final int DATA_FORMED = 1;
    private static final int DATA_CASING = 2;
    private static final int DATA_COILS = 3;
    private static final int DATA_BLANKETS = 4;
    private static final int DATA_INJECTORS = 5;
    private static final int DATA_DIAGNOSTICS = 6;
    private static final int DATA_COOLERS = 7;
    private static final int DATA_LOGIC = 8;
    private static final int DATA_FUEL = 9;
    private static final int DATA_TRITIUM = 10;
    private static final int DATA_IGNITION = 11;
    private static final int DATA_FUEL_PERCENT = 12;
    private static final int DATA_WIRELESS = 13;
    private static final int DATA_PORTS = 14;
    private static final int DATA_BREED_BLOCKED = 15;
    private static final int DATA_COUNT = 16;

    @Nullable
    private final TokamakControllerBlockEntity controller;

    private final int[] values = new int[DATA_COUNT];

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return index >= 0 && index < DATA_COUNT ? values[index] : 0;
        }

        @Override
        public void set(int index, int value) {
            if (index >= 0 && index < DATA_COUNT) {
                values[index] = value;
            }
        }

        @Override
        public int getCount() {
            return DATA_COUNT;
        }
    };

    /** 服务端用。 */
    public TokamakMenu(int containerId, Inventory playerInventory, TokamakControllerBlockEntity controller) {
        this(containerId, playerInventory, (BlockEntity) controller);
    }

    /** 客户端用。 */
    public TokamakMenu(int containerId, Inventory playerInventory, @Nullable BlockEntity blockEntity) {
        super(ModMenus.TOKAMAK_CONTROLLER.get(), containerId, playerInventory,
                TokamakControllerBlockEntity.SLOT_COUNT,
                blockEntity instanceof TokamakControllerBlockEntity be ? be : null, 0);
        this.controller = blockEntity instanceof TokamakControllerBlockEntity be ? be : null;
        // 6 行读数：结构 / 材料 / 部件 / 电力 / 燃料 / 状态，面板要留够位置
        setTextLines(STAT_LINES);

        Container container = container(blockEntity);
        for (int i = 0; i < TokamakControllerBlockEntity.FUEL_SLOTS; i++) {
            this.addSlot(new FuelSlot(container, i,
                    MachineLayout.ITEM_X + i * MachineLayout.ITEM_STEP, MachineLayout.ITEM_Y));
        }
        this.addSlot(new OutputSlot(container, TokamakControllerBlockEntity.SLOT_OUTPUT,
                MachineLayout.ITEM_X + 72, MachineLayout.ITEM_Y));

        this.addPlayerInventory(playerInventory);
        this.addDataSlots(this.data);
    }

    private static Container container(@Nullable BlockEntity blockEntity) {
        return blockEntity instanceof TokamakControllerBlockEntity be
                ? be
                : new SimpleContainer(TokamakControllerBlockEntity.SLOT_COUNT);
    }

    public static TokamakMenu fromNetwork(int containerId, Inventory playerInventory,
                                          RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        return new TokamakMenu(containerId, playerInventory,
                playerInventory.player.level().getBlockEntity(pos));
    }

    @Override
    public void broadcastChanges() {
        if (this.controller != null) {
            this.values[DATA_STATUS] = this.controller.statusCode();
            this.values[DATA_FORMED] = this.controller.isFormed() ? 1 : 0;
            this.values[DATA_CASING] = this.controller.casingCount();
            this.values[DATA_COILS] = this.controller.coilCount();
            this.values[DATA_BLANKETS] = this.controller.blanketCount();
            this.values[DATA_INJECTORS] = this.controller.injectorCount();
            this.values[DATA_DIAGNOSTICS] = this.controller.diagnosticCount();
            this.values[DATA_COOLERS] = this.controller.coolerCount();
            this.values[DATA_LOGIC] = this.controller.logicCount();
            this.values[DATA_FUEL] = this.controller.fuelCount();
            this.values[DATA_TRITIUM] = this.controller.tritiumCount();
            this.values[DATA_IGNITION] = this.controller.ignitionPercent();
            this.values[DATA_FUEL_PERCENT] = this.controller.fuelPercent();
            this.values[DATA_WIRELESS] = this.controller.wirelessSent();
            this.values[DATA_PORTS] = this.controller.portsInRange();
            this.values[DATA_BREED_BLOCKED] = this.controller.breedBlocked() ? 1 : 0;
        }
        super.broadcastChanges();
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (id == BUTTON_IGNITE && this.controller != null) {
            boolean started = this.controller.ignite();
            this.broadcastChanges();
            return started;
        }
        return false;
    }

    // ------------------------------------------------------------------
    // 读数
    // ------------------------------------------------------------------

    public int status() {
        return this.values[DATA_STATUS];
    }

    public boolean isFormed() {
        return this.values[DATA_FORMED] != 0;
    }

    public int casing() {
        return this.values[DATA_CASING];
    }

    public int coils() {
        return this.values[DATA_COILS];
    }

    public int blankets() {
        return this.values[DATA_BLANKETS];
    }

    public int injectors() {
        return this.values[DATA_INJECTORS];
    }

    public int diagnostics() {
        return this.values[DATA_DIAGNOSTICS];
    }

    public int coolers() {
        return this.values[DATA_COOLERS];
    }

    public int logic() {
        return this.values[DATA_LOGIC];
    }

    public int fuel() {
        return this.values[DATA_FUEL];
    }

    public int tritium() {
        return this.values[DATA_TRITIUM];
    }

    public int ignitionPercent() {
        return this.values[DATA_IGNITION];
    }

    public int fuelPercent() {
        return this.values[DATA_FUEL_PERCENT];
    }

    public int wirelessSent() {
        return this.values[DATA_WIRELESS];
    }

    public int portsInRange() {
        return this.values[DATA_PORTS];
    }

    public boolean breedBlocked() {
        return this.values[DATA_BREED_BLOCKED] != 0;
    }

    // ------------------------------------------------------------------
    // 版式
    // ------------------------------------------------------------------

    @Override
    public int textY() {
        return MachineLayout.textY(0);
    }

    @Override
    public int inventoryLabelY() {
        return textY() + STAT_LINES * MachineLayout.TEXT_STEP + 3;
    }

    @Override
    public int inventoryY() {
        return inventoryLabelY() + 10;
    }

    @Override
    public int guiHeight() {
        return inventoryY() + 58 + 18 + 6;
    }

    /** 燃料格：只收氘氚燃料单元。 */
    public static class FuelSlot extends Slot {

        public FuelSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return stack.is(cn.blockforge.generated.aftercritical.registry.ModItems.DT_FUEL_CELL.get());
        }
    }
}
