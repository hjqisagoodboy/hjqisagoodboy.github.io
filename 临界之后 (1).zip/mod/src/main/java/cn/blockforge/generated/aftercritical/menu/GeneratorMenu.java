package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.AbstractGeneratorBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.EnergyMachineHost;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 两种发电机共用的 GUI 菜单：1 个燃料槽 + 玩家背包。
 *
 * <p>燃烧发电机和燃料棒发电机界面长得一样，只有方块实体和功率不同，
 * 所以这里做一个通用菜单，注册时给两个不同的菜单类型（打开时才知道是哪种）。
 */
public class GeneratorMenu extends AbstractMachineMenu {

    public static final int FUEL_X = 30;
    public static final int FUEL_Y = 30;

    /** 燃料 → 出电：箭头从燃料槽一路指向右边，箭杆里灌的就是这份燃料烧到哪了。 */
    public static final MachineLayout.Arrow ARROW = new MachineLayout.Arrow(54, 38, 66);

    public GeneratorMenu(MenuType<?> type, int containerId, Inventory playerInventory,
                         @Nullable EnergyMachineHost machine, Container container) {
        super(type, containerId, playerInventory, AbstractGeneratorBlockEntity.SLOT_COUNT, machine);
        this.addSlot(new FilteredSlot(container, AbstractGeneratorBlockEntity.SLOT_FUEL, FUEL_X, FUEL_Y));
        this.addPlayerInventory(playerInventory);
    }

    @Override
    public MachineLayout.Arrow arrowGeometry() {
        return ARROW;
    }

    /** 客户端收到「打开菜单」的包后调用。 */
    public static GeneratorMenu fromNetwork(MenuType<?> type, int containerId, Inventory playerInventory,
                                            RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof AbstractGeneratorBlockEntity generator) {
            return new GeneratorMenu(type, containerId, playerInventory, generator, generator);
        }
        return new GeneratorMenu(type, containerId, playerInventory, null,
                new SimpleContainer(AbstractGeneratorBlockEntity.SLOT_COUNT));
    }

    /** 燃料槽：只收方块实体认可的东西（燃烧发电机认煤/木板/原木，燃料棒发电机只认燃料棒）。 */
    public static class FilteredSlot extends Slot {

        public FilteredSlot(Container container, int slot, int x, int y) {
            super(container, slot, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return this.container.canPlaceItem(this.getContainerSlot(), stack);
        }
    }
}
