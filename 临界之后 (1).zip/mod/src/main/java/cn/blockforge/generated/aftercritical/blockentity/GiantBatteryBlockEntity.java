package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.energy.BufferedEnergyStorage;
import cn.blockforge.generated.aftercritical.energy.EnergyTransfer;
import cn.blockforge.generated.aftercritical.menu.GiantBatteryMenu;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.IEnergyStorage;

import javax.annotation.Nullable;

/**
 * 巨型储能库：一块方块能装 <b>1.2 亿 FE</b>，一炉 8 支燃料棒发的电（约 1.08 亿 FE）全塞得下。
 *
 * <p>为什么需要它：汽轮机发出的电如果没地方去，它就会停下不吃蒸汽；蒸汽一堵，
 * 压水堆的蒸汽罐满了就不再产汽，温度一路飙升。把这块电池挂在汽轮机旁边，
 * 电有地方存，蒸汽就能一直走下去。
 *
 * <p>充放都是 <b>20,000 FE/t</b>：一台汽轮机满功率 2,000 FE/t，十台同时充也吃得下。
 * 本模组不做线缆的话，它默认每 tick 从六个邻居抽电、再往六个邻居送电，
 * 所以直接贴着汽轮机、贴着机器摆就能用。
 */
public class GiantBatteryBlockEntity extends BlockEntity
        implements MenuProvider, EnergyMachineHost, TickableBlockEntity, EnergyStorable {

    /** 储能上限：1.2 亿 FE（一炉 8 支燃料棒约发 1.08 亿 FE，留约 10% 余量）。 */
    public static final int ENERGY_CAPACITY = 120_000_000;
    /** 每 tick 最多充进来多少 FE。 */
    public static final int MAX_RECEIVE_PER_TICK = 20_000;
    /** 每 tick 最多放出去多少 FE。 */
    public static final int MAX_OUTPUT_PER_TICK = 20_000;

    private final BatteryStatusTracker statusTracker = new BatteryStatusTracker();
    private final BufferedEnergyStorage energy = new BufferedEnergyStorage(
            ENERGY_CAPACITY, MAX_RECEIVE_PER_TICK, MAX_OUTPUT_PER_TICK, this::onEnergyChanged);
    private int status = STATUS_IDLE;

    public GiantBatteryBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.GIANT_BATTERY.get(), pos, state);
    }

    public IEnergyStorage getEnergyStorage() {
        return this.energy;
    }

    /** 能量一有变动就记一笔：不管是谁改的（直连邻居、线缆网、GUI），状态都跟着变。 */
    private void onEnergyChanged() {
        setChanged();
        long gameTime = this.level == null ? 0L : this.level.getGameTime();
        this.statusTracker.onEnergyChanged(this.energy.getEnergyStored(), gameTime);
    }

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        // 只和直连的方块打交道。线缆里的电交给 CableNetwork 整网调度：
        // 先供机器，剩下的才充电池；电池自己去抽线缆会「边充边放」，
        // 玩家看到的就是「接了线缆永远在放电」。
        EnergyTransfer.pullForCharging(this.level, this.worldPosition, this.energy, MAX_RECEIVE_PER_TICK);
        EnergyTransfer.pushToConsumers(this.level, this.worldPosition, this.energy, MAX_OUTPUT_PER_TICK);

        int newStatus = this.statusTracker.status(this.level.getGameTime());
        if (this.status != newStatus) {
            this.status = newStatus;
            setChanged();
        }
    }

    @Override
    public int getStoredEnergy() {
        return this.energy.getEnergyStored();
    }

    @Override
    public void setStoredEnergy(int value) {
        this.energy.setEnergy(value);
        this.statusTracker.reset(this.energy.getEnergyStored());
        setChanged();
    }

    // ------------------------------------------------------------------
    // 界面读数
    // ------------------------------------------------------------------

    @Override
    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    @Override
    public int getEnergyCapacity() {
        return this.energy.getMaxEnergyStored();
    }

    @Override
    public int getStatus() {
        return this.status;
    }

    @Override
    public int getProgress() {
        return 0;
    }

    @Override
    public int getMaxProgress() {
        return 0;
    }

    // ------------------------------------------------------------------
    // 没有物品槽的容器（菜单接口要用）
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return 0;
    }

    @Override
    public boolean isEmpty() {
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        return ItemStack.EMPTY;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.giant_battery");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new GiantBatteryMenu(containerId, playerInventory, this);
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
        tag.putInt("Status", this.status);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
        this.status = tag.getInt("Status");
        this.statusTracker.reset(this.energy.getEnergyStored());
    }
}
