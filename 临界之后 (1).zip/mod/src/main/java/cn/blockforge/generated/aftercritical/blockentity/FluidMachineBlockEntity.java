package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.block.FluidMachineBlock;
import cn.blockforge.generated.aftercritical.energy.MachineEnergyStorage;
import cn.blockforge.generated.aftercritical.energy.RatedEnergyConsumer;
import cn.blockforge.generated.aftercritical.fluid.TankGroup;
import cn.blockforge.generated.aftercritical.itemhandler.ContainerItemHandler;
import cn.blockforge.generated.aftercritical.item.UniversalTankItem;
import cn.blockforge.generated.aftercritical.menu.FluidMachineMenu;
import cn.blockforge.generated.aftercritical.recipe.AssemblerIngredient;
import cn.blockforge.generated.aftercritical.recipe.FluidAmount;
import cn.blockforge.generated.aftercritical.recipe.FluidProcessInput;
import cn.blockforge.generated.aftercritical.recipe.FluidProcessRecipe;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidActionResult;
import net.neoforged.neoforge.fluids.FluidUtil;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;
import net.neoforged.neoforge.items.IItemHandler;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 三台流体机器共用的方块实体：电解槽、化工厂、空气分离器。
 *
 * <p>它和装配机的区别是「原料和产物都可能是流体」：
 * <ul>
 *   <li>物品：最多 2 个输入槽 + 1 个输出槽；</li>
 *   <li>流体：进液罐和出液罐各有几个由型号决定（化工厂 3 进 2 出、电解槽 1 进 3 出，
 *       每个罐 4000 mB），进出都走 NeoForge 的 IFluidHandler，管道、储罐可以直接接上；</li>
 *   <li>手里拿装满的桶右键机器就能把液体灌进进液罐（水桶、硫酸桶）。</li>
 * </ul>
 *
 * <p>具体是哪台机器、吃哪一类配方，由方块决定，见 {@link FluidMachineKind}。
 */
public class FluidMachineBlockEntity extends BlockEntity
        implements Container, MenuProvider, EnergyMachineHost, TickableBlockEntity, FluidTankHost,
        RatedEnergyConsumer {

    /**
     * 每个罐的容量。
     *
     * <p>注意：一台机器到底有几个进液罐、几个出液罐，看型号说明书（{@link FluidMachineKind}），
     * 罐子数组是<b>按型号现分配</b>的，不在这里写死上限。
     * 以前这里写死「进 3 / 出 2」，而电解槽要 3 个出液罐，
     * 机器一放下、第一次刷新就数组越界崩了（Index 2 out of bounds for length 2）。
     */
    public static final int TANK_CAPACITY = 4000;

    /** 至少给机器留 2 个输入槽（不够用的机器空着），产物槽排在它们后面。 */
    public static final int MIN_ITEM_INPUT_SLOTS = 2;

    /**
     * 所有型号里最多有几根流体长条（目前是化工厂的 3 进 + 2 出 = 5，电解槽是 1 进 + 3 出 = 4）。
     *
     * <p>界面按这个数准备同步数组：哪台机器用不满就空着，加新型号也不会错位。
     * 数字直接从型号表里算出来，改型号时不用再回来同步这份常量。
     */
    public static final int MAX_JAR_SLOTS = maxTankRows();

    /** 型号表里「进液罐 + 出液罐」最多的那台有几根长条。 */
    private static int maxTankRows() {
        int max = 0;
        for (FluidMachineKind kind : FluidMachineKind.values()) {
            max = Math.max(max, kind.fluidInputTanks() + kind.fluidOutputTanks());
        }
        return max;
    }

    /** 每根长条两个槽：左边「操作槽」放罐子干活，右边「返还槽」放干完活的罐子。 */
    public static final int JAR_SLOTS_PER_TANK = 2;

    public static final int ENERGY_CAPACITY = 10_000;
    public static final int MAX_PULL_PER_TICK = 512;

    /** 这台机器有几根流体长条（进液 + 出液，最多 5 根）。 */
    public static int tankCount(FluidMachineKind kind) {
        return Math.min(MAX_JAR_SLOTS, kind.fluidInputTanks() + kind.fluidOutputTanks());
    }

    /**
     * 这台机器一共有几个物品槽。
     *
     * <p>2 个输入槽永远留着（不够用的机器就空着），产物从 2 号槽开始；
     * 大多数机器只有 1 个产物槽，离心萃取器要 3 个。
     * 罐子槽排在物品槽后面，所以「几进几出」变了也不会撞车。
     */
    public static int itemSlotCount(FluidMachineKind kind) {
        return inputSlotCount(kind) + Math.max(1, kind.itemOutputSlots());
    }

    /** 这台机器实际占几个输入槽（玻璃固化炉要 3 个，大部分机器 1~2 个）。 */
    public static int inputSlotCount(FluidMachineKind kind) {
        return Math.max(MIN_ITEM_INPUT_SLOTS, kind.itemInputSlots());
    }

    /** 第 {@code index} 个产物槽是几号槽。 */
    public static int outputSlot(FluidMachineKind kind, int index) {
        return inputSlotCount(kind) + index;
    }

    /** 第 {@code tankIndex} 根长条的「操作槽」是几号槽（放罐子进去干活）。 */
    public static int jarOpSlotIndex(FluidMachineKind kind, int tankIndex) {
        return itemSlotCount(kind) + tankIndex * JAR_SLOTS_PER_TANK;
    }

    /** 第 {@code tankIndex} 根长条的「返还槽」是几号槽（干完活的罐子在这里等玩家/管道来取）。 */
    public static int jarReturnSlotIndex(FluidMachineKind kind, int tankIndex) {
        return jarOpSlotIndex(kind, tankIndex) + 1;
    }

    /** 这台机器的容器一共几个槽（物品槽 + 罐子槽）。 */
    public static int slotCount(FluidMachineKind kind) {
        return itemSlotCount(kind) + tankCount(kind) * JAR_SLOTS_PER_TANK;
    }

    /** 这个槽是不是罐子槽（操作槽或返还槽）。 */
    public static boolean isJarSlot(FluidMachineKind kind, int slot) {
        return slot >= itemSlotCount(kind) && slot < slotCount(kind);
    }

    /** 这个槽是不是「操作槽」（能往里塞罐子）。 */
    public static boolean isJarOpSlot(FluidMachineKind kind, int slot) {
        return isJarSlot(kind, slot) && (slot - itemSlotCount(kind)) % JAR_SLOTS_PER_TANK == 0;
    }

    /** 这个槽是不是「返还槽」（只能往外拿）。 */
    public static boolean isJarReturnSlot(FluidMachineKind kind, int slot) {
        return isJarSlot(kind, slot) && (slot - itemSlotCount(kind)) % JAR_SLOTS_PER_TANK == 1;
    }

    /** 这个槽位对应几号长条；不是罐子槽返回 -1。 */
    public static int tankIndexOfJarSlot(FluidMachineKind kind, int slot) {
        return isJarSlot(kind, slot) ? (slot - itemSlotCount(kind)) / JAR_SLOTS_PER_TANK : -1;
    }

    /** 从方块状态认出这是哪台机器（构造里 super 跑完之前还不能 getBlockState）。 */
    public static FluidMachineKind kindOf(BlockState state) {
        return state.getBlock() instanceof FluidMachineBlock block
                ? block.kind()
                : FluidMachineKind.ELECTROLYZER;
    }

    private final MachineEnergyStorage energy =
            new MachineEnergyStorage(ENERGY_CAPACITY, MAX_PULL_PER_TICK, this::setChanged);
    private final NonNullList<ItemStack> items;
    /** 罐子数组的长度跟着型号走：电解槽 1 进 3 出、化工厂 3 进 2 出、干燥炉一个罐都没有。 */
    private final FluidTank[] inputTanks;
    private final FluidTank[] outputTanks;

    /**
     * 给物品管道用的物品接口。
     *
     * <p>能往这台机器用得着的输入槽塞原料、能往罐子槽塞空罐；
     * 只能从产物槽抽成品、从罐子槽抽走装好的罐子。
     */
    private final IItemHandler itemHandler = new ContainerItemHandler(this,
            slot -> (slot >= 0 && slot < kind().itemInputSlots()) || isJarOpSlot(kind(), slot),
            slot -> isOutputSlot(slot) || isJarReturnSlot(kind(), slot),
            slot -> getMaxStackSize());

    private int progress;
    private int maxProgress;
    private int status = STATUS_IDLE;

    /** 辐射污染剩余 tick：离心萃取器回收短寿命同位素时会漏辐射，要用双氧水擦掉。 */
    private int pollutionTicks;

    /** 一次回收造成的污染持续多久（2 分钟）。 */
    public static final int POLLUTION_DURATION = 2_400;
    /** 擦一次污染要耗多少 mB 双氧水。 */
    public static final int DECONTAMINATION_COST = 500;

    @Nullable
    private FluidProcessRecipe activeRecipe;

    public FluidMachineBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.FLUID_MACHINE.get(), pos, state);
        FluidMachineKind kind = kindOf(state);
        // 槽位数量跟着机器型号走（多数是 3 个物品槽，离心萃取器要多两格产物槽）
        this.items = NonNullList.withSize(slotCount(kind), ItemStack.EMPTY);
        // 罐子也按型号分配：声明了几个就造几个，声明和实际永远对得上
        this.inputTanks = new FluidTank[kind.fluidInputTanks()];
        for (int i = 0; i < this.inputTanks.length; i++) {
            this.inputTanks[i] = new FluidTank(TANK_CAPACITY);
        }
        this.outputTanks = new FluidTank[kind.fluidOutputTanks()];
        for (int i = 0; i < this.outputTanks.length; i++) {
            this.outputTanks[i] = new FluidTank(TANK_CAPACITY);
        }
    }

    /** 自己到底是电解槽还是化工厂，看方块。 */
    public FluidMachineKind kind() {
        return getBlockState().getBlock() instanceof FluidMachineBlock block
                ? block.kind()
                : FluidMachineKind.ELECTROLYZER;
    }

    public net.neoforged.neoforge.energy.IEnergyStorage getEnergyStorage() {
        return this.energy;
    }

    /** 线缆用它判断自己扛不扛得住：电解槽 40、化工厂 80、空气分离器 120 FE/t。 */
    @Override
    public int ratedEnergyPerTick() {
        return kind().energyPerTick();
    }

    /** 对外暴露的流体接口：进液罐能灌，出液罐能抽。 */
    public IFluidHandler getFluidHandler() {
        return this.fluidHandler;
    }

    /** 对外暴露的物品接口：物品管道从这里塞原料、抽成品。 */
    public IItemHandler getItemHandler() {
        return this.itemHandler;
    }

    private final IFluidHandler fluidHandler = new IFluidHandler() {
        @Override
        public int getTanks() {
            return inputTanks.length + outputTanks.length;
        }

        @Override
        public FluidStack getFluidInTank(int tank) {
            FluidTank fluidTank = tankAt(tank);
            return fluidTank == null ? FluidStack.EMPTY : fluidTank.getFluid();
        }

        @Override
        public int getTankCapacity(int tank) {
            return TANK_CAPACITY;
        }

        @Override
        public boolean isFluidValid(int tank, FluidStack stack) {
            return tank >= 0 && tank < inputTanks.length;
        }

        @Override
        public int fill(FluidStack resource, FluidAction action) {
            boolean execute = action.execute();
            int filled = TankGroup.insert(inputTanks, resource, execute);
            if (execute && filled > 0) {
                setChanged();
            }
            return filled;
        }

        @Override
        public FluidStack drain(FluidStack resource, FluidAction action) {
            for (int i = 0; i < outputTanks.length; i++) {
                FluidTank tank = outputTanks[i];
                if (tank.isEmpty() || !FluidStack.isSameFluidSameComponents(tank.getFluid(), resource)) {
                    continue;
                }
                FluidStack drained = tank.drain(Math.min(resource.getAmount(), tank.getFluidAmount()), action);
                if (!drained.isEmpty()) {
                    setChanged();
                }
                return drained;
            }
            return FluidStack.EMPTY;
        }

        @Override
        public FluidStack drain(int maxDrain, FluidAction action) {
            for (int i = 0; i < outputTanks.length; i++) {
                FluidTank tank = outputTanks[i];
                if (tank.isEmpty()) {
                    continue;
                }
                FluidStack drained = tank.drain(Math.min(maxDrain, tank.getFluidAmount()), action);
                if (!drained.isEmpty()) {
                    setChanged();
                }
                return drained;
            }
            return FluidStack.EMPTY;
        }
    };

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        pullEnergyFromNeighbours();
        serviceJars();
        pushOutputFluids();

        FluidProcessRecipe recipe = findRecipe();
        if (recipe != this.activeRecipe) {
            boolean restoredFromSave = this.activeRecipe == null && this.progress > 0;
            this.activeRecipe = recipe;
            this.maxProgress = recipe == null ? 0 : recipe.duration();
            if (!restoredFromSave) {
                this.progress = 0;
            }
            this.progress = Math.min(this.progress, this.maxProgress);
            setChanged();
        }

        boolean outputBlocked = recipe != null && !canOutput(recipe);
        boolean working = false;

        if (recipe != null && !outputBlocked) {
            // 普通机器只有 1 挡（电够就干）；地下水开采机按手里有多少电决定 1~4 挡
            int speed = speedFor(recipe.energyPerTick());
            if (speed > 0) {
                this.energy.consume(recipe.energyPerTick() * speed);
                this.progress += speed;
                working = true;
                while (this.progress >= this.maxProgress && this.maxProgress > 0) {
                    craft(recipe);
                    this.progress -= this.maxProgress;
                }
                setChanged();
            }
        }

        tickPollution();

        int newStatus;
        if (working) {
            newStatus = STATUS_RUNNING;
        } else if (recipe == null) {
            newStatus = machineLacksFluid() ? STATUS_NO_FLUID : STATUS_IDLE;
        } else if (outputBlocked) {
            newStatus = STATUS_OUTPUT_BLOCKED;
        } else {
            newStatus = STATUS_NO_ENERGY;
        }
        if (this.status != newStatus) {
            this.status = newStatus;
            setChanged();
        }
        spawnPoolParticles(working);
    }

    /**
     * 冷却池在跑的时候往水里冒一点辐射粒子。
     *
     * <p>只是好看：让玩家一眼看出「这个池子正在干活」，不影响任何数值。
     */
    private void spawnPoolParticles(boolean working) {
        if (!working || this.kind() != FluidMachineKind.IRRADIATION_POOL) {
            return;
        }
        if (this.level == null || this.level.getGameTime() % 8 != 0) {
            return;
        }
        if (this.level instanceof net.minecraft.server.level.ServerLevel server) {
            server.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,
                    this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.9,
                    this.worldPosition.getZ() + 0.5, 3, 0.35, 0.2, 0.35, 0.0);
        }
    }

    /**
     * 在配方表里找一条「物品、催化剂和流体都够」的配方。
     *
     * <p>注意：不能因为「什么都没放」就直接返回，空气分离器的配方本来就不吃任何原料。
     *
     * <p>好几条都能做的时候（比如电解槽里的水，既能走「水 → 氢 + 氧」，也能走「水 → 氘 + 氢 + 氧」），
     * 以前是「配方表先给我哪条就用哪条」，同一个机器重进世界都可能换产线。
     * 现在按固定规矩挑，结果永远一样：
     * <ol>
     *   <li>要的物品 / 流体原料条目多的优先——放了海带就走海带那条，不是水那条；</li>
     *   <li>原料一样多时，产物更全的优先；</li>
     *   <li>还分不出来就按配方 id 排序，保证每次选同一条。</li>
     * </ol>
     *
     * <p>「水 → 氘 + 氢 + 氧」现在多了一个 {@code catalyst}（钯合金膜），
     * 槽里没放膜这条压根匹配不上，所以水电解不会再「顺带出氘」，
     * 想产氘得自己把膜放进 2 号槽——这就是两条配方分开的办法。
     */
    @Nullable
    public FluidProcessRecipe findRecipe() {
        if (this.level == null) {
            return null;
        }
        FluidProcessInput input = snapshot();
        FluidProcessRecipe best = null;
        ResourceLocation bestId = null;
        for (RecipeHolder<FluidProcessRecipe> holder : this.level.getRecipeManager()
                .getAllRecipesFor(kind().recipeType())) {
            FluidProcessRecipe recipe = holder.value();
            if (!recipe.matches(input, this.level)) {
                continue;
            }
            ResourceLocation id = holder.id();
            if (best == null || isPreferred(recipe, id, best, bestId)) {
                best = recipe;
                bestId = id;
            }
        }
        return best;
    }

    /**
     * 两条配方都做得出来时，{@code candidate} 是不是更该被选（规矩见 {@link #findRecipe()}）。
     *
     * <p>催化剂不参与这里的比较：它只是「允许这条配方成立」的配件，不算原料。
     * 这样电解槽里同时有海带和钯合金膜时，仍然是「海带 → 钠 + 氯气」优先
     * （原料条目 2 比水的 1 多），玩家不用为了点海带特地去把膜拿下来。
     */
    private static boolean isPreferred(FluidProcessRecipe candidate, ResourceLocation candidateId,
                                       FluidProcessRecipe current, ResourceLocation currentId) {
        int candidateInputs = candidate.itemInputs().size() + candidate.fluidInputs().size();
        int currentInputs = current.itemInputs().size() + current.fluidInputs().size();
        if (candidateInputs != currentInputs) {
            return candidateInputs > currentInputs;
        }
        int candidateOutputs = candidate.itemOutputs().size() + candidate.fluidOutputs().size();
        int currentOutputs = current.itemOutputs().size() + current.fluidOutputs().size();
        if (candidateOutputs != currentOutputs) {
            return candidateOutputs > currentOutputs;
        }
        return candidateId.toString().compareTo(currentId.toString()) < 0;
    }

    /** 物品够了、只差流体的时候返回 true，界面会显示「缺流体」。 */
    private boolean machineLacksFluid() {
        if (this.level == null) {
            return false;
        }
        FluidProcessInput input = snapshot();
        if (input.isEmpty()) {
            return false;
        }
        for (RecipeHolder<FluidProcessRecipe> holder : this.level.getRecipeManager()
                .getAllRecipesFor(kind().recipeType())) {
            FluidProcessRecipe recipe = holder.value();
            // 只关心「要物品（或催化剂）的配方」：一条原料都不要的配方（空气分离器）没有「缺流体」这回事
            if (recipe.itemInputs().isEmpty() && recipe.catalyst().isEmpty()) {
                continue;
            }
            if (recipe.matchesItems(input) && recipe.matchesCatalyst(input) && !recipe.matchesFluids(input)) {
                return true;
            }
        }
        return false;
    }

    /** 把物品槽和进液罐打包成一份「原料快照」。 */
    private FluidProcessInput snapshot() {
        int inputs = inputSlotCount(kind());
        List<ItemStack> stacks = new ArrayList<>(inputs);
        for (int i = 0; i < inputs; i++) {
            stacks.add(this.items.get(i));
        }
        List<FluidStack> fluids = new ArrayList<>(this.inputTanks.length);
        for (FluidTank tank : this.inputTanks) {
            fluids.add(tank.getFluid());
        }
        return new FluidProcessInput(stacks, fluids);
    }

    /** 这个槽是不是产物槽。 */
    public boolean isOutputSlot(int slot) {
        return slot >= outputSlot(kind(), 0) && slot < itemSlotCount(kind());
    }

    /** 产物槽放得下这条配方的全部产物吗（多产物的机器要挨个找位置）。 */
    public boolean canOutput(FluidProcessRecipe recipe) {
        return placeItems(recipe, true) && hasRoomForFluids(recipe);
    }

    /**
     * 这一 tick 能用几倍功率干活。
     *
     * <p>普通机器：电够额定功率就是 1，不够就是 0。
     * 地下水开采机（{@link FluidMachineKind#maxSpeedMultiplier()} 大于 1）：
     * 缓存里有几份就干几份，最多 4 份——所以「电通得越多，水出得越快」，
     * 而每 200 mB 花掉的电始终一样多（一个周期固定是「配方 tick 数 × 30 FE」）。
     */
    private int speedFor(int costPerTick) {
        if (costPerTick <= 0) {
            return 0;
        }
        int available = this.energy.getEnergyStored() / costPerTick;
        return Math.max(0, Math.min(kind().maxSpeedMultiplier(), available));
    }

    /**
     * 产出的液体还有地方装吗。
     *
     * <p>只有声明了「攒满就停」的机器（地下水开采机）才检查：
     * 水攒满、旁边又没人来接时它会停机等玩家，而不是把电烧成白开水。
     * 其余机器保持老规矩：出液罐满了就排掉，免得阶段 0 没管道时卡死。
     */
    private boolean hasRoomForFluids(FluidProcessRecipe recipe) {
        if (!kind().stallsWhenFluidOutputFull()) {
            return true;
        }
        for (FluidAmount spec : recipe.fluidOutputs()) {
            if (!hasRoomForFluid(spec.stack())) {
                return false;
            }
        }
        return true;
    }

    /**
     * 出液罐里还塞得下这一份液体吗。
     *
     * <p>只问分配器「这种液体该进哪一罐」：它选中的那一罐已经满了，就算别的罐还空着，
     * 也不算「有地方」——同一种液体不拆两罐，这是规矩。
     */
    private boolean hasRoomForFluid(FluidStack stack) {
        if (stack.isEmpty()) {
            return true;
        }
        int index = TankGroup.targetOf(this.outputTanks, stack.getFluid());
        if (index < 0) {
            return false;
        }
        FluidTank tank = this.outputTanks[index];
        return tank.getCapacity() - tank.getFluidAmount() >= stack.getAmount();
    }

    /**
     * 把配方的物品产物往产物槽里放：先看哪个槽空着、或者已经有同一种东西没堆满。
     *
     * @param simulate true 只试算（返回能不能放下），false 真的放进去
     * @return 全部产物都放得下就返回 true
     */
    private boolean placeItems(FluidProcessRecipe recipe, boolean simulate) {
        // 先在槽位的副本上模拟一遍，任何一样放不下就整条不加工
        ItemStack[] slots = new ItemStack[itemSlotCount(kind())];
        for (int i = 0; i < slots.length; i++) {
            slots[i] = this.items.get(i).copy();
        }
        for (ItemStack result : recipe.itemOutputs()) {
            if (result.isEmpty()) {
                continue;
            }
            int target = -1;
            for (int slot = outputSlot(kind(), 0); slot < slots.length; slot++) {
                ItemStack existing = slots[slot];
                if (existing.isEmpty()) {
                    target = slot;
                    break;
                }
                int limit = Math.min(existing.getMaxStackSize(), result.getMaxStackSize());
                if (ItemStack.isSameItemSameComponents(existing, result)
                        && existing.getCount() + result.getCount() <= limit) {
                    target = slot;
                    break;
                }
            }
            if (target < 0) {
                return false;
            }
            if (slots[target].isEmpty()) {
                slots[target] = result.copy();
            } else {
                slots[target].grow(result.getCount());
            }
        }
        if (!simulate) {
            for (int i = 0; i < slots.length; i++) {
                this.items.set(i, slots[i]);
            }
        }
        return true;
    }

    /** 完成一次反应：扣物品、扣流体，吐物品、吐流体。 */
    private void craft(FluidProcessRecipe recipe) {
        int inputs = inputSlotCount(kind());
        boolean[] used = new boolean[inputs];
        // 空气分离机的碳分子筛和钯合金膜是常驻部件，验过「在槽里」就够了，不扣数量
        boolean eatItems = kind().consumesItemInputs();
        for (AssemblerIngredient spec : recipe.itemInputs()) {
            for (int i = 0; i < inputs; i++) {
                if (used[i]) {
                    continue;
                }
                ItemStack stack = this.items.get(i);
                if (spec.test(stack)) {
                    used[i] = true;
                    if (eatItems) {
                        stack.shrink(spec.count());
                        if (stack.isEmpty()) {
                            this.items.set(i, ItemStack.EMPTY);
                        }
                    }
                    break;
                }
            }
        }

        for (FluidAmount spec : recipe.fluidInputs()) {
            for (int i = 0; i < this.kind().fluidInputTanks(); i++) {
                FluidTank tank = this.inputTanks[i];
                if (spec.test(tank.getFluid())) {
                    tank.drain(spec.amount(), IFluidHandler.FluidAction.EXECUTE);
                    break;
                }
            }
        }

        placeItems(recipe, false);

        for (FluidAmount spec : recipe.fluidOutputs()) {
            storeOutput(spec.stack());
        }
        // 离心萃取器回收短寿命同位素会甩出一片放射性粉尘：机器周围 2 分钟内都有辐射
        if (this.kind() == FluidMachineKind.CENTRIFUGAL_EXTRACTOR && producesPlatinum(recipe)) {
            this.pollutionTicks = POLLUTION_DURATION;
            if (this.level instanceof net.minecraft.server.level.ServerLevel server) {
                server.sendParticles(net.minecraft.core.particles.ParticleTypes.SNEEZE,
                        this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 1.0,
                        this.worldPosition.getZ() + 0.5, 24, 1.5, 0.8, 1.5, 0.05);
            }
        }
        fireVitrificationAdvancement(recipe);
        setChanged();
    }

    /**
     * 玻璃固化炉两条工艺各烧出一次，就给附近玩家记一笔，结局成就靠这两笔。
     *
     * <p>两条配方长得几乎一样，区别只在原料：废液路线要灌 {@code 裂变产物废液}，
     * 同位素路线一点液体都不要、多要一个短寿命同位素。所以「要不要吃液体」就能分清是哪条。
     * 机器不知道是谁在玩，按距离给附近玩家记账（和伽马辐照器一个规矩）。
     */
    private void fireVitrificationAdvancement(FluidProcessRecipe recipe) {
        if (this.level == null || this.kind() != FluidMachineKind.VITRIFICATION_FURNACE) {
            return;
        }
        String event = recipe.fluidInputs().isEmpty()
                ? ModAdvancementTriggers.VITRIFY_ISOTOPE
                : ModAdvancementTriggers.VITRIFY_WASTE;
        ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 32.0, event);
    }

    /** 这条配方是不是「短寿命同位素 → 铂族金属 + 稀有同位素」那条回收配方。 */
    private boolean producesPlatinum(FluidProcessRecipe recipe) {
        for (ItemStack result : recipe.itemOutputs()) {
            if (result.is(cn.blockforge.generated.aftercritical.registry.ModItems.PLATINUM_GROUP_METAL.get())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 污染期间每 2 秒给周围 12 格内的玩家挂一次辐射，并冒一点绿烟。
     *
     * <p>玩家拿双氧水右键机器就能提前擦掉（见 {@link #handleFluidInteraction}）。
     */
    private void tickPollution() {
        if (this.pollutionTicks <= 0 || this.level == null) {
            return;
        }
        this.pollutionTicks--;
        if (this.pollutionTicks % 40 == 0 && this.level instanceof net.minecraft.server.level.ServerLevel server) {
            for (net.minecraft.world.entity.player.Player player : server.players()) {
                if (!cn.blockforge.generated.aftercritical.effect.RadiationProtection.isFullSuit(player)
                        && player.distanceToSqr(this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5,
                        this.worldPosition.getZ() + 0.5) <= 144.0D) {
                    player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                            cn.blockforge.generated.aftercritical.registry.ModEffects.RADIATION_CONTAMINATION,
                            10 * 20, 0));
                }
            }
            server.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,
                    this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 1.0,
                    this.worldPosition.getZ() + 0.5, 3, 1.2, 0.3, 1.2, 0.0);
        }
        if (this.pollutionTicks == 0) {
            setChanged();
        }
    }

    /** 这台机器现在被污染了吗。 */
    public boolean isPolluted() {
        return this.pollutionTicks > 0;
    }

    public int pollutionTicks() {
        return this.pollutionTicks;
    }

    /**
     * 把产出的流体塞进出液罐。
     *
     * <p>塞哪一罐由 {@link TankGroup} 决定：罐里已经有这种液体就还是它，否则用最前面那个空罐。
     * 所以一种液体永远只占一个罐，不会再出现「两个出液罐都是过氧化氢」；
     * 反过来，1 号罐装满了也不会把过氧化氢挤到 2 号罐去占坑。
     *
     * <p>出液罐满了又没有管道来接的时候，多出来的部分直接排掉——
     * 阶段 0 还没有管道和储罐，不排掉的话机器会一直卡住。
     */
    private void storeOutput(FluidStack stack) {
        TankGroup.insert(this.outputTanks, stack, true);
    }

    /** 把出液罐里的东西送给相邻的流体容器（下一轮的管道、储罐，或者别的模组的管道）。 */
    private void pushOutputFluids() {
        if (this.level == null) {
            return;
        }
        for (int i = 0; i < this.outputTanks.length; i++) {
            FluidTank tank = this.outputTanks[i];
            if (tank.isEmpty()) {
                continue;
            }
            for (Direction side : Direction.values()) {
                IFluidHandler sink = this.level.getCapability(Capabilities.FluidHandler.BLOCK,
                        this.worldPosition.relative(side), side.getOpposite());
                if (sink == null) {
                    continue;
                }
                FluidStack offered = tank.drain(tank.getFluidAmount(), IFluidHandler.FluidAction.SIMULATE);
                if (offered.isEmpty()) {
                    break;
                }
                int accepted = sink.fill(offered, IFluidHandler.FluidAction.EXECUTE);
                if (accepted > 0) {
                    tank.drain(accepted, IFluidHandler.FluidAction.EXECUTE);
                    setChanged();
                    break;
                }
            }
        }
    }

    /** 从六个方向挨个问邻居要电，能抽多少算多少。 */
    private void pullEnergyFromNeighbours() {
        if (this.level == null) {
            return;
        }
        int space = this.energy.getFreeSpace();
        if (space <= 0) {
            return;
        }
        int budget = Math.min(space, MAX_PULL_PER_TICK);
        for (Direction side : Direction.values()) {
            if (budget <= 0) {
                break;
            }
            net.neoforged.neoforge.energy.IEnergyStorage source = this.level.getCapability(
                    Capabilities.EnergyStorage.BLOCK, this.worldPosition.relative(side), side.getOpposite());
            if (source == null || !source.canExtract()) {
                continue;
            }
            int moved = source.extractEnergy(budget, true);
            if (moved <= 0) {
                continue;
            }
            moved = source.extractEnergy(moved, false);
            if (moved > 0) {
                this.energy.receiveEnergy(moved, false);
                budget -= moved;
            }
        }
    }

    // ------------------------------------------------------------------
    // 罐子槽：每根长条右边一对（操作槽 + 返还槽）
    // ------------------------------------------------------------------

    /**
     * 每 tick 处理每根长条右边那一对罐子槽：左边「操作」，右边「返还」。
     *
     * <p>规则（看操作槽里放的是什么罐子）：
     * <ul>
     *   <li><b>进液长条</b>（机器要吃的液体）：放<b>满罐</b> → 倒进长条，
     *       倒空的罐子变回空罐、自动挪到右边返还槽；</li>
     *   <li><b>出液长条</b>（机器产出的液体）：放<b>空罐</b> → 从长条里灌满，
     *       满罐自动挪到右边返还槽。</li>
     * </ul>
     *
     * <p>一叠罐子（最多 64 个）也是这么处理：每个 tick 处理一个，处理完的往返还槽叠。
     * 玩家只管往操作槽塞一叠空罐、从返还槽拿一叠满罐。
     *
     * <p>返还槽放不下（满了，或者里面是别的流体）时，操作槽里那个罐子先不动，
     * 等玩家/管道把返还槽清干净再继续——这样不会把罐子吞掉。
     */
    private void serviceJars() {
        int tankCount = getTankCount();
        for (int i = 0; i < tankCount; i++) {
            processJar(i);
        }
    }

    /** 处理第 {@code tankIndex} 根长条的操作槽。 */
    private void processJar(int tankIndex) {
        FluidTank tank = tankAt(tankIndex);
        if (tank == null) {
            return;
        }
        int opSlot = jarOpSlotIndex(kind(), tankIndex);
        int retSlot = jarReturnSlotIndex(kind(), tankIndex);
        if (tankIndex < this.kind().fluidInputTanks()) {
            // 灌进液罐：操作槽里的罐子也交给分配器，不认「它插在哪个槽」。
            // 于是三个槽各插一个水罐也只会把 1 号罐灌满，不会三罐全变水。
            FluidStack inJar = UniversalTankItem.getFluid(this.items.get(opSlot));
            if (inJar.isEmpty()) {
                return;
            }
            int target = findInputTankFor(inJar.getFluid());
            if (target < 0) {
                // 所有进液罐都被别的液体占着：罐子原地不动，等腾出来再倒，不会被吞
                return;
            }
            if (!JarSlotService.pour(this.inputTanks[target], this.items, opSlot, retSlot)) {
                return;
            }
            setChanged();
            return;
        }
        if (JarSlotService.fill(tank, this.items, opSlot, retSlot)) {
            setChanged();
        }
    }

    /** 界面里右键长条时用：拿到第 {@code index} 号长条。 */
    @Nullable
    public FluidTank tankForGui(int index) {
        return tankAt(index);
    }

    // ------------------------------------------------------------------
    // 手上拿着的容器：通用流体罐 / 原版桶
    // ------------------------------------------------------------------

    /**
     * 手持容器右键机器时的处理：
     * <ul>
     *   <li>通用流体罐（满的）→ 倒进进液长条；</li>
     *   <li>通用流体罐（空的）→ 从出液长条里装，装多少算多少；</li>
     *   <li>原版桶（水桶、岩浆桶、空桶）→ 走 NeoForge 的通用容器逻辑，灌进 / 舀出 1000 mB。</li>
     * </ul>
     *
     * @return 真的做了容器的操作就返回 true，方块就不用再开界面了
     */
    public boolean handleFluidInteraction(Player player, InteractionHand hand) {
        if (this.level == null) {
            return false;
        }
        ItemStack held = player.getItemInHand(hand);
        if (held.getItem() instanceof UniversalTankItem) {
            // 被辐射污染了：手里拿着双氧水就先擦地，不往机器里倒
            if (tryDecontaminate(player, hand, held)) {
                return true;
            }
            return useTankInHand(player, hand, held);
        }
        if (held.is(Items.BUCKET) || held.getItem() instanceof BucketItem) {
            return useBucket(player, hand, held);
        }
        return false;
    }

    /**
     * 拿双氧水擦污染：耗 500 mB，污染立刻清零。
     *
     * @return 真的擦了就返回 true
     */
    private boolean tryDecontaminate(Player player, InteractionHand hand, ItemStack held) {
        if (this.pollutionTicks <= 0) {
            return false;
        }
        FluidStack stored = UniversalTankItem.getFluid(held);
        if (stored.isEmpty() || !stored.getFluid().isSame(ModFluids.HYDROGEN_PEROXIDE.source.get())
                || stored.getAmount() < DECONTAMINATION_COST) {
            return false;
        }
        this.pollutionTicks = 0;
        swapOne(player, hand, held, UniversalTankItem.withFluid(held, stored.getFluid(),
                stored.getAmount() - DECONTAMINATION_COST));
        playSound(SoundEvents.BUCKET_EMPTY);
        setChanged();
        return true;
    }

    /** 手上拿着通用流体罐：空的就从出液长条装，满的就往进液长条倒。 */
    private boolean useTankInHand(Player player, InteractionHand hand, ItemStack held) {
        FluidStack stored = UniversalTankItem.getFluid(held);
        if (stored.isEmpty()) {
            FluidStack probe = getFluidHandler().drain(UniversalTankItem.CAPACITY,
                    IFluidHandler.FluidAction.SIMULATE);
            if (probe.isEmpty()) {
                return false;
            }
            FluidStack drained = getFluidHandler().drain(probe.getAmount(),
                    IFluidHandler.FluidAction.EXECUTE);
            if (drained.isEmpty()) {
                return false;
            }
            swapOne(player, hand, held,
                    UniversalTankItem.withFluid(held, drained.getFluid(), drained.getAmount()));
            playSound(SoundEvents.BUCKET_FILL);
            return true;
        }
        int accepted = getFluidHandler().fill(stored.copy(), IFluidHandler.FluidAction.SIMULATE);
        if (accepted <= 0) {
            return false;
        }
        int filled = getFluidHandler().fill(stored.copyWithAmount(accepted),
                IFluidHandler.FluidAction.EXECUTE);
        if (filled <= 0) {
            return false;
        }
        swapOne(player, hand, held,
                UniversalTankItem.withFluid(held, stored.getFluid(), stored.getAmount() - filled));
        playSound(SoundEvents.BUCKET_EMPTY);
        return true;
    }

    /** 原版桶：交给 NeoForge 的容器工具，水桶灌水、空桶舀液体都靠它。 */
    private boolean useBucket(Player player, InteractionHand hand, ItemStack held) {
        IFluidHandler handler = getFluidHandler();
        FluidActionResult action = held.is(Items.BUCKET)
                ? FluidUtil.tryFillContainer(held, handler, UniversalTankItem.CAPACITY, player, true)
                : FluidUtil.tryEmptyContainer(held, handler, UniversalTankItem.CAPACITY, player, true);
        ItemStack result = action.getResult();
        if (!action.isSuccess() || result.isEmpty() || ItemStack.isSameItemSameComponents(result, held)) {
            return false;
        }
        swapOne(player, hand, held, result);
        playSound(SoundEvents.BUCKET_FILL);
        return true;
    }

    private void playSound(net.minecraft.sounds.SoundEvent sound) {
        if (this.level != null) {
            this.level.playSound(null, this.worldPosition, sound, SoundSource.BLOCKS, 1.0F, 1.0F);
        }
    }

    /** 手上那一格换成 {@code replacement}：一叠的少一个、把新的塞回背包（塞不下就丢地上）。 */
    private static void swapOne(Player player, InteractionHand hand, ItemStack held, ItemStack replacement) {
        if (held.getCount() <= 1) {
            player.setItemInHand(hand, replacement);
            return;
        }
        held.shrink(1);
        if (!player.getInventory().add(replacement)) {
            player.drop(replacement, false);
        }
    }

    // ------------------------------------------------------------------
    // 界面数据
    // ------------------------------------------------------------------

    @Override
    public int getEnergyStored() {
        return this.energy.getEnergyStored();
    }

    @Override
    public int getEnergyCapacity() {
        return this.energy.getMaxEnergyStored();
    }

    @Override
    public int getStatus() {
        return this.status;
    }

    @Override
    public int getProgress() {
        return this.progress;
    }

    @Override
    public int getMaxProgress() {
        return this.maxProgress;
    }

    @Override
    public int getTankCount() {
        return this.inputTanks.length + this.outputTanks.length;
    }

    @Override
    public int getTankAmount(int index) {
        FluidTank tank = tankAt(index);
        return tank == null ? 0 : tank.getFluidAmount();
    }

    @Override
    public int getTankFluidId(int index) {
        FluidTank tank = tankAt(index);
        if (tank == null || tank.isEmpty()) {
            return -1;
        }
        int id = BuiltInRegistries.FLUID.getId(tank.getFluid().getFluid());
        return id <= 0 ? -1 : id;
    }

    @Override
    public int getTankCapacity() {
        return TANK_CAPACITY;
    }

    /**
     * 这种液体现在该进几号进液罐（界面、罐子槽、手持罐都问这里）。
     *
     * <p>罐里装着别的液体的罐不会被选中；罐子一空位置立刻让出来，所以换液体直接倒就行，
     * 不用再额外做什么「解除占用」的操作。
     *
     * @return 罐号；整组进液罐都装着别的液体就返回 -1。
     *         注意「这一种自己那一罐已经灌满」时仍然返回那一罐，只是灌进去 0 mB——
     *         不换罐，免得同一种液体被拆成两罐
     */
    public int findInputTankFor(Fluid fluid) {
        if (fluid == null) {
            return -1;
        }
        return TankGroup.targetOf(this.inputTanks, fluid);
    }

    /**
     * 这台机器现在还能不能收这种液体——「有罐子愿意接」就算能。
     *
     * <p>一台机器一种液体只进一个罐，所以这个判断和「是几号罐」无关。
     */
    public boolean canAcceptFluid(Fluid fluid) {
        return findInputTankFor(fluid) >= 0;
    }

    /**
     * 第 {@code index} 号罐：先把进液罐数完，再数出液罐。
     *
     * <p>界面、物品管道、流体管道都用同一套编号，越界一律返回 {@code null}
     * （以前这里拿着写死的上限去取数组，机器型号一多就穿帮）。
     */
    @Nullable
    private FluidTank tankAt(int index) {
        if (index < 0) {
            return null;
        }
        if (index < this.inputTanks.length) {
            return this.inputTanks[index];
        }
        int output = index - this.inputTanks.length;
        return output < this.outputTanks.length ? this.outputTanks[output] : null;
    }

    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new FluidMachineMenu(ModMenus.menuFor(kind()), containerId, playerInventory, kind(),
                this, this, this, this);
    }

    @Override
    public Component getDisplayName() {
        return kind().displayName();
    }

    // ------------------------------------------------------------------
    // 物品槽
    // ------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return this.items.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : this.items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return this.items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(this.items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(this.items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        this.items.set(slot, stack);
        stack.limitSize(getMaxStackSize(stack));
        setChanged();
    }

    /**
     * 输入槽只收原料（流体罐不算原料）；输出槽不能塞；
     * 操作槽只认通用流体罐，返还槽根本不能塞（里面是机器放好的成品罐）。
     */
    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        if (isJarSlot(kind(), slot)) {
            if (!isJarOpSlot(kind(), slot)) {
                return false;
            }
            int tank = tankIndexOfJarSlot(kind(), slot);
            return tank >= 0 && tank < getTankCount()
                    && stack.getItem() instanceof UniversalTankItem;
        }
        if (isOutputSlot(slot)) {
            return false;
        }
        if (slot < 0 || slot >= this.kind().itemInputSlots()) {
            return false;
        }
        return !(stack.getItem() instanceof UniversalTankItem);
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        this.items.clear();
    }

    // ------------------------------------------------------------------
    // 存档
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("Energy", this.energy.getEnergyStored());
        tag.putInt("Progress", this.progress);
        tag.putInt("MaxProgress", this.maxProgress);
        tag.putInt("Status", this.status);
        tag.putInt("Pollution", this.pollutionTicks);
        ContainerHelper.saveAllItems(tag, this.items, registries);

        CompoundTag tanks = new CompoundTag();
        for (int i = 0; i < this.inputTanks.length; i++) {
            tanks.put("In" + i, this.inputTanks[i].writeToNBT(registries, new CompoundTag()));
        }
        for (int i = 0; i < this.outputTanks.length; i++) {
            tanks.put("Out" + i, this.outputTanks[i].writeToNBT(registries, new CompoundTag()));
        }
        tag.put("Tanks", tanks);
        // 罐子归哪种液体只看「罐里装着什么」，所以认领不用另外存，读档自然就对
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.energy.setEnergy(tag.getInt("Energy"));
        this.progress = tag.getInt("Progress");
        this.maxProgress = tag.getInt("MaxProgress");
        this.status = tag.getInt("Status");
        this.pollutionTicks = tag.getInt("Pollution");
        ContainerHelper.loadAllItems(tag, this.items, registries);

        CompoundTag tanks = tag.getCompound("Tanks");
        for (int i = 0; i < this.inputTanks.length; i++) {
            this.inputTanks[i].readFromNBT(registries, tanks.getCompound("In" + i));
        }
        // 旧存档里电解槽只存过 Out0/Out1，第 3 个罐读不到就是空的，机器照常能用
        for (int i = 0; i < this.outputTanks.length; i++) {
            this.outputTanks[i].readFromNBT(registries, tanks.getCompound("Out" + i));
        }
        // 老存档里三个进液罐可能都装的是水、两个出液罐可能都是过氧化氢：
        // 并到编号小的那个罐，腾出来的罐立刻能用（装不下的部分留在原罐，不丢液体）
        boolean merged = TankGroup.mergeDuplicates(this.inputTanks, 0, this.inputTanks.length);
        merged |= TankGroup.mergeDuplicates(this.outputTanks, 0, this.outputTanks.length);
        if (merged) {
            setChanged();
        }
    }
}
