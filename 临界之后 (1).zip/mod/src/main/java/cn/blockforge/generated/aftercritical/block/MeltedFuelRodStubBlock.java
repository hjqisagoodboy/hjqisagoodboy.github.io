package cn.blockforge.generated.aftercritical.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * 插在土里的熔毁燃料棒：核爆之后从堆芯里被掀出来、一头扎进焦土的燃料棒残桩。
 *
 * <p>它<b>不是</b>掉落物，而是摆在世界里的一截实体方块：十字形模型、四个朝向，
 * 爆心周围随机插上几截，远看就是一片歪歪斜斜的废燃料棒。玩家用手就能掰下来，
 * 掰下来得到的是原本那个「熔毁的燃料棒」物品（掉落表里写死了）。
 *
 * <p>没有碰撞体积（跟花草一样能走过去），但有一点点红光，表示里面还在发热。
 */
public class MeltedFuelRodStubBlock extends Block {

    /** 插的方向：0~3，对应模型四分之一圈一转，让燃料棒歪得各有不同。 */
    public static final IntegerProperty ROTATION = IntegerProperty.create("rotation", 0, 3);

    /** 细长的一条：够点到，又不挡住视线。 */
    private static final VoxelShape SHAPE = Block.box(4.0, 0.0, 4.0, 12.0, 14.0, 12.0);

    public MeltedFuelRodStubBlock(Properties properties) {
        super(properties);
        registerDefaultState(this.stateDefinition.any().setValue(ROTATION, 0));
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return simpleCodec(MeltedFuelRodStubBlock::new);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ROTATION);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(ROTATION, randomRotation(context.getLevel().getRandom()));
    }

    /** 随机一个朝向（核爆程序撒燃料棒时也用它）。 */
    public static int randomRotation(RandomSource random) {
        return random.nextInt(4);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos,
                                  CollisionContext context) {
        return SHAPE;
    }
}
