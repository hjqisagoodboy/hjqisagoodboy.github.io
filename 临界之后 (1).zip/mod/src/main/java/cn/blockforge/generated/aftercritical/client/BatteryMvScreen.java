package cn.blockforge.generated.aftercritical.client;

import cn.blockforge.generated.aftercritical.menu.BatteryMvMenu;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** 电池 MV 的界面：只有一条大能量条 + 电量数字。 */
public class BatteryMvScreen extends AbstractMachineScreen<BatteryMvMenu> {

    public BatteryMvScreen(BatteryMvMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }
}
