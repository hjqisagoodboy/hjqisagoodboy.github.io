package cn.blockforge.generated.aftercritical.compat.jei;

import cn.blockforge.generated.aftercritical.AfterCritical;
import cn.blockforge.generated.aftercritical.blockentity.BallMillBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.CompactorBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.CrusherBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.ForgingPressBlockEntity;
import cn.blockforge.generated.aftercritical.blockentity.ItemMachineKind;
import cn.blockforge.generated.aftercritical.blockentity.ResearchReactorControllerBlockEntity;
import cn.blockforge.generated.aftercritical.recipe.AssemblerRecipe;
import cn.blockforge.generated.aftercritical.recipe.FluidProcessRecipe;
import cn.blockforge.generated.aftercritical.recipe.MachineRecipe;
import cn.blockforge.generated.aftercritical.registry.ModBlocks;
import cn.blockforge.generated.aftercritical.registry.ModRecipes;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.level.block.Block;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * 和 JEI（物品管理器）对接的总开关。
 *
 * <p>JEI 会自己在所有模组里找带 {@link JeiPlugin} 注解的类，所以只要装了这个类，
 * 「打开 JEI 能看到这台机器怎么用」就成立了——没装 JEI 的时候这个类根本不会被碰到，
 * 也就不会因为缺类而崩溃。
 *
 * <p>这里注册三件事：配方类别（左边的分页）、每类里的配方内容、以及「哪台机器能查这一页」。
 *
 * <p><b>以后加新机器只要改一张表</b>：在 {@link #machinePages()} 里加一行
 * {@code machine(配方页, 方块, 每 tick 耗电, 有没有模具)}，
 * 它的分页、配方列表、催化剂（在 JEI 里对着机器按 U 能查配方）三样就全都自动接上了，
 * 不需要再动下面三个注册方法。配方内容仍然直接从游戏自己的配方管理器读，
 * 所以机器和 JEI 看的永远是同一份数据，不会两边对不上。
 */
@JeiPlugin
public class AfterCriticalJeiPlugin implements IModPlugin {

    /** JEI 里各个配方页的编号（分页顺序就按注册顺序）。 */
    public static final RecipeType<MachineRecipe> CRUSHING =
            RecipeType.create(AfterCritical.MOD_ID, "crusher", MachineRecipe.class);
    public static final RecipeType<MachineRecipe> BALL_MILLING =
            RecipeType.create(AfterCritical.MOD_ID, "ball_mill", MachineRecipe.class);
    public static final RecipeType<MachineRecipe> FORGING =
            RecipeType.create(AfterCritical.MOD_ID, "forging_press", MachineRecipe.class);
    public static final RecipeType<MachineRecipe> COMPACTING =
            RecipeType.create(AfterCritical.MOD_ID, "compactor", MachineRecipe.class);
    /** 烧结炉：把芯块坯烧成烧结芯块。 */
    public static final RecipeType<MachineRecipe> SINTERING =
            RecipeType.create(AfterCritical.MOD_ID, "sintering", MachineRecipe.class);
    /** 磨削机：把烧结芯块磨到尺寸，顺便掉一点废粉。 */
    public static final RecipeType<MachineRecipe> GRINDING =
            RecipeType.create(AfterCritical.MOD_ID, "grinding", MachineRecipe.class);
    /** 焊接机：燃料棒 + 端塞 → 密封燃料棒。 */
    public static final RecipeType<MachineRecipe> WELDING =
            RecipeType.create(AfterCritical.MOD_ID, "welding", MachineRecipe.class);
    public static final RecipeType<AssemblerRecipe> ASSEMBLER =
            RecipeType.create(AfterCritical.MOD_ID, "assembler", AssemblerRecipe.class);
    /**
     * 装配机 T2 的单独分页。
     *
     * <p>以前两种装配机共用「装配机 T1」这一个分页，于是 T2 专属的配方（氟化反应器、
     * 高压线缆、变压器 MV→HV、级联控制器……）在 JEI 里全都挂在 T1 名下，玩家会以为 T1 能做。
     * 现在一级配方进 {@link #ASSEMBLER}，二级配方进这一页，点哪台机器就只看得到它做得出来的。
     */
    public static final RecipeType<AssemblerRecipe> ASSEMBLER_T2 =
            RecipeType.create(AfterCritical.MOD_ID, "assembler_t2", AssemblerRecipe.class);
    /** 装配机 T3 的分页：只有三级配方（伽马辐照器、研究堆控制器、热室机械臂……）。 */
    public static final RecipeType<AssemblerRecipe> ASSEMBLER_T3 =
            RecipeType.create(AfterCritical.MOD_ID, "assembler_t3", AssemblerRecipe.class);
    public static final RecipeType<FluidProcessRecipe> ELECTROLYSIS =
            RecipeType.create(AfterCritical.MOD_ID, "electrolysis", FluidProcessRecipe.class);
    public static final RecipeType<FluidProcessRecipe> CHEMICAL_PLANT =
            RecipeType.create(AfterCritical.MOD_ID, "chemical_plant", FluidProcessRecipe.class);
    public static final RecipeType<FluidProcessRecipe> AIR_SEPARATION =
            RecipeType.create(AfterCritical.MOD_ID, "air_separation", FluidProcessRecipe.class);
    /** 地下水开采机：不要原料，通电就出水。 */
    public static final RecipeType<FluidProcessRecipe> GROUNDWATER =
            RecipeType.create(AfterCritical.MOD_ID, "groundwater", FluidProcessRecipe.class);
    public static final RecipeType<FluidProcessRecipe> LEACHING =
            RecipeType.create(AfterCritical.MOD_ID, "leaching", FluidProcessRecipe.class);
    public static final RecipeType<FluidProcessRecipe> PRECIPITATION =
            RecipeType.create(AfterCritical.MOD_ID, "precipitation", FluidProcessRecipe.class);
    public static final RecipeType<FluidProcessRecipe> DRYING =
            RecipeType.create(AfterCritical.MOD_ID, "drying", FluidProcessRecipe.class);
    public static final RecipeType<FluidProcessRecipe> CONVERSION =
            RecipeType.create(AfterCritical.MOD_ID, "conversion", FluidProcessRecipe.class);
    public static final RecipeType<FluidProcessRecipe> FLUORINATION =
            RecipeType.create(AfterCritical.MOD_ID, "fluorination", FluidProcessRecipe.class);
    public static final RecipeType<FluidProcessRecipe> CENTRIFUGE =
            RecipeType.create(AfterCritical.MOD_ID, "centrifuge", FluidProcessRecipe.class);
    public static final RecipeType<FluidProcessRecipe> HYDROLYSIS =
            RecipeType.create(AfterCritical.MOD_ID, "hydrolysis", FluidProcessRecipe.class);
    /** 伽马辐照器：要照的东西 + 钴60源 → 照完的东西。 */
    public static final RecipeType<MachineRecipe> GAMMA =
            RecipeType.create(AfterCritical.MOD_ID, "gamma_irradiation", MachineRecipe.class);
    /** 研究堆辐照孔道：靶材 → 辐照靶。 */
    public static final RecipeType<MachineRecipe> IRRADIATION =
            RecipeType.create(AfterCritical.MOD_ID, "irradiation", MachineRecipe.class);
    /** 辐照靶冷却池：辐照靶 + 水 → 冷却的靶材。 */
    public static final RecipeType<FluidProcessRecipe> COOLING =
            RecipeType.create(AfterCritical.MOD_ID, "cooling", FluidProcessRecipe.class);
    /** 热室机械臂：冷却的靶材 → 同位素。 */
    public static final RecipeType<MachineRecipe> HOT_CELL =
            RecipeType.create(AfterCritical.MOD_ID, "hot_cell", MachineRecipe.class);
    /** 冷凝器：乏蒸汽 → 水。 */
    public static final RecipeType<FluidProcessRecipe> CONDENSATION =
            RecipeType.create(AfterCritical.MOD_ID, "condensation", FluidProcessRecipe.class);
    /** 乏燃料冷却池：乏燃料组件 + 水 → 冷却的乏燃料组件。 */
    public static final RecipeType<FluidProcessRecipe> SPENT_FUEL_COOLING =
            RecipeType.create(AfterCritical.MOD_ID, "spent_fuel_cooling", FluidProcessRecipe.class);
    /** 剪切机：冷却的乏燃料组件 → 乏燃料碎块 + 空框架。 */
    public static final RecipeType<MachineRecipe> SHEARING =
            RecipeType.create(AfterCritical.MOD_ID, "shearing", MachineRecipe.class);
    /** 溶解槽：乏燃料碎块 + 硝酸 → 溶解液 + 壳渣。 */
    public static final RecipeType<FluidProcessRecipe> DISSOLUTION =
            RecipeType.create(AfterCritical.MOD_ID, "dissolution", FluidProcessRecipe.class);
    /** 萃取柱：溶解液 + TBP → 铀钚萃取液 + 裂变产物废液。 */
    public static final RecipeType<FluidProcessRecipe> EXTRACTION =
            RecipeType.create(AfterCritical.MOD_ID, "extraction", FluidProcessRecipe.class);
    /** 离心萃取器：萃取液 → 钚239 + 回收铀；废液 → 锶 / 铯 / 锕系。 */
    public static final RecipeType<FluidProcessRecipe> FISSION_SEPARATION =
            RecipeType.create(AfterCritical.MOD_ID, "fission_separation", FluidProcessRecipe.class);
    /** 核装置总装台：核弹本体 + 全部模块化组件。 */
    public static final RecipeType<MachineRecipe> WARHEAD_ASSEMBLY =
            RecipeType.create(AfterCritical.MOD_ID, "warhead_assembly", MachineRecipe.class);
    /** 玻璃固化炉：废液 + 玻璃 + 铅板 → 固化玻璃。 */
    public static final RecipeType<FluidProcessRecipe> VITRIFICATION =
            RecipeType.create(AfterCritical.MOD_ID, "vitrification", FluidProcessRecipe.class);

    /** 汽轮发电机：蒸汽 → 乏蒸汽 + 电（不是 Minecraft 配方，只是 JEI 展示条目）。 */
    public static final RecipeType<SteamGeneratorRecipeCategory.Entry> STEAM_GENERATION =
            RecipeType.create(AfterCritical.MOD_ID, "steam_generation",
                    SteamGeneratorRecipeCategory.Entry.class);

    /** 托卡马克的多方块预览（一层一条）。 */
    public static final RecipeType<MultiblockPreviewCategory.Entry> TOKAMAK_PREVIEW =
            RecipeType.create(AfterCritical.MOD_ID, "tokamak_preview",
                    MultiblockPreviewCategory.Entry.class);
    /** 物质嬗变器的多方块预览（一层一条）。 */
    public static final RecipeType<MultiblockPreviewCategory.Entry> TRANSMUTATOR_PREVIEW =
            RecipeType.create(AfterCritical.MOD_ID, "transmutator_preview",
                    MultiblockPreviewCategory.Entry.class);
    /** 物质嬗变：锕系元素 + 1,000,000 FE → 短寿命同位素（不是配方，是固定展示条目）。 */
    public static final RecipeType<TransmutationRecipeCategory.Entry> TRANSMUTATION =
            RecipeType.create(AfterCritical.MOD_ID, "transmutation",
                    TransmutationRecipeCategory.Entry.class);

    /** 一台矿机类机器在 JEI 里的登记项。 */
    private record MachinePage(RecipeType<MachineRecipe> jeiType,
                               net.minecraft.world.item.crafting.RecipeType<MachineRecipe> vanillaType,
                               Block block, int energyPerTick, boolean showsMold) {
    }

    /** 一台流体机器在 JEI 里的登记项。{@code hintKey} 不为空时，那一页底部多写一句提示。 */
    private record FluidPage(RecipeType<FluidProcessRecipe> jeiType,
                             net.minecraft.world.item.crafting.RecipeType<FluidProcessRecipe> vanillaType,
                             Block block, @Nullable String hintKey) {
    }

    /** 一个「单进多出式」机器（有输入槽、输出槽、可选模具槽）。 */
    private static MachinePage machine(RecipeType<MachineRecipe> jeiType,
                                       net.minecraft.world.item.crafting.RecipeType<MachineRecipe> vanillaType,
                                       Block block, int energyPerTick, boolean showsMold) {
        return new MachinePage(jeiType, vanillaType, block, energyPerTick, showsMold);
    }

    /**
     * 全部「单进多出式」机器，一张表管到底。
     *
     * <p>加新机器：在 {@link ModRecipes} 里注册配方类型 → 在 {@link ModBlocks} 里注册方块 →
     * 在这张表里加一行。
     */
    private static List<MachinePage> machinePages() {
        return List.of(
                machine(CRUSHING, ModRecipes.CRUSHING, ModBlocks.CRUSHER.get(),
                        CrusherBlockEntity.ENERGY_PER_TICK, false),
                machine(BALL_MILLING, ModRecipes.BALL_MILLING, ModBlocks.BALL_MILL.get(),
                        BallMillBlockEntity.ENERGY_PER_TICK, false),
                machine(FORGING, ModRecipes.FORGING, ModBlocks.FORGING_PRESS.get(),
                        ForgingPressBlockEntity.ENERGY_PER_TICK, true),
                machine(COMPACTING, ModRecipes.COMPACTING, ModBlocks.COMPACTOR.get(),
                        CompactorBlockEntity.ENERGY_PER_TICK, false),
                // 阶段 2 的燃料制造链：烧结炉、磨削机、焊接机
                machine(SINTERING, ModRecipes.SINTERING, ModBlocks.SINTERING_FURNACE.get(),
                        ItemMachineKind.SINTERING_FURNACE.energyPerTick(), false),
                machine(GRINDING, ModRecipes.GRINDING, ModBlocks.GRINDING_MACHINE.get(),
                        ItemMachineKind.GRINDING_MACHINE.energyPerTick(), false),
                machine(WELDING, ModRecipes.WELDING, ModBlocks.WELDING_MACHINE.get(),
                        ItemMachineKind.WELDING_MACHINE.energyPerTick(), false),
                // 阶段 4：伽马辐照器 + 研究堆辐照孔道
                machine(GAMMA, ModRecipes.GAMMA, ModBlocks.GAMMA_IRRADIATOR.get(),
                        ItemMachineKind.GAMMA_IRRADIATOR.energyPerTick(), false),
                machine(IRRADIATION, ModRecipes.IRRADIATION,
                        ModBlocks.RESEARCH_REACTOR_CONTROLLER.get(),
                        ResearchReactorControllerBlockEntity.ENERGY_PER_TICK, false),
                // 阶段 6：剪切机（冷却的乏燃料组件 → 碎块 + 空框架）
                machine(SHEARING, ModRecipes.SHEARING, ModBlocks.SHEARING_MACHINE.get(),
                        ItemMachineKind.SHEARING_MACHINE.energyPerTick(), false),
                // 阶段 5：热室机械臂（冷却的靶材 → 同位素）
                machine(HOT_CELL, ModRecipes.HOT_CELL, ModBlocks.HOT_CELL_ARM.get(),
                        cn.blockforge.generated.aftercritical.blockentity.HotCellArmBlockEntity.ENERGY_PER_TICK,
                        false),
                // 武器线：核装置总装台（核弹本体 + 全部模块化组件）
                machine(WARHEAD_ASSEMBLY, ModRecipes.WARHEAD_ASSEMBLY, ModBlocks.WARHEAD_ASSEMBLER.get(),
                        ItemMachineKind.WARHEAD_ASSEMBLY.energyPerTick(), false));
    }

    /**
     * 全部流体机器（电解槽、化工厂、空气分离器，以及阶段 1 的五台），同样是一张表。
     *
     * <p>加新流体机器：注册配方类型 → 注册方块 → 在 {@link FluidMachineKind} 里加一行 →
     * 在这张表里加一行，JEI 分页、配方列表、催化剂就自动齐了。
     */
    private static List<FluidPage> fluidPages() {
        return List.of(
                new FluidPage(ELECTROLYSIS, ModRecipes.ELECTROLYSIS, ModBlocks.ELECTROLYZER.get(), null),
                new FluidPage(CHEMICAL_PLANT, ModRecipes.CHEMICAL_PLANT, ModBlocks.CHEMICAL_PLANT.get(), null),
                // 空气分离机要放两个「常驻部件」：碳分子筛 + 钯合金膜，不消耗
                new FluidPage(AIR_SEPARATION, ModRecipes.AIR_SEPARATION, ModBlocks.AIR_SEPARATOR.get(),
                        "jei.aftercritical.air_separation.info"),
                // 唯一一台功率可变的机器：这一页底下说明「电越多水越快」和具体数值
                new FluidPage(GROUNDWATER, ModRecipes.GROUNDWATER, ModBlocks.GROUNDWATER_PUMP.get(),
                        "jei.aftercritical.groundwater.info"),
                new FluidPage(LEACHING, ModRecipes.LEACHING, ModBlocks.LEACHING_TANK.get(), null),
                new FluidPage(PRECIPITATION, ModRecipes.PRECIPITATION, ModBlocks.PRECIPITATION_TANK.get(), null),
                new FluidPage(DRYING, ModRecipes.DRYING, ModBlocks.DRYING_OVEN.get(), null),
                new FluidPage(CONVERSION, ModRecipes.CONVERSION, ModBlocks.CONVERTER.get(), null),
                new FluidPage(FLUORINATION, ModRecipes.FLUORINATION, ModBlocks.FLUORINATION_REACTOR.get(), null),
                // 离心机单台就是 200 FE/t，真正跑起来是一整排，这一页底下给一句电网规模的提示
                new FluidPage(CENTRIFUGE, ModRecipes.CENTRIFUGE, ModBlocks.GAS_CENTRIFUGE.get(),
                        "jei.aftercritical.centrifuge.power_hint"),
                new FluidPage(HYDROLYSIS, ModRecipes.HYDROLYSIS, ModBlocks.HYDROLYSIS_REACTOR.get(), null),
                new FluidPage(COOLING, ModRecipes.COOLING, ModBlocks.IRRADIATION_POOL.get(),
                        "jei.aftercritical.cooling.hint"),
                new FluidPage(CONDENSATION, ModRecipes.CONDENSATION, ModBlocks.CONDENSER.get(),
                        "jei.aftercritical.condenser.info"),
                // 阶段 6：乏燃料后处理线的五台
                new FluidPage(SPENT_FUEL_COOLING, ModRecipes.SPENT_FUEL_COOLING,
                        ModBlocks.SPENT_FUEL_POOL.get(), "jei.aftercritical.spent_fuel_cooling.hint"),
                new FluidPage(DISSOLUTION, ModRecipes.DISSOLUTION, ModBlocks.DISSOLUTION_TANK.get(), null),
                new FluidPage(EXTRACTION, ModRecipes.EXTRACTION, ModBlocks.EXTRACTION_COLUMN.get(), null),
                new FluidPage(FISSION_SEPARATION, ModRecipes.FISSION_SEPARATION,
                        ModBlocks.CENTRIFUGAL_EXTRACTOR.get(), null),
                new FluidPage(VITRIFICATION, ModRecipes.VITRIFICATION,
                        ModBlocks.VITRIFICATION_FURNACE.get(), null));
    }

    @Override
    public ResourceLocation getPluginUid() {
        return ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "jei");
    }

    @Override
    public void registerCategories(IRecipeCategoryRegistration registration) {
        IGuiHelper guiHelper = registration.getJeiHelpers().getGuiHelper();
        for (MachinePage page : machinePages()) {
            registration.addRecipeCategories(new MachineRecipeCategory(guiHelper, page.jeiType(),
                    title(page.block()), page.block(), page.energyPerTick(), page.showsMold()));
        }
        registration.addRecipeCategories(new AssemblerRecipeCategory(guiHelper, ASSEMBLER,
                title(ModBlocks.ASSEMBLER_T1.get()), ModBlocks.ASSEMBLER_T1.get()));
        registration.addRecipeCategories(new AssemblerRecipeCategory(guiHelper, ASSEMBLER_T2,
                title(ModBlocks.ASSEMBLER_T2.get()), ModBlocks.ASSEMBLER_T2.get()));
        registration.addRecipeCategories(new AssemblerRecipeCategory(guiHelper, ASSEMBLER_T3,
                title(ModBlocks.ASSEMBLER_T3.get()), ModBlocks.ASSEMBLER_T3.get()));
        for (FluidPage page : fluidPages()) {
            registration.addRecipeCategories(new FluidProcessRecipeCategory(guiHelper, page.jeiType(),
                    title(page.block()), page.block(), page.hintKey()));
        }
        registration.addRecipeCategories(new SteamGeneratorRecipeCategory(guiHelper, STEAM_GENERATION,
                title(ModBlocks.STEAM_GENERATOR.get()), ModBlocks.STEAM_GENERATOR.get()));
        // 阶段 7：结构预览 + 嬗变展示
        registration.addRecipeCategories(new MultiblockPreviewCategory(guiHelper, TOKAMAK_PREVIEW,
                Component.translatable("jei.aftercritical.tokamak.preview"), ModBlocks.TOKAMAK_CONTROLLER.get()));
        registration.addRecipeCategories(new MultiblockPreviewCategory(guiHelper, TRANSMUTATOR_PREVIEW,
                Component.translatable("jei.aftercritical.transmutator.preview"),
                ModBlocks.TRANSMUTATOR_CONTROLLER.get()));
        registration.addRecipeCategories(new TransmutationRecipeCategory(guiHelper, TRANSMUTATION,
                Component.translatable("jei.aftercritical.transmutation"), ModBlocks.TRANSMUTATOR_CONTROLLER.get()));
    }

    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        addInfoPages(registration);
        // 汽轮发电机是「蒸汽 → 电」的固定换算，没有数据包配方，直接给 JEI 一条展示条目
        registration.addRecipes(STEAM_GENERATION, List.of(
                new SteamGeneratorRecipeCategory.Entry(
                        cn.blockforge.generated.aftercritical.blockentity.SteamGeneratorBlockEntity
                                .STEAM_PER_TICK * 20,
                        cn.blockforge.generated.aftercritical.blockentity.SteamGeneratorBlockEntity
                                .STEAM_PER_TICK * 20,
                        cn.blockforge.generated.aftercritical.blockentity.SteamGeneratorBlockEntity
                                .OUTPUT_PER_TICK)));
        // 阶段 7：托卡马克 / 嬗变器一层一层的结构预览，以及嬗变换算
        registration.addRecipes(TOKAMAK_PREVIEW, MultiblockPreviewCategory.tokamakLayers());
        registration.addRecipes(TRANSMUTATOR_PREVIEW, MultiblockPreviewCategory.transmutatorLayers());
        registration.addRecipes(TRANSMUTATION, List.of(new TransmutationRecipeCategory.Entry(
                new ItemStack(cn.blockforge.generated.aftercritical.registry.ModItems.ACTINIDES.get()),
                new ItemStack(cn.blockforge.generated.aftercritical.registry.ModItems
                        .SHORT_LIVED_ISOTOPE.get()),
                cn.blockforge.generated.aftercritical.blockentity.TransmutatorControllerBlockEntity.COST,
                cn.blockforge.generated.aftercritical.blockentity.TransmutatorControllerBlockEntity.DURATION
                        / 20)));
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            return;
        }
        RecipeManager manager = level.getRecipeManager();
        for (MachinePage page : machinePages()) {
            add(registration, page.jeiType(), page.vanillaType(), manager);
        }
        add(registration, ASSEMBLER, ModRecipes.ASSEMBLER, manager, 1);
        add(registration, ASSEMBLER_T2, ModRecipes.ASSEMBLER, manager, 2);
        add(registration, ASSEMBLER_T3, ModRecipes.ASSEMBLER, manager, 3);
        for (FluidPage page : fluidPages()) {
            add(registration, page.jeiType(), page.vanillaType(), manager);
        }
    }

    /**
     * 阶段 3 的多方块控制器在 JEI 里的「信息页」。
     *
     * <p>JEI 没有通用的多方块预览接口，所以这里用文字把结构尺寸、材料数量、物理公式和操作方式写清楚，
     * 玩家在 JEI 里对着控制器按 R 就能看到——比翻聊天记录靠谱。
     */
    private static void addInfoPages(IRecipeRegistration registration) {
        addResearchReactorInfo(registration);
        registration.addItemStackInfo(new ItemStack(ModBlocks.SUBCRITICAL_CONTROLLER.get()),
                Component.translatable("jei.aftercritical.reactor.build"),
                Component.translatable("jei.aftercritical.subcritical.structure"),
                Component.translatable("jei.aftercritical.subcritical.physics"),
                Component.translatable("jei.aftercritical.subcritical.flux"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.CRITICAL_REACTOR_CONTROLLER.get()),
                Component.translatable("jei.aftercritical.reactor.build"),
                Component.translatable("jei.aftercritical.critical.structure"),
                Component.translatable("jei.aftercritical.critical.physics"),
                Component.translatable("jei.aftercritical.critical.control"),
                Component.translatable("jei.aftercritical.critical.meltdown"));
        registration.addItemStackInfo(new ItemStack(cn.blockforge.generated.aftercritical.registry.ModItems
                        .NEUTRON_SOURCE.get()),
                Component.translatable("tooltip.aftercritical.neutron_source"));
        registration.addItemStackInfo(new ItemStack(cn.blockforge.generated.aftercritical.registry.ModItems
                        .CONTROL_ROD.get()),
                Component.translatable("tooltip.aftercritical.control_rod"));
    }

    /** 研究堆是多方块，JEI 没有通用的结构预览，这里用文字把尺寸和材料写清楚。 */
    private static void addResearchReactorInfo(IRecipeRegistration registration) {
        registration.addItemStackInfo(new ItemStack(ModBlocks.RESEARCH_REACTOR_CONTROLLER.get()),
                Component.translatable("jei.aftercritical.research.build"),
                Component.translatable("jei.aftercritical.research.structure"),
                Component.translatable("jei.aftercritical.research.materials"),
                Component.translatable("jei.aftercritical.research.run"));

        // 阶段 5：压水堆同样用文字说明结构、端口和玩法
        registration.addItemStackInfo(new ItemStack(ModBlocks.PWR_CONTROLLER.get()),
                Component.translatable("jei.aftercritical.pwr.build"),
                Component.translatable("jei.aftercritical.pwr.structure"),
                Component.translatable("jei.aftercritical.pwr.ports"),
                Component.translatable("jei.aftercritical.pwr.run"),
                Component.translatable("jei.aftercritical.pwr.heat"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.STEAM_GENERATOR.get()),
                Component.translatable("jei.aftercritical.steam.info"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.CONDENSER.get()),
                Component.translatable("jei.aftercritical.condenser.info"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.COOLING_TOWER.get()),
                Component.translatable("block.aftercritical.cooling_tower.desc"));
        registration.addItemStackInfo(new ItemStack(
                        cn.blockforge.generated.aftercritical.registry.ModItems.HOT_CELL_ARM.get()),
                Component.translatable("jei.aftercritical.hot_cell.hint"),
                Component.translatable("tooltip.aftercritical.hot_cell_arm.hazard"));

        // 阶段 6：后处理线 + 快堆
        registration.addItemStackInfo(new ItemStack(ModBlocks.SPENT_FUEL_POOL.get()),
                Component.translatable("jei.aftercritical.spent_fuel_cooling.hint"),
                Component.translatable("jei.aftercritical.reprocess.chain"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.SHEARING_MACHINE.get()),
                Component.translatable("jei.aftercritical.reprocess.chain"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.VITRIFICATION_FURNACE.get()),
                Component.translatable("jei.aftercritical.vitrification.info"));
        registration.addItemStackInfo(new ItemStack(
                        cn.blockforge.generated.aftercritical.registry.ModItems.MOX_FUEL_ASSEMBLY.get()),
                Component.translatable("jei.aftercritical.mox.chain"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.FAST_REACTOR_CONTROLLER.get()),
                Component.translatable("jei.aftercritical.fast.build"),
                Component.translatable("jei.aftercritical.fast.structure"),
                Component.translatable("jei.aftercritical.fast.parts"),
                Component.translatable("jei.aftercritical.fast.run"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.SODIUM_STEAM_GENERATOR.get()),
                Component.translatable("jei.aftercritical.fast.generator"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.FAST_NEUTRON_DETECTOR.get()),
                Component.translatable("block.aftercritical.fast_neutron_detector.desc"));
        registration.addItemStackInfo(new ItemStack(
                        cn.blockforge.generated.aftercritical.registry.ModItems.FAST_SPENT_ASSEMBLY.get()),
                Component.translatable("jei.aftercritical.fast.spent"));

        // 阶段 7：聚变与终局
        registration.addItemStackInfo(new ItemStack(ModBlocks.TOKAMAK_CONTROLLER.get()),
                Component.translatable("jei.aftercritical.tokamak.build"),
                Component.translatable("jei.aftercritical.tokamak.parts"),
                Component.translatable("jei.aftercritical.tokamak.run"),
                Component.translatable("jei.aftercritical.tokamak.wireless"),
                Component.translatable("jei.aftercritical.tokamak.breeding"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.TRANSMUTATOR_CONTROLLER.get()),
                Component.translatable("jei.aftercritical.transmutator.build"),
                Component.translatable("jei.aftercritical.transmutator.run"),
                Component.translatable("jei.aftercritical.transmutator.ending_a"),
                Component.translatable("jei.aftercritical.transmutator.ending_b"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.ENERGY_PORT.get()),
                Component.translatable("jei.aftercritical.energy_port.info"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.GEOLOGIC_REPOSITORY.get()),
                Component.translatable("jei.aftercritical.repository.info"),
                Component.translatable("jei.aftercritical.repository.clean"),
                Component.translatable("jei.aftercritical.repository.ending"));
        registration.addItemStackInfo(new ItemStack(
                        cn.blockforge.generated.aftercritical.registry.ModItems.DT_FUEL_CELL.get()),
                Component.translatable("jei.aftercritical.fusion_fuel.chain"),
                Component.translatable("jei.aftercritical.fusion_fuel.cells"));
        registration.addItemStackInfo(new ItemStack(
                        cn.blockforge.generated.aftercritical.registry.ModItems.DEUTERIUM_CELL.get()),
                Component.translatable("jei.aftercritical.fusion_fuel.deuterium"));
        registration.addItemStackInfo(new ItemStack(
                        cn.blockforge.generated.aftercritical.registry.ModItems.LITHIUM7.get()),
                Component.translatable("jei.aftercritical.fusion_fuel.lithium"));
        registration.addItemStackInfo(new ItemStack(
                        cn.blockforge.generated.aftercritical.registry.ModItems.SHORT_LIVED_ISOTOPE.get()),
                Component.translatable("jei.aftercritical.endgame.isotope"));
        registration.addItemStackInfo(new ItemStack(ModBlocks.CENTRIFUGAL_EXTRACTOR.get()),
                Component.translatable("jei.aftercritical.endgame.pollution"));

        // 武器：总装台的用途 + 每颗核弹的装配图（要哪些组件，一页看完）
        registration.addItemStackInfo(new ItemStack(ModBlocks.WARHEAD_ASSEMBLER.get()),
                Component.translatable("jei.aftercritical.warhead.assembler"));
        for (cn.blockforge.generated.aftercritical.nuke.NukeKind kind
                : cn.blockforge.generated.aftercritical.nuke.NukeKind.values()) {
            List<Component> info = new java.util.ArrayList<>();
            info.add(Component.translatable("jei.aftercritical.nuke.parts", kind.componentCount()));
            // 组件名一行排三个，免得一行太长从屏幕右边出去
            StringBuilder row = new StringBuilder();
            int inRow = 0;
            for (cn.blockforge.generated.aftercritical.nuke.NukeKind.NukeSlot slot : kind.slots()) {
                if (inRow > 0) {
                    row.append(" · ");
                }
                row.append(Component.translatable(slot.component().langKey()).getString());
                if (++inRow == 3) {
                    info.add(Component.literal(row.toString())
                            .withStyle(net.minecraft.ChatFormatting.GRAY));
                    row.setLength(0);
                    inRow = 0;
                }
            }
            if (inRow > 0) {
                info.add(Component.literal(row.toString()).withStyle(net.minecraft.ChatFormatting.GRAY));
            }
            info.add(Component.translatable("jei.aftercritical.nuke.slots")
                    .withStyle(net.minecraft.ChatFormatting.DARK_GRAY));
            net.minecraft.world.item.Item nukeItem =
                    net.minecraft.core.registries.BuiltInRegistries.ITEM.get(
                            ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, kind.itemId()));
            registration.addItemStackInfo(new ItemStack(nukeItem), info.toArray(Component[]::new));
        }
    }

    @Override
    public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
        for (MachinePage page : machinePages()) {
            registration.addRecipeCatalyst(new ItemStack(page.block()), page.jeiType());
        }
        // 一级配方 T1、T2 都做得出来，所以两个催化剂都挂在 T1 那一页；
        // 二级配方只有 T2 做得出来，就只挂 T2 自己。
        registration.addRecipeCatalyst(new ItemStack(ModBlocks.ASSEMBLER_T1.get()), ASSEMBLER);
        registration.addRecipeCatalyst(new ItemStack(ModBlocks.ASSEMBLER_T2.get()), ASSEMBLER);
        registration.addRecipeCatalyst(new ItemStack(ModBlocks.ASSEMBLER_T2.get()), ASSEMBLER_T2);
        // 三级配方只有 T3 做得出来（T2 的菜单里没有 3 级配方，但催化剂还是挂上 T3 自己）
        registration.addRecipeCatalyst(new ItemStack(ModBlocks.ASSEMBLER_T3.get()), ASSEMBLER_T3);
        for (FluidPage page : fluidPages()) {
            registration.addRecipeCatalyst(new ItemStack(page.block()), page.jeiType());
        }
        registration.addRecipeCatalyst(new ItemStack(ModBlocks.STEAM_GENERATOR.get()), STEAM_GENERATION);
        // 阶段 7：对着控制器按 U 就能看结构预览 / 嬗变换算
        registration.addRecipeCatalyst(new ItemStack(ModBlocks.TOKAMAK_CONTROLLER.get()), TOKAMAK_PREVIEW);
        registration.addRecipeCatalyst(new ItemStack(ModBlocks.TRANSMUTATOR_CONTROLLER.get()),
                TRANSMUTATOR_PREVIEW);
        registration.addRecipeCatalyst(new ItemStack(ModBlocks.TRANSMUTATOR_CONTROLLER.get()), TRANSMUTATION);
    }

    /** JEI 分页的标题就用方块自己的名字，和物品栏里看到的一致。 */
    private static Component title(Block block) {
        return Component.translatable(block.getDescriptionId());
    }

    /**
     * 把游戏里的配方原样搬进 JEI（机器和 JEI 看的是同一份数据，不会两边对不上）。
     *
     * <p>这里按「配方类型」自己筛一遍，而不是调 {@code getAllRecipesFor}：
     * 那个方法在当前这套 mappings 里是原始类型，拿不到泛型信息。
     */
    @SuppressWarnings("unchecked")
    private static <T extends Recipe<?>> void add(IRecipeRegistration registration, RecipeType<T> jeiType,
                                                  net.minecraft.world.item.crafting.RecipeType<T> vanillaType,
                                                  RecipeManager manager) {
        List<T> recipes = new ArrayList<>();
        for (Object element : manager.getRecipes()) {
            RecipeHolder<?> holder = (RecipeHolder<?>) element;
            if (holder.value().getType() == vanillaType) {
                recipes.add((T) holder.value());
            }
        }
        registration.addRecipes(jeiType, recipes);
    }

    /**
     * 把装配配方按「机器等级」搬进 JEI：{@code exactTier} 是几，就只收 JSON 里写着几级的配方。
     *
     * <p>这样「装配机 T1」那一页里再也不会出现只有 T2 做得出来的东西。
     */
    private static void add(IRecipeRegistration registration, RecipeType<AssemblerRecipe> jeiType,
                            net.minecraft.world.item.crafting.RecipeType<AssemblerRecipe> vanillaType,
                            RecipeManager manager, int exactTier) {
        List<AssemblerRecipe> recipes = new ArrayList<>();
        for (Object element : manager.getRecipes()) {
            RecipeHolder<?> holder = (RecipeHolder<?>) element;
            if (holder.value() instanceof AssemblerRecipe recipe && holder.value().getType() == vanillaType
                    && recipe.tier() == exactTier) {
                recipes.add(recipe);
            }
        }
        registration.addRecipes(jeiType, recipes);
    }
}
