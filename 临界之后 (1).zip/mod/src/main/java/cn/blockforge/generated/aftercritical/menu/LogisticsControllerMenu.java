package cn.blockforge.generated.aftercritical.menu;

import cn.blockforge.generated.aftercritical.blockentity.LogisticsControllerBlockEntity;
import cn.blockforge.generated.aftercritical.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.level.block.entity.BlockEntity;

import javax.annotation.Nullable;

/**
 * 物流控制器的界面：3×3 的九格缓冲 + 玩家背包。
 *
 * <p>底下多写一句「已连接 n 个方向」，玩家把控制器摆在管道和机器中间就知道自己接对没有。
 */
public class LogisticsControllerMenu extends AbstractMachineMenu {

    /** 九格缓冲的第一格，以及格与格之间的距离。 */
    public static final int GRID_X = 30;
    public static final int GRID_Y = 24;
    public static final int STEP = 18;
    public static final int COLUMNS = 3;

    @Nullable
    private final LogisticsControllerBlockEntity controller;

    private int connected;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return connected;
        }

        @Override
        public void set(int index, int value) {
            connected = value;
        }

        @Override
        public int getCount() {
            return 1;
        }
    };

    /** 服务端用。 */
    public LogisticsControllerMenu(int containerId, Inventory playerInventory,
                                   LogisticsControllerBlockEntity controller) {
        this(ModMenus.LOGISTICS_CONTROLLER.get(), containerId, playerInventory, controller, controller);
    }

    private LogisticsControllerMenu(MenuType<?> type, int containerId, Inventory playerInventory,
                                    Container container, @Nullable LogisticsControllerBlockEntity controller) {
        super(type, containerId, playerInventory, LogisticsControllerBlockEntity.SLOT_COUNT,
                controller, 0);
        this.controller = controller;
        for (int slot = 0; slot < LogisticsControllerBlockEntity.SLOT_COUNT; slot++) {
            this.addSlot(new Slot(container, slot,
                    GRID_X + (slot % COLUMNS) * STEP, GRID_Y + (slot / COLUMNS) * STEP));
        }
        this.addPlayerInventory(playerInventory);
        this.addDataSlots(this.data);
    }

    /** 客户端收到「打开菜单」的包后调用。 */
    public static LogisticsControllerMenu fromNetwork(int containerId, Inventory playerInventory,
                                                      RegistryFriendlyByteBuf buffer) {
        BlockPos pos = buffer.readBlockPos();
        BlockEntity blockEntity = playerInventory.player.level().getBlockEntity(pos);
        if (blockEntity instanceof LogisticsControllerBlockEntity controller) {
            return new LogisticsControllerMenu(containerId, playerInventory, controller);
        }
        return new LogisticsControllerMenu(ModMenus.LOGISTICS_CONTROLLER.get(), containerId, playerInventory,
                new SimpleContainer(LogisticsControllerBlockEntity.SLOT_COUNT), null);
    }

    @Override
    public void broadcastChanges() {
        if (this.controller != null) {
            this.connected = this.controller.getConnected();
        }
        super.broadcastChanges();
    }

    public int getConnected() {
        return this.connected;
    }
}
