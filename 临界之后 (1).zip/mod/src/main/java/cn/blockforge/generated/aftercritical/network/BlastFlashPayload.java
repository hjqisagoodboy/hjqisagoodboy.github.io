package cn.blockforge.generated.aftercritical.network;

import cn.blockforge.generated.aftercritical.AfterCritical;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * 核爆的全屏爆闪包：服务器只告诉客户端「闪多亮」，怎么闪由客户端自己画。
 *
 * <p>为什么不发一个粒子：原版 {@code FLASH} 粒子在一百格外会渲染成一个白色方块
 * （上一版就是这个问题）。白幕是客户端直接在屏幕上盖一层白，多远的形状都一样，
 * 不会随着距离变形。
 *
 * <p>亮度压成一个字节（0~255），一帧的开销可以忽略。
 *
 * @param intensity 0~1，1 是爆心正中央的纯白，越小越淡
 */
public record BlastFlashPayload(float intensity) implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<BlastFlashPayload> TYPE =
            new CustomPacketPayload.Type<>(
                    ResourceLocation.fromNamespaceAndPath(AfterCritical.MOD_ID, "blast_flash"));

    public static final StreamCodec<FriendlyByteBuf, BlastFlashPayload> STREAM_CODEC =
            StreamCodec.of(
                    (buf, payload) -> buf.writeByte(Math.round(
                            Math.max(0.0F, Math.min(1.0F, payload.intensity())) * 255.0F)),
                    buf -> new BlastFlashPayload(buf.readUnsignedByte() / 255.0F));

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
