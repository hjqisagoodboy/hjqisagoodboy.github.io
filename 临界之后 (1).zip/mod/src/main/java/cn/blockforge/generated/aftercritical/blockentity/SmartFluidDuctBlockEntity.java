package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.block.SmartFluidDuctBlock;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModFluids;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.templates.FluidTank;

import javax.annotation.Nullable;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Set;

/**
 * 智能流体管道的方块实体：一根只会搬「自己被盖章的那种流体」的管子。
 *
 * <p>和老的流体管道最大的区别是——它<b>认流体</b>：
 * <ul>
 *   <li>没盖章（刚放下）时什么都不搬，但会和挨着的机器/罐子接上，方便玩家看走向；</li>
 *   <li>用流体识别码右键盖了章之后，只从「装着这种流体」的输出口抽 100 mB/t，
 *       再顺着同样盖了这种章的管道，送进愿意收下它的输入口；</li>
 *   <li>换一种章 = 换一根管子，缓存里剩的旧流体直接倒掉，不会串味。</li>
 * </ul>
 *
 * <p>管道不耗电。缓存只有一 tick 的量（100 mB），所以拆掉管道最多损失 100 mB。
 */
public class SmartFluidDuctBlockEntity extends BlockEntity implements TickableBlockEntity {

    /** 每 tick 搬多少 mB。 */
    public static final int TRANSFER_PER_TICK = 100;
    /** 管道内部缓存，正好一 tick 的量。 */
    public static final int BUFFER_CAPACITY = TRANSFER_PER_TICK;
    /** 一张管道网最多找多少个方块，防止玩家铺上几千根管道把服务器拖死。 */
    private static final int MAX_NETWORK_SIZE = 128;
    /** 接头多久重算一次（tick）。 */
    private static final int CONNECTION_REFRESH_INTERVAL = 20;

    private static final String TAG_MARKER = "Marker";
    private static final String TAG_BUFFER = "Buffer";

    /** 内部缓存（一 tick 的量）。 */
    private final FluidTank buffer = new FluidTank(BUFFER_CAPACITY);

    /** 被识别码盖的章：只搬这种流体；{@code null} 表示还没盖章。 */
    @Nullable
    private Fluid marker;

    /** 流体是从哪一面抽来的：送货时先跳过那一面，免得刚抽出来又原样灌回去。 */
    @Nullable
    private Direction sourceDirection;

    private int refreshTimer;

    public SmartFluidDuctBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.SMART_FLUID_DUCT.get(), pos, state);
    }

    // ------------------------------------------------------------------
    // 盖章
    // ------------------------------------------------------------------

    /** 这根管道盖的是什么章；没盖章返回 {@code null}。 */
    @Nullable
    public Fluid getMarker() {
        return this.marker;
    }

    /** 是否已经盖了章（盖了章的管道才会搬东西）。 */
    public boolean isMarked() {
        return this.marker != null;
    }

    /** 两根管道是不是盖的同一个章（都没盖章不算）。 */
    public boolean isSameMarkerAs(@Nullable SmartFluidDuctBlockEntity other) {
        if (this.marker == null || other == null || other.marker == null) {
            return false;
        }
        return this.marker.isSame(other.marker);
    }

    /**
     * 盖章 / 换章 / 擦掉章。
     *
     * <p>换章时顺手把缓存倒空：不然旧流体可能被送到新的目的地，串味。
     */
    public void setMarker(@Nullable Fluid fluid) {
        if (this.marker == fluid) {
            return;
        }
        this.marker = fluid;
        this.buffer.setFluid(FluidStack.EMPTY);
        this.sourceDirection = null;
        setChanged();

        // 把章写进方块状态：状态一变，客户端才会把这一格重新烘一遍，颜色立刻更新
        BlockState state = getBlockState();
        int index = ModFluids.ductIndexOf(fluid);
        if (state.getValue(SmartFluidDuctBlock.FLUID_INDEX) != index) {
            BlockState updated = state.setValue(SmartFluidDuctBlock.FLUID_INDEX, index);
            if (this.level != null && !this.level.isClientSide) {
                this.level.setBlock(this.worldPosition, updated, Block.UPDATE_ALL);
            }
        }
        syncToClient();
        refreshConnections();
    }

    /** 告诉客户端「章换了」，管道的颜色要跟着变。 */
    private void syncToClient() {
        if (this.level != null && !this.level.isClientSide) {
            this.level.sendBlockUpdated(this.worldPosition, getBlockState(), getBlockState(), Block.UPDATE_CLIENTS);
        }
    }

    // ------------------------------------------------------------------
    // 每 tick
    // ------------------------------------------------------------------

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        if (this.marker == null) {
            // 没盖章：不搬东西，但偶尔重算一下接头（旁边放了机器要接上）
            if (++this.refreshTimer >= CONNECTION_REFRESH_INTERVAL) {
                this.refreshTimer = 0;
                refreshConnections();
            }
            return;
        }
        if (++this.refreshTimer >= CONNECTION_REFRESH_INTERVAL) {
            this.refreshTimer = 0;
            refreshConnections();
        }
        if (this.buffer.isEmpty()) {
            pull();
        }
        if (!this.buffer.isEmpty()) {
            deliver();
        }
    }

    /**
     * 从六个方向的邻居里抽 100 mB「自己这种」流体。
     *
     * <p>机器的流体接口「能抽的只有出液罐」，所以对着机器抽就是「从输出槽抽」。
     * 管道之间不互相抽：送货时再穿过整张网。
     */
    private void pull() {
        if (this.level == null || this.marker == null) {
            return;
        }
        FluidStack request = new FluidStack(this.marker, TRANSFER_PER_TICK);
        for (Direction side : Direction.values()) {
            BlockPos neighbourPos = this.worldPosition.relative(side);
            if (this.level.getBlockEntity(neighbourPos) instanceof SmartFluidDuctBlockEntity) {
                continue;
            }
            IFluidHandler handler = this.level.getCapability(
                    Capabilities.FluidHandler.BLOCK, neighbourPos, side.getOpposite());
            if (handler == null) {
                continue;
            }
            // 只问「有没有这种流体」，装了别的东西的罐子会被 drain 直接拒绝
            FluidStack probe = handler.drain(request.copy(), IFluidHandler.FluidAction.SIMULATE);
            if (probe.isEmpty()) {
                continue;
            }
            int wanted = Math.min(probe.getAmount(), this.buffer.getCapacity() - this.buffer.getFluidAmount());
            if (wanted <= 0) {
                return;
            }
            FluidStack taken = handler.drain(probe.copyWithAmount(wanted), IFluidHandler.FluidAction.EXECUTE);
            if (taken.isEmpty()) {
                continue;
            }
            this.buffer.fill(taken, IFluidHandler.FluidAction.EXECUTE);
            this.sourceDirection = side;
            setChanged();
            return;
        }
    }

    /**
     * 把管子里的流体送进「同一张网里第一个愿意收下它的方块」。
     *
     * <p>网上能走的只有盖了同样章的管道；机器的流体接口「能灌的只有进液罐」，
     * 所以送进去就是「进输入槽」。
     */
    private void deliver() {
        if (this.level == null) {
            return;
        }
        if (this.buffer.getFluid().isEmpty()) {
            return;
        }

        Deque<BlockPos> queue = new ArrayDeque<>();
        Set<BlockPos> visited = new HashSet<>();
        queue.add(this.worldPosition);
        visited.add(this.worldPosition);

        while (!queue.isEmpty() && visited.size() <= MAX_NETWORK_SIZE) {
            BlockPos ductPos = queue.poll();
            boolean origin = ductPos.equals(this.worldPosition);
            for (Direction side : Direction.values()) {
                if (origin && side == this.sourceDirection) {
                    continue;
                }
                BlockPos neighbourPos = ductPos.relative(side);
                if (this.level.getBlockEntity(neighbourPos) instanceof SmartFluidDuctBlockEntity next) {
                    if (isSameMarkerAs(next) && visited.size() < MAX_NETWORK_SIZE && visited.add(neighbourPos)) {
                        queue.add(neighbourPos);
                    }
                    continue;
                }
                IFluidHandler handler = this.level.getCapability(
                        Capabilities.FluidHandler.BLOCK, neighbourPos, side.getOpposite());
                if (handler == null) {
                    continue;
                }
                FluidStack carried = this.buffer.getFluid();
                if (carried.isEmpty()) {
                    break;
                }
                FluidStack offer = carried.copyWithAmount(
                        Math.min(carried.getAmount(), TRANSFER_PER_TICK));
                int accepted = handler.fill(offer, IFluidHandler.FluidAction.EXECUTE);
                if (accepted <= 0) {
                    continue;
                }
                this.buffer.drain(accepted, IFluidHandler.FluidAction.EXECUTE);
                setChanged();
                if (this.buffer.isEmpty()) {
                    this.sourceDirection = null;
                    return;
                }
            }
        }
    }

    /**
     * 重算六个方向的接头。
     *
     * <p>盖了章之后「谁跟谁算接上」会变，所以不光要更新自己，还要挨个通知六个邻居
     * 也重新算一遍它们的接头。
     */
    private void refreshConnections() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        BlockState state = getBlockState();
        if (!(state.getBlock() instanceof SmartFluidDuctBlock duct)) {
            return;
        }
        BlockState updated = duct.refreshConnections(this.level, this.worldPosition, state);
        for (Direction side : Direction.values()) {
            BlockPos neighbourPos = this.worldPosition.relative(side);
            BlockState neighbourState = this.level.getBlockState(neighbourPos);
            BlockState refreshed = neighbourState.updateShape(
                    side.getOpposite(), updated, this.level, neighbourPos, this.worldPosition);
            if (!refreshed.equals(neighbourState)) {
                this.level.setBlock(neighbourPos, refreshed, Block.UPDATE_ALL);
            }
        }
        if (!updated.equals(state)) {
            this.level.setBlock(this.worldPosition, updated, Block.UPDATE_ALL);
        }
    }

    // ------------------------------------------------------------------
    // 存档与同步
    // ------------------------------------------------------------------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (this.marker != null) {
            tag.putString(TAG_MARKER, BuiltInRegistries.FLUID.getKey(this.marker).toString());
        }
        tag.put(TAG_BUFFER, this.buffer.writeToNBT(registries, new CompoundTag()));
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.marker = readMarker(tag);
        if (tag.contains(TAG_BUFFER)) {
            this.buffer.readFromNBT(registries, tag.getCompound(TAG_BUFFER));
        }
    }

    /** 通道：区块加载、以及盖章后的「客户端也要知道」都靠它带上章的信息。 */
    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Nullable
    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    /** 把 NBT 里的流体名读回来；读不到就是「没盖章」。 */
    @Nullable
    private static Fluid readMarker(CompoundTag tag) {
        if (!tag.contains(TAG_MARKER)) {
            return null;
        }
        ResourceLocation id = ResourceLocation.tryParse(tag.getString(TAG_MARKER));
        if (id == null) {
            return null;
        }
        Fluid fluid = BuiltInRegistries.FLUID.get(id);
        return fluid == Fluids.EMPTY ? null : fluid;
    }
}
