package cn.blockforge.generated.aftercritical.blockentity;

import cn.blockforge.generated.aftercritical.advancement.ModAdvancementTriggers;
import cn.blockforge.generated.aftercritical.block.ResearchReactorControllerBlock;
import cn.blockforge.generated.aftercritical.menu.ResearchReactorMenu;
import cn.blockforge.generated.aftercritical.recipe.MachineRecipe;
import cn.blockforge.generated.aftercritical.registry.ModBlockEntities;
import cn.blockforge.generated.aftercritical.registry.ModBlocks;
import cn.blockforge.generated.aftercritical.registry.ModItems;
import cn.blockforge.generated.aftercritical.registry.ModRecipes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.Set;

/**
 * 研究堆控制器：阶段 4 的多方块研究堆。
 *
 * <p>和阶段 3 的两台反应堆不一样，它不算 k_eff、不会熔毁、不烧硼酸——
 * 这是一台低功率、稳定运行的「照射装置」：插上燃料和控制棒，
 * 把靶材放进辐照孔道，等 10~20 分钟，靶材就变成带放射性的辐照靶，
 * 再拿去冷却池泡 5 分钟水，才能得到能用的同位素。
 *
 * <p>结构：7 宽 × 8 高 × 7 深，控制器贴在正面墙、贴地那一排的正中间，
 * 方块朝哪结构就往哪长（和阶段 3 的规则一模一样）。
 *
 * <p>槽位（16 个）：
 * <pre>
 *   0~3   燃料槽：低浓缩铀燃料组件，至少放 4 支
 *   4~7   控制棒槽：控制棒组件，至少插 4 支
 *   8~11  辐照孔道槽：放靶材，一次照一个
 *   12~15 产物槽：辐照完的靶
 * </pre>
 */
public class ResearchReactorControllerBlockEntity extends MachineBlockEntity {

    // ------------------------------------------------------------------
    // 结构尺寸与要求（最终定稿 v4 第 2 步）
    // ------------------------------------------------------------------

    /** 结构宽（左右各伸出 3 格）。 */
    public static final int SIZE_W = 7;
    /** 结构深（往朝向方向伸 7 格）。 */
    public static final int SIZE_D = 7;
    /** 结构高（往上 8 格）。 */
    public static final int SIZE_H = 8;

    /** 至少多少块石墨慢化剂。 */
    public static final int MIN_GRAPHITE = 64;
    /** 至少多少块反射层。 */
    public static final int MIN_REFLECTOR = 24;
    /** 至少多少块铅屏蔽。 */
    public static final int MIN_SHIELD = 64;
    /** 至少几条辐照孔道。 */
    public static final int MIN_CHANNELS = 4;
    /** 至少几个中子探测器。 */
    public static final int MIN_DETECTORS = 4;
    /** 池子里至少多少格水（一层 7×7 是 49 格，这里放宽到 16 格，摆得随意点也能过）。 */
    public static final int MIN_WATER = 16;
    /** 至少几支低浓缩铀燃料组件。 */
    public static final int MIN_FUEL = 4;
    /** 至少几支控制棒组件。 */
    public static final int MIN_RODS = 4;

    /** 额定耗电：100 FE/t，稳定运行不波动。 */
    public static final int ENERGY_PER_TICK = 100;

    /** 结构每 2 秒重查一次。 */
    public static final int VALIDATE_INTERVAL = 40;

    // ------------------------------------------------------------------
    // 槽位
    // ------------------------------------------------------------------

    public static final int FUEL_SLOTS = 4;
    public static final int ROD_SLOTS = 4;
    public static final int CHANNEL_SLOTS = 4;
    public static final int OUTPUT_SLOTS = 4;

    public static final int SLOT_FUEL_FIRST = 0;
    public static final int SLOT_ROD_FIRST = SLOT_FUEL_FIRST + FUEL_SLOTS;
    public static final int SLOT_CHANNEL_FIRST = SLOT_ROD_FIRST + ROD_SLOTS;
    public static final int SLOT_OUTPUT_FIRST = SLOT_CHANNEL_FIRST + CHANNEL_SLOTS;
    public static final int SLOT_COUNT = SLOT_OUTPUT_FIRST + OUTPUT_SLOTS;

    /** 能放进辐照孔道的 7 种靶材。 */
    public static final Set<Item> TARGETS = Set.of(
            ModItems.COBALT59_TARGET.get(), ModItems.LITHIUM6_TARGET.get(),
            ModItems.URANIUM238_TARGET.get(), ModItems.CESIUM133_TARGET.get(),
            ModItems.STRONTIUM88_TARGET.get(), ModItems.PLUTONIUM239_TARGET.get(),
            ModItems.SILICON30_TARGET.get());

    private static final int[] CHANNEL_SLOT_IDS = {
            SLOT_CHANNEL_FIRST, SLOT_CHANNEL_FIRST + 1, SLOT_CHANNEL_FIRST + 2, SLOT_CHANNEL_FIRST + 3};
    private static final int[] OUTPUT_SLOT_IDS = {
            SLOT_OUTPUT_FIRST, SLOT_OUTPUT_FIRST + 1, SLOT_OUTPUT_FIRST + 2, SLOT_OUTPUT_FIRST + 3};

    // ------------------------------------------------------------------
    // 状态
    // ------------------------------------------------------------------

    private boolean formed;
    private int graphite;
    private int reflector;
    private int shield;
    private int channels;
    private int detectors;
    private int water;
    private int validateTimer;

    /** 成就「研究堆开工」只记一次。 */
    private boolean irradiationMilestoneFired;

    public ResearchReactorControllerBlockEntity(BlockPos pos, BlockState state) {
        this(ModBlockEntities.RESEARCH_REACTOR.get(), pos, state);
    }

    protected ResearchReactorControllerBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state, SLOT_COUNT, ENERGY_PER_TICK);
    }

    // ------------------------------------------------------------------
    // MachineBlockEntity 要回答的问题
    // ------------------------------------------------------------------

    @Override
    protected int[] inputSlots() {
        return CHANNEL_SLOT_IDS;
    }

    @Override
    protected int[] outputSlots() {
        return OUTPUT_SLOT_IDS;
    }

    @Override
    protected RecipeType<MachineRecipe> recipeType() {
        return ModRecipes.IRRADIATION;
    }

    /**
     * 只有在「结构完整 + 燃料够 + 控制棒够」的时候才允许照射。
     *
     * <p>结构一拆，配方立刻作废，进度自动清零，不会出现「堆都拆了还在出同位素」。
     */
    @Override
    protected boolean isRecipeUsable(MachineRecipe recipe) {
        return this.formed && fuelCount() >= MIN_FUEL && rodCount() >= MIN_RODS;
    }

    @Override
    public void serverTick() {
        if (this.level == null || this.level.isClientSide) {
            return;
        }
        if (--this.validateTimer <= 0) {
            this.validateTimer = VALIDATE_INTERVAL;
            validateStructure();
        }
        super.serverTick();

        // 第一次真的开始照靶材：成就「研究堆开工」
        if (!this.irradiationMilestoneFired && isFormed() && isRunning()) {
            this.irradiationMilestoneFired = true;
            ModAdvancementTriggers.fireNearby(this.level, this.worldPosition, 48.0,
                    ModAdvancementTriggers.RESEARCH_IRRADIATION);
        }
    }

    // ------------------------------------------------------------------
    // 结构检测
    // ------------------------------------------------------------------

    /** 有空的时候立刻重查一遍结构（放方块、拆方块时调用）。 */
    public void validateSoon() {
        this.validateTimer = 1;
    }

    /**
     * 数一遍 7×8×7 的区域：石墨慢化剂、反射层、铅屏蔽、辐照孔道、中子探测器、水。
     */
    public void validateStructure() {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        Direction facing = facing();
        int px = facing.getStepZ();
        int pz = -facing.getStepX();
        int radius = (SIZE_W - 1) / 2;

        int graphiteCount = 0;
        int reflectorCount = 0;
        int shieldCount = 0;
        int channelCount = 0;
        int detectorCount = 0;
        int waterCount = 0;
        boolean complete = true;

        for (int depth = 0; depth < SIZE_D && complete; depth++) {
            for (int side = -radius; side <= radius && complete; side++) {
                for (int up = 0; up < SIZE_H && complete; up++) {
                    BlockPos pos = this.worldPosition.offset(
                            facing.getStepX() * depth + px * side, up, facing.getStepZ() * depth + pz * side);
                    if (!server.isLoaded(pos)) {
                        complete = false;
                        break;
                    }
                    if (pos.equals(this.worldPosition)) {
                        continue;
                    }
                    BlockState state = server.getBlockState(pos);
                    Block block = state.getBlock();
                    if (block == ModBlocks.GRAPHITE_MODERATOR.get()) {
                        graphiteCount++;
                    } else if (block == ModBlocks.BERYLLIUM_REFLECTOR.get()) {
                        reflectorCount++;
                    } else if (block == ModBlocks.RADIATION_SHIELD.get()) {
                        shieldCount++;
                    } else if (block == ModBlocks.IRRADIATION_CHANNEL.get()) {
                        channelCount++;
                    } else if (block == ModBlocks.NEUTRON_DETECTOR.get()) {
                        detectorCount++;
                    } else if (state.is(Blocks.WATER)) {
                        waterCount++;
                    }
                }
            }
        }

        boolean nowFormed = complete
                && graphiteCount >= MIN_GRAPHITE
                && reflectorCount >= MIN_REFLECTOR
                && shieldCount >= MIN_SHIELD
                && channelCount >= MIN_CHANNELS
                && detectorCount >= MIN_DETECTORS
                && waterCount >= MIN_WATER;

        if (nowFormed != this.formed || graphiteCount != this.graphite || reflectorCount != this.reflector
                || shieldCount != this.shield || channelCount != this.channels
                || detectorCount != this.detectors || waterCount != this.water) {
            this.formed = nowFormed;
            this.graphite = graphiteCount;
            this.reflector = reflectorCount;
            this.shield = shieldCount;
            this.channels = channelCount;
            this.detectors = detectorCount;
            this.water = waterCount;
            setChanged();
        }
    }

    /** 方块朝哪，结构就往哪长。 */
    private Direction facing() {
        BlockState state = getBlockState();
        if (state.hasProperty(ResearchReactorControllerBlock.FACING)) {
            return state.getValue(ResearchReactorControllerBlock.FACING);
        }
        return Direction.NORTH;
    }

    // ------------------------------------------------------------------
    // GUI 读数
    // ------------------------------------------------------------------

    public boolean isFormed() {
        return this.formed;
    }

    public int graphiteCount() {
        return this.graphite;
    }

    public int reflectorCount() {
        return this.reflector;
    }

    public int shieldCount() {
        return this.shield;
    }

    public int channelBlockCount() {
        return this.channels;
    }

    public int detectorCount() {
        return this.detectors;
    }

    public int waterCount() {
        return this.water;
    }

    /** 燃料槽里有几支燃料组件（按数量算，堆叠也算）。 */
    public int fuelCount() {
        int total = 0;
        for (int i = 0; i < FUEL_SLOTS; i++) {
            ItemStack stack = getItem(SLOT_FUEL_FIRST + i);
            if (stack.is(ModItems.LEU_FUEL_ASSEMBLY.get())) {
                total += stack.getCount();
            }
        }
        return total;
    }

    /** 控制棒槽里有几支控制棒组件。 */
    public int rodCount() {
        int total = 0;
        for (int i = 0; i < ROD_SLOTS; i++) {
            ItemStack stack = getItem(SLOT_ROD_FIRST + i);
            if (stack.is(ModItems.CONTROL_ROD.get())) {
                total += stack.getCount();
            }
        }
        return total;
    }

    // ------------------------------------------------------------------
    // 槽位规则
    // ------------------------------------------------------------------

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        if (slot >= SLOT_OUTPUT_FIRST) {
            return false;
        }
        if (slot >= SLOT_CHANNEL_FIRST) {
            return TARGETS.contains(stack.getItem());
        }
        if (slot >= SLOT_ROD_FIRST) {
            return stack.is(ModItems.CONTROL_ROD.get());
        }
        if (slot >= SLOT_FUEL_FIRST) {
            return stack.is(ModItems.LEU_FUEL_ASSEMBLY.get());
        }
        return true;
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.aftercritical.research_reactor");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new ResearchReactorMenu(containerId, playerInventory, this);
    }

}
