package cn.blockforge.generated.aftercritical.compat.jei;

import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.widgets.IRecipeExtrasBuilder;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

/**
 * 物质嬗变在 JEI 里的样子。
 *
 * <p>嬗变不是 JSON 配方（要一次性吃 1,000,000 FE，配方系统表达不了这个），
 * 所以这里给 JEI 塞一条固定的展示条目：左边一个锕系元素，右边一个短寿命同位素，
 * 底下写清楚能量和耗时。玩家对着物质嬗变器按 U 就能看到。
 */
public class TransmutationRecipeCategory implements IRecipeCategory<TransmutationRecipeCategory.Entry> {

    /** JEI 里展示的一条固定条目。 */
    public record Entry(ItemStack input, ItemStack output, int fe, int seconds) {
    }

    private static final int WIDTH = 150;
    private static final int HEIGHT = 64;
    private static final int SLOT = 18;

    private final RecipeType<Entry> recipeType;
    private final Component title;
    private final IDrawable icon;

    public TransmutationRecipeCategory(IGuiHelper guiHelper, RecipeType<Entry> recipeType,
                                       Component title, Block iconBlock) {
        this.recipeType = recipeType;
        this.title = title;
        this.icon = guiHelper.createDrawableItemLike(iconBlock);
    }

    @Override
    public RecipeType<Entry> getRecipeType() {
        return this.recipeType;
    }

    @Override
    public Component getTitle() {
        return this.title;
    }

    @Override
    public IDrawable getIcon() {
        return this.icon;
    }

    @Override
    public int getWidth() {
        return WIDTH;
    }

    @Override
    public int getHeight() {
        return HEIGHT;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, Entry recipe, IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 8, 8).addItemStack(recipe.input());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 104, 8).addItemStack(recipe.output());
    }

    @Override
    public void createRecipeExtras(IRecipeExtrasBuilder builder, Entry recipe, IFocusGroup focuses) {
        builder.addRecipeArrow().setPosition(46, 8);
        builder.addText(Component.translatable("jei.aftercritical.transmutation.line",
                recipe.fe(), recipe.seconds()), 8, 32);
        builder.addText(Component.translatable("jei.aftercritical.transmutation.note"), 8, 46);
    }
}
