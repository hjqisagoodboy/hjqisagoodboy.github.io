package cn.blockforge.generated.aftercritical.energy;

import cn.blockforge.generated.aftercritical.blockentity.EnergyPortBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 「无线供电网」：托卡马克 → 能量端口的登记簿。
 *
 * <p>如果每 tick 让托卡马克把 256 格内的方块挨个查一遍，一个 9×9×9 的堆能把服务器拖死。
 * 所以反过来做：能量端口放下（区块加载）时到这里报个到，拆掉 / 卸载时销号；
 * 托卡马克每 tick 只在这个小名单里找「同维度、距离 ≤ 256 格」的端口。
 *
 * <p>名单按维度分开存，所以跨维度的端口永远不会被误连——正好符合「同维度」这条规则。
 */
public final class WirelessEnergyGrid {

    /** 每个维度一份端口名单。用 {@link ResourceKey} 做键，跨维度天然隔开。 */
    private static final Map<ResourceKey<Level>, List<EnergyPortBlockEntity>> PORTS = new HashMap<>();

    private WirelessEnergyGrid() {}

    /** 端口放下 / 区块加载时登记。 */
    public static void register(EnergyPortBlockEntity port) {
        Level level = port.getLevel();
        if (level == null || level.isClientSide) {
            return;
        }
        List<EnergyPortBlockEntity> list = PORTS.computeIfAbsent(level.dimension(), key -> new ArrayList<>());
        if (!list.contains(port)) {
            list.add(port);
        }
    }

    /** 端口被拆 / 区块卸载时销号。 */
    public static void unregister(EnergyPortBlockEntity port) {
        Level level = port.getLevel();
        if (level == null) {
            return;
        }
        List<EnergyPortBlockEntity> list = PORTS.get(level.dimension());
        if (list == null) {
            return;
        }
        list.remove(port);
        if (list.isEmpty()) {
            PORTS.remove(level.dimension());
        }
    }

    /**
     * 找出同维度、以 {@code from} 为圆心、半径 {@code range} 格以内的所有端口。
     *
     * <p>顺手把已经失效的方块实体从名单里剔掉（区块卸载时方块实体的 setRemoved 不一定会跑）。
     */
    public static List<EnergyPortBlockEntity> portsInRange(Level level, BlockPos from, int range) {
        List<EnergyPortBlockEntity> result = new ArrayList<>();
        List<EnergyPortBlockEntity> list = PORTS.get(level.dimension());
        if (list == null) {
            return result;
        }
        long rangeSq = (long) range * range;
        Iterator<EnergyPortBlockEntity> iterator = list.iterator();
        while (iterator.hasNext()) {
            EnergyPortBlockEntity port = iterator.next();
            if (port.isRemoved() || port.getLevel() != level) {
                iterator.remove();
                continue;
            }
            if (port.getBlockPos().distSqr(from) <= rangeSq) {
                result.add(port);
            }
        }
        if (list.isEmpty()) {
            PORTS.remove(level.dimension());
        }
        return result;
    }

    /** 服务器关掉时清空名单，免得下一次进存档还惦记着上一局的方块实体。 */
    public static void clearAll() {
        PORTS.clear();
    }
}
