package cn.blockforge.generated.aftercritical.block;

import cn.blockforge.generated.aftercritical.world.ScorchedHeatData;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * 焦土 / 辐射焦土：核爆把地表烧成的一层黑壳，炸完还烫一阵子。
 *
 * <p>热的是「地」不是火：只要脚踩在上面，就一直着火，离开以后还要再烧几秒才灭。
 * 辐射焦土烧得更久，而且每隔一会儿额外补一点烧伤——光靠着火烫不死站着不动的人。
 *
 * <p>但它<b>只在炸完的头 10 分钟里烫</b>。冷却不是写在方块上的（方块状态存不下时间戳，
 * 也不想给几万块焦土各挂一个方块实体），而是由爆炸那边记的「热区」说了算，
 * 见 {@link ScorchedHeatData}。所以：
 * <ul>
 *   <li>炸完 10 分钟内踩上去 → 着火，跟在岩浆块上一个路子；</li>
 *   <li>10 分钟以后再踩 → 一块凉透的黑壳，什么都不发生；</li>
 *   <li>玩家自己拿焦土摆的、或者上一版存档里早就炸出来的焦土 → 没有热区，也是凉的。</li>
 * </ul>
 *
 * <p>被烫的不只是玩家：羊、僵尸、骷髅踩上来一样着火，只有本来就免疫火焰的生物
 * （下界那些）不受影响。这个效果不需要额外的 tick 事件，靠方块自己的
 * {@link #stepOn} 就能每 tick 触发，跟原版岩浆块是一个路子。
 */
public class ScorchedEarthBlock extends Block {

    /** 站上去以后持续烧几秒（离开焦土后也是这个数慢慢烧完）。 */
    private final int fireSeconds;
    /** 每隔多少 tick 额外补 1 点烧伤；0 表示只着火、不额外扣血。 */
    private final int burnInterval;

    public ScorchedEarthBlock(Properties properties, int fireSeconds) {
        this(properties, fireSeconds, 0);
    }

    public ScorchedEarthBlock(Properties properties, int fireSeconds, int burnInterval) {
        super(properties);
        this.fireSeconds = fireSeconds;
        this.burnInterval = burnInterval;
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        // 凉透的焦土跟普通泥土没两样：先看这一发爆炸的热区还在不在，不在就直接走人
        if (!level.isClientSide && level instanceof ServerLevel serverLevel
                && entity instanceof LivingEntity living && !living.fireImmune()
                && ScorchedHeatData.isHot(serverLevel, pos)) {
            living.setRemainingFireTicks(Math.max(living.getRemainingFireTicks(), this.fireSeconds * 20));
            // 辐射焦土温度更高：隔一会儿再补一点烧伤，不然光着火打不动站着的人
            if (this.burnInterval > 0 && level.getGameTime() % this.burnInterval == 0) {
                living.hurt(level.damageSources().hotFloor(), 1.0F);
            }
        }
        super.stepOn(level, pos, state, entity);
    }
}
