package cn.blockforge.generated.aftercritical.block;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

import java.util.List;

/**
 * 中子探测器：放在反应堆结构里，把当前中子通量变成红石信号（0~15）。
 *
 * <p>它自己不会算物理，值由控制器每 tick 写进方块状态里（{@code power} 属性）。
 * 通量按「数量级」对应信号强度：通量 1000 大概 6 格，一百万满格 15 格——
 * 这样红石灯、报警器、门这些东西都能直接接上去。
 *
 * <p>哪一格是探测器，是控制器扫描结构时记下来的；信号能不能变化也由控制器决定，
 * 所以探测器单独放着不会乱发信号。
 */
public class NeutronDetectorBlock extends Block {

    /** 0~15 的红石强度，和红石粉的 power 是同一个属性对象。 */
    public static final IntegerProperty POWER = BlockStateProperties.POWER;

    public NeutronDetectorBlock(Properties properties) {
        super(properties);
        registerDefaultState(defaultBlockState().setValue(POWER, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(POWER);
    }

    @Override
    protected boolean isSignalSource(BlockState state) {
        return true;
    }

    /** 朝任意方向的信号强度都是当前通量换算出来的值。 */
    @Override
    protected int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction) {
        return state.getValue(POWER);
    }

    /** 比较器读出来的模拟信号和红石强度一致。 */
    @Override
    protected int getAnalogOutputSignal(BlockState state, Level level, BlockPos pos) {
        return state.getValue(POWER);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
                                TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.aftercritical.neutron_detector.signal")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.aftercritical.neutron_detector.place")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
